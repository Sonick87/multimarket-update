"""멀티마켓 매니저 실행 파일. 사용법: main.py [--port 8765] [--host 0.0.0.0] [--no-browser]"""
import argparse, socket, sys, threading, webbrowser, os
import importlib.machinery

LAUNCHER = 2   # exe 껍데기 버전. 이 숫자가 바뀔 때만 exe를 새로 만들어야 함

def use_code_dir():
    """exe 옆 code\app 폴더가 있으면 exe 안의 프로그램 대신 그걸 씀(자동 업데이트는 이 폴더만 바꿈)"""
    if not getattr(sys, "frozen", False):
        return None
    code = os.path.join(os.path.dirname(sys.executable), "code")
    if not os.path.isfile(os.path.join(code, "app", "__init__.py")):
        return None
    class CodeFinder:
        def find_spec(self, name, path=None, target=None):
            if name == "app":
                return importlib.machinery.PathFinder.find_spec(name, [code])
            if name.startswith("app."):
                return importlib.machinery.PathFinder.find_spec(name, path)
            return None
    sys.meta_path.insert(0, CodeFinder())
    return code

def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.connect(("8.8.8.8", 80)); ip = s.getsockname()[0]; s.close(); return ip
    except OSError:
        return "127.0.0.1"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=int(os.environ.get("MM_PORT", 8765)))
    ap.add_argument("--host", default=os.environ.get("MM_HOST", "0.0.0.0"))
    ap.add_argument("--no-browser", action="store_true")
    a = ap.parse_args()
    code = use_code_dir()
    try:
        from app import updater, VERSION
    except Exception as ex:   # 받은 코드가 깨졌으면 exe 안의 원래 버전으로
        print(f"  업데이트된 코드를 읽지 못해 기본 버전으로 켭니다: {ex}")
        if code:
            import shutil
            shutil.move(code, code + "_broken")
        os.execv(sys.executable, [sys.executable] + sys.argv[1:])
    os.environ["MM_LAUNCHER"] = str(LAUNCHER)
    print(f" 멀티마켓 매니저 {VERSION} · 업데이트 확인 중…")
    updater.startup()
    from app.server import serve
    from app.paths import DATA
    srv = serve(a.host, a.port)
    print("=" * 56)
    print(" 멀티마켓 매니저 실행 중")
    print(f"  이 PC에서:      http://localhost:{a.port}")
    print(f"  팀원 PC·폰에서: http://{lan_ip()}:{a.port}  (같은 와이파이)")
    print(f"  데이터 폴더:    {DATA}")
    print("  끄려면 이 창을 닫으세요.")
    print("=" * 56)
    if not a.no_browser and sys.platform == "win32":
        threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{a.port}")).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    main()
