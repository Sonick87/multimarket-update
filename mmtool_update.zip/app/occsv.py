"""도매매·공급처에서 내려받은 상품 CSV/엑셀 읽기.
열 이름이 조금 달라도 찾도록 여러 이름을 봅니다. 못 찾으면 값 모양(W로 시작하는 코드, 그림 주소)으로 찾습니다."""
import csv, io, re
from . import xlsx

COLS = {
    "key": ["상품코드", "오너클랜상품코드", "오너클랜 상품코드", "상품번호", "selfcode", "product code", "code"],
    "name": ["마켓상품명", "상품명", "원본상품명", "원상품명", "오너클랜상품명", "product name", "name"],
    "price": ["오너클랜판매가", "오너클랜 판매가", "공급가", "도매가", "판매사공급가", "구매가", "공급단가", "판매가", "가격", "price"],
    "fixed": ["소비자준수가", "소비자가", "권장소비자가", "권장판매가", "시중가", "정가"],
    "ship": ["배송비", "기본배송비", "배송비용"],
    "stock": ["재고수량", "재고", "수량", "stock"],
    "ship_type": ["배송유형", "배송비유형", "배송방법"],
    "mcat": ["마켓카테고리"], "catcode": ["카테고리코드"],
    "status": ["판매상태", "상품상태", "상태"],
    "option": ["옵션", "옵션정보", "옵션내용", "조합형옵션", "옵션1값", "옵션값"],
    "image": ["대표이미지", "이미지", "이미지(대)", "기본이미지", "메인이미지", "상품이미지", "image"],
    "images2": ["추가이미지", "부가이미지", "이미지(추가)"],
    "detail": ["상세설명", "상세정보", "상세페이지", "상품상세", "상세", "description"],
    "category": ["카테고리명", "카테고리", "분류"],
    "keyword": ["키워드", "검색어", "태그"],
    "origin": ["원산지"], "maker": ["제조사"], "brand": ["브랜드"], "model": ["모델명"],
}
BAD_PRICE = ("소비자", "권장", "시중", "정가", "배송", "반품")

def decode(data):
    for enc in ("utf-8-sig", "cp949", "euc-kr"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", "replace")

def rows_of(filename, data):
    if filename.lower().endswith((".xlsx", ".xlsm")):
        sheets = xlsx.read(io.BytesIO(data))
        return max(sheets.values(), key=len) if sheets else []
    text = decode(data)
    dialect = csv.excel_tab if text.count("\t") > text.count(",") else csv.excel
    return [r for r in csv.reader(io.StringIO(text), dialect)]

def _norm(s):
    return re.sub(r"[\s_()\[\]·/-]", "", str(s or "")).lower()

def _find_header(rows):
    best, bi = 0, 0
    for i, r in enumerate(rows[:15]):
        cells = {_norm(c) for c in r}
        score = sum(1 for names in COLS.values() for n in names if _norm(n) in cells)
        if score > best:
            best, bi = score, i
    return bi

def _col(hdr, names, used, bad=()):
    nh = [_norm(h) for h in hdr]
    for n in names:                       # 똑같은 이름 먼저
        if _norm(n) in nh:
            i = nh.index(_norm(n))
            if i not in used and not any(b in hdr[i] for b in bad):
                return i
    for n in names:                       # 이름이 들어 있는 열
        for i, h in enumerate(nh):
            if i not in used and _norm(n) in h and not any(b in hdr[i] for b in bad):
                return i
    return None

def num(v):
    s = re.sub(r"[^\d.\-]", "", str(v or ""))
    try:
        return float(s) if s not in ("", "-", ".") else None
    except ValueError:
        return None

def parse(filename, data):
    """→ (상품 목록, 찾은 열 설명). 상품: key,name,price,fixed,ship,stock,soldout,option,images,detail,category,keyword"""
    rows = rows_of(filename, data)
    if not rows:
        return [], "빈 파일"
    hi = _find_header(rows)
    hdr = [str(c or "").strip() for c in rows[hi]]
    body = [r for r in rows[hi + 1:] if any(str(c or "").strip() for c in r)]
    idx, used = {}, set()
    BAD = {"price": BAD_PRICE, "stock": ("구매", "최소", "최대"), "option": ("명",), "ship": ("반품", "유형", "교환"), "category": ("코드", "마켓"), "name": ("옵션",)}
    for k in ("key", "name", "fixed", "price", "ship_type", "ship", "stock", "status", "option", "image", "images2", "detail", "mcat", "catcode", "category", "keyword", "origin", "maker", "brand", "model"):
        i = _col(hdr, COLS[k], used, BAD.get(k, ()))
        if k == "name" and i is not None and any(b in hdr[i] for b in ("옵션",)):
            i = None
        idx[k] = i
        if i is not None:
            used.add(i)
    sample = body[:30]
    col = lambda i: [str(r[i]).strip() if i < len(r) else "" for r in sample]
    if idx["key"] is None:                # W1234567 같은 값이 있는 열
        for i in range(len(hdr)):
            if i not in used and sum(bool(re.fullmatch(r"W\d{5,}", v)) for v in col(i)) >= max(1, len(sample) // 2):
                idx["key"] = i; used.add(i); break
    if idx["image"] is None:
        for i in range(len(hdr)):
            if i not in used and sum(bool(re.match(r"https?://\S+\.(jpe?g|png|gif|webp)", v, re.I)) for v in col(i)) >= max(1, len(sample) // 2):
                idx["image"] = i; used.add(i); break
    if idx["detail"] is None:
        for i in range(len(hdr)):
            if i not in used and sum("<img" in v.lower() for v in col(i)) >= max(1, len(sample) // 3):
                idx["detail"] = i; used.add(i); break
    get = lambda r, k: (str(r[idx[k]]).strip() if idx[k] is not None and idx[k] < len(r) and r[idx[k]] is not None else "")
    items = []
    for n, r in enumerate(body):
        name = get(r, "name")
        if not name:
            continue
        key = get(r, "key").upper() or f"CSV{n + 1}"
        imgs = [u for u in re.split(r"[\s,|;]+", get(r, "image") + " " + get(r, "images2")) if u.startswith("http")]
        cats = {}
        for line in get(r, "mcat").splitlines():   # 예: storefarm,50001794,생활/건강>...
            parts = line.split(",")
            if len(parts) >= 2 and parts[1].strip():
                cats[parts[0].strip().lower()] = parts[1].strip()
        if get(r, "catcode").isdigit():
            cats.setdefault("storefarm", get(r, "catcode"))
        ship = num(get(r, "ship"))
        if "무료" in get(r, "ship_type"):
            ship = 0.0
        fixed = num(get(r, "fixed"))
        st = get(r, "status")
        stock = num(get(r, "stock"))
        soldout = (bool(st) and any(w in st for w in ("품절", "중지", "종료", "불가"))) or (stock is not None and stock <= 0 and idx["stock"] is not None)
        items.append({"key": key, "name": name, "price": num(get(r, "price")) or 0, "fixed": fixed or None, "ship": ship,
                      "cats": {"naver": cats.get("storefarm") or cats.get("smartstore") or "", "coupang": cats.get("coupang", ""), "esm": cats.get("gmarket") or cats.get("auction") or ""},
                      "stock": int(stock) if stock is not None else 99, "soldout": soldout, "option": get(r, "option")[:200],
                      "images": list(dict.fromkeys(imgs))[:10], "detail": get(r, "detail"), "category": get(r, "category"),
                      "keyword": get(r, "keyword")[:100],
                      "info": {k: get(r, k) for k in ("origin", "maker", "brand", "model") if get(r, k)}})
    found = ", ".join(f"{k}={hdr[i]}" for k, i in idx.items() if i is not None and i < len(hdr))
    return items, found
