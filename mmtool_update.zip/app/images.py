"""상품 사진 자동 수집. 상품의 이미지 주소·소싱 링크·도매매 상품에서 사진을 찾아 내려받아 data/images 에 저장합니다.
가공(흰 배경 정사각형·여백 자르기·밝기 보정)은 브라우저에서 합니다(ui.py 의 IMG_JS). 그래서 추가 설치가 필요 없습니다."""
import html, json, os, re, struct, uuid, urllib.request, urllib.error
from urllib.parse import urljoin, urlparse
from .paths import IMAGES

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0 Safari/537.36"
MAX_BYTES = 15 * 1024 * 1024
MIN_SIDE = 300          # 이보다 작은 사진(아이콘·썸네일)은 버림
MAX_PICK = 10           # 소싱 페이지에서 가져올 최대 장수
SKIP = re.compile(r"logo|icon|sprite|avatar|blank|loading|placeholder|noimage|qrcode|banner_|/static/|//static\.|/enimages/|/shop_set/|\.gif($|\?)", re.I)

def _get(url, referer=None, limit=MAX_BYTES, timeout=25):
    h = {"User-Agent": UA, "Accept": "*/*", "Accept-Language": "ko,en;q=0.8,zh;q=0.6"}
    if referer:
        h["Referer"] = referer
    req = urllib.request.Request(url, headers=h)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
        if len(data) > limit:
            raise ValueError("파일이 너무 큽니다")
        return data, (r.headers.get("Content-Type") or "").lower()

def dims(b):
    """JPEG·PNG·GIF·WEBP 가로세로(픽셀). 모르면 None"""
    try:
        if b[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", b[16:24])
        if b[:6] in (b"GIF87a", b"GIF89a"):
            return struct.unpack("<HH", b[6:10])
        if b[:4] == b"RIFF" and b[8:12] == b"WEBP":
            k = b[12:16]
            if k == b"VP8X":
                return 1 + int.from_bytes(b[24:27], "little"), 1 + int.from_bytes(b[27:30], "little")
            if k == b"VP8 ":
                w, h = struct.unpack("<HH", b[26:30]); return w & 0x3FFF, h & 0x3FFF
            if k == b"VP8L":
                v = int.from_bytes(b[21:25], "little"); return (v & 0x3FFF) + 1, ((v >> 14) & 0x3FFF) + 1
        if b[:2] == b"\xff\xd8":
            i = 2
            while i < len(b) - 9:
                if b[i] != 0xFF:
                    i += 1; continue
                m = b[i + 1]
                if m in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    h, w = struct.unpack(">HH", b[i + 5:i + 9]); return w, h
                if m in (0xD8, 0x01) or 0xD0 <= m <= 0xD7:
                    i += 2; continue
                i += 2 + struct.unpack(">H", b[i + 2:i + 4])[0]
    except Exception:
        pass
    return None

def ext_of(b, ctype=""):
    if b[:8] == b"\x89PNG\r\n\x1a\n": return ".png"
    if b[:4] == b"RIFF" and b[8:12] == b"WEBP": return ".webp"
    if b[:6] in (b"GIF87a", b"GIF89a"): return ".gif"
    if b[:2] == b"\xff\xd8": return ".jpg"
    return None

def clean_url(u, base=None):
    u = html.unescape((u or "").strip()).replace("\\/", "/")
    if u.startswith("//"):
        u = "https:" + u
    if base and not u.startswith("http"):
        u = urljoin(base, u)
    # 1688·알리·이우고 썸네일 꼬리표 떼고 원본 크기로: a.jpg_220x220.jpg → a.jpg, a.jpg_.webp → a.jpg
    u = re.sub(r"(\.(?:jpe?g|png|webp))(?:_\d+x\d+[^/?#]*|_\.webp|\.\d+x\d+\.[a-z]+)$", r"\1", u, flags=re.I)
    u = re.sub(r"\?x-oss-process=.*$", "", u)
    return u

def save_bytes(pid, b):
    ext = ext_of(b)
    if not ext:
        return None
    name = f"p{pid}_{uuid.uuid4().hex[:8]}{ext}"
    with open(os.path.join(IMAGES, name), "wb") as f:
        f.write(b)
    return name

def download(pid, url, referer=None, min_side=0):
    """사진 하나 내려받아 저장. (파일이름, 사유)"""
    try:
        b, ct = _get(url, referer)
    except Exception as ex:
        return None, f"내려받기 실패: {ex}"
    if not ext_of(b):
        return None, "사진 파일이 아님"
    d = dims(b)
    if min_side and d and min(d) < min_side:
        return None, f"너무 작음({d[0]}×{d[1]})"
    return save_bytes(pid, b), ""

def imgs_in_html(text, base=None):
    """HTML에서 사진 주소 찾기: og:image 먼저, 그다음 img 태그·스크립트 안의 주소"""
    text = text or ""
    out = []
    for m in re.finditer(r'<meta[^>]+(?:property|name)=["\'](?:og:image|twitter:image)[^"\']*["\'][^>]*>', text, re.I):
        c = re.search(r'content=["\']([^"\']+)', m.group(0))
        if c:
            out.append(c.group(1))
    for m in re.finditer(r'<img[^>]+>', text, re.I):
        tag = m.group(0)
        for attr in ("data-original", "data-src", "data-lazy-src", "data-img", "src"):
            c = re.search(attr + r'=["\']([^"\']+)', tag, re.I)
            if c and not c.group(1).startswith("data:"):
                out.append(c.group(1)); break
    for m in re.finditer(r'(?:https?:)?\\?/\\?/[^"\'\s<>()]+?\.(?:jpe?g|png|webp)(?:_[^"\'\s<>()]*)?', text, re.I):
        out.append(m.group(0))
    seen, res = set(), []
    for u in out:
        u = clean_url(u, base)
        if not u.startswith("http") or SKIP.search(u) or u in seen:
            continue
        seen.add(u); res.append(u)
    return res

def from_page(pid, url, have=0, limit=MAX_PICK):
    """소싱 링크(이우고·1688·오너클랜 등) 페이지에서 큰 사진만 골라 저장"""
    try:
        b, ct = _get(url, limit=4 * 1024 * 1024)
    except Exception as ex:
        return [], f"소싱 페이지 열기 실패: {ex}"
    if ext_of(b):   # 링크 자체가 사진
        n = save_bytes(pid, b)
        return ([n] if n else []), ""
    text = b.decode("utf-8", "replace")
    if "charset=gb" in text[:3000].lower() or "gbk" in ct or "gb2312" in ct:
        text = b.decode("gb18030", "replace")
    origin = f"{urlparse(url).scheme}://{urlparse(url).netloc}/"
    names, tried = [], 0
    for u in imgs_in_html(text, url):
        if len(names) + have >= limit or tried >= 40:
            break
        tried += 1
        n, _ = download(pid, u, origin, MIN_SIDE)
        if n:
            names.append(n)
    return names, ("" if names else "소싱 페이지에서 쓸 만한 사진을 찾지 못함(로그인·차단 페이지일 수 있음)")

def collect(p, oc_item=None):
    """상품 사진을 모두 내 PC에 저장된 사진으로 맞춤. (새 목록, 안내 문구 목록)
    1) 이미 넣은 이미지 주소는 내려받아 로컬로 바꿈
    2) 사진이 없으면: 도매매 상품 사진 → 도매매 상세 HTML 속 사진 → 소싱 링크 페이지 순으로 찾음"""
    try:
        imgs = json.loads(p["images"] or "[]")
    except ValueError:
        imgs = []
    notes, out = [], []
    ref = p["source_url"] or None
    for i in imgs:
        if isinstance(i, str) and i.startswith("http"):
            n, why = download(p["id"], clean_url(i), ref)
            if n:
                out.append(n)
            else:
                out.append(i); notes.append(f"{i[:60]}… {why}")
        elif i and os.path.isfile(os.path.join(IMAGES, os.path.basename(i))):
            out.append(i)
    if out:
        return out, notes
    cands = []
    if oc_item:
        from .domeggook import images_of
        cands += images_of(oc_item)
        cands += imgs_in_html(oc_item.get("content") or "")
    if (p["supply_type"] or "") == "위탁" and p["detail_html"] and "<img" in (p["detail_html"] or ""):
        cands += imgs_in_html(p["detail_html"])
    seen = set()
    for u in cands:
        u = clean_url(u)
        if u in seen or len(out) >= MAX_PICK:
            continue
        seen.add(u)
        n, _ = download(p["id"], u, ref, MIN_SIDE)
        if n:
            out.append(n)
    if not out and p["source_url"] and str(p["source_url"]).startswith("http"):
        got, why = from_page(p["id"], p["source_url"])
        out += got
        if why:
            notes.append(why)
    if not out:
        notes.append("사진을 찾지 못했습니다. 사진을 직접 올리거나 이미지 주소를 넣어 주세요.")
    return out, notes
