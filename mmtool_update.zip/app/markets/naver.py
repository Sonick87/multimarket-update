"""네이버 스마트스토어 커머스API (apicenter.commerce.naver.com)"""
import base64, time, json, os, uuid, datetime
from .base import Market, MarketError
from ..bcrypt_pure import hashpw

BASE = "https://api.commerce.naver.com/external"
_tok = {}
_cats = {}
_catfix = {}

def _split_opt(text):
    import re
    parts = [x.strip() for x in text.split("/") if x.strip()]
    out = []
    for i, x_ in enumerate(parts[:3]):
        m = re.match(r"^(선택\d+|옵션\d+)\s+(.+)$", x_)
        out.append((m.group(1), m.group(2)) if m else ("옵션" if len(parts) == 1 else "옵션%d" % (i + 1), x_))
    return out

def fmt_phone(v):
    """엑셀의 '01039587209' 같은 번호를 네이버가 받는 010-3958-7209 형태로"""
    import re as _re
    d = _re.sub(r"\D", "", v or "")
    if len(d) == 11 and d.startswith("01"):
        return f"{d[:3]}-{d[3:7]}-{d[7:]}"
    if len(d) == 10 and d.startswith("01"):
        return f"{d[:3]}-{d[3:6]}-{d[6:]}"
    if len(d) == 9 and d.startswith("02"):
        return f"02-{d[2:5]}-{d[5:]}"
    if len(d) == 10 and d.startswith("02"):
        return f"02-{d[2:6]}-{d[6:]}"
    if len(d) in (10, 11) and d[0] == "0":
        return f"{d[:3]}-{d[3:-4]}-{d[-4:]}"
    return (v or "").strip()

def _bytes_trim(s, nbytes):
    """UTF-8 기준 nbytes 바이트 이하가 되도록 뒤에서부터 글자를 잘라냄(한글 1글자=3바이트)"""
    s = str(s or "").strip()
    while s and len(s.encode("utf-8")) > nbytes:
        s = s[:-1]
    return s.strip()

def _scrub_ship(h):
    from ..detail import scrub_ship
    return scrub_ship(h)

class Naver(Market):
    code, name = "naver", "네이버 스마트스토어"
    cred_fields = [("client_id", "애플리케이션 ID", False), ("client_secret", "애플리케이션 시크릿", True)]
    extra_fields = [("as_phone", "A/S·고객센터 전화(실제 번호, 필수)", ""), ("importer", "수입자(상호)", ""),
                    ("delivery_fee", "기본 배송비(0=무료)", "0"), ("return_fee", "반품 배송비(편도)", "3000"),
                    ("exchange_fee", "교환 배송비(왕복)", "6000"), ("origin_code", "원산지 코드(중국=0200037)", "0200037")]

    def token(self):
        cid, sec = self.creds["client_id"], self.creds["client_secret"]
        t = _tok.get(cid)
        if t and t[1] > time.time() + 60:
            return t[0]
        ts = str(int(time.time() * 1000))
        sign = base64.b64encode(hashpw(f"{cid}_{ts}".encode(), sec.encode())).decode()
        from urllib.parse import urlencode
        body = urlencode({"client_id": cid, "timestamp": ts, "client_secret_sign": sign,
                          "grant_type": "client_credentials", "type": "SELF"}).encode()
        for i in range(5):
            try:
                r = self.http("POST", BASE + "/v1/oauth2/token", {"Content-Type": "application/x-www-form-urlencoded"}, raw=body)
                break
            except MarketError as ex:
                if i < 4 and (" 429" in str(ex) or "RATE_LIMIT" in str(ex)):
                    time.sleep(1 + i * 2)
                    continue
                raise MarketError(self.friendly(str(ex)))
        _tok[cid] = (r["access_token"], time.time() + int(r.get("expires_in", 3600)))
        return r["access_token"]

    @staticmethod
    def friendly(msg):
        """네이버 에러 문구를 알아보기 쉽게: 원인 안내 + 틀린 항목 이름"""
        import re
        hints = []
        low = msg.lower()
        if "ip" in low and ("not_allowed" in low or "허용" in msg or "gw.ip" in low or "ip_" in low):
            hints.append("▶ 네이버 커머스API센터 > 내 애플리케이션 > API 호출 IP 에 서버 IP 168.110.41.196 이 등록돼 있어야 합니다")
        if "invalid_client" in low or "client_secret" in low or "인증" in msg and "401" in msg:
            hints.append("▶ 애플리케이션 ID·시크릿이 틀렸거나, 이 애플리케이션에 '상품' API 권한이 없습니다(마켓계정에서 키 확인)")
        if " 403" in msg or "forbidden" in low:
            hints.append("▶ 권한이 없습니다. 커머스API센터에서 이 애플리케이션에 상품 등록 API 권한이 있는지 확인하세요")
        m = re.search(r"(\{.*\})", msg, re.S)
        if m:
            try:
                j = json.loads(m.group(1))
                bad = [f"{(i.get('name') or i.get('type') or '')}: {i.get('message', '')}" for i in (j.get("invalidInputs") or [])[:8]]
                if bad:
                    hints.append("▶ 틀린 항목: " + " | ".join(bad))
                elif j.get("message"):
                    hints.append("▶ 네이버 메시지: " + str(j.get("message"))[:300])
            except ValueError:
                pass
        return msg if not hints else msg[:600] + "\n" + "\n".join(hints)

    def call(self, method, path, body=None, raw=None, headers=None):
        """요청이 많다(429 GW.RATE_LIMIT)고 하면 잠깐 쉬었다가 자동으로 다시 보냄(최대 6번)"""
        wait = 2.0
        for i in range(9):
            h = {"Authorization": "Bearer " + self.token()}
            h.update(headers or {})
            try:
                return self.http(method, BASE + path, h, body=body, raw=raw)
            except MarketError as ex:
                if i < 8 and (" 429" in str(ex) or "RATE_LIMIT" in str(ex)):
                    time.sleep(wait); wait = min(wait * 2, 30)
                    continue
                err = MarketError(self.friendly(str(ex)))
                err.invalid = self.parse_invalid(str(ex))
                raise err

    @staticmethod
    def parse_invalid(msg):
        """네이버가 알려 준 틀린 항목 목록 [(이름, 종류, 메시지)]"""
        import re
        return [(a, b, c.replace('\\"', '"')) for a, b, c in re.findall(r'\{\s*"name"\s*:\s*"([^"]+)"\s*,\s*"type"\s*:\s*"([^"]*)"\s*,\s*"message"\s*:\s*"((?:[^"\\]|\\.)*)"\s*\}', msg)]

    def test(self):
        if self.dry:
            return "미리보기 모드(키 없음)"
        self.token()
        return "토큰 발급 성공"

    def upload_images(self, paths):
        if self.dry or not paths:
            return []
        b = "----mm" + uuid.uuid4().hex
        parts = []
        for p in paths[:10]:
            with open(p, "rb") as f:
                data = f.read()
            # 파일 이름이 .jpg여도 실제로는 PNG/GIF인 경우가 있어 첫 바이트로 진짜 종류를 알아낸다
            if data[:3] == b"\xff\xd8\xff":
                ext, ctype = "jpg", "image/jpeg"
            elif data[:4] == b"\x89PNG":
                ext, ctype = "png", "image/png"
            elif data[:3] == b"GIF":
                ext, ctype = "gif", "image/gif"
            elif data[:2] == b"BM":
                ext, ctype = "bmp", "image/bmp"
            else:
                ext = os.path.splitext(p)[1].lower().strip(".") or "jpg"
                ctype = "image/" + ("jpeg" if ext == "jpg" else ext)
            fname = os.path.splitext(os.path.basename(p))[0] + "." + ext
            parts.append((f'--{b}\r\nContent-Disposition: form-data; name="imageFiles"; filename="{fname}"\r\n'
                          f'Content-Type: {ctype}\r\n\r\n').encode() + data + b"\r\n")
        raw = b"".join(parts) + f"--{b}--\r\n".encode()
        r = self.call("POST", "/v1/product-images/upload", raw=raw, headers={"Content-Type": f"multipart/form-data; boundary={b}"})
        return [i["url"] for i in r.get("images", [])]

    def search_category(self, keyword):
        if self.dry:
            return []
        if not _cats:
            for c in self.call("GET", "/v1/categories?last=true"):
                _cats[c["id"]] = c.get("wholeCategoryName", c.get("name"))
        return [{"id": k, "name": v} for k, v in _cats.items() if keyword in v][:50]

    def build_product(self, p, price, detail_html, image_urls):
        e = self.extra
        imgs = image_urls or ["https://example.com/대표이미지를_올려주세요.jpg"]
        fee = int(e.get("delivery_fee") or 0)
        try:
            imp = json.loads(p["import_json"] or "{}") if "import_json" in p.keys() else {}
        except (ValueError, TypeError, AttributeError):
            imp = json.loads(p.get("import_json") or "{}") if hasattr(p, "get") else {}
        notice_etc = {
            "returnCostReason": "단순 변심 반품 시 왕복 배송비는 구매자 부담", "noRefundReason": "사용·훼손 시 반품 불가",
            "qualityAssuranceStandard": "공정거래위원회 소비자분쟁해결기준에 따름", "compensationProcedure": "고객센터로 문의",
            "troubleShootingContents": "고객센터로 문의", "itemName": p["name"][:49], "modelName": p["name"][:49],
            "certificateDetails": "해당 없음", "manufacturer": "중국 제조사 / 수입: " + (e.get("importer") or "판매자"),
            "customerServicePhoneNumber": ("" if (e.get("as_phone") or "").strip() in ("010-0000-0000", "01000000000") else fmt_phone(e.get("as_phone"))),   # 네이버: A/S 책임자와 전화번호 · 소비자상담 전화번호 중 '하나만'
        }
        dfee = {"deliveryFeeType": "FREE" if fee == 0 else "PAID", "baseFee": fee, "deliveryFeePayType": "PREPAID"}
        claim = {"returnDeliveryFee": int(e.get("return_fee") or 3000), "exchangeDeliveryFee": int(e.get("exchange_fee") or 6000)}
        extra_attr, opt_info = {}, None
        if imp:   # 엑셀 양식으로 올린 상품: 파일의 배송비·반품비·옵션·태그 그대로
            ft = imp.get("fee_type")
            if ft == "무료":
                dfee = {"deliveryFeeType": "FREE", "baseFee": 0, "deliveryFeePayType": "PREPAID"}
            elif ft == "수량별":
                dfee = {"deliveryFeeType": "UNIT_QUANTITY_PAID", "baseFee": int(imp.get("base_fee") or 0), "repeatQuantity": max(int(imp.get("repeat") or 1), 1), "deliveryFeePayType": "PREPAID"}
            elif ft == "조건부무료" and imp.get("free_over"):
                dfee = {"deliveryFeeType": "CONDITIONAL_FREE", "baseFee": int(imp.get("base_fee") or 0), "freeConditionalAmount": int(imp["free_over"]), "deliveryFeePayType": "PREPAID"}
            else:
                dfee = {"deliveryFeeType": "PAID", "baseFee": int(imp.get("base_fee") or 0), "deliveryFeePayType": "PREPAID"}
            if imp.get("area"):
                def _af(v, dflt):   # 네이버는 제주/도서산간 추가배송비를 10~200,000원만 받는다(0원 불가)
                    v = int(float(v or 0))
                    return min(v, 200000) if v >= 10 else dflt
                dfee["deliveryFeeByArea"] = {"deliveryAreaType": "AREA_3", "area2extraFee": _af(imp["area"][0], 5000), "area3extraFee": _af(imp["area"][1], 5000)}
            claim = {"returnDeliveryFee": int(imp.get("return_fee") or 3000), "exchangeDeliveryFee": int(imp.get("exchange_fee") or 6000)}
            seo = {}
            if imp.get("tags"):
                seo["sellerTags"] = [{"text": _bytes_trim(t, 30)} for t in imp["tags"][:10] if _bytes_trim(t, 30)]
            if imp.get("page_title"):
                seo["pageTitle"] = imp["page_title"][:100]
            if imp.get("meta"):
                seo["metaDescription"] = imp["meta"][:160]
            if seo:
                extra_attr["seoInfo"] = seo
            if (imp.get("as_phone") or "").strip() not in ("", "010-0000-0000"):
                e = dict(e, as_phone=fmt_phone(imp["as_phone"]))
                notice_etc["customerServicePhoneNumber"] = e["as_phone"]
            if imp.get("options"):
                groups, combos = [], []
                for o in imp["options"]:
                    parts = _split_opt(o["text"])
                    if len(parts) > len(groups):
                        groups = [g for g, _ in parts]
                    combos.append((parts, o))
                base_stock = int(p["stock"] or 0)
                rows_ = []
                for parts, o in combos:
                    row = {"stockQuantity": o["stock"] if o["stock"] > 0 else base_stock, "price": o["price"], "usable": True}
                    for i, (_, v) in enumerate(parts[:3]):
                        row[f"optionName{i + 1}"] = v[:25]
                    rows_.append(row)
                # 네이버: 옵션가 0원·재고 1 이상·사용 Y 옵션이 1개는 있어야 함 → 가장 싼 옵션을 0원으로 맞추고 차액은 판매가에 더함(구매자 결제액은 그대로)
                _m = min((int(r_["price"] or 0) for r_ in rows_ if r_.get("stockQuantity", 0) > 0), default=0)
                if _m > 0:
                    for r_ in rows_:
                        r_["price"] = max(int(r_["price"] or 0) - _m, 0)
                    price = int(price) + _m
                for r_ in rows_:
                    if r_.get("stockQuantity", 0) < 1:
                        r_["stockQuantity"] = max(base_stock, 1)
                opt_info = {"optionCombinationSortType": "CREATE",
                            "optionCombinationGroupNames": {f"optionGroupName{i + 1}": g[:25] for i, g in enumerate(groups[:3])},
                            "optionCombinations": rows_}
        if not notice_etc["customerServicePhoneNumber"]:
            raise MarketError("A/S·고객센터 전화번호가 없습니다. 마켓계정(네이버)의 「A/S·고객센터 전화」 칸에 번호를 넣거나 엑셀의 'A/S 전화번호'를 채우세요")
        pay = {
            "originProduct": {
                "statusType": "SALE", "saleType": "NEW", "leafCategoryId": str(p["naver_cat"] or ""),
                "name": p["name"][:100], "detailContent": _scrub_ship(detail_html),
                "images": {"representativeImage": {"url": imgs[0]}, "optionalImages": [{"url": u} for u in imgs[1:10]]},
                "salePrice": price, "stockQuantity": int(p["stock"] or 0),
                "deliveryInfo": {
                    "deliveryType": "DELIVERY", "deliveryAttributeType": "NORMAL", "deliveryCompany": "CJGLS",
                    "deliveryFee": dfee,
                    "claimDeliveryInfo": claim,
                },
                "detailAttribute": {
                    "afterServiceInfo": {"afterServiceTelephoneNumber": e.get("as_phone", ""), "afterServiceGuideContent": "고객센터로 문의해 주세요"},
                    "originAreaInfo": {"originAreaCode": e.get("origin_code") or "0200037", "importer": e.get("importer") or "판매자"},
                    "minorPurchasable": True,
                    "productInfoProvidedNotice": {"productInfoProvidedNoticeType": "ETC", "etc": notice_etc},
                    "sellerCodeInfo": {"sellerManagementCode": f"MM{p['id']}"},
                    # 인증 대상 제외(어린이제품·KC·친환경) 표시 / 네이버쇼핑 검색정보(모델명·제조사)
                    "certificationTargetExcludeContent": {"childCertifiedProductExclusionYn": True, "kcCertifiedProductExclusionYn": "TRUE", "greenCertifiedProductExclusionYn": True},
                    "naverShoppingSearchInfo": {"modelName": p["name"][:49], "manufacturerName": (e.get("importer") or "판매자")[:50]},
                },
            },
            "smartstoreChannelProduct": {"naverShoppingRegistration": True, "channelProductDisplayStatusType": "ON"},
        }
        pay["originProduct"]["detailAttribute"].update(extra_attr)
        if opt_info:
            pay["originProduct"]["detailAttribute"]["optionInfo"] = opt_info
        return pay

    def fix_category(self, cid, name):
        """엑셀의 카테고리ID가 '리프(맨 아래) 카테고리'가 아니거나 없는 ID일 때 → 같은 계열에서 상품명과 가장 맞는 맨 아래 카테고리를 찾는다"""
        import re
        if cid in _catfix:
            return _catfix[cid]
        if not _cats:
            for c in self.call("GET", "/v1/categories?last=true"):
                _cats[c["id"]] = c.get("wholeCategoryName", c.get("name")) or ""
        if cid in _cats:
            return None
        prefix = ""
        try:
            info = self.call("GET", f"/v1/categories/{cid}")
            prefix = (info.get("wholeCategoryName") or info.get("name") or "") if isinstance(info, dict) else ""
        except MarketError:
            prefix = ""
        cands = [(k, v) for k, v in _cats.items() if prefix and v.startswith(prefix)] or ([] if prefix else list(_cats.items()))
        best, score = None, 0
        for k, v in cands:
            sc = 0
            for tok in re.split(r"[>\s/,]+", v):
                if len(tok) >= 2 and tok in name:
                    sc += len(tok)
            if sc > score:
                best, score = k, sc
        _catfix[cid] = best
        return best

    def autofix(self, payload, invalid):
        """네이버가 돌려준 에러를 읽고 고칠 수 있는 건 고쳐서 True. 못 고치면 False(그대로 에러를 보여 줌)"""
        import re
        changed = False
        name = (payload["originProduct"].get("name") or "")
        def walk(path, create=False):
            """점으로 나뉜 경로를 따라가 (담고 있는 dict 또는 list, 키 또는 번호)를 돌려줌. sellerTags[1].text 처럼 번호도 따라감"""
            toks = []
            for part in [x for x in path.split(".") if x]:
                mm = re.fullmatch(r"([^\[\]]*)((?:\[\d+\])*)", part)
                if not mm:
                    return None, None
                if mm.group(1):
                    toks.append(mm.group(1))
                toks += [int(i) for i in re.findall(r"\[(\d+)\]", mm.group(2))]
            if not toks:
                return None, None
            cur = payload
            for k in toks[:-1]:
                if isinstance(k, int):
                    if not isinstance(cur, list) or k >= len(cur):
                        return None, None
                    cur = cur[k]
                else:
                    if not isinstance(cur, dict):
                        return None, None
                    if k not in cur:
                        if not create:
                            return None, None
                        cur[k] = {}
                    cur = cur[k]
            last = toks[-1]
            if isinstance(last, int):
                return (cur, last) if isinstance(cur, list) and last < len(cur) else (None, None)
            return (cur, last) if isinstance(cur, dict) else (None, None)
        for path, typ, msg in invalid:
            d, k = walk(path, create=("unitPriceYn" in path))
            if d is None:
                continue
            v = d[k] if isinstance(d, list) else d.get(k)
            # 0) 카테고리ID가 리프가 아님 → 상품명에 맞는 리프 카테고리로 교체
            if path.endswith("leafCategoryId") and "NotValid" in typ:
                nid = self.fix_category(str(v), name)
                if nid and nid != str(v):
                    d[k] = nid; changed = True
                continue
            # 1-0) 바이트 수 제한(태그 30byte 등): 글자 수가 아니라 UTF-8 바이트로 자름
            mb = re.search(r"(\d+)\s*byte", msg, re.I)
            if "MaxByteLength" in typ and mb and isinstance(v, str):
                lim = int(mb.group(1)) - (1 if ("보다 작게" in msg or "미만" in msg) else 0)
                nv = _bytes_trim(v, max(lim, 3))
                if nv and nv != v:
                    d[k] = nv; changed = True
                continue
            # 1) 글자 수 제한
            m = re.search(r"(\d+)자", msg)
            if "MaxLength" in typ and m and isinstance(v, str):
                n = int(m.group(1)) - (1 if ("보다 작게" in msg or "미만" in msg) else 0)
                d[k] = v[:max(n, 1)]; changed = True; continue
            # 2) 금지 단어(태그·상품명 등)
            m = re.search(r"단어\(([^)]+)\)", msg)
            if typ.startswith("Restricted") and m:
                bad = [w.strip() for w in m.group(1).split(",") if w.strip()]
                if k == "sellerTags" and isinstance(v, list):
                    keep = [t for t in v if not any(w in t["text"] for w in bad)]
                    if keep: d[k] = keep
                    else: d.pop(k, None)
                    changed = changed or len(keep) != len(v)
                elif isinstance(v, str):
                    nv = v
                    for w in bad:
                        nv = nv.replace(w, "")
                    d[k] = " ".join(nv.split()); changed = changed or nv != v   # 태그가 통째로 금지어면 빈 글자가 남는데, 아래에서 빈 태그를 걷어냄
                continue
            # 3) 숫자 범위(추가배송비 등)
            m = re.search(r"([\d,]+)\s*에서\s*([\d,]+)\s*까지", msg)
            if "NumberRange" in typ and m and isinstance(v, (int, float)):
                lo, hi = int(m.group(1).replace(",", "")), int(m.group(2).replace(",", ""))
                nv = min(max(5000, lo), hi) if (int(v) < lo or int(v) > hi) else min(max(int(v), lo), hi)
                d[k] = nv; changed = changed or nv != v; continue
            # 4) 단위가격 사용여부
            if path.endswith("unitCapacity.unitPriceYn"):
                d[k] = False; changed = True; continue
            # 5) 비어 있으면 안 되는 모델명·제조사
            if ("NotEmpty" in typ or "NotNull" in typ) and k in ("modelName", "manufacturerName", "itemName") and not v:
                d[k] = (name or "상품")[:49]; changed = True; continue
        try:
            seo_ = payload["originProduct"]["detailAttribute"]["seoInfo"]
            tg = seo_.get("sellerTags")
            if isinstance(tg, list) and any(not (t.get("text") or "").strip() for t in tg):
                keep = [t for t in tg if (t.get("text") or "").strip()]
                if keep: seo_["sellerTags"] = keep
                else: seo_.pop("sellerTags", None)
                changed = True
        except (KeyError, TypeError, AttributeError):
            pass
        return changed

    def register(self, payload):
        if self.dry:
            return {"dry": True, "file": self.save_dry("register", payload), "market_id": "DRY-N", "sub_id": ""}
        if not payload["originProduct"]["leafCategoryId"]:
            raise MarketError("네이버 카테고리 ID가 비어 있습니다")
        r = None
        for _try in range(10):
            try:
                r = self.call("POST", "/v2/products", payload)
                break
            except MarketError as ex:
                inv = getattr(ex, "invalid", None) or self.parse_invalid(str(ex))
                if _try >= 9 or not inv or not self.autofix(payload, inv):
                    raise
        return {"market_id": str(r.get("originProductNo")), "sub_id": str(r.get("smartstoreChannelProductNo", "")), "raw": r}

    def list_store(self, limit=5000, progress=None):
        """스마트스토어에 올라가 있는 상품 전체(우리 프로그램 밖에서 올린 것 포함)"""
        if self.dry:
            return [{"origin": f"DRY{i}", "channel": f"DRYC{i}", "name": f"예시 상품 {i} (키를 넣으면 실제 상품이 보입니다)", "status": "SALE",
                     "price": 9900, "stock": 10, "image": "", "code": ""} for i in range(1, 4)]
        out, page = [], 1
        while len(out) < limit:
            r = self.call("POST", "/v1/products/search", {"page": page, "size": 100, "orderType": "NO"})
            for c in r.get("contents") or []:
                chs_ = c.get("channelProducts") or [{}]
                ch = chs_[0]
                img = ch.get("representativeImage") or {}
                out.append({"origin": str(c.get("originProductNo") or ch.get("originProductNo") or ""), "channel": str(ch.get("channelProductNo") or ""),
                            "name": ch.get("name") or "", "status": ch.get("statusType") or "", "price": ch.get("salePrice"),
                            "stock": ch.get("stockQuantity"), "image": img.get("url", "") if isinstance(img, dict) else "",
                            "code": ch.get("sellerManagementCode") or ""})
            total_pages = int(r.get("totalPages") or 0)
            if page >= total_pages or not r.get("contents"):
                break
            page += 1
            if progress:
                progress(len(out))
            time.sleep(1.0)
        return out[:limit]

    def delete_store(self, item):
        """원상품 삭제(되돌릴 수 없음)"""
        if self.dry or str(item.get("origin", "")).startswith("DRY"):
            return self.save_dry("delete", item)
        return self.call("DELETE", f"/v2/products/origin-products/{item['origin']}")

    def _origin(self, oid):
        return self.call("GET", f"/v2/products/origin-products/{oid}")

    def update_price_stock(self, listing, price, stock):
        if self.dry:
            return self.save_dry("update", {"origin": listing["market_id"], "price": price, "stock": stock})
        cur = self._origin(listing["market_id"])
        cur["originProduct"]["salePrice"] = price
        cur["originProduct"]["stockQuantity"] = stock
        return self.call("PUT", f"/v2/products/origin-products/{listing['market_id']}", cur)

    def set_sale(self, listing, on):
        if self.dry:
            return self.save_dry("status", {"origin": listing["market_id"], "on": on})
        cur = self._origin(listing["market_id"])
        cur["originProduct"]["statusType"] = "SALE" if on else "SUSPENSION"
        return self.call("PUT", f"/v2/products/origin-products/{listing['market_id']}", cur)

    def fetch_orders(self, days=3):
        if self.dry:
            return []
        kst = datetime.timezone(datetime.timedelta(hours=9))
        frm = (datetime.datetime.now(kst) - datetime.timedelta(hours=23)).isoformat(timespec="milliseconds")
        from urllib.parse import quote
        r = self.call("GET", f"/v1/pay-order/seller/product-orders/last-changed-statuses?lastChangedFrom={quote(frm)}")
        ids = [x["productOrderId"] for x in (r.get("data") or {}).get("lastChangeStatuses", [])]
        if not ids:
            return []
        d = self.call("POST", "/v1/pay-order/seller/product-orders/query", {"productOrderIds": ids[:300]})
        out = []
        for it in d.get("data", []):
            po, od = it.get("productOrder", {}), it.get("order", {})
            sa = po.get("shippingAddress") or {}
            out.append({"order_id": po.get("productOrderId"), "product_name": po.get("productName"), "qty": po.get("quantity"),
                        "amount": po.get("totalPaymentAmount"), "buyer": od.get("ordererName"),
                        "status": po.get("productOrderStatus"), "ordered_at": od.get("orderDate"), "raw": it,
                        "seller_code": po.get("sellerProductCode") or po.get("optionManageCode") or "", "option": po.get("productOption") or "",
                        "rcv": {"name": sa.get("name", ""), "phone": sa.get("tel1", ""), "zip": sa.get("zipCode", ""),
                                "addr1": sa.get("baseAddress", ""), "addr2": sa.get("detailedAddress", ""), "memo": po.get("shippingMemo", "")},
                        "ship_ref": {"productOrderId": po.get("productOrderId")}})
        return out

    def ship(self, ship_ref, courier_code, tracking):
        """발송처리(송장 등록)"""
        body = {"dispatchProductOrders": [{"productOrderId": ship_ref["productOrderId"], "deliveryMethod": "DELIVERY",
                                           "deliveryCompanyCode": courier_code, "trackingNumber": tracking,
                                           "dispatchDate": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec="milliseconds")}]}
        if self.dry:
            return {"dry": True, "file": self.save_dry("ship", body)}
        r = self.call("POST", "/v1/pay-order/seller/product-orders/dispatch", body)
        fail = (r.get("data") or {}).get("failProductOrderInfos") or []
        if fail:
            raise MarketError("네이버 발송처리 실패: " + json.dumps(fail, ensure_ascii=False)[:600])
        return r

    def confirm(self, ship_ref):
        """발주확인"""
        if self.dry:
            return {"dry": True}
        return self.call("POST", "/v1/pay-order/seller/product-orders/confirm", {"productOrderIds": [ship_ref["productOrderId"]]})
