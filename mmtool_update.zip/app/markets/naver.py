"""네이버 스마트스토어 커머스API (apicenter.commerce.naver.com)"""
import base64, time, json, os, uuid, datetime
from .base import Market, MarketError
from ..bcrypt_pure import hashpw

BASE = "https://api.commerce.naver.com/external"
_tok = {}
_cats = {}

class Naver(Market):
    code, name = "naver", "네이버 스마트스토어"
    cred_fields = [("client_id", "애플리케이션 ID", False), ("client_secret", "애플리케이션 시크릿", True)]
    extra_fields = [("as_phone", "A/S·고객센터 전화", "010-0000-0000"), ("importer", "수입자(상호)", ""),
                    ("delivery_fee", "기본 배송비(0=무료)", "0"), ("return_fee", "반품 배송비(편도)", "3000"),
                    ("exchange_fee", "교환 배송비(왕복)", "6000"), ("origin_code", "원산지 코드(중국=0200037)", "0200037")]

    def token(self):
        cid, sec = self.creds["client_id"], self.creds["client_secret"]
        t = _tok.get(cid)
        if t and t[1] > time.time() + 60:
            return t[0]
        ts = str(int(time.time() * 1000))
        sign = base64.b64encode(hashpw(f"{cid}_{ts}".encode(), sec.encode())).decode()
        from urllib.parse import urlencode
        body = urlencode({"client_id": cid, "timestamp": ts, "client_secret_sign": sign,
                          "grant_type": "client_credentials", "type": "SELF"}).encode()
        for i in range(5):
            try:
                r = self.http("POST", BASE + "/v1/oauth2/token", {"Content-Type": "application/x-www-form-urlencoded"}, raw=body)
                break
            except MarketError as ex:
                if i < 4 and (" 429" in str(ex) or "RATE_LIMIT" in str(ex)):
                    time.sleep(1 + i * 2)
                    continue
                raise
        _tok[cid] = (r["access_token"], time.time() + int(r.get("expires_in", 3600)))
        return r["access_token"]

    def call(self, method, path, body=None, raw=None, headers=None):
        """요청이 많다(429 GW.RATE_LIMIT)고 하면 잠깐 쉬었다가 자동으로 다시 보냄(최대 6번)"""
        wait = 2.0
        for i in range(9):
            h = {"Authorization": "Bearer " + self.token()}
            h.update(headers or {})
            try:
                return self.http(method, BASE + path, h, body=body, raw=raw)
            except MarketError as ex:
                if i < 8 and (" 429" in str(ex) or "RATE_LIMIT" in str(ex)):
                    time.sleep(wait); wait = min(wait * 2, 30)
                    continue
                raise

    def test(self):
        if self.dry:
            return "미리보기 모드(키 없음)"
        self.token()
        return "토큰 발급 성공"

    def upload_images(self, paths):
        if self.dry or not paths:
            return []
        b = "----mm" + uuid.uuid4().hex
        parts = []
        for p in paths[:10]:
            with open(p, "rb") as f:
                data = f.read()
            ext = os.path.splitext(p)[1].lower().strip(".") or "jpg"
            parts.append((f'--{b}\r\nContent-Disposition: form-data; name="imageFiles"; filename="{os.path.basename(p)}"\r\n'
                          f'Content-Type: image/{"jpeg" if ext == "jpg" else ext}\r\n\r\n').encode() + data + b"\r\n")
        raw = b"".join(parts) + f"--{b}--\r\n".encode()
        r = self.call("POST", "/v1/product-images/upload", raw=raw, headers={"Content-Type": f"multipart/form-data; boundary={b}"})
        return [i["url"] for i in r.get("images", [])]

    def search_category(self, keyword):
        if self.dry:
            return []
        if not _cats:
            for c in self.call("GET", "/v1/categories?last=true"):
                _cats[c["id"]] = c.get("wholeCategoryName", c.get("name"))
        return [{"id": k, "name": v} for k, v in _cats.items() if keyword in v][:50]

    def build_product(self, p, price, detail_html, image_urls):
        e = self.extra
        imgs = image_urls or ["https://example.com/대표이미지를_올려주세요.jpg"]
        fee = int(e.get("delivery_fee") or 0)
        notice_etc = {
            "returnCostReason": "단순 변심 반품 시 왕복 배송비는 구매자 부담", "noRefundReason": "사용·훼손 시 반품 불가",
            "qualityAssuranceStandard": "공정거래위원회 소비자분쟁해결기준에 따름", "compensationProcedure": "고객센터로 문의",
            "troubleShootingContents": "고객센터로 문의", "itemName": p["name"], "modelName": p["name"],
            "certificateDetails": "해당 없음", "manufacturer": "중국 제조사 / 수입: " + (e.get("importer") or "판매자"),
            "customerServicePhoneNumber": e.get("as_phone", ""),
        }
        return {
            "originProduct": {
                "statusType": "SALE", "saleType": "NEW", "leafCategoryId": str(p["naver_cat"] or ""),
                "name": p["name"][:100], "detailContent": detail_html,
                "images": {"representativeImage": {"url": imgs[0]}, "optionalImages": [{"url": u} for u in imgs[1:10]]},
                "salePrice": price, "stockQuantity": int(p["stock"] or 0),
                "deliveryInfo": {
                    "deliveryType": "DELIVERY", "deliveryAttributeType": "NORMAL", "deliveryCompany": "CJGLS",
                    "deliveryFee": {"deliveryFeeType": "FREE" if fee == 0 else "PAID", "baseFee": fee, "deliveryFeePayType": "PREPAID"},
                    "claimDeliveryInfo": {"returnDeliveryFee": int(e.get("return_fee") or 3000), "exchangeDeliveryFee": int(e.get("exchange_fee") or 6000)},
                },
                "detailAttribute": {
                    "afterServiceInfo": {"afterServiceTelephoneNumber": e.get("as_phone", ""), "afterServiceGuideContent": "고객센터로 문의해 주세요"},
                    "originAreaInfo": {"originAreaCode": e.get("origin_code") or "0200037", "importer": e.get("importer") or "판매자"},
                    "minorPurchasable": True,
                    "productInfoProvidedNotice": {"productInfoProvidedNoticeType": "ETC", "etc": notice_etc},
                    "sellerCodeInfo": {"sellerManagementCode": f"MM{p['id']}"},
                },
            },
            "smartstoreChannelProduct": {"naverShoppingRegistration": True, "channelProductDisplayStatusType": "ON"},
        }

    def register(self, payload):
        if self.dry:
            return {"dry": True, "file": self.save_dry("register", payload), "market_id": "DRY-N", "sub_id": ""}
        if not payload["originProduct"]["leafCategoryId"]:
            raise MarketError("네이버 카테고리 ID가 비어 있습니다")
        r = self.call("POST", "/v2/products", payload)
        return {"market_id": str(r.get("originProductNo")), "sub_id": str(r.get("smartstoreChannelProductNo", "")), "raw": r}

    def list_store(self, limit=5000, progress=None):
        """스마트스토어에 올라가 있는 상품 전체(우리 프로그램 밖에서 올린 것 포함)"""
        if self.dry:
            return [{"origin": f"DRY{i}", "channel": f"DRYC{i}", "name": f"예시 상품 {i} (키를 넣으면 실제 상품이 보입니다)", "status": "SALE",
                     "price": 9900, "stock": 10, "image": "", "code": ""} for i in range(1, 4)]
        out, page = [], 1
        while len(out) < limit:
            r = self.call("POST", "/v1/products/search", {"page": page, "size": 100, "orderType": "NO"})
            for c in r.get("contents") or []:
                chs_ = c.get("channelProducts") or [{}]
                ch = chs_[0]
                img = ch.get("representativeImage") or {}
                out.append({"origin": str(c.get("originProductNo") or ch.get("originProductNo") or ""), "channel": str(ch.get("channelProductNo") or ""),
                            "name": ch.get("name") or "", "status": ch.get("statusType") or "", "price": ch.get("salePrice"),
                            "stock": ch.get("stockQuantity"), "image": img.get("url", "") if isinstance(img, dict) else "",
                            "code": ch.get("sellerManagementCode") or ""})
            total_pages = int(r.get("totalPages") or 0)
            if page >= total_pages or not r.get("contents"):
                break
            page += 1
            if progress:
                progress(len(out))
            time.sleep(1.0)
        return out[:limit]

    def delete_store(self, item):
        """원상품 삭제(되돌릴 수 없음)"""
        if self.dry or str(item.get("origin", "")).startswith("DRY"):
            return self.save_dry("delete", item)
        return self.call("DELETE", f"/v2/products/origin-products/{item['origin']}")

    def _origin(self, oid):
        return self.call("GET", f"/v2/products/origin-products/{oid}")

    def update_price_stock(self, listing, price, stock):
        if self.dry:
            return self.save_dry("update", {"origin": listing["market_id"], "price": price, "stock": stock})
        cur = self._origin(listing["market_id"])
        cur["originProduct"]["salePrice"] = price
        cur["originProduct"]["stockQuantity"] = stock
        return self.call("PUT", f"/v2/products/origin-products/{listing['market_id']}", cur)

    def set_sale(self, listing, on):
        if self.dry:
            return self.save_dry("status", {"origin": listing["market_id"], "on": on})
        cur = self._origin(listing["market_id"])
        cur["originProduct"]["statusType"] = "SALE" if on else "SUSPENSION"
        return self.call("PUT", f"/v2/products/origin-products/{listing['market_id']}", cur)

    def fetch_orders(self, days=3):
        if self.dry:
            return []
        kst = datetime.timezone(datetime.timedelta(hours=9))
        frm = (datetime.datetime.now(kst) - datetime.timedelta(hours=23)).isoformat(timespec="milliseconds")
        from urllib.parse import quote
        r = self.call("GET", f"/v1/pay-order/seller/product-orders/last-changed-statuses?lastChangedFrom={quote(frm)}")
        ids = [x["productOrderId"] for x in (r.get("data") or {}).get("lastChangeStatuses", [])]
        if not ids:
            return []
        d = self.call("POST", "/v1/pay-order/seller/product-orders/query", {"productOrderIds": ids[:300]})
        out = []
        for it in d.get("data", []):
            po, od = it.get("productOrder", {}), it.get("order", {})
            sa = po.get("shippingAddress") or {}
            out.append({"order_id": po.get("productOrderId"), "product_name": po.get("productName"), "qty": po.get("quantity"),
                        "amount": po.get("totalPaymentAmount"), "buyer": od.get("ordererName"),
                        "status": po.get("productOrderStatus"), "ordered_at": od.get("orderDate"), "raw": it,
                        "seller_code": po.get("sellerProductCode") or po.get("optionManageCode") or "", "option": po.get("productOption") or "",
                        "rcv": {"name": sa.get("name", ""), "phone": sa.get("tel1", ""), "zip": sa.get("zipCode", ""),
                                "addr1": sa.get("baseAddress", ""), "addr2": sa.get("detailedAddress", ""), "memo": po.get("shippingMemo", "")},
                        "ship_ref": {"productOrderId": po.get("productOrderId")}})
        return out

    def ship(self, ship_ref, courier_code, tracking):
        """발송처리(송장 등록)"""
        body = {"dispatchProductOrders": [{"productOrderId": ship_ref["productOrderId"], "deliveryMethod": "DELIVERY",
                                           "deliveryCompanyCode": courier_code, "trackingNumber": tracking,
                                           "dispatchDate": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(timespec="milliseconds")}]}
        if self.dry:
            return {"dry": True, "file": self.save_dry("ship", body)}
        r = self.call("POST", "/v1/pay-order/seller/product-orders/dispatch", body)
        fail = (r.get("data") or {}).get("failProductOrderInfos") or []
        if fail:
            raise MarketError("네이버 발송처리 실패: " + json.dumps(fail, ensure_ascii=False)[:600])
        return r

    def confirm(self, ship_ref):
        """발주확인"""
        if self.dry:
            return {"dry": True}
        return self.call("POST", "/v1/pay-order/seller/product-orders/confirm", {"productOrderIds": [ship_ref["productOrderId"]]})
