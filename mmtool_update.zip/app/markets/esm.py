"""지마켓·옥션 ESM Trading API (etapi.esmplus.com). ESM+ 에서 API 사용 신청 후 받은 마스터ID·시크릿키가 필요합니다.
※ ESM API 상품 등록 형식은 공개 문서가 적어, 첫 등록 때 오류 메시지를 보고 필드를 맞춰야 할 수 있습니다."""
import base64, hmac, hashlib, json, time
from .base import Market, MarketError

BASE = "https://sa2.esmplus.com"

def _b64(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()

class ESM(Market):
    code, name = "esm", "지마켓·옥션(ESM)"
    cred_fields = [("master_id", "ESM 마스터 ID", False), ("secret_key", "API 시크릿 키", True)]
    extra_fields = [("gmarket_id", "지마켓 판매자 ID", ""), ("auction_id", "옥션 판매자 ID", ""), ("as_phone", "A/S 전화", ""),
                    ("importer", "수입자(상호)", ""), ("shipping_place", "출하지 번호", ""), ("delivery_fee", "기본 배송비(0=무료)", "0"),
                    ("return_fee", "반품 배송비(편도)", "3000")]

    def jwt(self):
        ssi = ",".join(x for x in [f"A:{self.extra['auction_id']}" if self.extra.get("auction_id") else "",
                                   f"G:{self.extra['gmarket_id']}" if self.extra.get("gmarket_id") else ""] if x)
        h = {"alg": "HS256", "typ": "JWT", "kid": self.creds["master_id"]}
        p = {"iss": "www.esmplus.com", "sub": "sell", "aud": "sa.esmplus.com", "ssi": ssi, "iat": int(time.time())}
        si = _b64(json.dumps(h).encode()) + "." + _b64(json.dumps(p).encode())
        return si + "." + _b64(hmac.new(self.creds["secret_key"].encode(), si.encode(), hashlib.sha256).digest())

    def call(self, method, path, body=None):
        return self.http(method, BASE + path, {"Authorization": "Bearer " + self.jwt()}, body=body)

    def test(self):
        if self.dry:
            return "미리보기 모드(키 없음)"
        self.call("GET", "/item/v1/categories/site-cats")
        return "연결 성공"

    def build_product(self, p, price, detail_html, image_urls):
        pr = price if isinstance(price, dict) else {"Gmkt": price, "Iac": price}
        e = self.extra
        imgs = image_urls or ["https://example.com/대표이미지를_올려주세요.jpg"]
        fee = int(e.get("delivery_fee") or 0)
        sites = []
        if e.get("gmarket_id"): sites.append({"siteType": 2, "sellerId": e["gmarket_id"]})
        if e.get("auction_id"): sites.append({"siteType": 1, "sellerId": e["auction_id"]})
        return {
            "itemBasicInfo": {"goodsName": {"kor": p["name"][:100]}, "category": {"site": [{"catCode": str(p["esm_cat"] or ""), "siteType": s["siteType"]} for s in sites]}},
            "itemAddtionalInfo": {
                "price": pr, "stock": {"Gmkt": int(p["stock"] or 0), "Iac": int(p["stock"] or 0)},
                "shipping": {"type": 1, "companyNo": 10013, "policy": {"fee": fee, "feeType": 1 if fee == 0 else 2},
                             "placeNo": e.get("shipping_place", ""), "returnAndExchange": {"fee": int(e.get("return_fee") or 3000)}},
                "officialNotice": {"officialNoticeNo": 35, "details": [
                    {"officialNoticeItemelementCode": "35-1", "value": p["name"]}, {"officialNoticeItemelementCode": "35-3", "value": "중국"},
                    {"officialNoticeItemelementCode": "35-4", "value": e.get("importer") or "판매자"},
                    {"officialNoticeItemelementCode": "35-6", "value": e.get("as_phone", "")}]},
                "origin": {"goodsType": 2, "code": "CN"}, "images": {"basicImgURL": imgs[0], "addImg": imgs[1:10]},
                "descriptions": {"kor": {"type": 2, "html": detail_html}}, "sellerManagementCode": f"MM{p['id']}",
            },
            "addtionalInfo": {"sellerShop": sites},
        }

    def register(self, payload):
        if self.dry:
            return {"dry": True, "file": self.save_dry("register", payload), "market_id": "DRY-E", "sub_id": ""}
        r = self.call("POST", "/item/v1/goods", payload)
        gno = r.get("goodsNo") or (r.get("data") or {}).get("goodsNo")
        if not gno:
            raise MarketError("ESM: " + json.dumps(r, ensure_ascii=False)[:800])
        return {"market_id": str(gno), "sub_id": json.dumps(r.get("siteDetail", ""), ensure_ascii=False), "raw": r}

    def update_price_stock(self, listing, price, stock):
        pr = price if isinstance(price, dict) else {"Gmkt": price, "Iac": price}
        if self.dry:
            return self.save_dry("update", {"goodsNo": listing["market_id"], "price": price, "stock": stock})
        return self.call("PUT", f"/item/v1/goods/{listing['market_id']}/sell-status",
                         {"isSell": {"Gmkt": True, "Iac": True}, "itemBasicInfo": {"price": pr, "stock": {"Gmkt": stock, "Iac": stock}}})

    def set_sale(self, listing, on):
        if self.dry:
            return self.save_dry("status", {"goodsNo": listing["market_id"], "on": on})
        return self.call("PUT", f"/item/v1/goods/{listing['market_id']}/sell-status", {"isSell": {"Gmkt": on, "Iac": on}})

    def ship(self, ship_ref, courier_code, tracking):
        """발송처리(ESM). 형식이 공개 문서와 다를 수 있어 첫 실제 전송 때 오류를 확인해야 합니다."""
        import datetime
        body = {"OrderNo": ship_ref["OrderNo"], "ShippingDate": datetime.datetime.now().strftime("%Y-%m-%d"),
                "DeliveryCompanyCode": int(courier_code) if str(courier_code).isdigit() else courier_code, "InvoiceNo": tracking}
        if self.dry:
            return {"dry": True, "file": self.save_dry("ship", body)}
        try:
            self.call("POST", f"/shipping/v1/Order/OrderCheck/{ship_ref['OrderNo']}", {})
        except MarketError:
            pass
        return self.call("POST", "/shipping/v1/Delivery/ShippingInfo", body)

    def confirm(self, ship_ref):
        return {"dry": True} if self.dry else self.call("POST", f"/shipping/v1/Order/OrderCheck/{ship_ref['OrderNo']}", {})

    def fetch_orders(self, days=3):
        if self.dry:
            return []
        import datetime
        to = datetime.datetime.now(); frm = to - datetime.timedelta(days=days)
        out = []
        for site in (1, 2):
            r = self.call("POST", "/shipping/v1/Order/RequestOrders", {"siteType": site, "orderStatus": 1, "requestDateType": 1,
                          "requestDateFrom": frm.strftime("%Y-%m-%d %H:%M"), "requestDateTo": to.strftime("%Y-%m-%d %H:%M")})
            for o in r.get("Data", {}).get("RequestOrders", []) if isinstance(r.get("Data"), dict) else []:
                out.append({"order_id": str(o.get("OrderNo")), "product_name": o.get("GoodsName"), "qty": o.get("ContrAmount"),
                            "amount": o.get("OrderAmount"), "buyer": o.get("BuyerName"), "status": "결제완료",
                            "ordered_at": o.get("OrderDate"), "raw": o,
                            "seller_code": o.get("SellerManagementCode") or o.get("OutGoodsNo") or "", "option": o.get("SelOption") or o.get("OptionName") or "",
                            "rcv": {"name": o.get("ReceiverName", ""), "phone": o.get("HpNo") or o.get("TelNo") or "", "zip": o.get("ZipCode", ""),
                                    "addr1": o.get("DelFullAddress") or o.get("Address1") or "", "addr2": o.get("Address2", ""), "memo": o.get("DelMemo", "")},
                            "ship_ref": {"OrderNo": o.get("OrderNo"), "siteType": site}})
        return out
