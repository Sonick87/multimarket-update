import json, os, time, urllib.request, urllib.error, uuid
from ..paths import OUTBOX

class MarketError(Exception):
    pass

class Market:
    code = ""
    name = ""
    cred_fields = []   # (key, 라벨, 비밀여부)
    extra_fields = []  # (key, 라벨, 기본값)

    def __init__(self, creds, extra, dry=False):
        self.creds = creds or {}
        self.extra = extra or {}
        self.dry = dry or not all(self.creds.get(k) for k, _, _ in self.cred_fields)

    def http(self, method, url, headers=None, body=None, raw=None, timeout=30):
        data = raw if raw is not None else (json.dumps(body, ensure_ascii=False).encode() if body is not None else None)
        h = {"Content-Type": "application/json;charset=UTF-8", "Accept": "application/json"}
        h.update(headers or {})
        req = urllib.request.Request(url, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                txt = r.read().decode("utf-8", "replace")
                return json.loads(txt) if txt.strip() else {}
        except urllib.error.HTTPError as e:
            txt = e.read().decode("utf-8", "replace")
            raise MarketError(f"{self.name} {e.code}: {txt[:1500]}")
        except urllib.error.URLError as e:
            raise MarketError(f"{self.name} 접속 실패: {e.reason}")

    def save_dry(self, action, payload):
        fn = os.path.join(OUTBOX, f"{time.strftime('%Y%m%d-%H%M%S')}_{self.code}_{action}_{uuid.uuid4().hex[:6]}.json")
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return fn

    # 하위 클래스가 구현
    def test(self): raise NotImplementedError
    def build_product(self, p, price, detail_html, image_urls): raise NotImplementedError
    def register(self, payload): raise NotImplementedError
    def update_price_stock(self, listing, price, stock): raise NotImplementedError
    def set_sale(self, listing, on): raise NotImplementedError
    def fetch_orders(self, days=3): raise NotImplementedError
    def upload_images(self, paths): return []
    def ship(self, ship_ref, courier_code, tracking): raise NotImplementedError
    def confirm(self, ship_ref): return {}
    def search_category(self, keyword): return []
    def list_store(self, limit=5000): raise MarketError(f"{self.name}: 스토어 상품 불러오기는 아직 네이버만 됩니다")
    def delete_store(self, item): raise MarketError(f"{self.name}: 스토어 상품 삭제는 아직 네이버만 됩니다")
