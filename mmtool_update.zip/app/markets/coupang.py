"""쿠팡 Wing Open API (developers.coupangcorp.com)"""
import hmac, hashlib, time, datetime
from urllib.parse import urlencode
from .base import Market, MarketError

BASE = "https://api-gateway.coupang.com"

class Coupang(Market):
    code, name = "coupang", "쿠팡"
    cred_fields = [("vendor_id", "업체코드(A0...)", False), ("access_key", "Access Key", False), ("secret_key", "Secret Key", True)]
    extra_fields = [("wing_id", "Wing 로그인 ID", ""), ("outbound_code", "출고지 코드", ""), ("return_code", "반품지 센터 코드", ""),
                    ("return_name", "반품지 이름", ""), ("return_phone", "반품지 전화", ""), ("return_zip", "반품지 우편번호", ""),
                    ("return_addr", "반품지 주소", ""), ("return_addr2", "반품지 상세주소", ""), ("as_phone", "A/S 전화", ""),
                    ("importer", "수입자(상호)", ""), ("delivery_fee", "기본 배송비(0=무료)", "0"), ("return_fee", "반품 배송비(편도)", "3000")]

    def call(self, method, path, query=None, body=None):
        qs = urlencode(query or {})
        dt = datetime.datetime.now(datetime.timezone.utc).strftime("%y%m%dT%H%M%SZ")
        msg = dt + method + path + qs
        sig = hmac.new(self.creds["secret_key"].encode(), msg.encode(), hashlib.sha256).hexdigest()
        auth = f"CEA algorithm=HmacSHA256, access-key={self.creds['access_key']}, signed-date={dt}, signature={sig}"
        return self.http(method, BASE + path + ("?" + qs if qs else ""), {"Authorization": auth, "X-EXTENDED-TIMEOUT": "90000"}, body=body)

    def test(self):
        if self.dry:
            return "미리보기 모드(키 없음)"
        r = self.call("GET", f"/v2/providers/marketplace_openapi/apis/api/v1/vendor/shipping-place/outbound", {"pageNum": 1, "pageSize": 10})
        return "연결 성공 · 출고지: " + ", ".join(str(x.get("outboundShippingPlaceCode")) + " " + x.get("shippingPlaceName", "") for x in r.get("content", []))

    def search_category(self, keyword):
        if self.dry:
            return []
        r = self.call("POST", "/v2/providers/openapi/apis/api/v1/categorization/predict", body={"productName": keyword})
        d = r.get("data") or {}
        return [{"id": d.get("predictedCategoryId"), "name": d.get("predictedCategoryName")}] if d else []

    def build_product(self, p, price, detail_html, image_urls):
        e = self.extra
        imgs = image_urls or ["https://example.com/대표이미지를_올려주세요.jpg"]
        fee = int(e.get("delivery_fee") or 0)
        now = datetime.datetime.now()
        images = [{"imageOrder": i, "imageType": "REPRESENTATION" if i == 0 else "DETAIL", "vendorPath": u} for i, u in enumerate(imgs[:10])]
        notices = [{"noticeCategoryName": "기타 재화", "noticeCategoryDetailName": k, "content": v} for k, v in [
            ("품명 및 모델명", p["name"]), ("인증/허가 사항", "해당사항 없음"), ("제조국(원산지)", "중국"),
            ("제조자(수입자)", "중국 제조사 / " + (e.get("importer") or "판매자")), ("소비자상담 관련 전화번호", e.get("as_phone", ""))]]
        item = {
            "itemName": (p["set_desc"] or p["name"])[:150], "originalPrice": int(price * 1.0), "salePrice": price,
            "maximumBuyCount": int(p["stock"] or 0), "maximumBuyForPerson": 0, "maximumBuyForPersonPeriod": 1,
            "outboundShippingTimeDay": 2, "unitCount": int(p["set_qty"] or 1), "adultOnly": "EVERYONE", "taxType": "TAX",
            "parallelImported": "NOT_PARALLEL_IMPORTED", "overseasPurchased": "NOT_OVERSEAS_PURCHASED", "pccNeeded": False,
            "externalVendorSku": f"MM{p['id']}", "images": images, "notices": notices, "attributes": [],
            "contents": [{"contentsType": "HTML", "contentDetails": [{"content": detail_html, "detailType": "TEXT"}]}],
        }
        return {
            "displayCategoryCode": int(p["coupang_cat"]) if str(p["coupang_cat"] or "").isdigit() else 0,
            "sellerProductName": p["name"][:100], "vendorId": self.creds.get("vendor_id", ""),
            "saleStartedAt": now.strftime("%Y-%m-%dT%H:%M:%S"), "saleEndedAt": "2099-01-01T23:59:59",
            "displayProductName": p["name"][:100], "brand": "", "generalProductName": p["name"][:100],
            "deliveryMethod": "SEQUENCIAL", "deliveryCompanyCode": "CJGLS",
            "deliveryChargeType": "FREE" if fee == 0 else "NOT_FREE", "deliveryCharge": fee, "freeShipOverAmount": 0,
            "deliveryChargeOnReturn": int(e.get("return_fee") or 3000), "remoteAreaDeliverable": "N", "unionDeliveryType": "UNION_DELIVERY",
            "returnCenterCode": e.get("return_code", ""), "returnChargeName": e.get("return_name", ""),
            "companyContactNumber": e.get("return_phone", ""), "returnZipCode": e.get("return_zip", ""),
            "returnAddress": e.get("return_addr", ""), "returnAddressDetail": e.get("return_addr2", ""),
            "returnCharge": int(e.get("return_fee") or 3000), "outboundShippingPlaceCode": e.get("outbound_code", ""),
            "vendorUserId": e.get("wing_id", ""), "requested": True, "items": [item],
        }

    def register(self, payload):
        if self.dry:
            return {"dry": True, "file": self.save_dry("register", payload), "market_id": "DRY-C", "sub_id": ""}
        if not payload["displayCategoryCode"]:
            raise MarketError("쿠팡 카테고리 코드가 비어 있습니다")
        r = self.call("POST", "/v2/providers/seller_api/apis/api/v1/marketplace/seller-products", body=payload)
        if str(r.get("code")) not in ("SUCCESS", "200"):
            raise MarketError("쿠팡: " + str(r))
        return {"market_id": str(r.get("data")), "sub_id": "", "raw": r}

    def _vendor_item(self, listing):
        if listing["sub_id"]:
            return listing["sub_id"]
        r = self.call("GET", f"/v2/providers/seller_api/apis/api/v1/marketplace/seller-products/{listing['market_id']}")
        items = (r.get("data") or {}).get("items") or []
        vid = items and items[0].get("vendorItemId")
        if not vid:
            raise MarketError("쿠팡 승인 대기 중이라 옵션 ID가 아직 없습니다")
        return str(vid)

    def update_price_stock(self, listing, price, stock):
        if self.dry:
            return self.save_dry("update", {"seller_product": listing["market_id"], "price": price, "stock": stock})
        vid = self._vendor_item(listing)
        base = f"/v2/providers/seller_api/apis/api/v1/marketplace/vendor-items/{vid}"
        self.call("PUT", f"{base}/prices/{price}", {"forceSalePriceUpdate": "true"})
        return self.call("PUT", f"{base}/quantities/{stock}")

    def set_sale(self, listing, on):
        if self.dry:
            return self.save_dry("status", {"seller_product": listing["market_id"], "on": on})
        vid = self._vendor_item(listing)
        return self.call("PUT", f"/v2/providers/seller_api/apis/api/v1/marketplace/vendor-items/{vid}/sales/{'resume' if on else 'stop'}")

    def fetch_orders(self, days=3):
        if self.dry:
            return []
        out = []
        to = datetime.date.today()
        frm = to - datetime.timedelta(days=days)
        for st in ("ACCEPT", "INSTRUCT", "DEPARTURE", "DELIVERING"):
            r = self.call("GET", f"/v2/providers/openapi/apis/api/v4/vendors/{self.creds['vendor_id']}/ordersheets",
                          {"createdAtFrom": frm.isoformat(), "createdAtTo": to.isoformat(), "status": st, "maxPerPage": 50})
            for o in r.get("data", []):
                rv = o.get("receiver") or {}
                for it in o.get("orderItems", []):
                    out.append({"order_id": f"{o.get('orderId')}-{it.get('vendorItemId')}", "product_name": it.get("vendorItemName"),
                                "qty": it.get("shippingCount"), "amount": it.get("orderPrice"), "buyer": (o.get("orderer") or {}).get("name"),
                                "status": st, "ordered_at": o.get("orderedAt"), "raw": o,
                                "seller_code": it.get("externalVendorSkuCode") or "", "option": it.get("sellerProductItemName") or "",
                                "rcv": {"name": rv.get("name", ""), "phone": rv.get("safeNumber") or rv.get("receiverNumber") or "",
                                        "zip": rv.get("postCode", ""), "addr1": rv.get("addr1", ""), "addr2": rv.get("addr2", ""),
                                        "memo": o.get("parcelPrintMessage") or ""},
                                "ship_ref": {"shipmentBoxId": o.get("shipmentBoxId"), "orderId": o.get("orderId"), "vendorItemId": it.get("vendorItemId")}})
        return out

    def confirm(self, ship_ref):
        """상품준비중 처리"""
        body = {"vendorId": self.creds.get("vendor_id"), "shipmentBoxIds": [ship_ref["shipmentBoxId"]]}
        if self.dry:
            return {"dry": True}
        return self.call("PUT", f"/v2/providers/openapi/apis/api/v4/vendors/{self.creds['vendor_id']}/ordersheets/acknowledgement", body=body)

    def ship(self, ship_ref, courier_code, tracking):
        """송장 업로드"""
        body = {"vendorId": self.creds.get("vendor_id"), "orderSheetInvoiceApplyDtos": [{
            "shipmentBoxId": ship_ref["shipmentBoxId"], "orderId": ship_ref["orderId"], "vendorItemId": ship_ref["vendorItemId"],
            "deliveryCompanyCode": courier_code, "invoiceNumber": tracking, "splitShipping": False, "preSplitShipped": False, "estimatedShippingDate": ""}]}
        if self.dry:
            return {"dry": True, "file": self.save_dry("ship", body)}
        try:
            self.confirm(ship_ref)
        except MarketError:
            pass   # 이미 상품준비중이면 오류가 날 수 있음
        r = self.call("POST", f"/v2/providers/openapi/apis/api/v4/vendors/{self.creds['vendor_id']}/orders/invoices", body=body)
        bad = [x for x in ((r.get("data") or {}).get("responseList") or []) if not x.get("succeed", True)]
        if bad:
            raise MarketError("쿠팡 송장 등록 실패: " + str(bad)[:600])
        return r
