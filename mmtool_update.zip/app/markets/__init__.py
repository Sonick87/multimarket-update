from .naver import Naver
from .coupang import Coupang
from .esm import ESM
from .pending import ALL_PENDING, FEATS, FEAT_NAMES
Naver.ready = Coupang.ready = ESM.ready = True
Naver.done = ["register", "load", "edit", "soldout", "orders", "ship"]
Coupang.done = ESM.done = ["register", "edit", "soldout", "orders", "ship"]
Naver.plan = Coupang.plan = ESM.plan = FEATS
MARKETS = {m.code: m for m in (Naver, Coupang, ESM, *ALL_PENDING)}
# 화면 표(14개 마켓). ESM 계정 하나가 옥션·G마켓을 같이 다룹니다.
MARKET_ROWS = [("쿠팡", "coupang"), ("스마트스토어", "naver"), ("11번가", "st11"), ("옥션", "esm"), ("G마켓", "esm"), ("롯데온", "lotteon"),
               ("톡스토어", "kakao"), ("GS SHOP", "gsshop"), ("토스", "toss"), ("SSG.COM", "ssg"), ("CJ온스타일", "cjon"),
               ("홈앤쇼핑", "hns"), ("W쇼핑", "wshop"), ("SK스토아", "skstoa")]
