from .naver import Naver
from .coupang import Coupang
from .esm import ESM
MARKETS = {m.code: m for m in (Naver, Coupang, ESM)}
