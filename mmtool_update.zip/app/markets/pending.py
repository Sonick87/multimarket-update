"""아직 API 연동 코드가 없는 마켓. 키는 미리 저장해 둘 수 있고, 연동 코드가 들어오면 자동 업데이트로 켜집니다."""
from .base import Market, MarketError

FEATS = ["register", "load", "edit", "soldout", "orders", "ship", "qna"]
FEAT_NAMES = {"register": "상품등록", "load": "상품불러오기", "edit": "상품수정", "soldout": "상품품절", "orders": "주문수집", "ship": "송장전송", "qna": "고객문의"}

class Pending(Market):
    ready = False
    where = ""      # 키 받는 곳 안내
    def _no(self, *a, **k):
        raise MarketError(f"{self.name}: 연동 준비 중입니다. 키는 저장해 두면 연동이 들어올 때 자동으로 씁니다.")
    def test(self):
        return "키 저장됨 · 연동 준비 중" if any(self.creds.values()) else "키 없음 · 연동 준비 중"
    build_product = register = update_price_stock = set_sale = ship = _no
    def fetch_orders(self, days=3):
        return []

def make(code, name, fields, where, plan):
    return type(code.capitalize(), (Pending,), {"code": code, "name": name, "cred_fields": fields, "where": where, "plan": plan})

FULL = FEATS
ORD = ["orders", "ship", "qna"]
St11 = make("st11", "11번가", [("api_key", "Open API Key", True)], "11번가 셀러오피스 → 셀러정보 → Open API 센터 → API Key 발급, 허용 IP에 서버 IP 등록", FULL)
Lotteon = make("lotteon", "롯데온", [("tr_no", "거래처번호", False), ("api_key", "API 인증키", True)], "롯데온 스토어센터 → 판매자정보 → OpenAPI 관리 → 인증키 발급, 허용 IP에 서버 IP 등록", FULL)
Kakao = make("kakao", "톡스토어", [("app_key", "앱 키(REST)", True), ("seller_id", "판매자 ID", False)], "카카오 톡스토어 판매자센터 → 판매관리 API 이용 신청(승인 필요)", FULL)
Gsshop = make("gsshop", "GS SHOP", [("sup_cd", "협력사 코드", False), ("api_key", "API 인증키", True)], "GS SHOP 파트너센터(입점 후) → 담당 MD에게 API 연동 신청", FULL)
Toss = make("toss", "토스", [("api_key", "API 키", True)], "토스쇼핑 판매자센터 → API 연동 신청", ["load", "soldout", "orders", "ship", "qna"])
Ssg = make("ssg", "SSG.COM", [("api_key", "API 인증키", True)], "SSG 파트너오피스(입점 후) → API 인증키 발급", ORD)
Cjon = make("cjon", "CJ온스타일", [("ven_cd", "협력사 코드", False), ("api_key", "API 인증키", True)], "CJ온스타일 협력사 시스템(입점 후) → 담당 MD에게 API 연동 신청", ORD)
Hns = make("hns", "홈앤쇼핑", [("ven_cd", "협력사 코드", False), ("api_key", "API 인증키", True)], "홈앤쇼핑 협력사 시스템(입점 후) → API 연동 신청", ORD)
Wshop = make("wshop", "W쇼핑", [("ven_cd", "협력사 코드", False), ("api_key", "API 인증키", True)], "W쇼핑 협력사 시스템(입점 후) → API 연동 신청", ORD)
Skstoa = make("skstoa", "SK스토아", [("ven_cd", "협력사 코드", False), ("api_key", "API 인증키", True)], "SK스토아 협력사 시스템(입점 후) → API 연동 신청", ORD)
ALL_PENDING = [St11, Lotteon, Kakao, Gsshop, Toss, Ssg, Cjon, Hns, Wshop, Skstoa]
