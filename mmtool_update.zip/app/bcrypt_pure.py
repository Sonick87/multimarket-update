"""순수 파이썬 bcrypt (네이버 커머스API 서명용). bcrypt 패키지가 있으면 그것을 씁니다."""
_B64 = "./ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
_P = None
_S = None


def _pi_words(n):
    # 파이의 소수부 16진수 자릿수를 32비트 단어 n개로 (Blowfish 초기값)
    digits = n * 8 + 10
    prec = digits * 4 + 64
    one = 1 << prec

    def arctan_inv(x):
        total, term, k, sign = 0, one // x, 1, 1
        x2 = x * x
        while term:
            total += sign * (term // k)
            term //= x2
            k += 2
            sign = -sign
        return total

    pi = 16 * arctan_inv(5) - 4 * arctan_inv(239)
    frac = pi - (3 << prec)
    words = []
    for _ in range(n):
        frac <<= 32
        w = frac >> prec
        frac &= one - 1
        words.append(w & 0xFFFFFFFF)
    return words


def _init():
    global _P, _S
    if _P is None:
        w = _pi_words(18 + 1024)
        _P = w[:18]
        _S = [w[18 + 256 * i: 18 + 256 * (i + 1)] for i in range(4)]


def _enc(P, S, l, r):
    s0, s1, s2, s3 = S
    for i in range(0, 16, 2):
        l ^= P[i]
        r ^= ((((s0[l >> 24] + s1[(l >> 16) & 255]) & 0xFFFFFFFF) ^ s2[(l >> 8) & 255]) + s3[l & 255]) & 0xFFFFFFFF
        r ^= P[i + 1]
        l ^= ((((s0[r >> 24] + s1[(r >> 16) & 255]) & 0xFFFFFFFF) ^ s2[(r >> 8) & 255]) + s3[r & 255]) & 0xFFFFFFFF
    return r ^ P[17], l ^ P[16]


def _stream(data, pos):
    w = 0
    for _ in range(4):
        w = ((w << 8) | data[pos]) & 0xFFFFFFFF
        pos = (pos + 1) % len(data)
    return w, pos


def _expand(P, S, key, salt=None):
    pos = 0
    for i in range(18):
        w, pos = _stream(key, pos)
        P[i] ^= w
    l = r = 0
    spos = 0
    for i in range(0, 18, 2):
        if salt:
            a, spos = _stream(salt, spos); b, spos = _stream(salt, spos)
            l ^= a; r ^= b
        l, r = _enc(P, S, l, r)
        P[i], P[i + 1] = l, r
    for box in S:
        for i in range(0, 256, 2):
            if salt:
                a, spos = _stream(salt, spos); b, spos = _stream(salt, spos)
                l ^= a; r ^= b
            l, r = _enc(P, S, l, r)
            box[i], box[i + 1] = l, r


def _b64enc(data):
    out, i = [], 0
    while i < len(data):
        c1 = data[i]; i += 1
        out.append(_B64[c1 >> 2]); c1 = (c1 & 3) << 4
        if i >= len(data):
            out.append(_B64[c1]); break
        c2 = data[i]; i += 1
        out.append(_B64[c1 | (c2 >> 4)]); c1 = (c2 & 15) << 2
        if i >= len(data):
            out.append(_B64[c1]); break
        c2 = data[i]; i += 1
        out.append(_B64[c1 | (c2 >> 6)]); out.append(_B64[c2 & 63])
    return "".join(out)


def _b64dec(s, n):
    vals = [_B64.index(c) for c in s]
    out, i = bytearray(), 0
    while len(out) < n and i + 1 < len(vals):
        out.append(((vals[i] << 2) | (vals[i + 1] >> 4)) & 255)
        if len(out) >= n or i + 2 >= len(vals): break
        out.append(((vals[i + 1] << 4) | (vals[i + 2] >> 2)) & 255)
        if len(out) >= n or i + 3 >= len(vals): break
        out.append(((vals[i + 2] << 6) | vals[i + 3]) & 255)
        i += 4
    return bytes(out)


def hashpw(password: bytes, salt: bytes) -> bytes:
    try:
        import bcrypt as _b  # 설치돼 있으면 빠른 C 구현 사용
        return _b.hashpw(password, salt)
    except ImportError:
        pass
    _init()
    s = salt.decode()
    parts = s.split("$")
    ver, cost, rest = parts[1], int(parts[2]), parts[3]
    raw_salt = _b64dec(rest[:22], 16)
    key = password + b"\x00" if ver >= "2a" else password
    key = key[:72]
    P = list(_P); S = [list(b) for b in _S]
    _expand(P, S, key, raw_salt)
    for _ in range(1 << cost):
        _expand(P, S, key)
        _expand(P, S, raw_salt)
    ctext = [0x4F727068, 0x65616E42, 0x65686F6C, 0x64657253, 0x63727944, 0x6F756274]
    for _ in range(64):
        for j in range(0, 6, 2):
            ctext[j], ctext[j + 1] = _enc(P, S, ctext[j], ctext[j + 1])
    out = b"".join(w.to_bytes(4, "big") for w in ctext)[:23]
    return ("$%s$%02d$%s%s" % (ver, cost, _b64enc(raw_salt), _b64enc(out))).encode()
