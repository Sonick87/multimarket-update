import json, os, re, time, threading, traceback, io, csv, struct, zlib, mimetypes, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlparse, parse_qs, quote
from email.parser import BytesParser
from email.policy import default as email_policy

from . import auth, pricing, detail, xlsx, naming, updater
from . import images as imgmod
from . import finder
from . import channels as chs
from . import notify, occsv
from .db import q, x, get_setting, set_setting, log
from .paths import IMAGES, OUTBOX, PAGES
from .secret import seal, unseal
from .markets import MARKETS
from .markets.base import MarketError
from .ui import page, e, ICON_SVG, MANIFEST, SW

ROUTES = []
def route(method, pattern, public=False, admin=False):
    def deco(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), fn, public, admin))
        return fn
    return deco

class Redirect(Exception):
    def __init__(self, to, flash=None, err=False):
        self.to, self.flash, self.err = to, flash, err

def go(to, flash=None, err=False):
    raise Redirect(to, flash, err)

# ---------- 공통 ----------
def market_for(acc, force_dry=False):
    cls = MARKETS[acc["market"]]
    creds = json.loads(unseal(acc["creds"]) or "{}") if acc["creds"] else {}
    dry = force_dry or get_setting("dry_run", True)
    return cls(creds, json.loads(acc["extra"] or "{}"), dry=dry)

def product(pid):
    p = q("SELECT * FROM products WHERE id=?", (pid,), one=True)
    if not p:
        go("/products", "상품이 없습니다", True)
    return p

def img_list(p):
    try:
        return json.loads(p["images"] or "[]")
    except ValueError:
        return []

def local_img_urls(p):
    return [i if i.startswith("http") else "/img/" + quote(i) for i in img_list(p)]

def make_detail(p, use_ai=False, image_urls=None):
    copy = None
    if use_ai:
        copy = detail.ai_copy(p)
    copy = copy or detail.auto_copy(p)
    return copy, detail.render(p, copy, image_urls if image_urls is not None else local_img_urls(p), p["template"] or "clean")

SHORT = {"naver": "N", "coupang": "C", "gmarket": "G", "auction": "A"}

def where_label(market, channel=None):
    """등록·주문 기록에 보여 줄 판매처 이름"""
    if market == "esm":
        return "지마켓·옥션"
    if market in MARKETS:
        return MARKETS[market].name
    return chs.label(channel or market)

def short_of(ch):
    return SHORT.get(ch["code"]) or ch["name"][:5]

def acc_price(p, market):
    """API 계정 등록가(원). ESM은 지마켓·옥션 가격을 따로 계산"""
    if market == "esm":
        return {"Gmkt": pricing.price_krw(p, "gmarket"), "Iac": pricing.price_krw(p, "auction")}
    return pricing.price_krw(p, market)

def price_num(pr):
    return pr["Gmkt"] if isinstance(pr, dict) else pr

def price_txt(pr):
    return f"지마켓 {pr['Gmkt']:,}원 · 옥션 {pr['Iac']:,}원" if isinstance(pr, dict) else f"{pr:,}원"

# ---------- 로그인 ----------
@route("GET", "/setup", public=True)
def setup_get(h):
    if q("SELECT 1 FROM users LIMIT 1"):
        go("/login")
    return page("처음 설정", """<div class="card" style="max-width:420px;margin:40px auto"><h1>처음 설정 · 관리자 만들기</h1>
<form method="post"><label>아이디</label><input name="username" required><label>이름</label><input name="name">
<label>비밀번호(8자 이상)</label><input name="pw" type="password" minlength="8" required><br><br><button class="btn">관리자 만들기</button></form></div>""")

@route("POST", "/setup", public=True)
def setup_post(h):
    if q("SELECT 1 FROM users LIMIT 1"):
        go("/login")
    f = h.form()
    auth.create_user(f["username"].strip(), f.get("name", ""), f["pw"], "admin")
    go("/login", "관리자 계정이 만들어졌습니다. 로그인하세요.")

@route("GET", "/login", public=True)
def login_get(h):
    if not q("SELECT 1 FROM users LIMIT 1"):
        go("/setup")
    return page("로그인", """<div class="card" style="max-width:380px;margin:50px auto"><h1>멀티마켓 매니저</h1>
<form method="post"><label>아이디</label><input name="username" required autofocus><label>비밀번호</label><input name="pw" type="password" required>
<br><br><button class="btn" style="width:100%">로그인</button></form></div>""", flash=h.flash, err=h.flash_err)

@route("POST", "/login", public=True)
def login_post(h):
    f = h.form()
    tok = auth.login(f.get("username", "").strip(), f.get("pw", ""))
    if not tok:
        go("/login", "아이디 또는 비밀번호가 틀렸습니다", True)
    log(f.get("username"), "로그인")
    h.set_cookie = f"mm_s={tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age=43200"
    go("/")

@route("GET", "/logout")
def logout(h):
    auth.logout(h.token)
    h.set_cookie = "mm_s=; Path=/; Max-Age=0"
    go("/login")

# ---------- 홈 ----------
@route("GET", "/")
def home(h):
    c = lambda sql: q(sql, one=True)[0]
    dry = get_setting("dry_run", True)
    stats = [("상품", c("SELECT COUNT(*) FROM products")), ("마켓 계정", c("SELECT COUNT(*) FROM accounts WHERE active=1")),
             ("등록된 상품", c("SELECT COUNT(*) FROM listings WHERE dry=0")), ("최근 3일 주문", c("SELECT COUNT(*) FROM orders WHERE ordered_at >= date('now','-3 day')"))]
    st = "".join(f'<div class="card"><div class="mut">{k}</div><div class="stat">{v}</div></div>' for k, v in stats)
    logs = "".join(f"<tr><td class='mut'>{time.strftime('%m-%d %H:%M', time.localtime(r['ts']))}</td><td>{e(r['user'] or '')}</td><td>{e(r['action'])}</td><td class='mut'>{e((r['detail'] or '')[:120])}</td></tr>"
                   for r in q("SELECT * FROM logs ORDER BY id DESC LIMIT 15"))
    upd = (f'<div class="flash">새 버전 {e(updater.state["latest"])} 이 있습니다. <a href="/admin">업데이트하기</a></div>' if updater.available() else "")
    mode = upd + ('<div class="flash err">지금은 <b>미리보기 모드</b>입니다. 마켓에 실제로 올라가지 않고 보낼 내용만 저장됩니다. 설정에서 끌 수 있습니다.</div>' if dry else "")
    steps = """<div class="card"><h2>사용 순서</h2><ol style="margin:0;padding-left:20px;line-height:2">
<li><a href="/accounts">마켓 계정</a>에 네이버·쿠팡·지마켓 API 키 넣기</li><li><a href="/products/import">엑셀로 상품 불러오기</a> 또는 <a href="/products/new">직접 추가</a></li>
<li>상품마다 사진 올리고 카테고리 코드 넣기 → <b>상세페이지 자동 제작</b></li><li>상품 목록에서 골라 <b>선택 마켓에 등록</b></li><li><a href="/listings">등록현황</a>에서 가격·재고·판매중지, <a href="/orders">주문</a>에서 주문 모아보기</li></ol></div>"""
    return page("홈", f'<h1>홈</h1>{mode}<div class="grid">{st}</div>{steps}<div class="card"><h2>최근 작업 <a class="mut" href="/history">전체 보기</a></h2><div class="tbl"><table>{logs or "<tr><td>아직 없음</td></tr>"}</table></div></div>', h.user, "/", h.flash, h.flash_err)

# ---------- 상품 ----------
@route("GET", "/products")
def products(h):
    kw = h.qs.get("q", "")
    typ = h.qs.get("type", "")
    rows = q("SELECT * FROM products WHERE (name LIKE ? OR theme LIKE ? OR keyword LIKE ?) AND (?='' OR COALESCE(supply_type,'사입')=?) ORDER BY id DESC LIMIT 500", (f"%{kw}%",) * 3 + (typ, typ))
    accs = q("SELECT * FROM accounts WHERE active=1 ORDER BY market,id")
    lst = {}
    allch = chs.all_channels()
    chmap = {c["code"]: c for c in chs.all_channels(False)}
    for l in q("SELECT product_id, market, channel, dry FROM listings"):
        mark = "G·A" if l["market"] == "esm" else (short_of(chmap[l["channel"]]) if l["channel"] in chmap else (l["channel"] or l["market"] or "?"))
        lst.setdefault(l["product_id"], set()).add(("🟡" if l["dry"] else "🟢") + mark)
    pol_opts = "".join(f'<option value="{i}">{e(n)}</option>' for i, n in pricing.policies())
    trs = []
    for p in rows:
        im = local_img_urls(p)
        th = f'<img class="thumb" src="{e(im[0])}">' if im else '<div class="thumb"></div>'
        pc = pricing.policy_for(p)
        pr = "<br>".join(f"<span class='mut'>{e(short_of(ch))}</span> {chs.fmt(pricing.price_for(p, ch, pc), ch)}" for ch in allch)
        trs.append(f"<tr><td><input type='checkbox' name='pid' value='{p['id']}'></td><td>{th}</td><td><a href='/products/{p['id']}'><b>{e(p['name'])}</b></a> <span class='tag'>{e(p['supply_type'] or '사입')}</span>{' <span class=tag>' + e(p['status']) + '</span>' if (p['status'] or '').startswith('품절') else ''}<div class='mut'>{e(p['theme'] or '')} · {e(p['set_desc'] or '')}</div></td>"
                   f"<td class='hide-m'>{pr}</td><td>{' '.join(sorted(lst.get(p['id'], [])))}</td><td class='hide-m'>{'✅' if p['detail_html'] else '—'}</td></tr>")
    acc_opts = "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' name='acc' value='{a['id']}' style='width:auto' checked> {e(MARKETS[a['market']].name)} · {e(a['label'])}</label>" for a in accs)
    acc_opts += "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' name='ch' value='{e(c['code'])}' style='width:auto'> {e(c['name'])} <span class='mut'>(엑셀)</span></label>" for c in allch if not c["api"])
    acc_opts = acc_opts or "<span class='mut'>마켓 계정이나 판매처를 먼저 추가하세요</span>"
    body = f"""<h1>상품</h1><div class="row" style="margin-bottom:12px"><form class="row" style="flex:1"><input name="q" value="{e(kw)}" placeholder="상품명·테마 검색" style="max-width:280px"><select name="type" style="max-width:120px"><option value="">사입+위탁</option><option {'selected' if typ == '사입' else ''}>사입</option><option {'selected' if typ == '위탁' else ''}>위탁</option></select><button class="btn gray">검색</button></form>
<a class="btn gray" href="/finder">잘 팔릴 상품 찾기</a><a class="btn gray" href="/suppliers">오너클랜 위탁상품 가져오기</a>
<a class="btn" href="/products/new">+ 직접 추가</a><a class="btn gray" href="/products/import">엑셀 불러오기</a></div>
<form method="post" action="/bulk" data-busy><div class="card"><div class="row" style="margin-bottom:8px">{acc_opts}</div><div class="row">
<button class="btn" name="do" value="detail" data-autoimg="bulk">선택 상품 상세페이지 자동 제작</button><button class="btn" name="do" value="detail_ai" data-autoimg="bulk">AI 문구로 제작</button><span class="mut" id="autoimg_note">사진도 자동으로 가져와 가공합니다</span>
<button class="btn green" name="do" value="register">선택 판매처에 등록</button><button class="btn red" name="do" value="delete" onclick="return confirm('삭제할까요?')">삭제</button></div>
<div class="row" style="margin-top:10px"><select name="bulk_policy" style="max-width:180px"><option value="">기본 정책</option>{pol_opts}</select><input name="bulk_margin" placeholder="개별 마진(비우면 정책값)" style="max-width:190px">
<button class="btn gray" name="do" value="price">가격 정책·마진 적용</button><button class="btn gray" name="do" value="sync">등록된 마켓 가격 동기화</button>
<button class="btn gray" name="do" value="soldout" onclick="return confirm('재고 0 + 모든 마켓 판매중지할까요?')">품절 처리</button><button class="btn gray" name="do" value="resume">판매 재개</button></div></div>
<div class="card tbl"><table><tr><th><input type="checkbox" data-all="pid" style="width:auto"></th><th></th><th>상품</th><th class="hide-m">판매가(판매처별)</th><th>등록</th><th class="hide-m">상세</th></tr>
{''.join(trs) or '<tr><td colspan=6>상품이 없습니다</td></tr>'}</table></div></form><p class="mut">등록 표시: 🟢 실제 등록(또는 엑셀 내보냄) · 🟡 미리보기 · N 네이버 · C 쿠팡 · G 지마켓 · A 옥션. 해외몰 등 직접 추가한 판매처는 <a href="/channels">판매처</a>에서 엑셀로 받아 각 사이트 대량등록에 올립니다.</p>"""
    return page("상품", body, h.user, "/products", h.flash, h.flash_err)

FIELDS = [("name", "상품명(마켓 노출)"), ("theme", "테마/분류"), ("keyword", "검색 키워드"), ("set_desc", "세트 구성(예: 4개 컬러 세트)"),
          ("set_qty", "세트 수량(개)"), ("cost_cny", "단가(위안)"), ("cost_krw", "단가(원, 입력 시 위안보다 우선)"), ("moq", "MOQ"),
          ("stock", "재고"), ("margin", "개별 마진(비우면 정책값)"), ("price_override", "판매가 직접 지정(비우면 자동)"), ("naver_cat", "네이버 카테고리 ID"),
          ("coupang_cat", "쿠팡 카테고리 코드"), ("esm_cat", "지마켓/옥션 카테고리 코드"), ("source_url", "소싱 링크"), ("source_name", "원문 상품명"),
          ("supplier_key", "위탁: 오너클랜 상품코드(W...)"), ("supplier_option", "위탁: 오너클랜 옵션값(/로 구분)"), ("supply_price", "위탁: 공급가(원)"),
          ("supply_ship", "위탁: 공급처 배송비(원)"), ("fixed_price", "위탁: 소비자가 준수가(원, 이 아래로 안 팖)")]
NUM = {"set_qty", "cost_cny", "cost_krw", "stock", "price_override", "margin", "supply_price", "supply_ship", "fixed_price"}

def num(v, typ=float):
    try:
        return typ(str(v).replace(",", "")) if str(v).strip() not in ("", "None") else None
    except ValueError:
        return None

@route("GET", "/products/new")
def product_new(h):
    pid = x("INSERT INTO products(name,set_qty,stock,updated,updated_by) VALUES('새 상품',1,100,?,?)", (time.time(), h.user["username"]))
    go(f"/products/{pid}")

@route("GET", r"/products/(\d+)")
def product_get(h, pid):
    p = product(pid)
    c = pricing.cfg()
    inputs = "".join(f'<div><label>{lab}</label><input name="{k}" value="{e("" if p[k] is None else (f"{p[k]:g}" if isinstance(p[k], float) else str(p[k])))}"></div>' for k, lab in FIELDS if k != "margin")
    themes = "".join(f'<option value="{k}" {"selected" if (p["template"] or "clean") == k else ""}>{v["label"]}</option>' for k, v in detail.THEMES.items())
    pts = p["points"] or ""
    try:
        pts = "\n".join(json.loads(pts))
    except ValueError:
        pass
    c = pricing.policy_for(p)
    pol_opts = '<option value="">기본 정책</option>' + "".join(f'<option value="{i}" {"selected" if p["policy_id"] == i else ""}>{e(n)}</option>' for i, n in pricing.policies())
    unit = "원" if c["margin_mode"] == "won" else "%"
    pcm, pcs = pricing.pj(p, "ch_margin"), pricing.pj(p, "ch_ship")
    fv = lambda d, k: "" if d.get(k) in (None, "") else f"{d[k]:g}"
    bd = "".join(f"<tr><td>{e(ch['name'])}<div class='mut'>수수료 {ch['fee']:g}%</div></td>"
                 f"<td><input name='pm_{ch['code']}' value='{fv(pcm, ch['code'])}' placeholder='{b['target']:g}' style='width:90px'><div class='mut'>지금 {b['target']:g}{unit} ({b['source']})</div></td>"
                 f"<td><input name='ps_{ch['code']}' value='{fv(pcs, ch['code'])}' placeholder='{b['ship']:,}' style='width:90px'><div class='mut'>지금 {b['ship']:,}원</div></td>"
                 f"<td><b>{b['price_text']}</b>{'' if ch['currency'] == 'KRW' else '<div class=mut>≈' + format(b['price_krw'], ',') + '원</div>'}</td><td>{b['total_cost']:,}</td><td>{b['fee']:,}</td><td>{b['profit']:,}</td><td>{b['margin_on_cost']}%</td><td>{b['margin_on_price']}%</td></tr>"
                 for ch in chs.all_channels() for b in [pricing.breakdown(p, ch, c)])
    imgs = "".join(f'<div style="text-align:center"><img src="{e(u)}"><br><button class="btn sm red" name="del_img" value="{i}">삭제</button></div>' for i, u in enumerate(local_img_urls(p)))
    lst = "".join(f"<tr><td>{e(where_label(l['market'], l['channel']))}</td><td>{e(l['label'] or '엑셀')}</td><td>{e(l['market_id'] or '')}</td><td>{'미리보기' if l['dry'] else '실제'}</td><td>{e(l['status'] or '')}</td></tr>"
                  for l in q("SELECT l.*, a.label FROM listings l LEFT JOIN accounts a ON a.id=l.account_id WHERE product_id=?", (pid,)))
    st = p["supply_type"] or "사입"
    stsel = f"""<div><label>판매 방식</label><select name="supply_type"><option value="사입">사입(우리가 재고 보유·직접 발송)</option><option value="위탁" {'selected' if st == '위탁' else ''}>위탁(오너클랜이 발송)</option></select></div>"""
    ocinfo = (f"<p class='mut'>위탁 상품: 오너클랜 {e(p['supplier_key'] or '')} · 상태 {e(p['supplier_status'] or '확인 전')} · 마지막 확인 {time.strftime('%m-%d %H:%M', time.localtime(p['supplier_checked'])) if p['supplier_checked'] else '없음'} · "
              f"총원가 = 공급가 × 세트수량 + 공급처 배송비(사입 부대비용·포장비 없음)</p>") if st == "위탁" else ""
    body = f"""<h1>{e(p['name'])} <span class="tag">{e(st)}</span></h1><form method="post" enctype="multipart/form-data" data-busy>
<div class="card"><h2>기본 정보</h2>{ocinfo}<div class="grid">{stsel}{inputs}</div>
<label>셀링 포인트(한 줄에 하나, 비우면 자동)</label><textarea name="points">{e(pts)}</textarea>
<label>주의사항(한 줄에 하나, 비우면 기본 문구)</label><textarea name="cautions">{e(p['cautions'] or '')}</textarea>
<label>메모(AI 문구 참고용)</label><textarea name="memo" style="min-height:60px">{e(p['memo'] or '')}</textarea>
<br><button class="btn" name="do" value="save">저장</button></div>
<div class="card"><h2>사진</h2><div class="imgs">{imgs or '<span class="mut">사진이 없습니다. 첫 번째 사진이 대표 이미지가 됩니다.</span>'}</div>
<label>사진 추가(여러 장 선택 가능)</label><input type="file" name="images" multiple accept="image/*"><label>또는 이미지 주소(한 줄에 하나)</label><textarea name="img_urls" style="min-height:50px"></textarea>
<br><button class="btn" name="do" value="save">사진 올리기</button></div>
<div class="card"><h2>판매가 계산</h2><div class="row"><div style="flex:1;min-width:200px"><label>가격 정책</label><select name="policy_id">{pol_opts}</select></div>
<div style="flex:1;min-width:200px"><label>이 상품만 마진 ({pricing.MODE_LABEL[c['margin_mode']]}, 비우면 정책값)</label><input name="margin" value="{'' if p['margin'] is None else f"{p['margin']:g}"}"></div>
<div style="flex:1;min-width:200px"><label>이 상품 배송비(원, 모든 판매처, 비우면 기본)</label><input name="ship" value="{'' if p['ship'] is None else f"{p['ship']:g}"}"></div>
<div style="align-self:flex-end"><button class="btn" name="do" value="save">적용</button></div></div><br><div class="tbl"><table>
<tr><th>판매처</th><th>이 상품 마진({'원' if c['margin_mode'] == 'won' else '%'})</th><th>이 상품 배송비(원)</th><th>판매가</th><th>총원가(원)</th><th>수수료(원)</th><th>이익(원)</th><th>원가 대비</th><th>판매가 대비</th></tr>{bd}</table></div>
<p class="mut">판매처마다 마진·배송비를 넣고 <b>적용</b>을 누르면 판매가가 다시 계산됩니다. 빈 칸은 위의 '이 상품만 마진' → 가격 정책 → 판매처 기본값 순서로 채워집니다. 이미 올린 마켓에 반영하려면 상품 목록에서 '등록된 마켓 가격 동기화'를 누르세요.</p>
<p class="mut">정책: {e(c['name'])} · 총원가 = 단가×{c['landed_mult']}(사입 부대비용) × 세트수량 + 포장 {c['pack_cost']:,} + 택배. 정책은 <a href="/policies">가격 정책</a>, 수수료·통화·환율은 <a href="/channels">판매처</a>에서 바꿉니다. 마켓 등록명 미리보기: {e(naming.process(p['name'], 'naver'))}</p></div>
<div class="card"><h2>상세페이지</h2><div class="row"><select name="template" style="max-width:200px">{themes}</select>
<button class="btn" name="do" value="detail" data-autoimg="{pid}">자동 제작</button><button class="btn" name="do" value="detail_ai" data-autoimg="{pid}">AI 문구로 제작</button>
<a class="btn gray" href="/products/{pid}/preview" target="_blank">새 창으로 보기</a><a class="btn gray" href="/products/{pid}/download">HTML 저장</a></div>
<label style="display:flex;gap:6px;align-items:center;margin-top:10px"><input type="checkbox" id="autoimg" checked style="width:auto">사진 자동으로 가져와서 가공하기(흰 배경 정사각형 대표 사진·여백 자르기·밝기 보정)</label>
<p class="mut" id="autoimg_note">사진이 없으면 이미지 주소 → 오너클랜 상품 사진 → 소싱 링크 페이지 순서로 찾아옵니다. 이미 가공한 사진은 다시 가공하지 않습니다.</p>
{f'<iframe src="/products/{pid}/preview"></iframe>' if p['detail_html'] else '<p class="mut">아직 만들지 않았습니다.</p>'}</div></form>
<div class="card"><h2>마켓 등록 기록</h2><div class="tbl"><table><tr><th>마켓</th><th>계정</th><th>마켓 상품번호</th><th>구분</th><th>상태</th></tr>{lst or '<tr><td colspan=5>없음</td></tr>'}</table></div></div>"""
    return page(p["name"], body, h.user, "/products", h.flash, h.flash_err)

def save_images(h, p, files, urls):
    imgs = img_list(p)
    for fn, data in files:
        if not data:
            continue
        ext = os.path.splitext(fn)[1].lower() or ".jpg"
        if ext not in (".jpg", ".jpeg", ".png", ".gif", ".webp"):
            continue
        name = f"p{p['id']}_{uuid.uuid4().hex[:8]}{ext}"
        with open(os.path.join(IMAGES, name), "wb") as f:
            f.write(data)
        imgs.append(name)
    imgs += [u.strip() for u in urls.splitlines() if u.strip().startswith("http")]
    return imgs

@route("POST", r"/products/(\d+)")
def product_post(h, pid):
    p = product(pid)
    f, files = h.multipart()
    vals = {}
    for k, _ in FIELDS:
        v = f.get(k, "")
        vals[k] = (num(v, int if k in ("set_qty", "stock", "price_override") else float) if k in NUM else v.strip())
    pts = [x_.strip() for x_ in f.get("points", "").splitlines() if x_.strip()]
    imgs = save_images(h, p, files.get("images", []), f.get("img_urls", ""))
    if "del_img" in f:
        i = int(f["del_img"])
        if 0 <= i < len(imgs):
            imgs.pop(i)
    vals["policy_id"] = num(f.get("policy_id"), int)
    vals["supply_type"] = "위탁" if f.get("supply_type") == "위탁" else "사입"
    vals["ship"] = num(f.get("ship"), float)
    allc = chs.all_channels(False)
    old_m, old_s = pricing.pj(p, "ch_margin"), pricing.pj(p, "ch_ship")
    for ch in allc:   # 화면에 없는(꺼진) 판매처 값은 그대로 둠
        if "pm_" + ch["code"] in f:
            old_m[ch["code"]] = num(f.get("pm_" + ch["code"]), float)
            old_s[ch["code"]] = num(f.get("ps_" + ch["code"]), float)
    vals["ch_margin"] = json.dumps({k: v for k, v in old_m.items() if v is not None})
    vals["ch_ship"] = json.dumps({k: v for k, v in old_s.items() if v is not None})
    sets = ", ".join(f"{k}=?" for k in vals)
    x(f"UPDATE products SET {sets}, points=?, cautions=?, memo=?, images=?, template=?, updated=?, updated_by=? WHERE id=?",
      (*vals.values(), json.dumps(pts, ensure_ascii=False) if pts else "", f.get("cautions", ""), f.get("memo", ""),
       json.dumps(imgs, ensure_ascii=False), f.get("template", "clean"), time.time(), h.user["username"], pid))
    do = f.get("do", "save")
    am = auto_stock(int(pid), h.user["username"])
    if do in ("detail", "detail_ai"):
        p = product(pid)
        try:
            copy, htm = make_detail(p, do == "detail_ai")
        except Exception as ex:
            go(f"/products/{pid}", f"AI 문구 생성 실패: {ex}", True)
        x("UPDATE products SET detail_html=?, points=CASE WHEN points='' OR points IS NULL THEN ? ELSE points END WHERE id=?",
          (htm, json.dumps(copy["points"], ensure_ascii=False), pid))
        log(h.user["username"], "상세페이지 제작", p["name"])
        go(f"/products/{pid}", "상세페이지를 만들었습니다")
    go(f"/products/{pid}", "저장했습니다" + ("\n" + am if am else ""))

def oc_item_for(p):
    if (p["supply_type"] or "") != "위탁" or not p["supplier_key"]:
        return None
    try:
        oc = ocmod.OwnerClan()
        return None if oc.dry else oc.item(p["supplier_key"])
    except Exception:
        return None

def gather_images(p, user):
    """사진 자동 수집 후 저장. 안내 문구 목록을 돌려줌"""
    imgs, notes = imgmod.collect(p, oc_item_for(p))
    x("UPDATE products SET images=? WHERE id=?", (json.dumps(imgs, ensure_ascii=False), p["id"]))
    log(user, "사진 자동 수집", f"{p['name']} {len(imgs)}장 " + "; ".join(notes)[:300])
    return imgs, notes

@route("POST", r"/products/(\d+)/fetch_images")
def product_fetch_images(h, pid):
    p = product(pid)
    imgs, notes = gather_images(p, h.user["username"])
    h.extra_headers = {"Content-Type": "application/json; charset=utf-8"}
    return json.dumps({"imgs": [{"i": i, "url": u if u.startswith("http") else "/img/" + quote(u), "done": u.startswith("http") or os.path.basename(u).startswith("px")}
                                for i, u in enumerate(imgs)], "notes": notes}, ensure_ascii=False)

@route("POST", r"/products/(\d+)/processed")
def product_processed(h, pid):
    """브라우저에서 가공한 사진으로 바꿔 끼움(원본 파일은 남겨 둠)"""
    p = product(pid)
    _, files = h.multipart()
    imgs = img_list(p)
    n = 0
    for k, lst in files.items():
        m = re.match(r"f(\d+)$", k or "")
        if not m or not lst or not lst[0][1]:
            continue
        i = int(m.group(1))
        data = lst[0][1]
        if i >= len(imgs) or data[:2] != b"\xff\xd8":
            continue
        name = f"px_p{p['id']}_{uuid.uuid4().hex[:8]}.jpg"
        with open(os.path.join(IMAGES, name), "wb") as f:
            f.write(data)
        imgs[i] = name
        n += 1
    x("UPDATE products SET images=? WHERE id=?", (json.dumps(imgs, ensure_ascii=False), p["id"]))
    h.extra_headers = {"Content-Type": "application/json"}
    return json.dumps({"ok": n})

@route("GET", r"/products/(\d+)/preview")
def product_preview(h, pid):
    p = product(pid)
    return f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;background:#eee">{p["detail_html"] or "아직 없음"}</body></html>'

@route("GET", r"/products/(\d+)/download")
def product_download(h, pid):
    p = product(pid)
    h.extra_headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(p['name'][:40])}.html"}
    return f'<!doctype html><html><head><meta charset="utf-8"></head><body>{p["detail_html"] or ""}</body></html>'

# ---------- 엑셀 불러오기 ----------
COLMAP = {"name": ["한국어 상품명", "상품명", "name"], "theme": ["테마", "분류", "카테고리"], "keyword": ["아이템스카우트 검색어", "검색어", "키워드"],
          "source_name": ["원문 상품명(이우고)", "원문 상품명", "영문상품명"], "cost_cny": ["최저가(위안)", "단가(위안)"], "cost_krw": ["최저가(원)", "단가(원)"],
          "moq": ["MOQ"], "set_desc": ["세트 구성 예시", "세트 구성"], "source_url": ["상품 링크", "링크", "소싱 링크"],
          "set_qty": ["세트 수량"], "stock": ["재고"], "naver_cat": ["네이버 카테고리"], "coupang_cat": ["쿠팡 카테고리"], "esm_cat": ["지마켓 카테고리"]}

@route("GET", "/products/import")
def import_get(h):
    body = """<h1>엑셀 불러오기</h1><div class="card"><form method="post" enctype="multipart/form-data" data-busy>
<label>파일(.xlsx 또는 .csv)</label><input type="file" name="file" accept=".xlsx,.csv" required>
<label>시트 이름(비우면 '추천 상품' → 첫 시트 순서로 찾음)</label><input name="sheet" placeholder="추천 상품">
<label>최대 불러올 개수</label><input name="limit" value="200"><br><br><button class="btn">불러오기</button></form></div>
<div class="card"><h2>알아보는 열 이름</h2><p class="mut">한국어 상품명(또는 상품명) · 테마 · 아이템스카우트 검색어 · 원문 상품명 · 최저가(위안) · 최저가(원) · MOQ · 세트 구성 예시 · 세트 수량 · 재고 · 상품 링크 · 네이버 카테고리 · 쿠팡 카테고리 · 지마켓 카테고리.<br>
한국_판매추천_소비자검토_2026-11.xlsx 를 그대로 넣으면 됩니다. '4개 컬러 세트'처럼 구성에 숫자가 있으면 세트 수량을 자동으로 잡습니다.</p>
<a class="btn gray" href="/products/template.csv">빈 양식 받기(CSV)</a></div>"""
    return page("엑셀 불러오기", body, h.user, "/products", h.flash, h.flash_err)

@route("GET", "/products/template.csv")
def template_csv(h):
    h.extra_headers = {"Content-Disposition": "attachment; filename=product_template.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿상품명,테마,검색어,세트 구성,세트 수량,단가(위안),단가(원),MOQ,재고,상품 링크,네이버 카테고리,쿠팡 카테고리,지마켓 카테고리\n털 집게핀 4개 세트,헤어,털 집게핀,4개 컬러 세트,4,0.8,,3,100,https://...,,,\n"

@route("POST", "/products/import")
def import_post(h):
    f, files = h.multipart()
    fn, data = (files.get("file") or [("", b"")])[0]
    if not data:
        go("/products/import", "파일을 골라 주세요", True)
    if fn.lower().endswith(".csv"):
        rows = list(csv.reader(io.StringIO(data.decode("utf-8-sig", "replace"))))
    else:
        sheets = xlsx.read(io.BytesIO(data))
        want = f.get("sheet", "").strip()
        name = want if want in sheets else ("추천 상품" if "추천 상품" in sheets else next(iter(sheets)))
        rows = sheets[name]
    hdr_i = next((i for i, r in enumerate(rows[:10]) if any(str(c or "").strip() in sum(COLMAP.values(), []) for c in r)), None)
    if hdr_i is None:
        go("/products/import", "열 이름(상품명 등)을 찾지 못했습니다", True)
    hdr = [str(c or "").strip() for c in rows[hdr_i]]
    idx = {k: next((hdr.index(n) for n in names if n in hdr), None) for k, names in COLMAP.items()}
    if idx["name"] is None:
        go("/products/import", "상품명 열이 없습니다", True)
    limit = num(f.get("limit"), int) or 200
    n = 0
    for r in rows[hdr_i + 1:]:
        get = lambda k: (r[idx[k]] if idx[k] is not None and idx[k] < len(r) else None)
        name = str(get("name") or "").strip()
        if not name:
            continue
        set_desc = str(get("set_desc") or "")
        sq = num(get("set_qty"), int) or (int(m.group(1)) if (m := re.search(r"(\d+)\s*(개|장|pcs|입)", set_desc)) else 1)
        cny, krw = num(get("cost_cny")), num(get("cost_krw"))
        x("""INSERT INTO products(name,theme,keyword,source_name,source_url,cost_cny,cost_krw,set_qty,set_desc,moq,stock,naver_cat,coupang_cat,esm_cat,updated,updated_by)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (name, get("theme"), get("keyword"), get("source_name"), get("source_url"), cny, None if cny else krw, sq, set_desc,
           str(get("moq") or ""), num(get("stock"), int) or 100, str(get("naver_cat") or ""), str(get("coupang_cat") or ""), str(get("esm_cat") or ""),
           time.time(), h.user["username"]))
        n += 1
        if n >= limit:
            break
    log(h.user["username"], "엑셀 불러오기", f"{fn} {n}개")
    go("/products", f"{n}개 상품을 불러왔습니다")

# ---------- 일괄 작업 / 등록 ----------
def register_one(p, acc, user):
    m = market_for(acc)
    p = naming.fill_categories(p)
    p["name"] = naming.process(p["name"], acc["market"])
    price = acc_price(p, acc["market"])
    imgs = img_list(p)
    local = [os.path.join(IMAGES, i) for i in imgs if not i.startswith("http")]
    remote = [i for i in imgs if i.startswith("http")]
    urls = remote
    if local:
        up = m.upload_images(local) if acc["market"] == "naver" else []
        if not up and not m.dry:
            # 쿠팡·ESM은 공개 이미지 주소가 필요 → 같은 상품의 네이버 업로드 주소를 재사용
            nv = q("SELECT a.* FROM accounts a WHERE a.market='naver' AND a.active=1 LIMIT 1", one=True)
            if nv:
                up = market_for(nv).upload_images(local)
        urls = (up or []) + remote
    if m.dry and not urls:
        urls = ["/img/" + i for i in imgs]
    _, htm = make_detail(p, False, urls) if not p.get("detail_html") or local else (None, p["detail_html"])
    payload = m.build_product(p, price, htm, urls)
    r = m.register(payload)
    x("INSERT INTO listings(product_id,account_id,market,channel,market_id,sub_id,price,stock,status,last_result,dry,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
      (p["id"], acc["id"], acc["market"], "gmarket" if acc["market"] == "esm" else acc["market"], r.get("market_id"), r.get("sub_id"), price_num(price), p["stock"], "미리보기" if r.get("dry") else "등록요청",
       json.dumps(r.get("raw") or r.get("file"), ensure_ascii=False)[:4000], 1 if r.get("dry") else 0, time.time()))
    x("UPDATE products SET status='등록', naver_cat=?, coupang_cat=?, esm_cat=? WHERE id=?", (p["naver_cat"], p["coupang_cat"], p["esm_cat"], p["id"]))
    log(user, ("미리보기 " if r.get("dry") else "") + "마켓 등록", f"{MARKETS[acc['market']].name} {p['name']} {price_txt(price)}")
    return r

def register_channel(p, ch, user):
    """API가 없는 판매처(해외몰 등): 등록 목록에 올려 두고 판매처 화면에서 엑셀로 받음"""
    price = pricing.price_for(p, ch)
    old = q("SELECT id FROM listings WHERE product_id=? AND channel=? AND account_id IS NULL", (p["id"], ch["code"]), one=True)
    if old:
        x("UPDATE listings SET price=?, stock=?, status='엑셀 대기', updated=? WHERE id=?", (price, p["stock"], time.time(), old["id"]))
    else:
        x("INSERT INTO listings(product_id,account_id,market,channel,price,stock,status,dry,updated) VALUES(?,?,?,?,?,?,?,?,?)",
          (p["id"], None, "", ch["code"], price, p["stock"], "엑셀 대기", 0, time.time()))
    x("UPDATE products SET status='등록' WHERE id=?", (p["id"],))
    log(user, "판매처 등록(엑셀)", f"{ch['name']} {p['name']} {chs.fmt(price, ch)}")
    return price

AUTO_OUT = "품절(재고없음)"

def auto_stock(pid, user="자동"):
    """재고가 0 이하가 되면 등록된 모든 판매처 자동 품절, 재고를 다시 넣으면 자동 판매 재개. (설정에서 끌 수 있음)"""
    if not get_setting("auto_soldout_stock", True):
        return ""
    p = q("SELECT * FROM products WHERE id=?", (pid,), one=True)
    if not p:
        return ""
    has = q("SELECT 1 FROM listings WHERE product_id=? LIMIT 1", (pid,), one=True)
    st = p["status"] or ""
    if (p["stock"] or 0) <= 0 and not st.startswith("품절"):
        if not has:
            x("UPDATE products SET status=? WHERE id=?", (AUTO_OUT, pid))
            return "재고 0 → 품절"
        n, ms = push_listings(pid, "soldout", AUTO_OUT)
        notify.send("재고 0 → 자동 품절", f"{p['name']} ({n}곳 판매중지)", "soldout")
        log(user, "재고 0 → 자동 품절", f"{p['name']} {n}곳" + ("; " + "; ".join(ms)[:300] if ms else ""))
        return f"재고가 0이라 {n}곳 판매처를 품절 처리했습니다" + ("\n" + "\n".join(ms) if ms else "")
    if (p["stock"] or 0) > 0 and st == AUTO_OUT:
        x("UPDATE products SET status=? WHERE id=?", ("등록" if has else "준비", pid))
        if not has:
            return ""
        n, ms = push_listings(pid, "resume")
        push_listings(pid, "sync")
        log(user, "재고 입고 → 자동 판매 재개", f"{p['name']} {n}곳")
        return f"재고가 들어와 {n}곳 판매처 판매를 다시 열었습니다" + ("\n" + "\n".join(ms) if ms else "")
    return ""

def stock_sweep():
    """재고 0인데 아직 판매 중인 상품을 찾아 품절 처리(엑셀로 재고를 바꾼 경우 등)"""
    for r in q("SELECT id FROM products WHERE COALESCE(stock,0)<=0 AND COALESCE(status,'') NOT LIKE '품절%' AND id IN (SELECT product_id FROM listings)"):
        try:
            auto_stock(r["id"])
        except Exception:
            traceback.print_exc()

def push_listings(pid, do, status_label="품절"):
    """등록된 모든 판매처에 가격 동기화(sync)·품절(soldout)·재개(resume) 반영. (반영 건수, 오류 목록)"""
    p = product(pid)
    n, msgs = 0, []
    if do == "soldout":
        x("UPDATE products SET stock=0, status=? WHERE id=?", (status_label, pid))
    for l in q("SELECT * FROM listings WHERE product_id=?", (pid,)):
        if not l["account_id"]:   # 엑셀 판매처: 기록만 바꾸고 다음 엑셀에 반영
            ch = chs.get(l["channel"])
            if not ch:
                continue
            if do == "sync":
                x("UPDATE listings SET price=?, stock=?, status='엑셀 대기', updated=? WHERE id=?", (pricing.price_for(p, ch), p["stock"], time.time(), l["id"]))
            else:
                x("UPDATE listings SET stock=?, status=?, updated=? WHERE id=?", (0 if do == "soldout" else p["stock"], "품절" if do == "soldout" else "엑셀 대기", time.time(), l["id"]))
            n += 1
            continue
        acc = q("SELECT * FROM accounts WHERE id=?", (l["account_id"],), one=True)
        if not acc:
            continue
        m = market_for(acc, force_dry=bool(l["dry"]))
        try:
            if do == "sync":
                price = acc_price(p, l["market"])
                m.update_price_stock(l, price, int(p["stock"] or 0))
                x("UPDATE listings SET price=?, stock=?, updated=? WHERE id=?", (price_num(price), p["stock"], time.time(), l["id"]))
            else:
                m.set_sale(l, do == "resume")
                x("UPDATE listings SET status=?, updated=? WHERE id=?", ("판매중" if do == "resume" else "품절", time.time(), l["id"]))
            n += 1
        except Exception as ex:
            msgs.append(f"{where_label(l['market'], l['channel'])} · {p['name']}: {ex}")
    return n, msgs

def publish(pids, accs, chans, user):
    """상품들을 마켓 계정(API)·엑셀 판매처에 등록. 상세페이지 없으면 먼저 만듦. (건수, 메시지, 실패 여부)"""
    ok, msgs, bad = 0, [], False
    for pid in pids:
        p = product(pid)
        if not p["detail_html"]:
            if not img_list(p):
                gather_images(p, user); p = product(pid)
            _, htm = make_detail(p)
            x("UPDATE products SET detail_html=? WHERE id=?", (htm, pid))
            p = product(pid)
        for a in accs:
            try:
                r = register_one(p, a, user)
                ok += 1
                if r.get("dry"):
                    msgs.append(f"[미리보기] {MARKETS[a['market']].name} · {p['name']} → {os.path.basename(r['file'])}")
            except (MarketError, Exception) as ex:
                bad = True
                msgs.append(f"[실패] {MARKETS[a['market']].name} · {p['name']}: {ex}")
                log(user, "등록 실패", f"{MARKETS[a['market']].name} {p['name']}: {ex}")
        for ch in chans:
            register_channel(p, ch, user)
            ok += 1
    if chans:
        msgs.append("엑셀 판매처(" + ", ".join(c["name"] for c in chans) + ")는 판매처 화면에서 엑셀을 받아 각 사이트에 올리세요.")
    return ok, msgs, bad

@route("POST", "/bulk")
def bulk(h):
    f = h.form_multi()
    pids = [int(i) for i in f.get("pid", [])]
    do = (f.get("do") or ["detail"])[0]
    if not pids:
        go("/products", "상품을 하나 이상 고르세요", True)
    msgs, bad = [], False
    if do == "delete":
        for pid in pids:
            x("DELETE FROM products WHERE id=?", (pid,))
        go("/products", f"{len(pids)}개 삭제했습니다")
    if do == "price":
        pol = num((f.get("bulk_policy") or [""])[0], int)
        mg = num((f.get("bulk_margin") or [""])[0], float)
        for pid in pids:
            x("UPDATE products SET policy_id=?, margin=?, updated=?, updated_by=? WHERE id=?", (pol, mg, time.time(), h.user["username"], pid))
        log(h.user["username"], "가격 정책 일괄 적용", f"{len(pids)}개 정책={pol} 마진={mg}")
        go("/products", f"{len(pids)}개 상품에 가격 정책을 적용했습니다. 마켓에 반영하려면 '등록된 마켓 가격 동기화'를 누르세요.")
    if do in ("sync", "soldout", "resume"):
        n = 0
        for pid in pids:
            k, ms = push_listings(pid, do)
            n += k; msgs += ms; bad = bad or bool(ms)
        log(h.user["username"], {"sync": "가격 동기화", "soldout": "품절 처리", "resume": "판매 재개"}[do], f"{n}건")
        go("/products", f"{n}건 마켓에 반영했습니다\n" + "\n".join(msgs[:30]), bad)
    if do in ("detail", "detail_ai"):
        for pid in pids:
            p = product(pid)
            try:
                if not img_list(p):
                    gather_images(p, h.user["username"]); p = product(pid)
                copy, htm = make_detail(p, do == "detail_ai")
                x("UPDATE products SET detail_html=? WHERE id=?", (htm, pid))
            except Exception as ex:
                bad = True; msgs.append(f"{p['name']}: {ex}")
        log(h.user["username"], "상세페이지 일괄 제작", f"{len(pids)}개")
        go("/products", f"{len(pids)}개 상세페이지를 만들었습니다\n" + "\n".join(msgs), bad)
    accs = [q("SELECT * FROM accounts WHERE id=?", (int(a),), one=True) for a in f.get("acc", [])]
    accs = [a for a in accs if a]
    chans = [c for c in (chs.get(k) for k in f.get("ch", [])) if c]
    if not accs and not chans:
        go("/products", "등록할 마켓 계정이나 판매처를 고르세요", True)
    ok, ms, b2 = publish(pids, accs, chans, h.user["username"])
    msgs += ms; bad = bad or b2
    go("/products", f"{ok}건 처리했습니다\n" + "\n".join(msgs[:30]), bad)

# ---------- 등록 현황 ----------
@route("GET", "/listings")
def listings(h):
    rows = q("""SELECT l.*, p.name, a.label FROM listings l LEFT JOIN products p ON p.id=l.product_id LEFT JOIN accounts a ON a.id=l.account_id
                ORDER BY l.id DESC LIMIT 500""")
    trs = "".join(f"""<tr><td>{e(where_label(l['market'], l['channel']))}<div class="mut">{e(l['label'] or ('엑셀 내보내기' if not l['account_id'] else ''))}</div></td><td><a href="/products/{l['product_id']}">{e(l['name'] or '(삭제됨)')}</a><div class="mut">{e(l['market_id'] or '')}</div></td>
<td><span class="tag {'dry' if l['dry'] else 'ok'}">{'미리보기' if l['dry'] else e(l['status'] or '')}</span></td>
<td><form method="post" action="/listings/{l['id']}" class="row" data-busy><input name="price" value="{l['price'] or ''}" style="width:90px"><input name="stock" value="{l['stock'] or ''}" style="width:70px">
<button class="btn sm" name="do" value="update">반영</button><button class="btn sm gray" name="do" value="off">판매중지</button><button class="btn sm green" name="do" value="on">재개</button><button class="btn sm red" name="do" value="forget">기록삭제</button></form></td></tr>""" for l in rows)
    body = f"""<h1>등록 현황</h1><div class="card tbl"><table><tr><th>판매처</th><th>상품</th><th>상태</th><th>가격 · 재고</th></tr>{trs or '<tr><td colspan=4>아직 등록한 상품이 없습니다</td></tr>'}</table></div>
<p class="mut">쿠팡은 등록 후 승인(보통 수 시간~1일)이 끝나야 가격·재고를 바꿀 수 있습니다.</p>"""
    return page("등록 현황", body, h.user, "/listings", h.flash, h.flash_err)

@route("POST", r"/listings/(\d+)")
def listing_post(h, lid):
    l = q("SELECT * FROM listings WHERE id=?", (lid,), one=True)
    f = h.form()
    do = f.get("do")
    if do == "forget":
        x("DELETE FROM listings WHERE id=?", (lid,))
        go("/listings", "기록을 지웠습니다(마켓의 상품은 그대로)")
    if not l["account_id"]:   # 엑셀 판매처
        if do == "update":
            pr = num(f.get("price"), float)
            st = num(f.get("stock"), int)
            x("UPDATE listings SET price=?, stock=?, status='엑셀 대기', updated=? WHERE id=?", (l["price"] if pr is None else pr, l["stock"] if st is None else st, time.time(), lid))
        else:
            x("UPDATE listings SET status=?, updated=? WHERE id=?", ("판매중지" if do == "off" else "엑셀 대기", time.time(), lid))
        go("/listings", "바꿨습니다. 판매처 화면에서 엑셀을 다시 받아 올리세요.")
    acc = q("SELECT * FROM accounts WHERE id=?", (l["account_id"],), one=True)
    if not acc:
        go("/listings", "계정이 삭제되었습니다", True)
    m = market_for(acc, force_dry=bool(l["dry"]))
    try:
        if do == "update":
            price, stock = num(f.get("price"), int) or l["price"], num(f.get("stock"), int)
            stock = l["stock"] if stock is None else stock
            m.update_price_stock(l, price, stock)
            x("UPDATE listings SET price=?, stock=?, updated=? WHERE id=?", (price, stock, time.time(), lid))
        else:
            m.set_sale(l, do == "on")
            x("UPDATE listings SET status=?, updated=? WHERE id=?", ("판매중" if do == "on" else "판매중지", time.time(), lid))
    except MarketError as ex:
        go("/listings", str(ex), True)
    log(h.user["username"], f"등록상품 {do}", f"{l['market']} {l['market_id']}")
    go("/listings", "반영했습니다" + (" (미리보기)" if m.dry else ""))

# ---------- 주문 ----------
PAID = {"PAYED", "ACCEPT", "INSTRUCT", "결제완료"}   # 발주·발송 대상 상태

def product_by_code(code):
    m = re.match(r"MM(\d+)", str(code or ""))
    return q("SELECT * FROM products WHERE id=?", (int(m.group(1)),), one=True) if m else None

def save_order(acc, o):
    p = product_by_code(o.get("seller_code"))
    st = (p["supply_type"] or "사입") if p else "사입"
    po = ("발주대기" if st == "위탁" else "발송대기") if str(o.get("status")) in PAID else ""
    mk = acc["market"] if acc else o.get("market", "naver")
    is_new = not q("SELECT 1 FROM orders WHERE market=? AND order_id=?", (mk, o["order_id"]), one=True)
    x("""INSERT INTO orders(account_id,market,order_id,product_name,qty,amount,buyer,status,ordered_at,raw,product_id,supply_type,seller_code,option_text,rcv,ship_ref,po_status,collected)
         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
         ON CONFLICT(market,order_id) DO UPDATE SET status=excluded.status,
           po_status=CASE WHEN COALESCE(orders.po_status,'')='' THEN excluded.po_status ELSE orders.po_status END""",
      (acc["id"] if acc else None, acc["market"] if acc else o.get("market", "naver"), o["order_id"], o["product_name"], o["qty"], o["amount"], o["buyer"],
       o["status"], o["ordered_at"], json.dumps(o.get("raw"), ensure_ascii=False)[:8000], p["id"] if p else None, st, o.get("seller_code", ""),
       o.get("option", ""), json.dumps(o.get("rcv") or {}, ensure_ascii=False), json.dumps(o.get("ship_ref") or {}, ensure_ascii=False), po, time.time()))
    if is_new and p and st == "사입" and po:   # 사입 상품: 팔린 만큼 재고 빼고, 0이 되면 자동 품절
        x("UPDATE products SET stock=MAX(COALESCE(stock,0)-?,0) WHERE id=?", (int(o.get("qty") or 1), p["id"]))
        auto_stock(p["id"])
    return is_new

def collect_orders(user="자동"):
    n, errs, new = 0, [], []
    for a in q("SELECT * FROM accounts WHERE active=1"):
        m = market_for(a)
        if m.dry:
            continue
        try:
            for o in m.fetch_orders():
                if save_order(a, o):
                    new.append(f"{MARKETS[a['market']].name} · {o.get('product_name') or ''} {o.get('qty') or 1}개 {int(float(o.get('amount') or 0)):,}원")
                n += 1
        except Exception as ex:
            errs.append(f"{MARKETS[a['market']].name} {a['label']}: {ex}")
    log(user, "주문 수집", f"{n}건 {'; '.join(errs)[:500]}")
    if new:
        notify.send(f"새 주문 {len(new)}건", "\n".join(new[:15]) + (f"\n외 {len(new) - 15}건" if len(new) > 15 else ""), "order")
    if errs:
        notify.send("주문 수집 오류", "\n".join(errs)[:1000], "error")
    if (get_setting("ownerclan", {}) or {}).get("auto_order"):
        auto_place_orders(user)
    return n, errs

@route("GET", "/orders")
def orders(h):
    rows = q("SELECT o.*, a.label FROM orders o LEFT JOIN accounts a ON a.id=o.account_id ORDER BY ordered_at DESC LIMIT 500")
    trs = "".join(f"<tr><td>{e(where_label(o['market']))}<div class='mut'>{e(o['label'] or '')}</div></td><td>{e(str(o['ordered_at'] or '')[:16])}</td><td>{e(o['product_name'] or '')}</td><td>{o['qty'] or ''}</td><td>{(o['amount'] or 0):,}</td><td>{e(mask(o['buyer'] or ''))}</td><td><span class='tag'>{e(o['status'] or '')}</span><div class='mut'>{e(o['supply_type'] or '')} {e(o['po_status'] or '')}</div></td></tr>" for o in rows)
    mins = get_setting("order_interval", 30)
    body = f"""<h1>주문</h1><div class="row" style="margin-bottom:12px"><form method="post" action="/orders/collect" data-busy><button class="btn">지금 주문 모으기</button></form>
<a class="btn gray" href="/orders.csv">엑셀(CSV) 받기</a><span class="mut">자동 수집: {mins}분마다 (설정에서 변경)</span></div>
<div class="card tbl"><table><tr><th>마켓</th><th>주문일</th><th>상품</th><th>수량</th><th>금액</th><th>주문자</th><th>상태</th></tr>{trs or '<tr><td colspan=7>주문이 없습니다(미리보기 모드에서는 수집하지 않습니다)</td></tr>'}</table></div>"""
    return page("주문", body, h.user, "/orders", h.flash, h.flash_err)

@route("POST", "/orders/collect")
def orders_collect(h):
    n, errs = collect_orders(h.user["username"])
    go("/orders", f"{n}건 모았습니다" + ("\n" + "\n".join(errs) if errs else ""), bool(errs))

@route("GET", "/orders.csv")
def orders_csv(h):
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["마켓", "주문번호", "주문일", "상품", "수량", "금액", "주문자", "상태"])
    for o in q("SELECT * FROM orders ORDER BY ordered_at DESC"):
        w.writerow([where_label(o["market"]), o["order_id"], o["ordered_at"], o["product_name"], o["qty"], o["amount"], o["buyer"], o["status"]])
    h.extra_headers = {"Content-Disposition": "attachment; filename=orders.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿" + out.getvalue()

# ---------- 마켓 계정 ----------
@route("GET", "/accounts")
def accounts(h):
    rows = q("SELECT * FROM accounts ORDER BY market, id")
    trs = "".join(f"""<tr><td>{MARKETS[a['market']].name}</td><td><a href="/accounts/{a['id']}"><b>{e(a['label'])}</b></a><div class="mut">담당: {e(a['owner'] or '')}</div></td>
<td>{'<span class="tag ok">사용</span>' if a['active'] else '<span class="tag bad">꺼짐</span>'} {'<span class="tag">키 있음</span>' if a['creds'] else '<span class="tag dry">키 없음</span>'}</td>
<td><form method="post" action="/accounts/{a['id']}/test" data-busy><button class="btn sm gray">연결 확인</button></form></td></tr>""" for a in rows)
    opts = "".join(f'<a class="btn" href="/accounts/new/{k}">+ {m.name}</a>' for k, m in MARKETS.items())
    body = f"""<h1>마켓 계정</h1><div class="row" style="margin-bottom:12px">{opts}</div><div class="card tbl"><table><tr><th>마켓</th><th>계정</th><th>상태</th><th></th></tr>{trs or '<tr><td colspan=4>계정이 없습니다</td></tr>'}</table></div>
<div class="card"><h2>API 키 받는 곳</h2><ul class="mut" style="line-height:1.9"><li>네이버: 커머스API센터(apicenter.commerce.naver.com) → 애플리케이션 등록 → ID·시크릿, 호출 IP에 서버 IP 등록</li>
<li>쿠팡: Wing → 판매자정보 → 추가판매정보 → OPEN API 키 발급(업체코드·Access·Secret), 허용 IP에 서버 IP 등록</li>
<li>지마켓·옥션: ESM+ → 판매자정보 → API 사용 신청(승인 필요) → 마스터 ID·시크릿 키</li></ul>
<p class="mut">키는 이 서버에만 저장됩니다(Windows에서는 암호화). 한 마켓에 계정을 여러 개 넣을 수 있습니다.</p></div>"""
    return page("마켓 계정", body, h.user, "/accounts", h.flash, h.flash_err)

def account_form(h, m, a=None):
    creds = json.loads(unseal(a["creds"]) or "{}") if a and a["creds"] else {}
    extra = json.loads(a["extra"] or "{}") if a else {}
    cf = "".join(f'<div><label>{lab}{" (바꿀 때만 입력)" if sec and creds.get(k) else ""}</label><input name="c_{k}" value="{"" if sec else e(creds.get(k, ""))}" {"type=password" if sec else ""} autocomplete="off"></div>' for k, lab, sec in m.cred_fields)
    ef = "".join(f'<div><label>{lab}</label><input name="x_{k}" value="{e(extra.get(k, d))}"></div>' for k, lab, d in m.extra_fields)
    delb = f'<button class="btn red" name="do" value="delete" onclick="return confirm(\'계정을 지울까요?\')">삭제</button>' if a else ""
    cat = f"""<div class="card"><h2>카테고리 찾기</h2><form method="post" action="/accounts/{a['id']}/category" class="row" data-busy><input name="kw" placeholder="예: 헤어핀" style="max-width:260px"><button class="btn gray">찾기</button></form>
{h.qs.get('cat_result','')}</div>""" if a else ""
    return page(m.name, f"""<h1>{m.name} 계정</h1><form method="post" class="card"><div class="grid"><div><label>계정 이름(구분용)</label><input name="label" value="{e(a['label'] if a else '')}" required></div>
<div><label>담당자</label><input name="owner" value="{e((a['owner'] if a else '') or h.user['name'] or '')}"></div>
<div><label>사용</label><select name="active"><option value="1">사용</option><option value="0" {"selected" if a and not a['active'] else ""}>끄기</option></select></div></div>
<h2 style="margin-top:18px">API 키</h2><div class="grid">{cf}</div><h2 style="margin-top:18px">기본값</h2><div class="grid">{ef}</div><br>
<div class="row"><button class="btn" name="do" value="save">저장</button>{delb}</div></form>{cat}""", h.user, "/accounts", h.flash, h.flash_err)

@route("GET", r"/accounts/new/(\w+)")
def account_new(h, market):
    return account_form(h, MARKETS[market])

@route("GET", r"/accounts/(\d+)")
def account_get(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    return account_form(h, MARKETS[a["market"]], a)

def account_save(h, market, a=None):
    f = h.form()
    m = MARKETS[market]
    if f.get("do") == "delete" and a:
        x("DELETE FROM accounts WHERE id=?", (a["id"],))
        log(h.user["username"], "마켓 계정 삭제", a["label"])
        go("/accounts", "삭제했습니다")
    old = json.loads(unseal(a["creds"]) or "{}") if a and a["creds"] else {}
    creds = {k: (f.get("c_" + k, "").strip() or old.get(k, "")) for k, _, _ in m.cred_fields}
    extra = {k: f.get("x_" + k, "").strip() for k, _, _ in m.extra_fields}
    sealed = seal(json.dumps(creds)) if any(creds.values()) else ""
    if a:
        x("UPDATE accounts SET label=?, creds=?, extra=?, active=?, owner=? WHERE id=?", (f["label"], sealed, json.dumps(extra, ensure_ascii=False), int(f.get("active", 1)), f.get("owner"), a["id"]))
        aid = a["id"]
    else:
        aid = x("INSERT INTO accounts(market,label,creds,extra,active,owner,created) VALUES(?,?,?,?,?,?,?)",
                (market, f["label"], sealed, json.dumps(extra, ensure_ascii=False), int(f.get("active", 1)), f.get("owner"), time.time()))
    log(h.user["username"], "마켓 계정 저장", f"{m.name} {f['label']}")
    go(f"/accounts/{aid}", "저장했습니다")

@route("POST", r"/accounts/new/(\w+)")
def account_create(h, market):
    account_save(h, market)

@route("POST", r"/accounts/(\d+)")
def account_update(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    account_save(h, a["market"], a)

@route("POST", r"/accounts/(\d+)/test")
def account_test(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    m = MARKETS[a["market"]](json.loads(unseal(a["creds"]) or "{}") if a["creds"] else {}, json.loads(a["extra"] or "{}"))
    try:
        go("/accounts", f"{m.name} {a['label']}: {m.test()}")
    except MarketError as ex:
        go("/accounts", str(ex), True)

@route("POST", r"/accounts/(\d+)/category")
def account_category(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    m = MARKETS[a["market"]](json.loads(unseal(a["creds"]) or "{}") if a["creds"] else {}, json.loads(a["extra"] or "{}"))
    kw = h.form().get("kw", "")
    try:
        res = m.search_category(kw)
    except MarketError as ex:
        go(f"/accounts/{aid}", str(ex), True)
    txt = "\n".join(f"{r['id']}  {r['name']}" for r in res) or ("키를 넣어야 찾을 수 있습니다" if m.dry else "결과 없음")
    go(f"/accounts/{aid}", f"'{kw}' 카테고리\n{txt}")

# ---------- 팀원 ----------
@route("GET", "/users", admin=True)
def users(h):
    trs = "".join(f"""<tr><td>{e(u['username'])}</td><td>{e(u['name'] or '')}</td><td>{'관리자' if u['role']=='admin' else '팀원'}</td>
<td><form method="post" action="/users/{u['id']}" class="row"><input name="pw" type="password" placeholder="새 비밀번호" style="width:140px"><button class="btn sm gray" name="do" value="pw">변경</button>
{'' if u['id']==h.user['id'] else '<button class="btn sm red" name="do" value="del" onclick="return confirm(&quot;삭제?&quot;)">삭제</button>'}</form></td></tr>""" for u in q("SELECT * FROM users"))
    body = f"""<h1>팀원</h1><div class="card tbl"><table><tr><th>아이디</th><th>이름</th><th>권한</th><th></th></tr>{trs}</table></div>
<form method="post" action="/users" class="card"><h2>팀원 추가</h2><div class="grid"><div><label>아이디</label><input name="username" required></div><div><label>이름</label><input name="name"></div>
<div><label>비밀번호</label><input name="pw" type="password" minlength="8" required></div><div><label>권한</label><select name="role"><option value="staff">팀원</option><option value="admin">관리자</option></select></div></div><br><button class="btn">추가</button></form>"""
    return page("팀원", body, h.user, "/users", h.flash, h.flash_err)

@route("POST", "/users", admin=True)
def users_add(h):
    f = h.form()
    try:
        auth.create_user(f["username"].strip(), f.get("name", ""), f["pw"], f.get("role", "staff"))
    except Exception:
        go("/users", "이미 있는 아이디입니다", True)
    log(h.user["username"], "팀원 추가", f["username"])
    go("/users", "추가했습니다")

@route("POST", r"/users/(\d+)", admin=True)
def users_edit(h, uid):
    f = h.form()
    if f.get("do") == "del":
        x("DELETE FROM users WHERE id=?", (uid,)); x("DELETE FROM sessions WHERE user_id=?", (uid,))
        go("/users", "삭제했습니다")
    if len(f.get("pw", "")) < 8:
        go("/users", "비밀번호는 8자 이상", True)
    x("UPDATE users SET pw=? WHERE id=?", (auth.hash_pw(f["pw"]), uid))
    go("/users", "비밀번호를 바꿨습니다")

@route("GET", "/me")
def me(h):
    return page("내 정보", """<h1>내 비밀번호 변경</h1><form method="post" class="card" style="max-width:420px"><label>현재 비밀번호</label><input name="old" type="password">
<label>새 비밀번호</label><input name="pw" type="password" minlength="8"><br><br><button class="btn">변경</button></form>""", h.user, "/me", h.flash, h.flash_err)

@route("POST", "/me")
def me_post(h):
    f = h.form()
    if not auth.check_pw(f.get("old", ""), h.user["pw"]) or len(f.get("pw", "")) < 8:
        go("/me", "현재 비밀번호가 틀렸거나 새 비밀번호가 8자 미만입니다", True)
    x("UPDATE users SET pw=? WHERE id=?", (auth.hash_pw(f["pw"]), h.user["id"]))
    go("/", "비밀번호를 바꿨습니다")

# ---------- 설정 ----------
@route("GET", "/settings")
def settings(h):
    c = pricing.cfg(); shop = get_setting("shop", {}) or {}; ai = get_setting("ai", {}) or {}; nr = naming.rules()
    dry = get_setting("dry_run", True); adm = h.user["role"] == "admin"
    dis = "" if adm else "disabled"
    body = f"""<h1>설정</h1>{'' if adm else '<div class="flash err">설정은 관리자만 바꿀 수 있습니다.</div>'}<form method="post"><fieldset {dis} style="border:0;padding:0;margin:0">
<div class="card"><h2>등록 모드</h2><select name="dry_run" style="max-width:420px"><option value="1">미리보기 모드(마켓에 안 올림, 보낼 내용만 저장)</option><option value="0" {'' if dry else 'selected'}>실제 등록 모드</option></select></div>
<div class="card"><h2>기본 가격 정책</h2>{policy_form(c)}<p class="mut">상품별로 다른 정책을 쓰려면 <a href="/policies">가격 정책</a>에서 정책을 더 만드세요.</p></div>
<div class="card"><h2>상품명 가공 (마켓 등록 때 적용)</h2><div class="grid"><div><label>앞에 붙일 문구</label><input name="nr_prefix" value="{e(nr.get('prefix',''))}" placeholder="예: [국내발송]"></div>
<div><label>뒤에 붙일 문구</label><input name="nr_suffix" value="{e(nr.get('suffix',''))}"></div></div>
<label>금지어(쉼표로 구분, 상품명에서 지움)</label><input name="nr_banned" value="{e(nr.get('banned',''))}" placeholder="예: 최저가, 정품, 무료">
<label>단어 바꾸기(한 줄에 하나, 바꿀말=>새말)</label><textarea name="nr_replace" style="min-height:60px" placeholder="헤어클립=>집게핀">{e(nr.get('replace',''))}</textarea>
<p class="mut">길이 제한은 <a href="/channels">판매처</a>마다 정한 글자 수에서 자동으로 자릅니다(기본: 네이버·쿠팡 100자, 지마켓·옥션 50자).</p></div>
<div class="card"><h2>카테고리 자동 매칭</h2><p class="mut">한 줄에 하나: <b>테마나 상품명에 들어 있는 말 = 네이버ID, 쿠팡코드, 지마켓코드</b>. 상품에 카테고리가 비어 있으면 이 표로 채워서 등록합니다.</p>
<textarea name="category_map" placeholder="집게핀 = 50000805, 80284, 300024012">{e(get_setting('category_map', '') or '')}</textarea></div>
<div class="card"><h2>상점 정보(상세페이지에 들어감)</h2><div class="grid"><div><label>상점 이름</label><input name="shop_name" value="{e(shop.get('name',''))}"></div>
<div><label>상단 띠 문구</label><input name="shop_banner" value="{e(shop.get('banner',''))}" placeholder="오늘 주문 · 내일 도착"></div><div><label>고객센터 안내</label><input name="shop_cs" value="{e(shop.get('cs',''))}"></div></div></div>
<div class="card"><h2>AI 상세페이지 문구(선택)</h2><p class="mut">Claude API 키(console.anthropic.com)를 넣으면 'AI 문구로 제작'이 작동합니다. 없으면 기본 문구로 만듭니다.</p><div class="grid">
<div><label>API 키 {'(저장됨, 바꿀 때만 입력)' if ai.get('api_key') else ''}</label><input name="ai_key" type="password" autocomplete="off"></div><div><label>모델</label><input name="ai_model" value="{e(ai.get('model','claude-sonnet-5-5'))}"></div></div></div>
<div class="card"><h2>자동 주문 수집</h2><label>간격(분, 0 = 끔)</label><input name="order_interval" value="{get_setting('order_interval', 30)}" style="max-width:160px"></div>
<div class="card"><h2>재고 자동 품절</h2><select name="auto_soldout_stock" style="max-width:420px"><option value="1">켜기: 재고 0이면 모든 판매처 자동 품절, 재고 넣으면 자동 재개</option><option value="0" {'' if get_setting('auto_soldout_stock', True) else 'selected'}>끄기</option></select>
<p class="mut">사입 상품은 주문이 들어올 때마다 재고가 자동으로 줄어듭니다. 위탁 상품은 오너클랜 품절·재입고를 따라갑니다.</p></div>
{'<button class="btn">저장</button>' if adm else ''}</fieldset></form><p><a href="/me">내 비밀번호 바꾸기</a></p>"""
    return page("설정", body, h.user, "/settings", h.flash, h.flash_err)

def policy_form(c):
    modes = "".join(f'<option value="{k}" {"selected" if c["margin_mode"] == k else ""}>{v}</option>' for k, v in pricing.MODE_LABEL.items())
    v = lambda x_: "" if x_ in (None, "") else f"{x_:g}" if isinstance(x_, (int, float)) else e(str(x_))
    per = "".join(f"""<tr><td>{e(ch['name'])}{'' if ch['active'] else ' <span class=mut>(꺼짐)</span>'}</td><td><input name="mm_{ch['code']}" value="{v(c['market_margin'].get(ch['code']))}" placeholder="{'판매처 기본 ' + format(ch['margin'], 'g') if ch['margin'] is not None else '정책 기본'}"></td>
<td class="mut">{ch['fee']:g}%</td><td><input name="ms_{ch['code']}" value="{v(c['market_ship'].get(ch['code']))}" placeholder="{'판매처 ' + format(ch['ship'], 'g') if ch['ship'] is not None else '기본값'}"></td></tr>""" for ch in chs.all_channels(False))
    return f"""<div class="grid"><div><label>마진 방식</label><select name="margin_mode">{modes}</select></div>
<div><label>기본 마진 (% 또는 원)</label><input name="margin" value="{v(c['margin'])}"></div>
<div><label>환율(1위안 = 원)</label><input name="cny_krw" value="{v(c['cny_krw'])}"></div><div><label>사입 부대비용 배수(단가×)</label><input name="landed_mult" value="{v(c['landed_mult'])}"></div>
<div><label>포장비(건)</label><input name="pack_cost" value="{v(c['pack_cost'])}"></div><div><label>기본 택배비(건)</label><input name="ship_cost" value="{v(c['ship_cost'])}"></div>
<div><label>올림 단위(원)</label><select name="round_to">{"".join(f'<option value="{u}" {"selected" if int(c["round_to"]) == u else ""}>{u}원</option>' for u in (10, 100, 1000))}</select></div>
<div><label>끝자리 900원 맞춤</label><select name="end_with_900"><option value="1">예</option><option value="0" {'' if c['end_with_900'] else 'selected'}>아니오</option></select></div>
<div><label>최저 판매가(원)</label><input name="min_price" value="{v(c.get('min_price') or 0)}"></div></div>
<div class="tbl" style="margin-top:12px"><table><tr><th>판매처</th><th>이 정책의 판매처별 마진(비우면 기본)</th><th>수수료</th><th>택배·배송비(원, 비우면 기본)</th></tr>{per}</table></div>
<p class="mut">수수료·통화·환율과 판매처 기본 마진은 <a href="/channels">판매처</a>에서 정합니다. 해외몰은 국제배송비를 택배비 칸에 원화로 넣으세요.</p>
<p class="mut">예) 원가 대비 200% = 이익이 총원가의 2배 · 판매가 대비 50% = 판매가의 절반이 이익 · 정액 5000 = 한 건에 5,000원 남기기. 상품 화면에서 상품별 마진도 따로 넣을 수 있습니다.</p>"""

def parse_policy(f, name):
    n = lambda k, d=None: num(f.get(k), float) if num(f.get(k), float) is not None else d
    return {"name": name, "margin_mode": f.get("margin_mode", "pct"), "margin": n("margin", 200), "cny_krw": n("cny_krw", 200),
            "landed_mult": n("landed_mult", 1.5), "pack_cost": n("pack_cost", 300), "ship_cost": n("ship_cost", 3000),
            "round_to": int(n("round_to", 100)), "end_with_900": f.get("end_with_900") == "1", "min_price": n("min_price", 0),
            "market_margin": {ch["code"]: n("mm_" + ch["code"]) for ch in chs.all_channels(False)},
            "market_ship": {ch["code"]: n("ms_" + ch["code"]) for ch in chs.all_channels(False)}}

@route("GET", "/policies")
def policies_page(h):
    rows = q("SELECT * FROM policies ORDER BY id")
    cnt = {r[0]: r[1] for r in q("SELECT policy_id, COUNT(*) FROM products GROUP BY policy_id")}
    trs = f"<tr><td><a href='/settings'><b>기본 정책</b></a></td><td>{cnt.get(None, 0)}</td><td>{e(desc(pricing.cfg()))}</td></tr>"
    trs += "".join(f"<tr><td><a href='/policies/{r['id']}'><b>{e(r['name'])}</b></a></td><td>{cnt.get(r['id'], 0)}</td><td>{e(desc(pricing._merge(json.loads(r['data']))))}</td></tr>" for r in rows)
    return page("가격 정책", f"""<h1>가격 정책</h1><div class="row" style="margin-bottom:12px"><a class="btn" href="/policies/new">+ 정책 만들기</a></div>
<div class="card tbl"><table><tr><th>정책</th><th>상품 수</th><th>내용</th></tr>{trs}</table></div>
<p class="mut">예: '저가 소모품' 정책은 원가 대비 300%, '선물용' 정책은 정액 6,000원처럼 나눠 두고, 상품 목록에서 여러 개 골라 한 번에 적용합니다.</p>""", h.user, "/policies", h.flash, h.flash_err)

def desc(c):
    unit = "원" if c["margin_mode"] == "won" else "%"
    mm = ", ".join(f"{chs.label(k)} {v:g}{unit}" for k, v in c["market_margin"].items() if v not in (None, ""))
    return f"{pricing.MODE_LABEL[c['margin_mode']]} {c['margin']:g}{unit}" + (f" (판매처별: {mm})" if mm else "")

@route("GET", r"/policies/(new|\d+)")
def policy_get(h, pid):
    r = None if pid == "new" else q("SELECT * FROM policies WHERE id=?", (pid,), one=True)
    c = pricing._merge(json.loads(r["data"])) if r else pricing.cfg()
    adm = h.user["role"] == "admin"
    delb = '<button class="btn red" name="do" value="delete" onclick="return confirm(\'정책을 지울까요? 쓰던 상품은 기본 정책으로 바뀝니다\')">삭제</button>' if r and adm else ""
    return page("가격 정책", f"""<h1>가격 정책</h1><form method="post" class="card"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0"><label>정책 이름</label><input name="pname" value="{e(r['name'] if r else '')}" required>
{policy_form(c)}<br><div class="row">{'<button class="btn" name="do" value="save">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}{delb}</div></fieldset></form>""", h.user, "/policies", h.flash, h.flash_err)

@route("POST", r"/policies/(new|\d+)", admin=True)
def policy_post(h, pid):
    f = h.form()
    if f.get("do") == "delete" and pid != "new":
        x("UPDATE products SET policy_id=NULL WHERE policy_id=?", (pid,)); x("DELETE FROM policies WHERE id=?", (pid,))
        go("/policies", "정책을 지웠습니다")
    data = json.dumps(parse_policy(f, f["pname"]), ensure_ascii=False)
    if pid == "new":
        pid = x("INSERT INTO policies(name, data) VALUES(?,?)", (f["pname"], data))
    else:
        x("UPDATE policies SET name=?, data=? WHERE id=?", (f["pname"], data, pid))
    log(h.user["username"], "가격 정책 저장", f["pname"])
    go("/policies", "저장했습니다")

# ---------- 판매처(국내·해외 자유 추가) ----------
CH_FIELDS = [("name", "판매처 이름"), ("fee", "수수료 %"), ("margin", "판매처 기본 마진(비우면 정책값)"), ("ship", "택배·국제배송비(원, 비우면 정책값)"),
             ("fx", "환율(1 통화 = 원)"), ("round_to", "올림 단위(판매처 통화)"), ("ending", "끝자리(900 / .99 / .90 / 0 / 비움)"), ("name_max", "상품명 최대 글자 수"), ("sort", "표시 순서")]

def ch_row_desc(c):
    m = "정책값" if c["margin"] is None else f"{c['margin']:g}"
    s = "정책값" if c["ship"] is None else f"{c['ship']:,.0f}원"
    cur = "원화" if c["currency"] == "KRW" else f"{c['currency']} (1 = {c['fx']:g}원)"
    return m, s, cur

@route("GET", "/channels")
def channels_page(h):
    adm = h.user["role"] == "admin"
    cnt = {r[0]: r[1] for r in q("SELECT channel, COUNT(*) FROM listings GROUP BY channel")}
    trs = ""
    pc = pricing.cfg()
    unit = "원" if pc["margin_mode"] == "won" else "%"
    fv = lambda x_: "" if x_ is None else f"{x_:g}"
    for c in chs.all_channels(False):
        m, s, cur = ch_row_desc(c)
        exp = f'<a class="btn sm gray" href="/channels/{c["id"]}/export.csv">엑셀 받기</a>' if not c["api"] else ""
        if adm:
            cells = (f"<td><input name='fee_{c['id']}' value='{fv(c['fee'])}' style='width:80px'></td>"
                     f"<td><input name='margin_{c['id']}' value='{fv(c['margin'])}' placeholder='정책 {pc['margin']:g}' style='width:100px'></td>"
                     f"<td><input name='ship_{c['id']}' value='{fv(c['ship'])}' placeholder='정책 {pc['ship_cost']:,.0f}' style='width:100px'></td>")
        else:
            cells = f"<td>{c['fee']:g}%</td><td>{m}</td><td>{s}</td>"
        trs += (f"<tr><td><a href='/channels/{c['id']}'><b>{e(c['name'])}</b></a>{'' if c['active'] else ' <span class=tag>꺼짐</span>'}<div class='mut'>{chs.API_LABEL.get(c['api'] or '', c['api'])} · <a href='/channels/{c['id']}'>통화·환율 등 더보기</a></div></td>"
                f"{cells}<td>{cur}</td><td>{c['name_max']}자</td><td>{cnt.get(c['code'], 0)} {exp}</td></tr>")
    presets = "".join(f'<option value="{i}">{e(p[0])} (수수료 {p[1]:g}% · {p[2]})</option>' for i, p in enumerate(chs.PRESETS))
    add = f"""<div class="card"><h2>판매처 추가</h2><form method="post" action="/channels/new" class="row">
<select name="preset" style="max-width:340px"><option value="">직접 입력(빈 칸에서 시작)</option>{presets}</select><button class="btn">+ 추가</button></form>
<p class="mut">예시 값(수수료·환율)은 대략적인 추정치입니다. 추가한 뒤 실제 계약 수수료와 오늘 환율로 고쳐 주세요. 이름은 '해외쇼핑몰1'처럼 마음대로 바꿔도 됩니다.</p></div>""" if adm else ""
    tbl = f"""<div class="card"><div class="tbl"><table><tr><th>판매처</th><th>수수료 %</th><th>기본 마진({unit})</th><th>배송비(원)</th><th>통화</th><th>상품명</th><th>등록 상품</th></tr>{trs}</table></div>"""
    if adm:
        tbl = f"""<form method="post" action="/channels/quick">{tbl}<br><button class="btn">수수료·마진·배송비 저장</button>
<p class="mut">빈 칸은 가격 정책 값(마진 {pc['margin']:g}{unit}, 배송비 {pc['ship_cost']:,.0f}원)을 씁니다. 상품마다 따로 정하려면 상품 화면의 '판매가 계산' 표에 넣으세요.</p></div></form>"""
    else:
        tbl += "</div>"
    body = f"""<h1>판매처</h1>{add}{tbl}
<div class="card"><h2>어떻게 쓰나요</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>네이버·쿠팡·지마켓·옥션은 <a href="/accounts">마켓 계정</a>에 API 키를 넣으면 바로 등록됩니다.</li>
<li>그 밖의 판매처(아마존·쇼피·큐텐·11번가·자사몰 등)는 여기서 추가하고 수수료·마진·통화를 정합니다.</li>
<li>상품 목록에서 상품을 골라 그 판매처에 체크 → <b>선택 판매처에 등록</b>.</li>
<li>이 화면의 <b>엑셀 받기</b>로 상품명·판매가(그 나라 통화)·재고·사진 주소·상세페이지가 든 파일을 받아 각 사이트 대량등록 메뉴에 올립니다.</li></ol>
<p class="mut">판매가는 (총원가 + 마진) ÷ (1 − 수수료)를 원화로 계산한 뒤 환율로 나눠 그 나라 통화로 바꾸고, 올림 단위·끝자리에 맞춥니다. 마진 우선순위: 상품 개별 > 가격 정책의 판매처별 > 판매처 기본 > 정책 기본.</p></div>"""
    return page("판매처", body, h.user, "/channels", h.flash, h.flash_err)

@route("POST", "/channels/quick", admin=True)
def channel_quick(h):
    f = h.form()
    n = 0
    for c in chs.all_channels(False):
        if f"fee_{c['id']}" not in f:
            continue
        fee = num(f.get(f"fee_{c['id']}"), float)
        x("UPDATE channels SET fee=?, margin=?, ship=? WHERE id=?",
          (c["fee"] if fee is None else fee, num(f.get(f"margin_{c['id']}"), float), num(f.get(f"ship_{c['id']}"), float), c["id"]))
        n += 1
    log(h.user["username"], "판매처 수수료·마진·배송비 저장", f"{n}곳")
    go("/channels", "저장했습니다. 이미 올린 상품에 반영하려면 상품 목록에서 '등록된 마켓 가격 동기화'를 누르세요.")

@route("POST", "/channels/new", admin=True)
def channel_new(h):
    f = h.form()
    i = num(f.get("preset"), int)
    if i is not None and 0 <= i < len(chs.PRESETS):
        name, fee, cur, fx, rt, end, nm = chs.PRESETS[i]
    else:
        n = q("SELECT COUNT(*) FROM channels WHERE api='' OR api IS NULL", one=True)[0] + 1
        name, fee, cur, fx, rt, end, nm = f"해외쇼핑몰{n}", 10, "USD", 1400, 0.01, ".99", 100
    sort = (q("SELECT MAX(sort) FROM channels", one=True)[0] or 0) + 1
    cid = x("INSERT INTO channels(code,name,api,fee,currency,fx,round_to,ending,name_max,active,sort) VALUES(?,?,?,?,?,?,?,?,?,1,?)",
            ("tmp" + uuid.uuid4().hex[:6], name, "", fee, cur, fx, rt, end, nm, sort))
    x("UPDATE channels SET code=? WHERE id=?", (f"ch{cid}", cid))
    log(h.user["username"], "판매처 추가", name)
    go(f"/channels/{cid}", f"'{name}' 판매처를 추가했습니다. 수수료·마진·환율을 확인하고 저장하세요.")

@route("GET", r"/channels/(\d+)")
def channel_get(h, cid):
    c = q("SELECT * FROM channels WHERE id=?", (cid,), one=True)
    if not c:
        go("/channels", "판매처가 없습니다", True)
    adm = h.user["role"] == "admin"
    builtin = bool(c["api"])
    v = lambda x_: "" if x_ is None else (f"{x_:g}" if isinstance(x_, float) else e(str(x_)))
    inputs = ""
    for k, lab in CH_FIELDS:
        if builtin and k in ("fx", "round_to", "ending"):
            continue
        inputs += f'<div><label>{lab}</label><input name="{k}" value="{v(c[k])}"></div>'
    curs = "".join(f'<option value="{k}" {"selected" if c["currency"] == k else ""}>{k} {n}</option>' for k, n in chs.CURRENCIES)
    cur = "" if builtin else f'<div><label>통화</label><select name="currency">{curs}</select></div>'
    act = f'<div><label>사용</label><select name="active"><option value="1">켜기</option><option value="0" {"" if c["active"] else "selected"}>끄기(목록·가격 계산에서 숨김)</option></select></div>'
    delb = "" if builtin or not adm else '<button class="btn red" name="do" value="delete" onclick="return confirm(\'판매처를 지울까요? 등록 기록도 같이 지워집니다\')">삭제</button>'
    note = ("<p class='mut'>API로 바로 등록하는 판매처라 원화·올림 단위는 가격 정책을 따릅니다. 수수료·기본 마진·배송비·상품명 길이만 바꿀 수 있습니다.</p>" if builtin else
            "<p class='mut'>예: 아마존 미국이면 통화 USD, 환율 1400, 올림 단위 0.01, 끝자리 .99 → 12.99달러처럼 맞춥니다. 일본은 JPY, 올림 단위 10, 끝자리 0.</p>")
    sample = ""
    p = q("SELECT * FROM products ORDER BY id DESC LIMIT 1", one=True)
    if p:
        b = pricing.breakdown(p, c)
        sample = f"<p>예시: <b>{e(p['name'])}</b> → 판매가 <b>{b['price_text']}</b> (원화 ≈{b['price_krw']:,}원, 이익 {b['profit']:,}원, 원가 대비 {b['margin_on_cost']}%)</p>"
    body = f"""<h1>{e(c['name'])}</h1><form method="post" class="card"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0">
<div class="mut">{chs.API_LABEL.get(c['api'] or '', c['api'])}</div><div class="grid">{inputs}{cur}{act}</div>{note}{sample}
<div class="row">{'<button class="btn" name="do" value="save">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}{delb}<a class="btn gray" href="/channels">목록</a></div></fieldset></form>"""
    return page(c["name"], body, h.user, "/channels", h.flash, h.flash_err)

@route("POST", r"/channels/(\d+)", admin=True)
def channel_post(h, cid):
    c = q("SELECT * FROM channels WHERE id=?", (cid,), one=True)
    if not c:
        go("/channels", "판매처가 없습니다", True)
    f = h.form()
    if f.get("do") == "delete" and not c["api"]:
        x("DELETE FROM listings WHERE channel=? AND account_id IS NULL", (c["code"],))
        x("DELETE FROM channels WHERE id=?", (cid,))
        log(h.user["username"], "판매처 삭제", c["name"])
        go("/channels", "지웠습니다")
    g = lambda k, d=None: num(f.get(k), float) if num(f.get(k), float) is not None else d
    vals = {"name": (f.get("name") or c["name"]).strip(), "fee": g("fee", c["fee"]), "margin": g("margin"), "ship": g("ship"),
            "name_max": int(g("name_max", c["name_max"] or 100)), "sort": int(g("sort", c["sort"] or 0)), "active": 1 if f.get("active", "1") == "1" else 0}
    if not c["api"]:
        vals.update({"currency": f.get("currency", "KRW"), "fx": 1 if f.get("currency") == "KRW" else g("fx", c["fx"] or 1),
                     "round_to": g("round_to", c["round_to"] or 100), "ending": (f.get("ending") or "").strip()})
    x(f"UPDATE channels SET {', '.join(k + '=?' for k in vals)} WHERE id=?", (*vals.values(), cid))
    log(h.user["username"], "판매처 저장", f"{vals['name']} 수수료 {vals['fee']:g}%")
    go(f"/channels/{cid}", "저장했습니다")

@route("GET", r"/channels/(\d+)/export\.csv")
def channel_export(h, cid):
    c = q("SELECT * FROM channels WHERE id=?", (cid,), one=True)
    if not c:
        go("/channels", "판매처가 없습니다", True)
    host = h.headers.get("Host", "localhost:8765")
    base = ("https://" if h.headers.get("X-Forwarded-Proto") == "https" else "http://") + host
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["상품번호", "상품명", f"판매가({c['currency']})", "원화 환산", "재고", "상태", "대표 이미지", "추가 이미지", "테마", "검색어", "세트 구성", "원문 상품명", "소싱 링크", "상세페이지 HTML"])
    rows = q("SELECT l.id lid, l.price lprice, l.stock lstock, l.status lstatus, p.* FROM listings l JOIN products p ON p.id=l.product_id WHERE l.channel=? AND l.account_id IS NULL ORDER BY l.id", (c["code"],))
    for r in rows:
        imgs = [i if i.startswith("http") else base + "/img/" + quote(i) for i in img_list(r)]
        price = r["lprice"]
        fx = c["fx"] if c["currency"] != "KRW" else 1
        w.writerow([r["id"], naming.process(r["name"], c["code"]), price, round(float(price or 0) * float(fx or 1)), 0 if r["lstatus"] in ("품절", "판매중지") else r["lstock"],
                    r["lstatus"], imgs[0] if imgs else "", " ".join(imgs[1:]), r["theme"] or "", r["keyword"] or "", r["set_desc"] or "",
                    r["source_name"] or "", r["source_url"] or "", (r["detail_html"] or "").replace("/img/", base + "/img/")])
    x("UPDATE listings SET status='엑셀 내보냄', updated=? WHERE channel=? AND account_id IS NULL AND status='엑셀 대기'", (time.time(), c["code"]))
    log(h.user["username"], "판매처 엑셀 받기", f"{c['name']} {len(rows)}개")
    h.extra_headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(c['name'])}_{time.strftime('%Y%m%d')}.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿" + buf.getvalue()

# ---------- 오너클랜 위탁 ----------
from . import ownerclan as ocmod
from . import couriers

def oc_conf():
    return get_setting("ownerclan", {}) or {}

def consign_policy_id():
    r = q("SELECT id FROM policies WHERE name='위탁 기본'", one=True)
    return r["id"] if r else None

def import_items(items, split, policy_id, user):
    """오너클랜 상품 → 우리 상품(위탁). 같은 코드·옵션이 있으면 정보만 갱신"""
    made, updated = 0, 0
    for it in items:
        if not it or not it.get("key"):
            continue
        opts = it.get("options") or []
        if split and len(opts) > 1:
            picks = opts
        else:
            live = [o for o in opts if (o.get("quantity") or 0) > 0]
            picks = [(live or opts)[0]] if opts else [None]
        for o in picks:
            vals = [a.get("value") for a in (o or {}).get("optionAttributes") or []]
            otext = " / ".join(str(v) for v in vals)
            name = it.get("name") or it["key"]
            if split and len(opts) > 1 and otext:
                name = f"{name} {otext}"
            price = ocmod.price_of(it, vals)
            stock = int((o or {}).get("quantity") or 0) if o else 99
            soldout = ocmod.is_soldout(it, vals or None)
            imgs = ocmod.images_of(it)
            old = q("SELECT * FROM products WHERE supplier='ownerclan' AND supplier_key=? AND COALESCE(supplier_option,'')=?", (it["key"], otext), one=True)
            if old:
                x("UPDATE products SET supply_price=?, cost_krw=?, supply_ship=?, fixed_price=?, supplier_status=?, supplier_checked=?, stock=? WHERE id=?",
                  (price, price, it.get("shippingFee"), it.get("fixedPrice") or None, "품절" if soldout else "판매중", time.time(), 0 if soldout else min(stock, 999), old["id"]))
                updated += 1
                continue
            x("""INSERT INTO products(name,theme,keyword,source_name,source_url,cost_krw,set_qty,set_desc,stock,images,detail_html,status,updated,updated_by,
                   supply_type,supplier,supplier_key,supplier_option,supply_price,supply_ship,fixed_price,supplier_status,supplier_checked,policy_id)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (name, "위탁", "", it.get("name"), f"https://ownerclan.com/V2/product/view.php?selfcode={it['key']}", price, 1, otext,
               0 if soldout else min(stock, 999), json.dumps(imgs, ensure_ascii=False), it.get("content") or None, "품절" if soldout else "준비",
               time.time(), user, "위탁", "ownerclan", it["key"], otext, price, it.get("shippingFee"), it.get("fixedPrice") or None,
               "품절" if soldout else "판매중", time.time(), policy_id))
            made += 1
    log(user, "오너클랜 상품 가져오기", f"새로 {made}개, 갱신 {updated}개")
    return made, updated

def sync_ownerclan(user="자동"):
    """위탁 상품의 공급가·품절을 오너클랜에서 다시 읽어 반영"""
    c = oc_conf()
    oc = ocmod.OwnerClan()
    rows = q("SELECT * FROM products WHERE supply_type='위탁' AND supplier='ownerclan' AND supplier_key!=''")
    if not rows:
        return "위탁 상품이 없습니다"
    items = {it["key"]: it for it in oc.items(sorted({r["supplier_key"] for r in rows})) if it}
    changed, out, back, gone, errs = 0, 0, 0, 0, []
    for p in rows:
        it = items.get(p["supplier_key"])
        if not it:
            gone += 1
            continue
        vals = [v.strip() for v in (p["supplier_option"] or "").split("/") if v.strip()]
        price = ocmod.price_of(it, vals or None)
        soldout = ocmod.is_soldout(it, vals or None)
        price_changed = abs(float(p["supply_price"] or 0) - price) >= 1 or (it.get("shippingFee") is not None and float(p["supply_ship"] or 0) != float(it.get("shippingFee") or 0))
        x("UPDATE products SET supply_price=?, cost_krw=?, supply_ship=?, fixed_price=?, supplier_status=?, supplier_checked=? WHERE id=?",
          (price, price, it.get("shippingFee") if it.get("shippingFee") is not None else p["supply_ship"], it.get("fixedPrice") or p["fixed_price"],
           "품절" if soldout else "판매중", time.time(), p["id"]))
        if price_changed:
            changed += 1
            log(user, "오너클랜 가격 변경", f"{p['name']} {p['supply_price'] or 0:,.0f} → {price:,.0f}원")
            if c.get("auto_price", True) and not soldout:
                _, ms = push_listings(p["id"], "sync"); errs += ms
        if soldout and p["status"] != "품절(공급처)" and c.get("auto_soldout", True):
            _, ms = push_listings(p["id"], "soldout", "품절(공급처)"); errs += ms
            out += 1
            log(user, "오너클랜 품절 → 판매중지", p["name"])
        elif not soldout and p["status"] == "품절(공급처)" and c.get("auto_soldout", True):
            x("UPDATE products SET stock=?, status='등록' WHERE id=?", (99, p["id"]))
            _, ms = push_listings(p["id"], "resume"); errs += ms
            back += 1
            log(user, "오너클랜 재입고 → 판매 재개", p["name"])
    msg = f"{len(rows)}개 확인 · 가격 변경 {changed} · 품절로 판매중지 {out} · 재입고로 재개 {back}" + (f" · 오너클랜에서 못 찾음 {gone}" if gone else "")
    log(user, "오너클랜 동기화", msg + ("; " + "; ".join(errs)[:400] if errs else ""))
    if out or back or changed:
        notify.send("오너클랜 품절·가격 변경", msg, "soldout")
    set_setting("ownerclan_last_sync", time.time())
    return msg + ("\n" + "\n".join(errs[:20]) if errs else "")

def place_order(o, user):
    """위탁 주문 1건을 오너클랜에 발주"""
    p = q("SELECT * FROM products WHERE id=?", (o["product_id"],), one=True) if o["product_id"] else None
    if not p or (p["supply_type"] or "") != "위탁" or not p["supplier_key"]:
        raise ocmod.OCError("오너클랜 상품코드가 연결되지 않은 주문입니다(상품 화면에서 위탁·상품코드를 넣어 주세요)")
    rcv = json.loads(o["rcv"] or "{}")
    for k, lab in (("name", "받는 분"), ("phone", "연락처"), ("zip", "우편번호"), ("addr1", "주소")):
        if not rcv.get(k):
            raise ocmod.OCError(f"주문에 {lab}이(가) 없습니다")
    vals = [v.strip() for v in (p["supplier_option"] or "").split("/") if v.strip()]
    qty = int(o["qty"] or 1) * int(p["set_qty"] or 1)
    oc = ocmod.OwnerClan(force_dry=get_setting("dry_run", True))
    inp = oc.order_input([(p["supplier_key"], vals, qty)], rcv, rcv.get("memo", ""))
    r = oc.create_order(inp)
    x("UPDATE orders SET po_status=?, po_key=?, po_msg=? WHERE id=?",
      ("발주완료(미리보기)" if r.get("dry") else "발주완료", r["key"], os.path.basename(r.get("file", "")) if r.get("dry") else "", o["id"]))
    log(user, "오너클랜 발주" + (" 미리보기" if r.get("dry") else ""), f"{p['name']} ×{qty} → {r['key']}")
    return r

def auto_place_orders(user="자동"):
    for o in q("SELECT * FROM orders WHERE po_status='발주대기' AND supply_type='위탁'"):
        try:
            place_order(o, user)
        except Exception as ex:
            x("UPDATE orders SET po_status='발주실패', po_msg=? WHERE id=?", (str(ex)[:500], o["id"]))

def send_tracking(o, user):
    """송장을 마켓에 보내고 발송완료로"""
    if not o["tracking"]:
        raise MarketError("송장번호가 없습니다")
    acc = q("SELECT * FROM accounts WHERE id=?", (o["account_id"],), one=True) if o["account_id"] else None
    if not acc:   # 예시 주문 등
        x("UPDATE orders SET po_status='발송완료(예시)', shipped_at=? WHERE id=?", (time.time(), o["id"]))
        return
    code = couriers.code(o["courier"], acc["market"])
    if not code:
        raise MarketError(f"택배사 '{o['courier']}'의 {MARKETS[acc['market']].name} 코드를 모릅니다")
    m = market_for(acc)
    r = m.ship(json.loads(o["ship_ref"] or "{}"), code, o["tracking"])
    x("UPDATE orders SET po_status=?, shipped_at=?, po_msg=? WHERE id=?",
      ("발송완료(미리보기)" if isinstance(r, dict) and r.get("dry") else "발송완료", time.time(), "", o["id"]))
    log(user, "송장 전송", f"{MARKETS[acc['market']].name} {o['order_id']} {o['courier']} {o['tracking']}")

def check_tracking(user="자동"):
    """오너클랜 발주 건의 송장을 확인해 마켓으로 보냄"""
    oc = ocmod.OwnerClan()
    got, sent, errs = 0, 0, []
    for o in q("SELECT * FROM orders WHERE po_status IN ('발주완료','발주완료(미리보기)','송장받음') AND po_key!=''"):
        try:
            if o["po_status"] != "송장받음":
                od = oc.order(o["po_key"])
                tr = next((pp for pp in (od.get("products") or []) if pp.get("trackingNumber")), None)
                if not tr:
                    continue
                x("UPDATE orders SET courier=?, tracking=?, po_status='송장받음' WHERE id=?",
                  (tr.get("shippingCompanyName") or tr.get("shippingCompanyCode") or "", tr["trackingNumber"], o["id"]))
                got += 1
                o = q("SELECT * FROM orders WHERE id=?", (o["id"],), one=True)
            send_tracking(o, user)
            sent += 1
        except Exception as ex:
            errs.append(f"{o['order_id']}: {ex}")
            x("UPDATE orders SET po_msg=? WHERE id=?", (str(ex)[:500], o["id"]))
    if got or sent or errs:
        log(user, "송장 확인", f"새 송장 {got} · 마켓 전송 {sent}" + ("; " + "; ".join(errs)[:400] if errs else ""))
    return got, sent, errs

def purge_personal():
    """발송 끝난 지 90일 지난 주문의 받는 분 정보 지우기"""
    x("UPDATE orders SET rcv='{}', buyer='' WHERE shipped_at IS NOT NULL AND shipped_at < ? AND rcv!='{}'", (time.time() - 90 * 86400,))

def mask(name):
    name = name or ""
    return name[:1] + "*" * max(0, len(name) - 2) + name[-1:] if len(name) > 1 else name

@route("GET", "/suppliers")
def suppliers_page(h):
    c = oc_conf(); adm = h.user["role"] == "admin"
    last = get_setting("ownerclan_last_sync")
    n = q("SELECT COUNT(*) FROM products WHERE supply_type='위탁'", one=True)[0]
    pol_opts = "".join(f'<option value="{i}" {"selected" if i == consign_policy_id() else ""}>{e(nm)}</option>' for i, nm in pricing.policies())
    chk = lambda k, d=True: "checked" if c.get(k, d) else ""
    results = ""
    if h.qs.get("q"):
        try:
            its = ocmod.OwnerClan().search(h.qs["q"], 50, num(h.qs.get("min"), int), num(h.qs.get("max"), int))
            results = "".join(f"<tr><td><input type='checkbox' name='key' value='{e(it['key'])}' style='width:auto'></td><td>{e(it['key'])}</td><td>{e(it.get('name') or '')}</td>"
                              f"<td>{float(it.get('price') or 0):,.0f}원</td><td>{len(it.get('options') or [])}</td><td>{'품절' if ocmod.is_soldout(it) else '판매중'}</td></tr>" for it in its)
            results = f"""<form method="post" action="/suppliers/import" data-busy><div class="tbl"><table><tr><th><input type="checkbox" data-all="key" style="width:auto"></th><th>코드</th><th>상품명</th><th>공급가</th><th>옵션</th><th>상태</th></tr>{results or '<tr><td colspan=6>결과 없음</td></tr>'}</table></div>
<input type="hidden" name="policy_id" value="{consign_policy_id() or ''}"><label style="display:inline-flex;gap:6px;margin:10px 0"><input type="checkbox" name="split" value="1" style="width:auto"> 옵션마다 상품을 따로 만들기</label><br><button class="btn green">선택 상품 가져오기</button></form>"""
        except Exception as ex:
            results = f'<div class="flash err">{e(str(ex))}</div>'
    setform = f"""<div class="card"><h2>오너클랜 연결</h2><form method="post" action="/suppliers/save"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0"><div class="grid">
<div><label>오너클랜 판매사 아이디</label><input name="username" value="{e(c.get('username', ''))}" autocomplete="off"></div>
<div><label>비밀번호 {'(저장됨, 바꿀 때만 입력)' if c.get('password') else ''}</label><input name="password" type="password" autocomplete="new-password"></div>
<div><label>서버</label><select name="env"><option value="prod">실서버</option><option value="sandbox" {'selected' if c.get('env') == 'sandbox' else ''}>테스트(샌드박스)</option></select></div>
<div><label>품절·가격 확인 간격(시간, 0=끔)</label><input name="sync_hours" value="{c.get('sync_hours', 3)}"></div></div>
<label style="display:flex;gap:8px;margin-top:10px"><input type="checkbox" name="auto_soldout" value="1" style="width:auto" {chk('auto_soldout')}> 오너클랜에서 품절되면 모든 마켓 판매중지, 재입고되면 다시 판매</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="auto_price" value="1" style="width:auto" {chk('auto_price')}> 공급가가 바뀌면 판매가를 다시 계산해 마켓에 반영</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="auto_order" value="1" style="width:auto" {chk('auto_order', False)}> 주문이 들어오면 오너클랜에 자동 발주(예치금이 바로 빠져나갑니다. 처음에는 끄고 직접 누르는 걸 권합니다)</label>
<br>{'<button class="btn">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}</fieldset></form>
<form method="post" action="/suppliers/test" class="row" style="margin-top:8px" data-busy><button class="btn gray">연결 확인</button></form>
<p class="mut">오너클랜 API 센터(ownerclan.com → API 센터)에서 API 사용 신청이 먼저 필요합니다. 아이디·비밀번호가 없으면 미리보기 모드로 예시 상품·예시 발주만 만들어집니다.</p></div>"""
    body = f"""<h1>오너클랜 위탁</h1><div class="grid"><div class="card"><div class="mut">위탁 상품</div><div class="stat">{n}</div></div>
<div class="card"><div class="mut">마지막 품절·가격 확인</div><div class="stat" style="font-size:18px">{time.strftime('%m-%d %H:%M', time.localtime(last)) if last else '아직 없음'}</div>
<form method="post" action="/suppliers/sync" data-busy><button class="btn sm">지금 확인</button></form></div></div>
<div class="card"><h2>오너클랜 CSV 파일로 자동 등록</h2><p class="mut">오너클랜에서 받은 상품 파일을 넣으면 상품을 만들고 마켓에 바로 올린 뒤 폰으로 알려 드립니다.</p><a class="btn green" href="/suppliers/csv">CSV 넣기</a></div>
<div class="card"><h2>상품코드로 가져오기</h2><form method="post" action="/suppliers/import" data-busy><label>오너클랜 상품코드(W로 시작, 한 줄에 하나 또는 쉼표로 구분)</label><textarea name="keys" placeholder="W1234567&#10;W7654321"></textarea>
<div class="row"><div style="flex:1;min-width:180px"><label>가격 정책</label><select name="policy_id">{pol_opts}</select></div>
<label style="display:inline-flex;gap:6px;align-self:flex-end"><input type="checkbox" name="split" value="1" style="width:auto"> 옵션마다 상품을 따로 만들기</label>
<button class="btn green" style="align-self:flex-end">가져오기</button></div></form></div>
<div class="card"><h2>오너클랜에서 찾기</h2><form class="row"><input name="q" value="{e(h.qs.get('q', ''))}" placeholder="검색어" style="max-width:240px"><input name="min" value="{e(h.qs.get('min', ''))}" placeholder="최저 공급가" style="max-width:120px"><input name="max" value="{e(h.qs.get('max', ''))}" placeholder="최고 공급가" style="max-width:120px"><button class="btn gray">찾기</button></form><br>{results}</div>
{setform}
<div class="card"><h2>사입·위탁 같이 쓰는 법</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>가져온 상품은 '위탁'으로 표시되고 '위탁 기본' 가격 정책(공급가 + 공급처 배송비 기준)이 붙습니다. 정책은 <a href="/policies">가격 정책</a>에서 바꿉니다.</li>
<li>상품 목록에서 사입 상품과 똑같이 상세페이지를 만들고 마켓에 올립니다.</li>
<li>주문이 들어오면 <a href="/fulfill">발주·송장</a>에서 위탁 주문은 오너클랜 발주, 사입 주문은 송장 입력으로 나뉘어 보입니다.</li>
<li>오너클랜 송장이 나오면 자동으로 받아 마켓에 보냅니다.</li></ol></div>"""
    return page("오너클랜 위탁", body, h.user, "/suppliers", h.flash, h.flash_err)

@route("POST", "/suppliers/save", admin=True)
def suppliers_save(h):
    f = h.form(); c = oc_conf()
    c.update({"username": f.get("username", "").strip(), "env": f.get("env", "prod"), "sync_hours": num(f.get("sync_hours"), float) or 0,
              "auto_soldout": f.get("auto_soldout") == "1", "auto_price": f.get("auto_price") == "1", "auto_order": f.get("auto_order") == "1"})
    if f.get("password"):
        c["password"] = seal(f["password"])
    set_setting("ownerclan", c); set_setting("ownerclan_token", {})
    log(h.user["username"], "오너클랜 설정 저장", f"자동발주={'켬' if c['auto_order'] else '끔'}")
    go("/suppliers", "저장했습니다")

@route("POST", "/suppliers/test")
def suppliers_test(h):
    try:
        go("/suppliers", ocmod.OwnerClan().test())
    except ocmod.OCError as ex:
        go("/suppliers", str(ex), True)

@route("POST", "/suppliers/sync")
def suppliers_sync(h):
    try:
        go("/suppliers", sync_ownerclan(h.user["username"]))
    except ocmod.OCError as ex:
        go("/suppliers", str(ex), True)

@route("POST", "/suppliers/import")
def suppliers_import(h):
    f = h.form_multi()
    keys = [k.strip().upper() for k in re.split(r"[\s,]+", " ".join(f.get("keys", [])) + " " + " ".join(f.get("key", []))) if k.strip()]
    if not keys:
        go("/suppliers", "상품코드를 넣거나 골라 주세요", True)
    try:
        items = ocmod.OwnerClan().items(list(dict.fromkeys(keys)))
    except ocmod.OCError as ex:
        go("/suppliers", str(ex), True)
    pol = num((f.get("policy_id") or [""])[0], int) or consign_policy_id()
    made, upd = import_items(items, (f.get("split") or [""])[0] == "1", pol, h.user["username"])
    miss = len(set(keys) - {it.get("key") for it in items if it})
    go("/products?type=" + quote("위탁"), f"위탁 상품 {made}개를 새로 만들고 {upd}개를 갱신했습니다" + (f". 오너클랜에서 못 찾은 코드 {miss}개" if miss else "") + ". 상세페이지를 만들고 마켓에 올리세요.")

# ---------- 오너클랜 CSV → 자동 등록 ----------
def csv_import(items, policy_id, user):
    """오너클랜 CSV 상품 → 우리 위탁 상품. 같은 코드·옵션이면 가격·재고만 갱신. (새 상품 번호, 갱신된 상품 번호)"""
    new, upd = [], []
    for it in items:
        opt = it["option"] if len(it["option"]) <= 60 else ""
        price, stock = float(it["price"] or 0), (0 if it["soldout"] else max(0, min(int(it["stock"]), 999)))
        old = q("SELECT * FROM products WHERE supplier='ownerclan' AND supplier_key=? AND COALESCE(supplier_option,'')=?", (it["key"], opt), one=True)
        if old:
            x("UPDATE products SET supply_price=?, cost_krw=?, supply_ship=COALESCE(?,supply_ship), fixed_price=COALESCE(?,fixed_price), supplier_status=?, supplier_checked=?, stock=?, "
              "status=CASE WHEN ?=0 AND status='품절' THEN '준비' ELSE status END WHERE id=?",
              (price, price, it["ship"], it["fixed"], "품절" if it["soldout"] else "판매중", time.time(), stock, 1 if it["soldout"] else 0, old["id"]))
            upd.append(old["id"])
            continue
        detail_html = it["detail"] if "<" in it["detail"] else None
        theme = (it["category"].split(">")[-1].strip() if it["category"] else "") or "위탁"
        x("""INSERT INTO products(name,theme,keyword,source_name,source_url,cost_krw,set_qty,set_desc,stock,images,detail_html,status,updated,updated_by,
               supply_type,supplier,supplier_key,supplier_option,supply_price,supply_ship,fixed_price,supplier_status,supplier_checked,policy_id)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (it["name"], theme, it["keyword"], it["name"],
           ("https://ownerclan.com/V2/product/view.php?selfcode=" + it["key"]) if it["key"].startswith("W") else "", price, 1, opt, stock,
           json.dumps(it["images"], ensure_ascii=False), detail_html, "품절" if it["soldout"] else "준비", time.time(), user,
           "위탁", "ownerclan", it["key"], opt, price, it["ship"], it["fixed"], "품절" if it["soldout"] else "판매중", time.time(), policy_id))
        new.append(q("SELECT last_insert_rowid()", one=True)[0])
    log(user, "오너클랜 CSV 가져오기", f"새로 {len(new)}개, 갱신 {len(upd)}개")
    return new, upd

CSV_JOB = {"running": False}
updater.busy = lambda: bool(CSV_JOB.get("running"))

def csv_job(items, accs, chans, user, fname):
    CSV_JOB.update({"running": True, "start": time.time(), "file": fname, "total": len(items), "done": 0, "msg": "상품 만드는 중"})
    lines, fails = [], []
    try:
        new, upd = csv_import(items, consign_policy_id(), user)
        listed = lambda pid: q("SELECT 1 FROM listings WHERE product_id=? LIMIT 1", (pid,), one=True)
        # 새 상품 + 전에 품절이라 못 올렸다가 이번에 재고가 생긴 상품
        to_reg = [pid for pid in new + [u for u in upd if not listed(u)] if (product(pid)["supplier_status"] or "") != "품절"]
        upd = [u for u in upd if u not in to_reg]
        ok = 0
        for i, pid in enumerate(to_reg):
            CSV_JOB.update({"done": i, "msg": f"마켓에 올리는 중 {i + 1}/{len(to_reg)}"})
            try:
                k, ms, bad = publish([pid], accs, chans, user)
                ok += k
                fails += [m for m in ms if m.startswith("[실패]")]
            except Exception as ex:
                fails.append(f"[실패] {product(pid)['name']}: {ex}")
        synced = 0
        for pid in upd:      # 이미 올린 상품: 가격·재고만 마켓에 반영
            if q("SELECT 1 FROM listings WHERE product_id=? AND account_id IS NOT NULL LIMIT 1", (pid,), one=True):
                p = product(pid)
                if (p["supplier_status"] or "") == "품절":
                    k, ms = push_listings(pid, "soldout", "품절(공급처)")
                else:
                    k, ms = push_listings(pid, "sync")
                synced += k; fails += ms
        soldout_new = len([pid for pid in new if pid not in to_reg])
        dry = get_setting("dry_run", True)
        lines = [f"파일: {fname}", f"새 상품 {len(new)}개 · 이미 있던 상품 {len(upd)}개(가격·재고 갱신)",
                 f"마켓 등록 {ok}건" + (" (미리보기 모드라 실제로는 안 올라감)" if dry else "") + (f" · 품절이라 건너뜀 {soldout_new}개" if soldout_new else ""),
                 f"이미 올린 상품 가격·재고 반영 {synced}건" if upd else "", f"실패 {len(fails)}건" if fails else "실패 없음"]
        lines = [l for l in lines if l]
        CSV_JOB.update({"msg": "\n".join(lines), "fails": fails[:50]})
        log(user, "오너클랜 CSV 자동 등록", " · ".join(lines)[:500])
        notify.send("상품 자동 등록 " + ("완료" if not fails else f"완료(실패 {len(fails)}건)"), "\n".join(lines + fails[:10]), "upload")
    except Exception as ex:
        traceback.print_exc()
        CSV_JOB.update({"msg": f"오류로 멈췄습니다: {ex}", "fails": fails[:50]})
        notify.send("상품 자동 등록 오류", f"{fname}: {ex}", "error")
    finally:
        CSV_JOB.update({"running": False, "end": time.time()})

def csv_targets():
    c = get_setting("csv_targets", None)
    accs = q("SELECT * FROM accounts WHERE active=1 ORDER BY id")
    if c is None:
        return [a["id"] for a in accs], []
    return c.get("accs", []), c.get("chans", [])

@route("GET", "/suppliers/csv")
def suppliers_csv_get(h):
    acc_sel, ch_sel = csv_targets()
    accs = q("SELECT * FROM accounts WHERE active=1 ORDER BY id")
    acc_html = "".join(f'<label style="display:flex;gap:8px"><input type="checkbox" name="acc" value="{a["id"]}" style="width:auto" {"checked" if a["id"] in acc_sel else ""}> {e(MARKETS[a["market"]].name)} · {e(a["label"] or "")}</label>' for a in accs) \
        or '<p class="mut">아직 마켓 계정이 없습니다. <a href="/accounts">마켓 계정</a>에서 먼저 넣으세요. 없으면 상품만 만들어 둡니다.</p>'
    ch_html = "".join(f'<label style="display:flex;gap:8px"><input type="checkbox" name="ch" value="{e(c["code"])}" style="width:auto" {"checked" if c["code"] in ch_sel else ""}> {e(c["name"])} (엑셀)</label>' for c in chs.all_channels() if not c["api"])
    j = CSV_JOB
    if j.get("running"):
        status = f'<div class="card"><h2>진행 중</h2><p>{e(j.get("file", ""))} · {e(j.get("msg", ""))}</p><p class="mut">이 화면을 닫아도 서버에서 계속 진행됩니다. 끝나면 폰으로 알려 드립니다.</p><a class="btn gray" href="/suppliers/csv">새로고침</a></div>'
    elif j.get("end"):
        fl = "".join(f"<li>{e(m)}</li>" for m in j.get("fails") or [])
        status = f'<div class="card"><h2>지난 작업 결과 ({time.strftime("%m-%d %H:%M", time.localtime(j["end"]))})</h2><pre style="white-space:pre-wrap;margin:0">{e(j.get("msg", ""))}</pre>{"<ul>" + fl + "</ul>" if fl else ""}<p><a href="/listings">등록현황 보기</a></p></div>'
    else:
        status = ""
    dry = get_setting("dry_run", True)
    nc = notify.conf()
    body = f"""<h1>오너클랜 CSV 자동 등록</h1>{status}
{'<div class="flash err">지금은 <b>미리보기 모드</b>라 마켓에 실제로 올라가지 않습니다. 실제로 올리려면 <a href="/settings">설정</a>에서 등록 모드를 <b>실제 등록 모드</b>로 바꾸세요.</div>' if dry else ''}
<form method="post" enctype="multipart/form-data" class="card" data-busy><h2>1. 파일 넣기</h2>
<label>오너클랜에서 받은 상품 파일(.csv 또는 .xlsx)</label><input type="file" name="file" accept=".csv,.xlsx,.txt" required>
<h2 style="margin-top:16px">2. 올릴 곳</h2>{acc_html}{ch_html}
<p class="mut">고른 곳은 기억해 두었다가 다음에도 똑같이 씁니다.</p>
<button class="btn green">넣고 자동으로 올리기</button></form>
<div class="card"><h2>이렇게 처리됩니다</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>파일의 상품을 '위탁' 상품으로 만듭니다. 가격은 '위탁 기본' <a href="/policies">가격 정책</a>(마진)으로 계산합니다.</li>
<li>상세페이지가 파일에 있으면 그대로, 없으면 사진으로 자동 제작합니다.</li>
<li>고른 마켓에 바로 올립니다. 품절 상품은 건너뜁니다.</li>
<li>같은 상품코드가 이미 있으면 새로 올리지 않고 가격·재고만 마켓에 반영합니다. 그래서 오너클랜 파일을 매일 다시 넣어도 됩니다.</li>
<li>끝나면 폰으로 결과 알림이 갑니다. (알림: {'켜짐' if nc.get('ntfy_topic') or nc.get('tg_chat') else '꺼짐'} · <a href="/notify">폰 알림 설정</a>)</li></ol>
<p class="mut">열 이름은 상품코드·상품명·오너클랜판매가(공급가)·소비자가·배송비·재고수량·옵션·대표이미지·상세설명 등을 알아서 찾습니다.</p></div>"""
    return page("오너클랜 CSV 자동 등록", body, h.user, "/suppliers", h.flash, h.flash_err)

@route("POST", "/suppliers/csv")
def suppliers_csv_post(h):
    if CSV_JOB.get("running"):
        go("/suppliers/csv", "앞 작업이 아직 진행 중입니다. 끝나면 다시 넣어 주세요.", True)
    f, files = h.multipart()
    fn, data = (files.get("file") or [("", b"")])[0]
    if not data:
        go("/suppliers/csv", "파일을 골라 주세요", True)
    try:
        items, found = occsv.parse(fn, data)
    except Exception as ex:
        go("/suppliers/csv", f"파일을 읽지 못했습니다: {ex}", True)
    if not items:
        go("/suppliers/csv", "상품을 찾지 못했습니다. 첫 줄에 '상품명' 같은 열 이름이 있는 파일인지 확인해 주세요.", True)
    acc_ids = [int(v) for v in h.multi_values("acc") if v.isdigit()]
    ch_codes = h.multi_values("ch")
    set_setting("csv_targets", {"accs": acc_ids, "chans": ch_codes})
    accs = [a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (i,), one=True) for i in acc_ids) if a]
    chans = [c for c in (chs.get(k) for k in ch_codes) if c]
    log(h.user["username"], "오너클랜 CSV 넣음", f"{fn} {len(items)}개 · 찾은 열: {found}"[:500])
    threading.Thread(target=csv_job, args=(items, accs, chans, h.user["username"], fn), daemon=True).start()
    time.sleep(0.5)
    go("/suppliers/csv", f"{len(items)}개 상품을 읽었습니다. 지금 서버에서 마켓에 올리는 중이고, 끝나면 폰으로 알려 드립니다.\n찾은 열: {found}")

# ---------- 폰 알림 ----------
@route("GET", "/notify")
def notify_get(h):
    c = notify.conf(); adm = h.user["role"] == "admin"
    chk = lambda k: "checked" if c.get(k, True) else ""
    topic = c.get("ntfy_topic", "")
    body = f"""<h1>폰 알림</h1>
<div class="card"><h2>방법 1. ntfy 앱 (가입 없음, 추천)</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>폰에서 앱스토어·플레이스토어에 <b>ntfy</b> 를 검색해 설치합니다.</li>
<li>앱에서 <b>+</b> (Subscribe to topic) 를 누르고 아래 이름을 그대로 넣습니다.</li>
<li>아래 <b>시험 알림 보내기</b> 를 눌러 폰에 알림이 오는지 봅니다.</li></ol>
<p style="font-size:20px;margin:12px 0"><b>{e(topic)}</b></p><p class="mut">이 이름을 아는 사람은 알림을 볼 수 있으니 남에게 알려 주지 마세요. 팀원도 같은 이름을 넣으면 함께 받습니다.</p></div>
<form method="post" class="card"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0"><h2>설정</h2>
<div class="grid"><div><label>ntfy 알림 이름(topic)</label><input name="ntfy_topic" value="{e(topic)}"></div>
<div><label>ntfy 서버</label><input name="ntfy_server" value="{e(c.get('ntfy_server', 'https://ntfy.sh'))}"></div></div>
<h2 style="margin-top:16px">방법 2. 텔레그램 (선택)</h2><div class="grid">
<div><label>봇 토큰 {'(저장됨, 바꿀 때만 입력)' if c.get('tg_token') else ''}</label><input name="tg_token" type="password" autocomplete="off" placeholder="@BotFather 에서 받은 토큰"></div>
<div><label>채팅 ID</label><input name="tg_chat" value="{e(c.get('tg_chat', ''))}" placeholder="숫자"></div></div>
<h2 style="margin-top:16px">어떤 알림을 받을까요</h2>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_upload" value="1" style="width:auto" {chk('on_upload')}> 상품 자동 등록 결과(CSV 넣은 뒤)</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_order" value="1" style="width:auto" {chk('on_order')}> 새 주문</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_soldout" value="1" style="width:auto" {chk('on_soldout')}> 품절·재입고·공급가 변경</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_error" value="1" style="width:auto" {chk('on_error')}> 오류</label>
<br>{'<button class="btn">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}</fieldset></form>
<form method="post" action="/notify/test" data-busy><button class="btn gray">시험 알림 보내기</button></form>"""
    return page("폰 알림", body, h.user, "/notify", h.flash, h.flash_err)

@route("POST", "/notify", admin=True)
def notify_post(h):
    f = h.form(); c = notify.conf()
    c.update({"ntfy_topic": re.sub(r"[^A-Za-z0-9_-]", "", f.get("ntfy_topic", ""))[:64], "ntfy_server": (f.get("ntfy_server") or "https://ntfy.sh").strip(),
              "tg_chat": f.get("tg_chat", "").strip()})
    for k in ("on_upload", "on_order", "on_soldout", "on_error"):
        c[k] = f.get(k) == "1"
    if f.get("tg_token"):
        c["tg_token"] = seal(f["tg_token"].strip())
    set_setting("notify", c)
    log(h.user["username"], "폰 알림 설정 저장")
    go("/notify", "저장했습니다")

@route("POST", "/notify/test")
def notify_test(h):
    sent = notify.send("멀티마켓 시험 알림", "알림이 잘 옵니다. " + time.strftime("%m-%d %H:%M"), wait=True)
    if sent:
        go("/notify", "보냈습니다. 폰에 알림이 왔는지 확인하세요.")
    go("/notify", "보내지 못했습니다. 알림 이름(topic)이나 텔레그램 설정을 확인하세요. 자세한 내용은 작업 이력에 있습니다.", True)

# ---------- 잘 팔릴 상품 자동 찾기 ----------
def finder_import(fids, user):
    """추천 후보 → 우리 위탁 상품. 만들어진 상품 번호 목록"""
    rows = [q("SELECT * FROM finds WHERE id=?", (i,), one=True) for i in fids]
    rows = [r for r in rows if r]
    if not rows:
        return []
    keys = list(dict.fromkeys(r["item_key"] for r in rows))
    items = ocmod.OwnerClan().items(keys)
    import_items(items, False, consign_policy_id(), user)
    pids = []
    for r in rows:
        pr = q("SELECT id FROM products WHERE supplier='ownerclan' AND supplier_key=? ORDER BY id LIMIT 1", (r["item_key"],), one=True)
        if pr:
            pids.append(pr["id"])
            x("UPDATE finds SET status='가져옴', product_id=? WHERE id=?", (pr["id"], r["id"]))
    return list(dict.fromkeys(pids))

def finder_auto(user="자동"):
    """자동 찾기(켜져 있을 때) + 자동 등록(켜져 있을 때)"""
    c = finder.conf()
    if not c.get("auto_find"):
        return
    if time.time() - (get_setting("finder_last") or 0) < float(c.get("find_hours") or 24) * 3600:
        return
    try:
        finder.run(user)
    except Exception as ex:
        set_setting("finder_last", time.time())
        log(user, "상품 자동 찾기 실패", str(ex)[:300]); return
    if not c.get("auto_register"):
        return
    day0 = time.mktime(time.localtime()[:3] + (0, 0, 0, 0, 0, -1))
    done = q("SELECT COUNT(*) FROM finds WHERE status IN ('가져옴','등록됨') AND found_at>=?", (day0,), one=True)[0]
    left = int(c.get("max_per_day") or 0) - done
    if left <= 0:
        return
    fids = [r["id"] for r in q("SELECT id FROM finds WHERE status='추천' AND score>=? ORDER BY score DESC LIMIT ?", (float(c.get("min_score") or 0), left))]
    if not fids:
        return
    accs = [a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (int(i),), one=True) for i in c.get("reg_accs") or []) if a]
    chans = [ch for ch in (chs.get(k) for k in c.get("reg_chans") or []) if ch]
    pids = finder_import(fids, user)
    if pids and (accs or chans):
        ok, ms, _ = publish(pids, accs, chans, user)
        for pid in pids:
            x("UPDATE finds SET status='등록됨' WHERE product_id=?", (pid,))
        log(user, "자동 찾기 → 자동 등록", f"{len(pids)}개 상품 {ok}건 " + "; ".join(ms)[:300])

@route("GET", "/finder")
def finder_page(h):
    c = finder.conf()
    st = h.qs.get("st", "추천")
    rows = q("SELECT * FROM finds WHERE status=? ORDER BY score DESC, id DESC LIMIT 300", (st,))
    accs = q("SELECT * FROM accounts WHERE active=1 ORDER BY market,id")
    allch = chs.all_channels()
    ck = lambda on: "checked" if on else ""
    acc_opts = "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' style='width:auto' name='acc' value='{a['id']}' {ck(not c.get('reg_accs') or str(a['id']) in map(str, c.get('reg_accs') or []))}> {e(MARKETS[a['market']].name)} · {e(a['label'])}</label>" for a in accs)
    acc_opts += "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' style='width:auto' name='ch' value='{e(ch['code'])}' {ck(ch['code'] in (c.get('reg_chans') or []))}> {e(ch['name'])} <span class='mut'>(엑셀)</span></label>" for ch in allch if not ch["api"])
    acc_opts = acc_opts or "<span class='mut'>마켓 계정이나 판매처를 먼저 추가하세요</span>"
    def fv(v):
        return "" if v in (None, "") else f"{v:,.0f}" if isinstance(v, (int, float)) else e(str(v))
    trs = "".join(f"""<tr><td><input type="checkbox" name="fid" value="{r['id']}" style="width:auto"></td><td>{f'<img class="thumb" src="{e(r["image"])}" loading="lazy" referrerpolicy="no-referrer">' if r['image'] else '<div class="thumb"></div>'}</td>
<td><b>{e(r['item_name'] or '')}</b><div class="mut">{e(r['item_key'])} · 키워드 <b>{e(r['keyword'])}</b>{f" · 월 검색 {r['volume']:,}" if r['volume'] else ''}</div><div class="mut">{e(r['why'] or '')}</div></td>
<td><b style="font-size:18px">{r['score']:g}</b></td><td>{fv(r['supply_price'])}원</td><td><b>{fv(r['our_price'])}원</b>{f"<div class='mut'>시장 {fv(r['mkt_low'])}~{fv(r['mkt_avg'])}</div>" if r['mkt_avg'] else ''}</td><td>{fv(r['profit'])}원</td>
<td>{f"<a href='/products/{r['product_id']}'>상품 보기</a>" if r['product_id'] else ''}</td></tr>""" for r in rows)
    tabs = " ".join(f"<a class='btn sm {'' if st == t else 'gray'}' href='/finder?st={quote(t)}'>{t} {q('SELECT COUNT(*) FROM finds WHERE status=?', (t,), one=True)[0]}</a>" for t in ("추천", "가져옴", "등록됨", "제외"))
    last = get_setting("finder_last")
    sel = lambda name, on: f"<select name='{name}' style='max-width:260px'><option value='1'>켜기</option><option value='0' {'' if on else 'selected'}>끄기</option></select>"
    keyinfo = lambda k: " (저장됨, 바꿀 때만 입력)" if c.get(k) else ""
    body = f"""<h1>잘 팔릴 상품 자동 찾기</h1>
<div class="card"><div class="row"><form method="post" action="/finder/run" data-busy class="row" style="flex:1"><input name="seeds" value="{e(c.get('seeds') or '')}" placeholder="찾을 분야(쉼표로): 집게핀, 키링, 다꾸, 반려견 간식" style="flex:1;min-width:240px"><button class="btn">지금 찾기</button></form></div>
<p class="mut">자동 찾기: <b>{'켜짐' if c.get('auto_find') else '꺼짐'}</b>({c.get('find_hours')}시간마다) · 자동 등록: <b>{'켜짐' if c.get('auto_register') else '꺼짐'}</b>(하루 최대 {c.get('max_per_day')}개, {c.get('min_score')}점 이상) · 마지막 찾기 {time.strftime('%m-%d %H:%M', time.localtime(last)) if last else '없음'}</p>
<p class="mut">점수 = 수요(네이버 월 검색량) 40 + 경쟁(네이버 쇼핑 상품 수 ÷ 검색량) 30 + 가격(우리 판매가가 시장가보다 싼지) 30. 이익이 {fv(c.get('min_profit'))}원 미만인 상품과 이미 가져온 상품은 뺍니다.</p></div>
<div class="row" style="margin-bottom:10px">{tabs}</div>
<form id="ff" method="post" action="/finder/act" data-busy><div class="card"><div class="row" style="margin-bottom:8px">{acc_opts}</div>
<div class="row"><button class="btn green" type="button" id="fpub">선택 상품 가져와서 등록(사진 가공·상세페이지 포함)</button><button class="btn" name="do" value="import">가져오기만</button><button class="btn gray" name="do" value="skip">제외</button><button class="btn gray" name="do" value="back">추천으로 되돌리기</button><span class="mut" id="autoimg_note"></span></div></div>
<div class="card tbl"><table><tr><th><input type="checkbox" data-all="fid" style="width:auto"></th><th></th><th>상품 · 근거</th><th>점수</th><th>공급가</th><th>우리 판매가</th><th>이익</th><th></th></tr>{trs or '<tr><td colspan=8>아직 후보가 없습니다. 위에서 분야를 넣고 지금 찾기를 누르세요.</td></tr>'}</table></div></form>
<form method="post" action="/finder/save"><div class="card"><h2>자동 켜기·끄기</h2><div class="grid">
<div><label>자동 찾기</label>{sel('auto_find', c.get('auto_find'))}</div><div><label>몇 시간마다</label><input name="find_hours" value="{fv(c.get('find_hours'))}"></div>
<div><label>자동 등록(찾은 상품을 바로 마켓에 올림)</label>{sel('auto_register', c.get('auto_register'))}</div><div><label>하루 최대 등록 수</label><input name="max_per_day" value="{fv(c.get('max_per_day'))}"></div>
<div><label>자동 등록 최소 점수</label><input name="min_score" value="{fv(c.get('min_score'))}"></div><div><label>최소 이익(원)</label><input name="min_profit" value="{fv(c.get('min_profit'))}"></div>
<div><label>오너클랜 공급가 범위(원)</label><div class="row"><input name="min_price" value="{fv(c.get('min_price'))}" style="width:45%"><input name="max_price" value="{fv(c.get('max_price'))}" style="width:45%"></div></div>
<div><label>최소 월 검색량</label><input name="min_volume" value="{fv(c.get('min_volume'))}"></div><div><label>한 번에 볼 키워드 수</label><input name="max_keywords" value="{fv(c.get('max_keywords'))}"></div><div><label>키워드당 오너클랜 상품 수</label><input name="per_keyword" value="{fv(c.get('per_keyword'))}"></div></div>
<p class="mut">자동 등록은 위 표의 마켓·판매처 체크 상태를 따릅니다(저장할 때 같이 저장). 자동 등록된 상품의 사진은 가공 없이 원본으로 올라갑니다. 가공하려면 상품 화면에서 자동 제작을 다시 누르세요.</p>
<h2>네이버 API 키</h2><div class="grid">
<div><label>네이버 개발자센터 Client ID</label><input name="naver_id" value="{e(c.get('naver_id') or '')}"></div><div><label>Client Secret{keyinfo('naver_secret')}</label><input name="naver_secret" type="password" autocomplete="off"></div>
<div><label>검색광고 CUSTOMER_ID</label><input name="ad_customer" value="{e(c.get('ad_customer') or '')}"></div><div><label>검색광고 액세스라이선스{keyinfo('ad_key')}</label><input name="ad_key" type="password" autocomplete="off"></div><div><label>검색광고 비밀키{keyinfo('ad_secret')}</label><input name="ad_secret" type="password" autocomplete="off"></div></div>
<p class="mut">① developers.naver.com → Application 등록 → 사용 API '검색' 선택 → Client ID·Secret (쇼핑 경쟁 상품 수·시장가). ② searchad.naver.com 가입 → 도구 → API 사용 관리 → 액세스라이선스·비밀키·CUSTOMER_ID (월 검색량·연관 키워드). 둘 다 무료입니다. 없어도 작동하지만 점수가 덜 정확합니다.</p>
<input type="hidden" name="acc_from" value="ff"><button class="btn">저장</button></div></form>
<script>
document.querySelector('form[action="/finder/save"]').addEventListener('submit',ev=>{{const f=ev.target;document.querySelectorAll('#ff input[name=acc]:checked,#ff input[name=ch]:checked').forEach(c=>{{const h=document.createElement('input');h.type='hidden';h.name=c.name;h.value=c.value;f.appendChild(h)}})}});
document.getElementById('fpub').onclick=async()=>{{
 const f=document.getElementById('ff'),note=document.getElementById('autoimg_note');const fids=[...f.querySelectorAll('input[name=fid]:checked')].map(c=>c.value);
 if(!fids.length){{alert('상품을 하나 이상 고르세요');return}}
 const tg=[...f.querySelectorAll('input[name=acc]:checked,input[name=ch]:checked')];if(!tg.length){{alert('올릴 마켓이나 판매처를 고르세요');return}}
 f.querySelectorAll('button').forEach(b=>b.disabled=true);note.textContent='오너클랜에서 가져오는 중…';
 const fd=new URLSearchParams();fids.forEach(i=>fd.append('fid',i));
 const r=await fetch('/finder/import',{{method:'POST',body:fd}});const j=await r.json();if(j.error){{note.textContent=j.error;f.querySelectorAll('button').forEach(b=>b.disabled=false);return}}
 for(let i=0;i<j.pids.length;i++){{try{{await mmAutoImg(j.pids[i],{{set textContent(t){{note.textContent=(i+1)+'/'+j.pids.length+' 상품 · '+t}}}})}}catch(e){{}}}}
 note.textContent='마켓에 올리는 중…';const g=document.createElement('form');g.method='post';g.action='/bulk';
 const add=(n,v)=>{{const h=document.createElement('input');h.type='hidden';h.name=n;h.value=v;g.appendChild(h)}};
 add('do','register');j.pids.forEach(p=>add('pid',p));tg.forEach(c=>add(c.name,c.value));add('from','finder');document.body.appendChild(g);g.submit();
}};
</script>"""
    return page("상품 찾기", body, h.user, "/finder", h.flash, h.flash_err)

@route("POST", "/finder/run")
def finder_run(h):
    f = h.form()
    c = get_setting("finder", {}) or {}
    c["seeds"] = f.get("seeds", "").strip()
    set_setting("finder", c)
    try:
        n, msg, notes = finder.run(h.user["username"])
    except (finder.FindError, ocmod.OCError) as ex:
        go("/finder", str(ex), True)
    go("/finder", msg + ("\n" + "\n".join(notes) if notes else ""))

@route("POST", "/finder/import")
def finder_import_api(h):
    f = h.form_multi()
    h.extra_headers = {"Content-Type": "application/json; charset=utf-8"}
    try:
        pids = finder_import([int(i) for i in f.get("fid", [])], h.user["username"])
    except Exception as ex:
        return json.dumps({"error": f"가져오기 실패: {ex}"}, ensure_ascii=False)
    for pid in pids:
        x("UPDATE finds SET status='등록됨' WHERE product_id=?", (pid,))
    return json.dumps({"pids": pids})

@route("POST", "/finder/act")
def finder_act(h):
    f = h.form_multi()
    fids = [int(i) for i in f.get("fid", [])]
    do = (f.get("do") or [""])[0]
    if not fids:
        go("/finder", "상품을 하나 이상 고르세요", True)
    if do in ("skip", "back"):
        for i in fids:
            x("UPDATE finds SET status=? WHERE id=?", ("제외" if do == "skip" else "추천", i))
        go("/finder", f"{len(fids)}개를 {'제외했습니다' if do == 'skip' else '추천으로 되돌렸습니다'}")
    try:
        pids = finder_import(fids, h.user["username"])
    except Exception as ex:
        go("/finder", f"가져오기 실패: {ex}", True)
    go("/products?type=" + quote("위탁"), f"{len(pids)}개를 위탁 상품으로 가져왔습니다. 상세페이지를 만들고 마켓에 올리세요.")

@route("POST", "/finder/save")
def finder_save(h):
    f = h.form_multi()
    g = lambda k, d="": (f.get(k) or [d])[0]
    c = get_setting("finder", {}) or {}
    for k in ("find_hours", "max_per_day", "min_score", "min_profit", "min_price", "max_price", "min_volume", "max_keywords", "per_keyword"):
        v = num(g(k).replace(",", ""), float)
        c[k] = v if v is not None else finder.DEFAULT[k]
    c["auto_find"] = g("auto_find") == "1"
    c["auto_register"] = g("auto_register") == "1"
    c["reg_accs"] = f.get("acc", [])
    c["reg_chans"] = f.get("ch", [])
    c["naver_id"] = g("naver_id").strip(); c["ad_customer"] = g("ad_customer").strip()
    for k in ("naver_secret", "ad_key", "ad_secret"):
        if g(k).strip():
            c[k] = seal(g(k).strip())
    set_setting("finder", c)
    log(h.user["username"], "상품 찾기 설정 저장", f"자동 찾기 {'켜짐' if c['auto_find'] else '꺼짐'} · 자동 등록 {'켜짐' if c['auto_register'] else '꺼짐'}")
    go("/finder", "저장했습니다")

# ---------- 발주·송장 ----------
@route("GET", "/fulfill")
def fulfill(h):
    def rows(sql, args=()):
        return q("SELECT o.*, p.name pname, p.supplier_key, p.supply_price, p.supply_ship, p.set_qty, a.label FROM orders o LEFT JOIN products p ON p.id=o.product_id LEFT JOIN accounts a ON a.id=o.account_id " + sql, args)
    cour = "".join(f"<option>{e(n)}</option>" for n in couriers.names())
    def rcv_txt(o):
        r = json.loads(o["rcv"] or "{}")
        return f"{e(mask(r.get('name', '')))}<div class='mut'>{e((r.get('addr1') or '')[:18])}</div>"
    def base(o):
        return (f"<td>{e(where_label(o['market']))}<div class='mut'>{e(o['label'] or '예시')}</div></td><td>{e(o['pname'] or o['product_name'] or '')}"
                f"<div class='mut'>{e(o['option_text'] or '')} · {e(str(o['order_id']))}</div></td><td>{o['qty'] or 1}</td><td>{(o['amount'] or 0):,}</td><td>{rcv_txt(o)}</td>")
    wait = rows("WHERE o.po_status IN ('발주대기','발주실패') ORDER BY o.id")
    t1 = "".join(f"<tr><td><input type='checkbox' name='oid' value='{o['id']}' style='width:auto'></td>{base(o)}<td>{e(o['supplier_key'] or '연결 안 됨')}"
                 f"<div class='mut'>공급 {(float(o['supply_price'] or 0) * int(o['qty'] or 1) * int(o['set_qty'] or 1) + float(o['supply_ship'] or 0)):,.0f}원</div>"
                 f"{('<div style=color:#dc2626>' + e(o['po_msg'] or '') + '</div>') if o['po_status'] == '발주실패' else ''}</td></tr>" for o in wait)
    sent = rows("WHERE o.po_status IN ('발주완료','발주완료(미리보기)','송장받음') ORDER BY o.id")
    t2 = "".join(f"<tr>{base(o)}<td>{e(o['po_key'] or '')}<div class='mut'>{e(o['po_status'])} {e(o['courier'] or '')} {e(o['tracking'] or '')}</div>"
                 f"{('<div class=mut>' + e(o['po_msg']) + '</div>') if o['po_msg'] else ''}"
                 f"<details><summary class='mut' style='cursor:pointer'>송장 직접 넣기</summary><form method='post' action='/fulfill/{o['id']}/ship' class='row' data-busy><select name='courier' style='width:120px'>{cour}</select>"
                 f"<input name='tracking' placeholder='송장번호' style='width:130px'><button class='btn sm green'>보내기</button></form></details></td></tr>" for o in sent)
    own = rows("WHERE o.po_status IN ('발송대기') ORDER BY o.id")
    t3 = "".join(f"<tr>{base(o)}<td><form method='post' action='/fulfill/{o['id']}/ship' class='row' data-busy><select name='courier' style='width:120px'>{cour}</select>"
                 f"<input name='tracking' placeholder='송장번호' style='width:130px'><button class='btn sm green'>보내기</button></form>"
                 f"{'' if o['product_id'] else '<div class=mut>상품 연결 안 됨</div>'}{('<div class=mut>' + e(o['po_msg']) + '</div>') if o['po_msg'] else ''}</td></tr>" for o in own)
    done = rows("WHERE o.po_status LIKE '발송완료%' ORDER BY o.shipped_at DESC LIMIT 50")
    t4 = "".join(f"<tr>{base(o)}<td>{e(o['supply_type'] or '')} · {e(o['courier'] or '')} {e(o['tracking'] or '')}<div class='mut'>{e(o['po_status'])} {time.strftime('%m-%d %H:%M', time.localtime(o['shipped_at'])) if o['shipped_at'] else ''}</div></td></tr>" for o in done)
    th = "<tr><th>마켓</th><th>상품</th><th>수량</th><th>결제액</th><th>받는 분</th>"
    demo = ""
    if h.user["role"] == "admin" and get_setting("dry_run", True):
        opts = "".join(f"<option value='{p['id']}'>[{e(p['supply_type'] or '사입')}] {e(p['name'][:30])}</option>" for p in q("SELECT id,name,supply_type FROM products ORDER BY supply_type DESC, id DESC LIMIT 200"))
        demo = f"""<div class="card"><h2>예시 주문 만들기(미리보기 모드에서 흐름 연습용)</h2><form method="post" action="/fulfill/demo" class="row"><select name="pid" style="max-width:360px">{opts}</select><button class="btn gray">예시 주문 추가</button></form></div>"""
    auto = "자동 발주 켜짐" if oc_conf().get("auto_order") else "자동 발주 꺼짐(직접 눌러 발주)"
    body = f"""<h1>발주·송장</h1>
<div class="card"><h2>① 위탁 발주 대기 <span class="mut">({len(wait)}건 · {auto})</span></h2><form method="post" action="/fulfill/order" data-busy><div class="tbl"><table>
<tr><th><input type="checkbox" data-all="oid" style="width:auto"></th>{th[4:]}<th>오너클랜</th></tr>{t1 or '<tr><td colspan=7>없음</td></tr>'}</table></div><br>
<button class="btn green" onclick="return confirm('선택한 주문을 오너클랜에 발주할까요? 예치금이 빠져나갑니다')">선택 주문 오너클랜 발주</button></form></div>
<div class="card"><h2>② 오너클랜 송장 기다리는 중 <span class="mut">({len(sent)}건)</span></h2><form method="post" action="/fulfill/check" data-busy><button class="btn sm">지금 송장 확인</button></form><br>
<div class="tbl"><table>{th}<th>발주번호 · 송장</th></tr>{t2 or '<tr><td colspan=6>없음</td></tr>'}</table></div><p class="mut">송장이 나오면 자동으로 마켓에 보내고 ④로 옮깁니다(주문 수집 때마다 확인).</p></div>
<div class="card"><h2>③ 사입 발송 대기 <span class="mut">({len(own)}건)</span></h2><div class="row" style="margin-bottom:8px"><a class="btn sm gray" href="/fulfill/ship.csv">택배 접수용 엑셀(CSV) 받기</a>
<form method="post" action="/fulfill/upload" enctype="multipart/form-data" class="row" data-busy><input type="file" name="file" accept=".csv" style="max-width:220px"><button class="btn sm gray">송장 엑셀 올리기</button></form></div>
<div class="tbl"><table>{th}<th>송장 입력</th></tr>{t3 or '<tr><td colspan=6>없음</td></tr>'}</table></div>
<p class="mut">송장 엑셀은 '주문번호, 택배사, 송장번호' 세 열이면 됩니다(받은 CSV에 송장만 채워서 올려도 됨).</p></div>
<div class="card"><h2>④ 발송 완료(최근 50건)</h2><div class="tbl"><table>{th}<th>송장</th></tr>{t4 or '<tr><td colspan=6>없음</td></tr>'}</table></div>
<p class="mut">받는 분 정보는 발송 후 90일이 지나면 자동으로 지웁니다.</p></div>{demo}"""
    return page("발주·송장", body, h.user, "/fulfill", h.flash, h.flash_err)

@route("POST", "/fulfill/order")
def fulfill_order(h):
    f = h.form_multi()
    ids = [int(i) for i in f.get("oid", [])]
    if not ids:
        go("/fulfill", "주문을 고르세요", True)
    ok, msgs = 0, []
    for i in ids:
        o = q("SELECT * FROM orders WHERE id=?", (i,), one=True)
        try:
            r = place_order(o, h.user["username"]); ok += 1
            if r.get("dry"):
                msgs.append(f"[미리보기] {o['product_name']} → {os.path.basename(r.get('file', ''))}")
        except Exception as ex:
            x("UPDATE orders SET po_status='발주실패', po_msg=? WHERE id=?", (str(ex)[:500], i))
            msgs.append(f"[실패] {o['product_name']}: {ex}")
    go("/fulfill", f"{ok}건 발주했습니다\n" + "\n".join(msgs[:30]), ok < len(ids))

@route("POST", "/fulfill/check")
def fulfill_check(h):
    try:
        got, sent, errs = check_tracking(h.user["username"])
    except ocmod.OCError as ex:
        go("/fulfill", str(ex), True)
    go("/fulfill", f"새 송장 {got}건, 마켓 전송 {sent}건\n" + "\n".join(errs[:20]), bool(errs))

@route("POST", r"/fulfill/(\d+)/ship")
def fulfill_ship(h, oid):
    f = h.form()
    if not f.get("tracking", "").strip():
        go("/fulfill", "송장번호를 넣어 주세요", True)
    x("UPDATE orders SET courier=?, tracking=? WHERE id=?", (f.get("courier", ""), re.sub(r"[^0-9A-Za-z]", "", f["tracking"]), oid))
    try:
        send_tracking(q("SELECT * FROM orders WHERE id=?", (oid,), one=True), h.user["username"])
    except Exception as ex:
        x("UPDATE orders SET po_msg=? WHERE id=?", (str(ex)[:500], oid))
        go("/fulfill", f"송장 전송 실패: {ex}", True)
    go("/fulfill", "송장을 보냈습니다")

@route("GET", "/fulfill/ship.csv")
def fulfill_csv(h):
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["주문번호", "택배사", "송장번호", "마켓", "상품", "옵션", "수량", "받는 분", "연락처", "우편번호", "주소", "상세주소", "배송 메모"])
    for o in q("SELECT o.*, p.name pname FROM orders o LEFT JOIN products p ON p.id=o.product_id WHERE o.po_status='발송대기' ORDER BY o.id"):
        r = json.loads(o["rcv"] or "{}")
        w.writerow([o["order_id"], "", "", where_label(o["market"]), o["pname"] or o["product_name"], o["option_text"] or "", o["qty"],
                    r.get("name", ""), r.get("phone", ""), r.get("zip", ""), r.get("addr1", ""), r.get("addr2", ""), r.get("memo", "")])
    log(h.user["username"], "택배 접수용 엑셀 받기")
    h.extra_headers = {"Content-Disposition": f"attachment; filename=ship_{time.strftime('%Y%m%d')}.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿" + buf.getvalue()

@route("POST", "/fulfill/upload")
def fulfill_upload(h):
    _, files = h.multipart()
    fn, data = (files.get("file") or [("", b"")])[0]
    if not data:
        go("/fulfill", "파일을 골라 주세요", True)
    rows = list(csv.reader(io.StringIO(data.decode("utf-8-sig", "replace"))))
    ok, msgs = 0, []
    for r in rows[1:]:
        if len(r) < 3 or not r[0].strip() or not r[2].strip():
            continue
        o = q("SELECT * FROM orders WHERE order_id=? AND po_status='발송대기'", (r[0].strip(),), one=True)
        if not o:
            continue
        x("UPDATE orders SET courier=?, tracking=? WHERE id=?", (r[1].strip() or "CJ대한통운", re.sub(r"[^0-9A-Za-z]", "", r[2]), o["id"]))
        try:
            send_tracking(q("SELECT * FROM orders WHERE id=?", (o["id"],), one=True), h.user["username"]); ok += 1
        except Exception as ex:
            msgs.append(f"{r[0]}: {ex}")
            x("UPDATE orders SET po_msg=? WHERE id=?", (str(ex)[:500], o["id"]))
    go("/fulfill", f"{ok}건 송장을 보냈습니다\n" + "\n".join(msgs[:30]), bool(msgs))

@route("POST", "/fulfill/demo", admin=True)
def fulfill_demo(h):
    p = product(num(h.form().get("pid"), int))
    oid = f"DEMO-{uuid.uuid4().hex[:8]}"
    save_order(None, {"market": "naver", "order_id": oid, "product_name": p["name"], "qty": 1, "amount": pricing.price_krw(p, "naver"), "buyer": "홍길동",
                      "status": "PAYED", "ordered_at": time.strftime("%Y-%m-%d %H:%M"), "raw": {}, "seller_code": f"MM{p['id']}", "option": p["supplier_option"] or "",
                      "rcv": {"name": "홍길동", "phone": "010-0000-0000", "zip": "06236", "addr1": "서울특별시 강남구 테헤란로 1", "addr2": "101호", "memo": "문 앞"},
                      "ship_ref": {}})
    go("/fulfill", f"예시 주문({p['supply_type'] or '사입'})을 만들었습니다")

@route("GET", "/history")
def history(h):
    kw = h.qs.get("q", "")
    rows = q("SELECT * FROM logs WHERE action LIKE ? OR detail LIKE ? OR user LIKE ? ORDER BY id DESC LIMIT 1000", (f"%{kw}%",) * 3)
    trs = "".join(f"<tr><td class='mut'>{time.strftime('%m-%d %H:%M', time.localtime(r['ts']))}</td><td>{e(r['user'] or '')}</td><td>{e(r['action'])}</td><td>{e(r['detail'] or '')}</td></tr>" for r in rows)
    return page("작업 이력", f"""<h1>작업 이력</h1><form class="row" style="margin-bottom:12px"><input name="q" value="{e(kw)}" placeholder="예: 마켓 등록, 실패, 팀원 이름" style="max-width:300px"><button class="btn gray">검색</button></form>
<div class="card tbl"><table><tr><th>시간</th><th>누가</th><th>작업</th><th>내용</th></tr>{trs or '<tr><td colspan=4>없음</td></tr>'}</table></div>""", h.user, "/history")

@route("POST", "/settings", admin=True)
def settings_post(h):
    f = h.form()
    fl = lambda k, d: num(f.get(k), float) if num(f.get(k), float) is not None else d
    set_setting("pricing", parse_policy(f, "기본 정책"))
    set_setting("name_rules", {"prefix": f.get("nr_prefix", ""), "suffix": f.get("nr_suffix", ""), "banned": f.get("nr_banned", ""), "replace": f.get("nr_replace", "")})
    set_setting("category_map", f.get("category_map", ""))
    set_setting("shop", {"name": f.get("shop_name", ""), "banner": f.get("shop_banner", ""), "cs": f.get("shop_cs", "")})
    ai = get_setting("ai", {}) or {}
    if f.get("ai_key"):
        ai["api_key"] = seal(f["ai_key"].strip())
    ai["model"] = f.get("ai_model") or "claude-sonnet-5-5"
    set_setting("ai", ai)
    set_setting("dry_run", f.get("dry_run") == "1")
    set_setting("order_interval", int(fl("order_interval", 30)))
    set_setting("auto_soldout_stock", f.get("auto_soldout_stock", "1") == "1")
    log(h.user["username"], "설정 저장")
    go("/settings", "저장했습니다")

@route("GET", "/more")
def more(h):
    items = [("/suppliers/csv", "📥 오너클랜 CSV 자동 등록"), ("/notify", "🔔 폰 알림"), ("/finder", "🔎 잘 팔릴 상품 자동 찾기"), ("/fulfill", "🚚 발주·송장"), ("/suppliers", "🤝 오너클랜 위탁"), ("/listings", "🛒 등록현황"), ("/channels", "🌏 판매처(해외몰 추가·수수료·마진)"), ("/accounts", "🔑 마켓 계정"), ("/policies", "💰 가격 정책(마진)"), ("/history", "📜 작업 이력"), ("/settings", "⚙️ 설정"), ("/me", "🔒 내 비밀번호")]
    if h.user["role"] == "admin":
        items += [("/users", "👥 팀원 관리"), ("/admin", "🛠 백업·업데이트")]
    items.append(("/logout", "↩ 로그아웃"))
    return page("더보기", "<h1>더보기</h1>" + "".join(f'<a class="card" style="display:block;color:inherit" href="{u}">{t}</a>' for u, t in items), h.user, "/more")

@route("GET", "/admin", admin=True)
def admin_page(h):
    from . import VERSION
    return page("백업·업데이트", f"""<h1>백업·업데이트</h1><div class="card"><h2>백업</h2><p class="mut">상품·계정·주문 데이터 전체(app.db)를 내려받습니다. 일주일에 한 번 받아 두세요.</p><a class="btn" href="/admin/backup">백업 파일 받기</a></div>
<div class="card"><h2>자동 업데이트</h2>
<p>현재 버전 <b>{VERSION}</b> · 업데이트 위치의 최신 버전 <b>{e(updater.state['latest'] or '확인 안 됨')}</b> {'<span class="tag ok">새 버전 있음</span>' if updater.available() else ''}</p>
{f'<p class="mut">바뀐 점: {e(updater.state["notes"])}</p>' if updater.state['notes'] else ''}{f'<p class="mut" style="color:#b91c1c">{e(updater.state["error"])}</p>' if updater.state['error'] else ''}
<form method="post" action="/admin/updater" class="row" data-busy><button class="btn gray" name="do" value="check">지금 확인</button>{'<button class="btn green" name="do" value="apply">지금 업데이트</button>' if updater.available() else ''}</form>
<form method="post" action="/admin/updater"><label>업데이트 위치(폴더 경로 또는 https 주소, 비우면 프로그램 옆 update 폴더)</label><input name="src" value="{e(get_setting('update_source', '') or '')}" placeholder="{e(updater.source())}">
<label>자동 업데이트</label><select name="auto" style="max-width:420px"><option value="1">켜기 (켤 때 바로, 켜져 있으면 새벽 4시에 교체)</option><option value="0" {'' if updater.auto_on() else 'selected'}>끄기 (알림만, 버튼으로 직접)</option></select>
<br><br><button class="btn" name="do" value="save">저장</button></form>
<p class="mut">팀 전체를 한 번에 올리려면: 공유 드라이브(구글드라이브·원드라이브)에 폴더를 하나 만들어 모든 PC의 업데이트 위치로 지정하고, 새 버전이 나오면 그 폴더에 version.json·MultiMarket.exe 를 넣으면 됩니다.</p></div>
<div class="card"><h2>직접 업데이트(zip 올리기)</h2><p class="mut">서버·파이썬 설치본용. 새 버전 zip(mmtool_update.zip)을 올리면 교체 후 다시 켜집니다.</p>
<form method="post" action="/admin/update" enctype="multipart/form-data" data-busy><input type="file" name="file" accept=".zip" required><br><br><button class="btn">업데이트</button></form></div>""", h.user, "/admin", h.flash, h.flash_err)

@route("GET", "/admin/backup", admin=True)
def admin_backup(h):
    import sqlite3, tempfile
    from .paths import DB_PATH
    tmp = os.path.join(tempfile.gettempdir(), "mm_backup.db")
    src = sqlite3.connect(DB_PATH); dst = sqlite3.connect(tmp); src.backup(dst); dst.close(); src.close()
    h.extra_headers = {"Content-Type": "application/octet-stream", "Content-Disposition": f"attachment; filename=multimarket_{time.strftime('%Y%m%d')}.db"}
    with open(tmp, "rb") as f:
        return f.read()

@route("POST", "/admin/updater", admin=True)
def admin_updater(h):
    f = h.form()
    do = f.get("do")
    if do == "save":
        from .db import set_setting
        set_setting("update_source", f.get("src", "").strip())
        set_setting("auto_update", f.get("auto") == "1")
        updater.check()
        go("/admin", "저장했습니다")
    if do == "apply":
        log(h.user["username"], "자동 업데이트 실행", updater.state["latest"])
        def run():
            time.sleep(1)
            try:
                updater.apply()
            except Exception as ex:
                updater.state["error"] = f"업데이트 실패: {ex}"
        threading.Thread(target=run, daemon=True).start()
        go("/admin", f"{updater.state['latest']} 버전으로 바꾸는 중입니다. 20초 뒤 새로고침하세요.")
    updater.check()
    go("/admin", "새 버전이 있습니다" if updater.available() else (updater.state["error"] or "최신 버전입니다"), bool(updater.state["error"]))

@route("POST", "/admin/update", admin=True)
def admin_update(h):
    import zipfile, sys
    _, files = h.multipart()
    fn, data = (files.get("file") or [("", b"")])[0]
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if getattr(sys, "frozen", False):
        go("/admin", ".exe 버전은 새 .exe 파일로 바꿔 끼우면 됩니다", True)
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        names = [n for n in z.namelist() if n.endswith(".py") and ".." not in n and not n.startswith("/")]
        if "main.py" not in names:
            raise ValueError("main.py가 없는 zip입니다")
        for n in names:
            os.makedirs(os.path.dirname(os.path.join(root, n)) or root, exist_ok=True)
            with open(os.path.join(root, n), "wb") as f:
                f.write(z.read(n))
    except Exception as ex:
        go("/admin", f"업데이트 실패: {ex}", True)
    log(h.user["username"], "프로그램 업데이트", fn)
    threading.Timer(1.5, lambda: os._exit(0)).start()   # systemd가 다시 켭니다
    go("/admin", "업데이트했습니다. 10초 뒤 새로고침하세요.")

# ---------- 정적 ----------
def _png(size):
    rows = []
    for y in range(size):
        row = bytearray([0])
        for x_ in range(size):
            inner = size * .22 < x_ < size * .78 and size * .38 < y < size * .78
            handle = (abs(((x_ - size / 2) ** 2 + (y - size * .38) ** 2) ** .5 - size * .14) < size * .03) and y < size * .38
            row += bytes((47, 111, 237) if inner else (255, 255, 255) if handle else (17, 24, 39))
        rows.append(bytes(row))
    raw = zlib.compress(b"".join(rows))
    ch = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)) + ch(b"IDAT", raw) + ch(b"IEND", b"")

_ICONS = {}
@route("GET", r"/icon(-512)?\.png", public=True)
def icon_png(h, big):
    s = 512 if big else 192
    if s not in _ICONS:
        _ICONS[s] = _png(s)
    h.extra_headers = {"Content-Type": "image/png", "Cache-Control": "max-age=86400"}
    return _ICONS[s]

@route("GET", "/icon.svg", public=True)
def icon_svg(h):
    h.extra_headers = {"Content-Type": "image/svg+xml"}
    return ICON_SVG

@route("GET", "/manifest.json", public=True)
def manifest(h):
    h.extra_headers = {"Content-Type": "application/manifest+json"}
    return MANIFEST

@route("GET", "/sw.js", public=True)
def sw(h):
    h.extra_headers = {"Content-Type": "application/javascript"}
    return SW

@route("GET", r"/img/(.+)", public=True)
def img(h, name):
    from urllib.parse import unquote
    name = os.path.basename(unquote(name))
    path = os.path.join(IMAGES, name)
    if not os.path.isfile(path):
        h.status = 404
        return "없음"
    h.extra_headers = {"Content-Type": mimetypes.guess_type(name)[0] or "application/octet-stream", "Cache-Control": "max-age=86400"}
    with open(path, "rb") as f:
        return f.read()

# ---------- HTTP 처리 ----------
class Handler(BaseHTTPRequestHandler):
    server_version = "MultiMarket/1.0"

    def log_message(self, fmt, *args):
        pass

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 60 * 1024 * 1024:
            raise ValueError("파일이 너무 큽니다(60MB 초과)")
        return self.rfile.read(n) if n else b""

    def form(self):
        return {k: v[0] for k, v in parse_qs(self._body().decode("utf-8", "replace"), keep_blank_values=True).items()}

    def form_multi(self):
        return parse_qs(self._body().decode("utf-8", "replace"), keep_blank_values=True)

    def multipart(self):
        ct = self.headers.get("Content-Type", "")
        body = self._body()
        if "multipart" not in ct:
            return {k: v[0] for k, v in parse_qs(body.decode(), keep_blank_values=True).items()}, {}
        msg = BytesParser(policy=email_policy).parsebytes(b"Content-Type: " + ct.encode() + b"\r\n\r\n" + body)
        fields, files = {}, {}
        self._mvals = {}
        for part in msg.iter_parts():
            name = part.get_param("name", header="content-disposition")
            fn = part.get_filename()
            data = part.get_payload(decode=True) or b""
            if fn is not None:
                files.setdefault(name, []).append((fn, data))
            else:
                fields[name] = data.decode("utf-8", "replace")
                self._mvals.setdefault(name, []).append(fields[name])
        return fields, files

    def multi_values(self, name):
        """multipart 양식에서 같은 이름의 값 여러 개(체크박스)"""
        return list(getattr(self, "_mvals", {}).get(name, []))

    def handle_any(self, method):
        u = urlparse(self.path)
        self.qs = {k: v[0] for k, v in parse_qs(u.query).items()}
        ck = SimpleCookie(self.headers.get("Cookie", ""))
        self.token = ck["mm_s"].value if "mm_s" in ck else None
        self.flash = unquote_c(ck["mm_f"].value) if "mm_f" in ck else None
        self.flash_err = "mm_fe" in ck
        self.user = auth.user_for(self.token)
        self.set_cookie, self.extra_headers, self.status = None, {}, 200
        clear_flash = bool(self.flash)
        for m, rx, fn, public, admin in ROUTES:
            mt = rx.match(u.path)
            if m == method and mt:
                break
        else:
            return self.send(404, page("없음", "<h1>페이지가 없습니다</h1>", self.user))
        try:
            if not public and not self.user:
                go("/login")
            if admin and self.user["role"] != "admin":
                go("/", "관리자만 할 수 있습니다", True)
            out = fn(self, *mt.groups())
            self.send(self.status, out, clear_flash)
        except Redirect as r:
            self.send_response(303)
            self.send_header("Location", r.to)
            if self.set_cookie:
                self.send_header("Set-Cookie", self.set_cookie)
            if r.flash:
                self.send_header("Set-Cookie", "mm_f=" + quote(r.flash[:1500]) + "; Path=/; Max-Age=60")
                self.send_header("Set-Cookie", "mm_fe=1; Path=/; Max-Age=60" if r.err else "mm_fe=; Path=/; Max-Age=0")
            self.end_headers()
        except Exception as ex:
            traceback.print_exc()
            self.send(500, page("오류", f"<h1>오류</h1><div class='flash err'>{e(str(ex))}</div><a href='javascript:history.back()'>뒤로</a>", self.user))

    def send(self, code, out, clear_flash=False):
        data = out if isinstance(out, bytes) else str(out or "").encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", self.extra_headers.pop("Content-Type", "text/html; charset=utf-8") if hasattr(self, "extra_headers") else "text/html; charset=utf-8")
        for k, v in (getattr(self, "extra_headers", {}) or {}).items():
            self.send_header(k, v)
        if getattr(self, "set_cookie", None):
            self.send_header("Set-Cookie", self.set_cookie)
        if clear_flash:
            self.send_header("Set-Cookie", "mm_f=; Path=/; Max-Age=0")
            self.send_header("Set-Cookie", "mm_fe=; Path=/; Max-Age=0")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")

def unquote_c(v):
    from urllib.parse import unquote
    return unquote(v)

def scheduler():
    last = 0
    while True:
        time.sleep(30)
        try:
            mins = get_setting("order_interval", 30) or 0
            if mins and time.time() - last > mins * 60:
                last = time.time()
                if q("SELECT 1 FROM accounts WHERE active=1 AND creds!='' LIMIT 1") and not get_setting("dry_run", True):
                    collect_orders()
                if q("SELECT 1 FROM orders WHERE po_status IN ('발주완료','송장받음') LIMIT 1"):
                    check_tracking()
                purge_personal()
            stock_sweep()
            finder_auto()
            oc = oc_conf()
            hrs = float(oc.get("sync_hours", 3) or 0)
            if hrs and oc.get("username") and time.time() - (get_setting("ownerclan_last_sync") or 0) > hrs * 3600:
                set_setting("ownerclan_last_sync", time.time())
                sync_ownerclan()
        except Exception:
            traceback.print_exc()

def serve(host="0.0.0.0", port=8765):
    threading.Thread(target=scheduler, daemon=True).start()
    updater.start_background()
    srv = ThreadingHTTPServer((host, port), Handler)
    return srv
