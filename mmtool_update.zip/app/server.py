import urllib.parse, json, os, re, time, threading, traceback, io, csv, struct, zlib, mimetypes, uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlparse, parse_qs, quote
from email.parser import BytesParser
from email.policy import default as email_policy

from . import auth, pricing, detail, xlsx, naming, updater
from . import images as imgmod
from . import finder
from . import channels as chs
from . import notify, occsv, ssimport
from .db import q, x, get_setting, set_setting, log
from .paths import IMAGES, OUTBOX, PAGES
from .secret import seal, unseal
from .markets import MARKETS, MARKET_ROWS, FEATS, FEAT_NAMES

def RA(rows):
    """연동 코드가 있는 마켓 계정만 (등록 대상)"""
    return [a for a in rows if getattr(MARKETS.get(a["market"]), "ready", False)]
from .markets.base import MarketError
from .ui import page, e, ICON_SVG, MANIFEST, SW

ROUTES = []
def route(method, pattern, public=False, admin=False):
    def deco(fn):
        ROUTES.append((method, re.compile("^" + pattern + "$"), fn, public, admin))
        return fn
    return deco

class Redirect(Exception):
    def __init__(self, to, flash=None, err=False):
        self.to, self.flash, self.err = to, flash, err

def go(to, flash=None, err=False):
    raise Redirect(to, flash, err)

# ---------- 공통 ----------
def market_for(acc, force_dry=False):
    cls = MARKETS[acc["market"]]
    creds = json.loads(unseal(acc["creds"]) or "{}") if acc["creds"] else {}
    if not force_dry and not any(creds.values()):
        raise ValueError(f"{cls.name} 계정 '{acc['label']}'에 API 키가 없습니다. 마켓계정에서 키를 넣으세요")
    dry = bool(force_dry)
    return cls(creds, json.loads(acc["extra"] or "{}"), dry=dry)

def acc_mode(acc):
    """(실제 등록 가능?, 빠진 키 이름들). API 키가 모두 있어야 실제로 올라가고, 하나라도 비어 있으면 미리보기로만 저장됨"""
    cls = MARKETS[acc["market"]]
    try:
        creds = json.loads(unseal(acc["creds"]) or "{}") if acc["creds"] else {}
    except ValueError:
        creds = {}
    miss = [lab for k, lab, _ in cls.cred_fields if not creds.get(k)]
    return (not miss), miss

def acc_todo(acc):
    """등록 전에 채워야 하는 계정 설정(없으면 등록이 실패함)"""
    out = []
    if acc["market"] == "naver":
        try:
            ex = json.loads(acc["extra"] or "{}")
        except ValueError:
            ex = {}
        if (ex.get("as_phone") or "").strip() in ("", "010-0000-0000", "01000000000"):
            out.append("A/S·고객센터 전화(실제 번호)")
    return out

def mode_banner(accs):
    """등록 전에 크게 보여 주는 안내: 실제로 올라가는지, 미리보기인지"""
    bad = [(a, acc_mode(a)[1]) for a in accs if not acc_mode(a)[0]]
    ok = [a for a in accs if acc_mode(a)[0]]
    out = ""
    for a in accs:
        td = acc_todo(a)
        if td:
            out += (f"<div class='flash err' style='font-size:18px;padding:16px'><b>⚠ 먼저 채워야 할 설정: {e(MARKETS[a['market']].name)} · {e(a['label'])}</b><br>"
                    f"{e(', '.join(td))}이(가) 비어 있어서 <b>등록하면 실패합니다.</b> <a href='/accounts'><b>마켓계정</b></a>에서 채운 뒤 등록하세요.</div>")
    for a, miss in bad:
        out += (f"<div class='flash err' style='font-size:18px;padding:16px'><b>⚠ 미리보기 모드: {e(MARKETS[a['market']].name)} · {e(a['label'])}</b><br>"
                f"이 계정은 API 키({e(', '.join(miss))})가 비어 있어서 <b>등록 버튼을 눌러도 실제로 올라가지 않습니다.</b><br>"
                f"해제 방법: <a href='/accounts'><b>마켓계정</b></a>에서 이 계정의 키를 모두 넣고 저장하세요.</div>")
    if ok:
        out += ("<div class='card' style='border-left:6px solid #16a34a;font-size:16px'><b>✅ 실제 등록 모드</b>: "
                + e(" · ".join(f"{MARKETS[a['market']].name} {a['label']}" for a in ok))
                + " — 등록하면 바로 마켓에 올라갑니다. (네이버는 API 호출 IP에 서버 주소 168.110.41.196 이 등록돼 있어야 합니다. 안 되면 등록 뒤 나오는 오류 문구에 나타납니다)</div>")
    if not accs:
        out += "<div class='flash err' style='font-size:18px;padding:16px'><b>마켓 계정이 없습니다.</b> <a href='/accounts'>마켓계정</a>에서 스마트스토어 계정을 먼저 추가하세요.</div>"
    return out

def product(pid):
    p = q("SELECT * FROM products WHERE id=?", (pid,), one=True)
    if not p:
        go("/products", "상품이 없습니다", True)
    return p

def img_list(p):
    try:
        return json.loads(p["images"] or "[]")
    except ValueError:
        return []

def local_img_urls(p):
    return [i if i.startswith("http") else "/img/" + quote(i) for i in img_list(p)]

def make_detail(p, use_ai=False, image_urls=None):
    copy = None
    if use_ai:
        copy = detail.ai_copy(p)
    copy = copy or detail.auto_copy(p)
    return copy, detail.render(p, copy, image_urls if image_urls is not None else local_img_urls(p), p["template"] or "clean")

SHORT = {"naver": "N", "coupang": "C", "gmarket": "G", "auction": "A"}

def where_label(market, channel=None):
    """등록·주문 기록에 보여 줄 판매처 이름"""
    if market == "esm":
        return "지마켓·옥션"
    if market in MARKETS:
        return MARKETS[market].name
    return chs.label(channel or market)

def short_of(ch):
    return SHORT.get(ch["code"]) or ch["name"][:5]

def acc_price(p, market):
    """API 계정 등록가(원). ESM은 지마켓·옥션 가격을 따로 계산"""
    if market == "esm":
        return {"Gmkt": pricing.price_krw(p, "gmarket"), "Iac": pricing.price_krw(p, "auction")}
    return pricing.price_krw(p, market)

def price_num(pr):
    return pr["Gmkt"] if isinstance(pr, dict) else pr

def price_txt(pr):
    return f"지마켓 {pr['Gmkt']:,}원 · 옥션 {pr['Iac']:,}원" if isinstance(pr, dict) else f"{pr:,}원"

# ---------- 로그인 ----------
@route("GET", "/setup", public=True)
def setup_get(h):
    if q("SELECT 1 FROM users LIMIT 1"):
        go("/login")
    return page("처음 설정", """<div class="card" style="max-width:420px;margin:40px auto"><h1>처음 설정 · 관리자 만들기</h1>
<form method="post"><label>아이디</label><input name="username" required><label>이름</label><input name="name">
<label>비밀번호(8자 이상)</label><input name="pw" type="password" minlength="8" required><br><br><button class="btn">관리자 만들기</button></form></div>""")

@route("POST", "/setup", public=True)
def setup_post(h):
    if q("SELECT 1 FROM users LIMIT 1"):
        go("/login")
    f = h.form()
    auth.create_user(f["username"].strip(), f.get("name", ""), f["pw"], "admin")
    go("/login", "관리자 계정이 만들어졌습니다. 로그인하세요.")

@route("GET", "/login", public=True)
def login_get(h):
    if not q("SELECT 1 FROM users LIMIT 1"):
        go("/setup")
    return page("로그인", """<div class="card" style="max-width:380px;margin:50px auto"><h1>멀티마켓 매니저</h1>
<form method="post"><label>아이디</label><input name="username" required autofocus><label>비밀번호</label><input name="pw" type="password" required>
<br><br><button class="btn" style="width:100%">로그인</button></form></div>""", flash=h.flash, err=h.flash_err)

@route("POST", "/login", public=True)
def login_post(h):
    f = h.form()
    tok = auth.login(f.get("username", "").strip(), f.get("pw", ""))
    if not tok:
        go("/login", "아이디 또는 비밀번호가 틀렸습니다", True)
    log(f.get("username"), "로그인")
    h.set_cookie = f"mm_s={tok}; Path=/; HttpOnly; SameSite=Lax; Max-Age=43200"
    go("/")

@route("GET", "/logout")
def logout(h):
    auth.logout(h.token)
    h.set_cookie = "mm_s=; Path=/; Max-Age=0"
    go("/login")

# ---------- 홈 ----------
@route("GET", "/")
def home(h):
    c = lambda sql, a=(): q(sql, a, one=True)[0] or 0
    dry = False
    LIVE = "('등록요청','판매중')"
    selling = c(f"SELECT COUNT(*) FROM listings WHERE dry=0 AND status IN {LIVE}")
    before = c("SELECT COUNT(*) FROM products p WHERE COALESCE(p.status,'')<>'품절' AND NOT EXISTS (SELECT 1 FROM listings l WHERE l.product_id=p.id AND l.dry=0)")
    amt7 = c("SELECT SUM(amount) FROM orders WHERE ordered_at >= date('now','-7 day')")
    new1 = c("SELECT COUNT(*) FROM orders WHERE ordered_at >= date('now','-1 day')")
    cards = [("판매중 상품", f"{selling:,}"), ("판매 전 상품", f"{before:,}"), ("7일 주문금액(원)", f"{int(amt7):,}"), ("신규 주문(24시간)", f"{new1:,}"), ("답변 대기 문의", "준비 중")]
    st = "".join(f'<div class="card" style="margin:0"><div class="mut">{k}</div><div class="stat">{v}</div></div>' for k, v in cards)
    # 상점(마켓 계정)별
    rows = ""
    for a in q("SELECT * FROM accounts WHERE active=1 ORDER BY market, id"):
        n_sell = c(f"SELECT COUNT(*) FROM listings WHERE account_id=? AND dry=0 AND status IN {LIVE}", (a["id"],))
        n_prev = c("SELECT COUNT(*) FROM listings WHERE account_id=? AND dry=1", (a["id"],))
        o7 = q("SELECT COUNT(*), SUM(amount) FROM orders WHERE account_id=? AND ordered_at >= date('now','-7 day')", (a["id"],), one=True)
        rows += (f"<tr><td><b>{e(a['label'])}</b><div class='mut'>{MARKETS[a['market']].name}</div></td><td>{n_sell:,}</td><td>{n_prev:,}</td>"
                 f"<td>{o7[0] or 0:,}</td><td>{int(o7[1] or 0):,}</td><td><a class='btn sm gray' href='/accounts/{a['id']}/store'>스토어 상품</a></td></tr>")
    stores = f"""<div class="tbl" style="margin-top:12px"><table><tr><th>상점</th><th>판매중</th><th>미리보기</th><th>7일 주문</th><th>7일 주문금액</th><th></th></tr>
{rows or '<tr><td colspan=6 class="mut" style="text-align:center;padding:30px">연동한 상점이 없습니다. <a href="/accounts">마켓 연동하기 →</a></td></tr>'}</table></div>"""
    # 시작하기 5단계
    oc = oc_conf(); fz = get_setting("finder", {}) or {}
    n_acc = c("SELECT COUNT(*) FROM accounts WHERE active=1 AND COALESCE(creds,'')<>''")
    _ca, _cc = csv_targets()
    auto_reg = bool(_ca or _cc)
    blocked = get_setting("domeggook_blocked")
    soldout_on = oc.get("auto_soldout", True) and oc.get("api_key") and float(oc.get("sync_hours", 3) or 0) > 0
    oi = int(get_setting("order_interval", 30) or 0)
    first_acc = q("SELECT id FROM accounts WHERE active=1 AND COALESCE(creds,'')<>'' ORDER BY id", one=True)
    def qbtn(act, label, color="gray"):
        return f'<form method="post" action="/home/quick" style="display:inline;margin:0"><input type="hidden" name="act" value="{act}"><button class="btn sm {color}">{label}</button></form>'
    tag = lambda ok, txt: f'<span class="tag {"ok" if ok else "dry"}">{txt}</span>'
    steps = [
        ("마켓 연동", tag(n_acc, f"{n_acc}개 연동됨" if n_acc else "연동 안 됨"), "판매 중인 마켓 계정의 API 키를 넣어야 상품·주문을 다룰 수 있어요.",
         (f'<form method="post" action="/accounts/{first_acc["id"]}/test" style="display:inline;margin:0"><input type="hidden" name="back" value="/"><button class="btn sm gray">연결 확인</button></form>' if first_acc else '<a class="btn sm" href="/accounts">API 키 넣기</a>')),
        ("자동 등록 켜기", tag(auto_reg, "켜짐" if auto_reg else "꺼져 있음"), "도매매 엑셀을 넣으면 상품을 만들고 고른 마켓에 바로 올려요.",
         qbtn("autoreg_off", "끄기") if auto_reg else qbtn("autoreg_on", "켜기", "green")),
        ("품절·단종 자동 관리", tag(soldout_on and not blocked, "도매매 차단됨" if blocked else ("켜짐" if soldout_on else ("꺼짐" if not oc.get("auto_soldout", True) else "도매매 연결 필요"))), "공급처가 품절되면 모든 마켓을 판매중지, 재입고되면 다시 판매해요.",
         qbtn("soldout_off", "끄기") if oc.get("auto_soldout", True) else qbtn("soldout_on", "켜기", "green")),
        ("주문 수집", tag(oi and n_acc, f"{oi}분마다" if oi else "꺼짐"), "마켓 주문을 모아 발주·송장까지 한 화면에서 처리해요.",
         (qbtn("orders_now", "지금 수집") + " " + qbtn("orders_off", "끄기")) if oi else qbtn("orders_on", "켜기", "green")),
        ("문의 수집·답변", tag(False, "준비 중"), "마켓 문의를 모아 한 화면에서 답변해요. 다음 업데이트에 들어갑니다.", ""),
    ]
    first = next((i for i, s_ in enumerate(steps) if 'tag ok' not in s_[1]), None)
    sl = "".join(f"""<div class="card" style="margin:0 0 8px;padding:12px;{'border:2px solid #3b82f6' if i == first else ''}">
<div style="display:flex;gap:8px;align-items:center"><span style="display:inline-flex;width:22px;height:22px;border-radius:50%;background:#1e3a8a;color:#fff;font-size:12px;align-items:center;justify-content:center">{i + 1}</span><b>{t}</b> {tg}</div>
<div class="mut" style="margin-top:4px">{d}</div>{f'<div style="margin-top:8px">{u}</div>' if u else ''}</div>""" for i, (t, tg, d, u) in enumerate(steps))
    # 엑셀 넣기: 홈에서 파일만 고르면 바로 올림
    j = CSV_JOB
    if j.get("running"):
        job = f'<p class="flash">진행 중: {e(j.get("file", ""))} · {e(j.get("msg", ""))} <a href="/">새로고침</a></p>'
    elif j.get("end"):
        job = f'<p class="mut">지난 결과 ({time.strftime("%m-%d %H:%M", time.localtime(j["end"]))}): {e(str(j.get("msg", ""))[:200])}</p>'
    else:
        job = ""
    upload = f"""<form method="post" action="/suppliers/csv" enctype="multipart/form-data" id="homeup" style="display:inline;margin:0" data-busy>
<input type="hidden" name="back" value="/"><input type="hidden" name="use_saved" value="1">
<label class="btn green" style="cursor:pointer;margin:0">📥 도매매 엑셀 넣기<input type="file" name="file" accept=".csv,.xlsx,.txt" style="display:none" onchange="if(this.files.length)this.form.submit()"></label></form>"""
    # 오늘 프로그램이 한 일
    t0 = (time.time() + 32400) // 86400 * 86400 - 32400  # 한국 시간 자정
    done = q("SELECT action, COUNT(*) n FROM logs WHERE ts>=? AND user IN ('자동','system','auto') GROUP BY action ORDER BY n DESC", (t0,))
    today = "".join(f"<li>{e(r['action'])} <b>{r['n']}</b>건</li>" for r in done) or "<li class='mut'>오늘은 아직 자동으로 처리한 작업이 없습니다.</li>"
    mine = q("SELECT COUNT(*) FROM logs WHERE ts>=?", (t0,), one=True)[0]
    upd = (f'<div class="flash">새 버전 {e(updater.state["latest"])} 이 있습니다. <a href="/admin">업데이트하기</a></div>' if updater.available() else "")
    mode = upd + ('<div class="flash err">지금은 <b>미리보기 모드</b>입니다. 마켓에 실제로 올라가지 않습니다. <a href="/settings">설정</a>에서 실제 등록 모드로 바꿀 수 있습니다.</div>' if dry else "")
    body = f"""{mode}<div style="display:grid;grid-template-columns:minmax(240px,280px) 1fr minmax(220px,260px);gap:14px;align-items:start" class="homegrid">
<div><div class="card" style="padding:14px"><h2 style="margin-top:0">시작하기</h2>{sl}</div></div>
<div><div class="card"><div class="row"><h2 style="margin:0">상점 현황</h2><a class="btn sm gray" href="/" style="margin-left:auto">새로고침</a></div>
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-top:12px">{st}</div>{stores}</div>
<div class="card"><h2>빠른 메뉴</h2>{job}<div class="row">{upload}<a class="btn gray" href="/products">📦 상품</a><a class="btn gray" href="/listings">🛒 등록현황</a><a class="btn gray" href="/fulfill">🚚 발주·송장</a><a class="btn gray" href="/sell/consign">💰 판매설정</a></div></div></div>
<div><div class="card"><h2 style="margin-top:0">오늘 프로그램이 한 일</h2><ul style="margin:0;padding-left:18px;line-height:1.9">{today}</ul>
<p class="mut">오늘 기록 {mine}건 · <a href="/history">작업 이력 보기 →</a></p></div>
<div class="card"><h2 style="margin-top:0">자동으로 하는 일</h2><ul style="margin:0;padding-left:18px;line-height:1.9"><li>새 주문 자동 수집</li><li>도매매 품절·가격 따라가기</li><li>재고 0이면 자동 품절</li><li>폰 알림 (<a href="/notify">설정</a>)</li></ul></div></div></div>
<style>@media (max-width:1000px){{.homegrid{{grid-template-columns:1fr !important}}}}</style>"""
    return page("홈", body, h.user, "/", h.flash, h.flash_err)

@route("POST", "/home/quick")
def home_quick(h):
    act = h.form().get("act", "")
    who = h.user["username"]
    if act == "autoreg_on":
        ids = [a["id"] for a in RA(q("SELECT id, market FROM accounts WHERE active=1 ORDER BY id"))]
        if not ids:
            go("/", "먼저 마켓을 연동해 주세요. 연동한 마켓에 자동으로 올립니다.", True)
        set_setting("csv_targets", {"accs": ids, "chans": []}); log(who, "자동 등록 켬", str(ids))
        go("/", f"자동 등록을 켰습니다. 이제 엑셀을 넣으면 연동한 마켓 {len(ids)}곳에 바로 올립니다.")
    if act == "autoreg_off":
        set_setting("csv_targets", {"accs": [], "chans": []}); log(who, "자동 등록 끔")
        go("/", "자동 등록을 껐습니다. 엑셀을 넣으면 상품만 만들어 둡니다.")
    if act in ("soldout_on", "soldout_off"):
        c = oc_conf(); c["auto_soldout"] = act == "soldout_on"; set_setting("domeggook", c)
        log(who, "품절 자동 관리 " + ("켬" if c["auto_soldout"] else "끔"))
        go("/", "품절·단종 자동 관리를 " + ("켰습니다." if c["auto_soldout"] else "껐습니다."))
    if act in ("orders_on", "orders_off"):
        set_setting("order_interval", 30 if act == "orders_on" else 0)
        log(who, "주문 자동 수집 " + ("켬(30분)" if act == "orders_on" else "끔"))
        go("/", "주문 자동 수집을 " + ("켰습니다. 30분마다 모읍니다." if act == "orders_on" else "껐습니다."))
    if act == "orders_now":
        threading.Thread(target=collect_orders, args=(who,), daemon=True).start()
        go("/", "주문 수집을 시작했습니다. 잠시 뒤 새로고침하면 반영됩니다.")
    go("/", "알 수 없는 동작입니다.", True)

# ---------- B2B(도매매 위탁) · 사입: 상품란과 쇼핑몰 관리를 따로 ----------
def store_btn(a):
    if a["market"] != "naver":
        return ""
    return '<a class="btn sm" href="/accounts/%d/store">스토어 상품 보기·삭제</a>' % a["id"]

def kind_targets(kind):
    if kind == "consign":
        return csv_targets()
    c = get_setting("own_targets", None)
    if c is None:
        return [a["id"] for a in RA(q("SELECT * FROM accounts WHERE active=1 ORDER BY id"))], []
    return c.get("accs", []), c.get("chans", [])

_OVERSEAS_RE = re.compile(r"\[\s*해외\s*\]|해외\s*(?:직\s*)?(?:배송|직구|발송|구매)|구매\s*대행|배송\s*대행|직구|국제\s*배송|중국\s*(?:에서|발송|배송|직배송|현지)|(?:배송|도착)\s*(?:기간)?\s*[:：]?\s*(?:7|10|14|15|20)\s*[~\-]\s*\d+\s*일|oversea|abroad", re.I)

def high_ship(p):
    """공급처·엑셀 택배비가 1만원 이상이면 그 금액(CHOI 기준: 택배비 1만원 이상 = 해외배송), 아니면 0"""
    try:
        ii = json.loads(p["import_json"] or "{}")
    except (ValueError, TypeError, KeyError):
        ii = {}
    try:
        s = float(p["supply_ship"] or 0)
    except (ValueError, TypeError, KeyError):
        s = 0
    b = int(ii.get("base_fee") or 0) if ii.get("fee_type") not in (None, "", "무료") else 0
    m = max(b, s)
    return int(m) if m >= 10000 else 0

def overseas_hit(p):
    """해외배송으로 보는 상품이면 이유를 돌려줌: 택배비 1만원 이상, 또는 상품명·상세·메모에 해외배송(직구·구매대행·중국발송 등) 표시. 아니면 None"""
    _h = high_ship(p)
    if _h:
        return f"택배비 {_h:,}원"
    try:
        txt = " ".join(str(p[k] or "") for k in ("name", "source_name", "supplier_status", "memo", "cautions", "points", "import_json", "supplier_option"))
    except (KeyError, IndexError):
        txt = str(p["name"] or "")
    htm = re.sub(r"<[^>]+>", " ", str(p["detail_html"] or "")) if "detail_html" in p.keys() else ""
    m = _OVERSEAS_RE.search(txt + " " + htm)
    return m.group(0) if m else None

def kind_page(h, kind):
    consign = kind == "consign"
    base = "/b2b" if consign else "/own"
    typ = "위탁" if consign else "사입"
    acc_sel, ch_sel = kind_targets(kind)
    accs = RA(q("SELECT * FROM accounts WHERE active=1 ORDER BY market,id"))
    mine = "".join(f'<label style="display:flex;gap:8px"><input type="checkbox" name="acc" value="{a["id"]}" style="width:auto" {"checked" if a["id"] in acc_sel else ""}> {e(MARKETS[a["market"]].name)} · {e(a["label"] or "")}</label>' for a in accs) \
        or '<p class="mut">연동된 마켓이 없습니다. <a href="/accounts">마켓계정</a>에서 키를 넣으세요.</p>'
    mine += "".join(f'<label style="display:flex;gap:8px"><input type="checkbox" name="ch" value="{e(c["code"])}" style="width:auto" {"checked" if c["code"] in ch_sel else ""}> {e(c["name"])} (엑셀)</label>' for c in chs.all_channels() if not c["api"])
    kw = h.qs.get("q", "")
    stf = h.qs.get("st", "")
    # 스마트스토어 상품조회처럼: 상태별 개수 + 상태 필터 + 상품번호 검색
    _ns = {}
    for l in q("SELECT product_id, status, market_id FROM listings WHERE dry=0 AND market='naver'"):
        s0 = l["status"] or ""
        k = "판매중" if s0 in ("등록요청", "판매중") else ("품절" if s0.startswith("품절") else ("판매중지" if s0 in ("판매중지", "판매금지", "판매종료") else "기타"))
        _ns[l["product_id"]] = k if _ns.get(l["product_id"]) != "판매중" else "판매중"
    allp = q("SELECT * FROM products WHERE COALESCE(supply_type,'사입')=? AND (name LIKE ? OR theme LIKE ? OR keyword LIKE ? OR id IN (SELECT product_id FROM listings WHERE market_id=?)) ORDER BY id DESC", (typ,) + (f"%{kw}%",) * 3 + (kw,))
    cnts = {"전체": len(allp), "판매중": 0, "품절": 0, "판매중지": 0, "미등록": 0, "해외배송": 0}
    _ov = {p["id"] for p in allp if overseas_hit(p)}
    cnts["해외배송"] = len(_ov)
    _hi = {p["id"] for p in allp if high_ship(p)}
    cnts["택배비1만원↑"] = len(_hi)
    def _fee_of(p):
        try:
            ii = json.loads(p["import_json"] or "{}")
        except (ValueError, TypeError):
            ii = {}
        b = int(ii.get("base_fee") or 0) if ii.get("fee_type") not in (None, "", "무료") else 0
        try:
            s = float(p["supply_ship"] or 0)
        except (ValueError, TypeError):
            s = 0
        return max(b, s)
    _h3 = {p["id"] for p in allp if _fee_of(p) >= 3001}
    cnts["택배비3001원↑"] = len(_h3)
    for p in allp:
        k = _ns.get(p["id"], "미등록")
        cnts[k if k in cnts else "판매중지"] += 1 if k != "기타" else 0
    rows = [p for p in allp if not stf or stf == "전체" or (p["id"] in _ov if stf == "해외배송" else (p["id"] in _hi if stf == "택배비1만원↑" else (p["id"] in _h3 if stf == "택배비3001원↑" else _ns.get(p["id"], "미등록") == stf)))][:1000]
    lst = {}
    for l in q("SELECT product_id, market, channel, dry FROM listings"):
        lst.setdefault(l["product_id"], set()).add(("🟡" if l["dry"] else "🟢") + (l["market"] or l["channel"] or "?"))
    def _shipinfo(p):
        """(숫자 택배비, 표시 문구): 엑셀 양식 상품은 파일의 배송비 규칙, 그 외는 공급처 택배비"""
        try:
            ii = json.loads(p["import_json"] or "{}")
        except (ValueError, TypeError):
            ii = {}
        if ii.get("fee_type"):
            b = int(ii.get("base_fee") or 0)
            ft = ii.get("fee_type")
            if ft == "무료" or b == 0:
                return 0, "무료"
            if ft == "수량별" and ii.get("repeat"):
                return b, f"{b:,} <span class='mut'>/{ii['repeat']}개마다</span>"
            if ft == "조건부무료" and ii.get("free_over"):
                return b, f"{b:,} <span class='mut'>({int(ii['free_over']):,}원↑무료)</span>"
            return b, f"{b:,}"
        s = float(p["supply_ship"] or 0)
        return s, (f"{s:,.0f}" if s else "<span class='mut'>-</span>")
    _sh0 = {p["id"]: _shipinfo(p) for p in rows}
    _sh = {i: (n, (f"<b style='color:#dc2626'>⚠ {t}</b>" if n >= 3001 else t)) for i, (n, t) in _sh0.items()}
    srt = h.qs.get("sort", "")
    _key = {"cost": lambda p: float(p["supply_price"] or p["cost_krw"] or 0), "sale": lambda p: float(p["price_override"] or 0), "ship": lambda p: _sh[p["id"]][0]}
    if srt.rsplit("_", 1)[0] in _key and srt.endswith(("_asc", "_desc")):
        rows = sorted(rows, key=_key[srt.rsplit("_", 1)[0]], reverse=srt.endswith("_desc"))
    def _sb(col, label):
        return f"{label}<br><a href='{base}?st={quote(stf)}&q={quote(kw)}&sort={col}_asc' style='font-size:11px;{'font-weight:bold;' if srt == col + '_asc' else ''}'>최저↑</a> <a href='{base}?st={quote(stf)}&q={quote(kw)}&sort={col}_desc' style='font-size:11px;{'font-weight:bold;' if srt == col + '_desc' else ''}'>최고↓</a>"
    ns_ = get_setting("naver_sync") or {}
    if ns_.get("t"):
        sync_card = (f"<div class='card'><div class='row'><div><b>🔄 네이버 연동 확인</b> <span class='mut'>{time.strftime('%m-%d %H:%M', time.localtime(ns_['t']))} (30분마다 자동)</span><br>"
                     + (f"<span style='color:#dc2626'>⚠ {e(ns_['error'])}</span>" if ns_.get("error") else
                        (f"<span style='color:#dc2626'><b>⚠ 어긋남</b>: 스토어 {ns_.get('store', 0):,}개인데 프로그램 기록은 {ns_.get('mine', 0):,}개입니다 (스토어에 없어 정리 {ns_.get('removed', 0)}개 · 프로그램 밖에서 올린 상품 {ns_.get('only_store', 0)}개)</span><br>" if (ns_.get('removed') or ns_.get('only_store') or ns_.get('store', 0) != ns_.get('mine', 0)) else "<span style='color:#16a34a'><b>✔ 일치</b></span> ")
                        + f"스토어 {ns_.get('store', 0):,}개 · 프로그램 기록 {ns_.get('mine', 0):,}개 · 스토어에 없어 정리한 기록 {ns_.get('removed', 0)}개 · 상태 반영 {ns_.get('status_changed', 0)}개" + (f" · 프로그램 밖에서 올린 스토어 상품 {ns_['only_store']}개" if ns_.get("only_store") else ""))
                     + f"</div><form method='post' action='/navercheck' data-busy><input type='hidden' name='back' value='{base}'><button class='btn gray sm'>지금 확인</button></form></div></div>")
    else:
        sync_card = (f"<div class='card'><div class='row'><div><b>🔄 네이버 연동 확인</b> <span class='mut'>아직 확인 전입니다(30분마다 자동으로 합니다)</span></div>"
                     f"<form method='post' action='/navercheck' data-busy><input type='hidden' name='back' value='{base}'><button class='btn gray sm'>지금 확인</button></form></div></div>")
    pj = NAVER_PURGE
    purge_card = ""
    if pj.get("total"):
        purge_card = (f"<div class='card' style='border:2px solid #dc2626'><h2>🗑 삭제 진행 상황</h2><p>{'삭제 중…' if pj.get('running') else '끝났습니다.'} {pj['done']}/{pj['total']}개 처리 · 네이버에서 지운 상품 {pj['naver']}개 · 실패 {pj['fail']}개</p>"
                      + ("<p class='mut'>실패한 상품은 프로그램 목록에 그대로 남겨 두었습니다.</p><ul>" + "".join(f"<li>{e(t)}</li>" for t in pj['errors'][:10]) + "</ul>" if pj['fail'] else "")
                      + ("<script>setTimeout(function(){location.reload()},4000)</script>" if pj.get("running") else "") + "</div>")
    stcards = "".join(f"<a href='{base}?st={quote(n)}&q={quote(kw)}' style='text-decoration:none;color:inherit;padding:10px 18px;border-radius:10px;border:1px solid #d1d5db;{'background:#dcfce7;' if (stf or '전체') == n else ''}'><div class='mut'>{n}</div><b style='font-size:22px'>{cnts[n]:,}</b> 건</a>" for n in ("전체", "판매중", "품절", "판매중지", "미등록", "해외배송", "택배비1만원↑", "택배비3001원↑"))
    trs = "".join(f"<tr><td><input type='checkbox' name='pid' value='{p['id']}'></td><td><a href='/products/{p['id']}'><b>{e(p['name'])}</b></a>"
                  f"<div class='mut'>{e(p['supplier_status'] or p['status'] or '')}{' <b style=color:#dc2626>🌏해외배송</b>' if p['id'] in _ov else ''}</div></td><td>{(p['supply_price'] or p['cost_krw'] or 0):,.0f}</td><td>{('<b>%s</b>' % format(int(p['price_override']), ',')) if p['price_override'] else '<span class=mut>미정</span>'}</td><td>{_sh[p['id']][1]}</td><td>{p['stock'] if p['stock'] is not None else ''}</td>"
                  f"<td>{' '.join(sorted(lst.get(p['id'], [])))}</td></tr>" for p in rows)
    hid = "".join(f'<input type="hidden" name="acc" value="{i}">' for i in acc_sel) + "".join(f'<input type="hidden" name="ch" value="{e(c)}">' for c in ch_sel)
    cnt = q("SELECT COUNT(*) FROM products WHERE COALESCE(supply_type,'사입')=?", (typ,), one=True)[0]
    n_nn = q("SELECT COUNT(*) FROM products WHERE COALESCE(supply_type,'사입')=? AND NOT EXISTS (SELECT 1 FROM listings l WHERE l.product_id=products.id AND l.market='naver' AND l.dry=0 AND COALESCE(l.market_id,'')<>'')", (typ,), one=True)[0]
    ss_form = """<form method="post" action="/b2b/smartstore" enctype="multipart/form-data" data-busy class="row" style="margin-top:10px">
<input type="file" name="files" multiple accept=".xlsx,.zip" required style="max-width:340px"><select name="price_mode" style="max-width:260px"><option value="sale">엑셀 판매가 = 우리 판매가</option><option value="cost">엑셀 판매가 = 공급가(마진 계산)</option></select>
<button class="btn green">스마트스토어 양식 올리기</button></form>
<p class="mut">이미지 zip과 엑셀들(SMARTSTORE_… 본문, 키워드, 배송비, 옵션)을 한꺼번에 골라 올리세요. 종류는 자동으로 알아봅니다. 상세페이지·배송비(수량별 포함)·제주/도서산간·태그·옵션이 파일 그대로 올라갑니다. 60MB까지(넘으면 zip을 나눠서).</p>"""
    if consign:
        job = job_card(base)
        upload = f"""<form method="post" action="/suppliers/csv" enctype="multipart/form-data" data-busy class="row"><input type="hidden" name="back" value="/b2b"><input type="hidden" name="use_saved" value="1">
<input type="hidden" name="review" value="1"><input type="file" name="file" multiple accept=".csv,.xlsx,.txt,.zip" required style="max-width:340px"><select name="price_mode" style="max-width:260px"><option value="sale">엑셀 판매가 = 우리 판매가</option><option value="cost">엑셀 판매가 = 공급가(마진 계산)</option></select>
<button class="btn green">올리고 바로 등록</button></form>{job}
<p class="mut"><b>엑셀 여러 개와 이미지 zip을 이 칸 하나에서 한꺼번에</b> 올립니다. 파일 선택 창에서 Ctrl(또는 Shift)을 누른 채 엑셀들과 zip을 모두 고르세요. 스마트스토어 양식(본문·키워드·배송비·옵션 엑셀 + 이미지 zip)이면 상세페이지·배송비·제주/도서산간·태그·옵션이 파일 그대로 올라가고, 아래 「올릴 쇼핑몰」에 체크한 곳에 바로 등록됩니다. 같은 상품번호는 가격·재고만 갱신합니다. 한 번에 60MB까지(넘으면 나눠서).</p>
<div class="row"><a class="btn gray" href="/suppliers">도매매에서 찾아 가져오기</a><a class="btn gray" href="/sell/consign">💰 B2B 판매설정(마진)</a></div>"""
        title = "B2B 상품 (도매매 위탁)"
    else:
        upload = """<form method="post" action="/products/import" enctype="multipart/form-data" data-busy class="row"><input type="hidden" name="kind" value="own">
<input type="file" name="file" accept=".xlsx,.csv" required style="max-width:300px"><input name="limit" value="500" style="width:80px" title="최대 개수"><button class="btn green">엑셀 올려서 사입 상품 만들기</button></form>
<p class="mut">상품명·단가(위안 또는 원)·세트 수량·MOQ·재고·상품 링크 열을 알아봅니다(<a href="/products/template.csv">빈 양식</a>). 올린 뒤 상품을 골라 아래 버튼으로 상세페이지 제작 → 등록합니다.</p>
<div class="row"><a class="btn gray" href="/products/new">+ 직접 추가</a><a class="btn gray" href="/sell/own">📦 사입 판매설정(마진)</a></div>"""
        title = "사입 상품"
    acc_tbl = "".join(f"<tr><td>{MARKETS[a['market']].name}</td><td>{e(a['label'])}</td><td><form method='post' action='/accounts/{a['id']}/test' data-busy><input type='hidden' name='back' value='{base}'><button class='btn sm gray'>연결 확인</button></form></td>"
                      f"<td>{store_btn(a)}</td></tr>" for a in accs if a["id"] in acc_sel)
    body = f"""<h1>{title} <span class="mut">({cnt}개)</span></h1>
{sync_card}{purge_card}<div class="card"><h2>상품 조회 <span class="mut">(스마트스토어 상품조회와 같은 방식: 상태를 누르면 그 상품만 보입니다)</span></h2><div class="row" style="gap:12px">{stcards}</div>
<form method="post" action="/bulk" data-busy class="row" style="margin-top:8px"><input type="hidden" name="back" value="{base}"><button class="btn red" name="do" value="del_overseas" onclick="return prompt('해외배송 상품 {cnts['해외배송']}개를 프로그램과 네이버 스마트스토어에서 모두 삭제합니다. 되돌릴 수 없습니다. 진행하려면 숫자 {cnts['해외배송']} 를 입력하세요.')==='{cnts['해외배송']}'">🌏 해외배송 상품 전부 지우기 ({cnts['해외배송']}개, 네이버도 삭제)</button></form>
<form method="post" action="/autoclean" class="row" style="margin:6px 0"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="on" value="1" style="width:auto" {'checked' if get_setting('auto_clean', True) else ''}> 🧹 자동 정리: 해외배송 상품은 가져오자마자·1시간마다 알아서 지움(네이버에 올라간 상품은 남김)</label><input type="hidden" name="back" value="{base}"><button class="btn gray sm">저장</button><span class="mut">{('최근 자동 정리: ' + time.strftime('%m-%d %H:%M', time.localtime(get_setting('auto_clean_last')['t'])) + ' ' + str(get_setting('auto_clean_last')['n']) + '개') if get_setting('auto_clean_last') else ''}</span></form>
<p class="mut">택배비1만원↑ = 공급처 택배비가 1만원 이상인 상품(도매매 해외직배송 상품에 많음). 눌러서 확인하고, 해외배송이면 체크해서 삭제하세요. · 🌏 해외배송 = 택배비 1만원 이상이거나 상품명·상세에 해외배송·직구·구매대행·중국발송 등이 적힌 상품. 이런 상품은 등록하지 않고 건너뜁니다. 눌러서 확인한 뒤 전체 체크 → 삭제하세요.</p>
<form method="get" action="{base}" class="row" style="margin-top:10px"><input name="q" value="{e(kw)}" placeholder="상품명 또는 네이버 상품번호" style="max-width:300px"><input type="hidden" name="st" value="{e(stf)}"><button class="btn gray">검색</button></form></div>
<div class="card"><div class="row" style="gap:28px"><div><div class="mut">프로그램 전체</div><b style="font-size:24px">{cnt}</b> 개</div><div><div class="mut">🟢 네이버 등록됨</div><b style="font-size:24px;color:#16a34a">{cnt - n_nn}</b> 개</div><div><div class="mut">네이버 미등록</div><b style="font-size:24px">{n_nn}</b> 개</div></div>
<p class="mut">네이버 스마트스토어 화면의 판매중 개수와 다르면: 판매금지·삭제된 상품이거나, 이 프로그램을 쓰기 전에 올린 상품일 수 있습니다. 위 숫자는 이 프로그램이 등록 성공을 기록한 상품 수입니다.</p></div>
<div class="card"><h2>엑셀 올리기</h2>{upload}</div>
<div class="card"><h2>🏬 {typ} 쇼핑몰 관리</h2><p class="mut">택배비: <b>{'미포함 (구매자가 배송비 따로)' if (consign_policy() if consign else pricing.cfg()).get('ship_mode') == 'separate' else '포함 (무료배송)'}</b> · <a href="{'/sell/consign' if consign else '/sell/own'}">판매설정에서 바꾸기</a></p><form method="post" action="{base}/targets"><p class="mut">이 상품들을 올릴 쇼핑몰을 고르세요. {'B2B' if consign else '사입'}과 {'사입' if consign else 'B2B'}은 따로 저장됩니다.</p>{mine}<br><button class="btn">저장</button></form>
<div class="tbl" style="margin-top:12px"><table><tr><th>마켓</th><th>계정</th><th></th><th></th></tr>{acc_tbl or '<tr><td colspan=4 class="mut">고른 쇼핑몰이 없습니다</td></tr>'}</table></div></div>
<form method="post" action="/bulk" data-busy><input type="hidden" name="back" value="{base}">{hid}
<div class="card"><h2>💰 체크한 상품에 마진 더하기</h2><div class="row"><select name="mmode" style="max-width:190px"><option value="won">정액(원) 더하기</option><option value="pct">정률(%) 더하기</option></select><input name="mval" placeholder="예: 300 또는 30" style="max-width:150px"><button class="btn" name="do" value="margin">마진 적용</button></div>
<p class="mut">공급가에 마진을 더해 10원 단위로 올린 값이 「판매가」가 됩니다(190원짜리는 정액 300원처럼). 적용 후 등록하면 그 판매가로 올라갑니다. 이미 올린 상품은 「등록된 마켓 가격 동기화」.</p></div>
<div class="card"><div class="row"><a class="btn gray" href="/products/export.xlsx?kind={kind}&q={quote(kw)}">⬇ 올려놓은 상품만 엑셀로 받기(지운 상품 제외)</a><button class="btn gray" formaction="/products/export.xlsx" formmethod="post" name="kind" value="{kind}" data-dl>⬇ 체크한 상품만 엑셀로 받기</button></div></div>
<div class="card"><div class="row"><button class="btn" name="do" value="detail" data-autoimg="bulk">선택 상품 상세페이지 자동 제작</button>
<button class="btn green" name="do" value="register">선택 상품을 위 쇼핑몰에 등록</button>
<button class="btn gray" name="do" value="ship_text">상세페이지 당일발송 문구 → 2~3일 도착</button>
<button class="btn gray" name="do" value="sync">등록된 마켓 가격 동기화</button>
<button class="btn gray" name="do" value="soldout" onclick="return confirm('모든 마켓 판매중지할까요?')">품절 처리</button><button class="btn gray" name="do" value="resume">판매 재개</button>
<button class="btn red" name="do" value="delete" onclick="return confirm('체크한 상품을 프로그램과 네이버 스마트스토어에서 삭제합니다(네이버 삭제는 되돌릴 수 없음). 계속할까요?')">삭제(네이버도)</button></div></div>
<div class="card"><div class="row"><input name="fee" form="sfee" placeholder="택배비(원) 예: 3000, 무료는 0" style="max-width:240px"><button class="btn gray" form="sfee">엑셀로 올린 상품 택배비 한 번에 바꾸기</button></div>
<p class="mut">스마트스토어 양식으로 올린 상품은 엑셀에 적힌 배송비(수량별·조건부 포함)가 그대로 올라갑니다. 여기서 한 값으로 통일할 수 있습니다.</p></div>
<div class="card"><div class="row"><button class="btn red" name="do" value="del_not_naver" onclick="return confirm('네이버에 등록되지 않은 상품 {n_nn}개를 이 목록에서 모두 지웁니다. 네이버에 등록된 상품은 남습니다. 계속할까요?')">네이버 등록한 상품 빼고 전부 지우기 ({n_nn}개)</button></div><p class="mut">체크하지 않아도 됩니다. 네이버 스마트스토어에 실제로 올라간 기록(🟢 naver)이 있는 상품만 남기고, 나머지는 이 프로그램 목록에서 지웁니다. 스마트스토어의 상품은 지우지 않습니다.</p></div>
<div class="card tbl"><div class="row" style="margin-bottom:8px"><input name="q" form="sf" value="{e(kw)}" placeholder="상품 검색" style="max-width:240px"></div>
<table><tr><th><input type="checkbox" data-all="pid" style="width:auto"></th><th>상품</th><th>{_sb('cost', '공급가' if consign else '원가')}</th><th>{_sb('sale', '판매가')}</th><th>{_sb('ship', '택배비')}</th><th>재고</th><th>등록</th></tr>{trs or '<tr><td colspan=7 class="mut">아직 상품이 없습니다. 위에서 엑셀을 올려 주세요.</td></tr>'}</table></div></form>
<form id="sf" method="get" action="{base}"></form><form id="sfee" method="post" action="/shipfix"><input type="hidden" name="back" value="{base}"></form>"""
    return page(title, body, h.user, base, h.flash, h.flash_err)

@route("GET", "/b2b")
def b2b_page(h):
    return kind_page(h, "consign")

@route("GET", "/own")
def own_page(h):
    return kind_page(h, "own")

def save_targets(h, kind):
    f = h.form_multi()
    accs = [int(v) for v in f.get("acc", []) if v.isdigit()]
    chans = f.get("ch", [])
    set_setting("csv_targets" if kind == "consign" else "own_targets", {"accs": accs, "chans": chans})
    log(h.user["username"], ("B2B" if kind == "consign" else "사입") + " 쇼핑몰 저장", f"계정 {accs} 판매처 {chans}")
    go("/b2b" if kind == "consign" else "/own", "쇼핑몰 선택을 저장했습니다")

def attach_images(zip_paths, user):
    """이미지 zip만 올렸을 때: 파일 이름(상품번호.jpg)으로 이미 있는 상품을 찾아 사진을 붙임. (새 id들, 사진 붙은 상품 id들, 메시지)"""
    import zipfile
    hit, miss = [], 0
    for zp in zip_paths:
        with zipfile.ZipFile(zp) as zf:
            for n in zf.namelist():
                base = os.path.basename(n)
                m = re.match(r"^(\d+)(?:[_\-].*)?\.(jpe?g|png|gif|webp)$", base, re.I)
                if not m:
                    continue
                prod = q("SELECT id, images FROM products WHERE supplier='domeggook' AND supplier_key=? ORDER BY id", (m.group(1),))
                if not prod:
                    miss += 1; continue
                dst = os.path.join(IMAGES, base)
                with open(dst, "wb") as o:
                    o.write(zf.read(n))
                for pr in prod:
                    cur = json.loads(pr["images"] or "[]")
                    if base not in cur:
                        cur.append(base)
                        x("UPDATE products SET images=?, updated=?, updated_by=? WHERE id=?", (json.dumps(cur, ensure_ascii=False), time.time(), user, pr["id"]))
                    if pr["id"] not in hit:
                        hit.append(pr["id"])
    msg = f"사진을 {len(hit)}개 상품에 붙였습니다" + (f" (맞는 상품이 없는 사진 {miss}장은 건너뜀)" if miss else "")
    log(user, "이미지 zip 적용", msg)
    return [], hit, msg

def ss_import(fl, cost_mode, user, policy_id=None, staging=False):
    """스마트스토어 양식(엑셀들+이미지 zip)을 읽어 B2B(위탁) 상품으로 만들거나 갱신. (새 id들, 갱신 id들, 메시지)"""
    r = ssimport.parse(fl)
    zf = r["zip"]
    names = {os.path.basename(n): n for n in zf.namelist()} if zf else {}
    made = upd = miss_img = 0
    new_ids, upd_ids = [], []
    pol = policy_id or consign_policy_id()
    for it in r["items"]:
        saved = []
        for fn in it["images"]:
            if fn.startswith("http"):
                saved.append(fn); continue
            if fn in names:
                dst = os.path.join(IMAGES, os.path.basename(fn))
                if not os.path.isfile(dst):
                    with open(dst, "wb") as o:
                        o.write(zf.read(names[fn]))
                saved.append(os.path.basename(fn))
            else:
                miss_img += 1
        info = json.dumps(it["info"], ensure_ascii=False)
        price = float(it["price"])
        old = q("SELECT id FROM products WHERE supplier='domeggook' AND supplier_key=? AND COALESCE(supplier_option,'')=''", (it["code"],), one=True)
        vals = dict(name=it["name"][:100], source_name=it["name"], source_url=ocmod.item_url(it["code"], oc_conf().get("market", "supply")), naver_cat=it["cat"],
                    stock=min(it["stock"], 99999), images=json.dumps(saved, ensure_ascii=False), detail_html=it["detail"] or None, template="imported",
                    ship=float(it["info"]["base_fee"]), import_json=info, supply_price=price if cost_mode else None, cost_krw=price if cost_mode else None,
                    price_override=None if (cost_mode and not staging) else price, policy_id=pol)
        if staging:   # 검토 화면용: 엑셀 금액을 공급가로 저장하고 판매가는 일단 같은 값(마진은 검토 화면에서 정함)
            vals["supply_price"] = price; vals["cost_krw"] = price
        if old:
            sets = ", ".join(f"{k}=?" for k in vals)
            x(f"UPDATE products SET {sets}, updated=?, updated_by=? WHERE id=?", tuple(vals.values()) + (time.time(), user, old["id"]))
            upd += 1; upd_ids.append(old["id"])
        else:
            vals.pop("policy_id")
            cols = list(vals) + ["theme", "keyword", "set_qty", "status", "supply_type", "supplier", "supplier_key", "supplier_option", "supplier_status", "updated", "updated_by", "policy_id"]
            args = tuple(vals.values()) + ("B2B", ",".join(it["info"]["tags"][:3]), 1, "검토대기" if staging else "준비", "위탁", "domeggook", it["code"], "", "판매중", time.time(), user, pol)
            pid = x(f"INSERT INTO products({','.join(cols)}) VALUES({','.join('?' * len(cols))})", args)
            new_ids.append(pid); made += 1
    c = r["counts"]
    log(user, "스마트스토어 양식 올림", f"상품 {made}개 새로, {upd}개 갱신 · 이미지 없음 {miss_img}")
    msg = (f"상품 {made}개를 새로 만들고 {upd}개를 갱신했습니다. (배송비 {c['delivery']}개 · 태그 {c['keyword']}개 · 옵션 있는 상품 {c['option_products']}개 읽음"
           + (f" · 이미지 못 찾음 {miss_img}장" if miss_img else "") + (" · " + " / ".join(r["notes"]) if r["notes"] else "") + ")")
    if not zf:
        msg += " 이미지 zip이 없어 사진은 비어 있습니다."
    return new_ids, upd_ids, msg

@route("POST", "/b2b/smartstore")
def b2b_smartstore(h):
    f, files = h.multipart()
    fl = [(fn, data) for fn, data in files.get("files", []) if data]
    if not fl:
        go("/b2b", "파일을 골라 주세요(엑셀들과 이미지 zip을 한꺼번에 선택)", True)
    try:
        _n, _u, msg = ss_import(fl, f.get("price_mode") == "cost", h.user["username"])
    except Exception as ex:
        go("/b2b", f"파일을 읽지 못했습니다: {ex}", True)
    go("/b2b", msg)

def _rnd10(v):
    return int(-(-float(v) // 10) * 10)   # 10원 단위 올림

def _review_rows():
    return q("SELECT * FROM products WHERE supplier='domeggook' AND status='검토대기' ORDER BY id")

RV_KEYS = ("cmin", "cmax", "smin", "smax", "per")
RV_SORTS = ("cost_asc", "cost_desc", "sale_asc", "sale_desc")

def _rv_params(get):
    """화면 조건(공급가·판매가 최저/최고, 한 페이지 개수)을 꺼낸다. get(key) -> 문자열"""
    d = {}
    for k in RV_KEYS:
        v = (get(k) or "").strip().replace(",", "")
        if v and num(v, float) is not None:
            d[k] = v
    sv = (get("sort") or "").strip()
    if sv in RV_SORTS:
        d["sort"] = sv
    return d

def _rv_sort(rows, d):
    sv = d.get("sort")
    if not sv:
        return rows
    key = (lambda p: float(p["supply_price"] or 0)) if sv.startswith("cost") else (lambda p: float(p["price_override"] or p["supply_price"] or 0))
    return sorted(rows, key=key, reverse=sv.endswith("desc"))

def _rv_filter(rows, d):
    def pick(lo, hi, fn):
        a = num(d.get(lo), float) if d.get(lo) else None
        b = num(d.get(hi), float) if d.get(hi) else None
        return (lambda p: (a is None or fn(p) >= a) and (b is None or fn(p) <= b))
    fc = pick("cmin", "cmax", lambda p: float(p["supply_price"] or 0))
    fs = pick("smin", "smax", lambda p: float(p["price_override"] or p["supply_price"] or 0))
    return [p for p in rows if fc(p) and fs(p)]

def _rv_sorthdr(d, kind, label):
    """금액 칸 바로 위: 최저순(▲)·최고순(▼) 버튼. 지금 정렬은 진하게"""
    cur = d.get("sort", "")
    def link(sv, txt):
        dd = {k: v for k, v in d.items() if k != "sort"}; dd["sort"] = sv
        on = "" if cur == sv else "gray"
        return f'<a class="btn sm {on}" style="padding:2px 6px" href="{_rv_url(dd)}">{txt}</a>'
    return f'<div style="white-space:nowrap">{link(kind + "_asc", "최저")}{link(kind + "_desc", "최고")}</div>{label}'

def _rv_url(d, pg=1):
    from urllib.parse import urlencode
    dd = dict(d)
    if pg and pg > 1:
        dd["page"] = pg
    return "/b2b/review" + ("?" + urlencode(dd) if dd else "")

@route("GET", "/b2b/review")
def b2b_review(h):
    d = _rv_params(h.qs.get)
    allrows = _review_rows()
    rows = _rv_sort(_rv_filter(allrows, d), d)
    pg = max(1, num(h.qs.get("page"), int) or 1)
    per = min(1000, max(10, int(num(d.get("per"), float) or 100)))
    show = rows[(pg - 1) * per: pg * per]
    trs = []
    for p in show:
        im = local_img_urls(p)
        th = f'<img class="thumb" src="{e(im[0])}">' if im else '<div class="thumb"></div>'
        info = json.loads(p["import_json"] or "{}")
        fee = f"{info.get('fee_type', '')} {int(info.get('base_fee') or 0):,}원" + (f"/{info['repeat']}개" if info.get("repeat") else "")
        cost = float(p["supply_price"] or 0); sale = float(p["price_override"] or cost)
        mg = sale - cost
        opts = len(info.get("options") or [])
        trs.append(f"<tr><td><input type='checkbox' name='pid' value='{p['id']}' style='width:auto' checked></td><td>{th}</td>"
                   f"<td><a target='_blank' href='{e(p['source_url'] or '')}'>{e(p['supplier_key'])}</a></td><td style='min-width:220px'>{e((p['name'] or '')[:60])}<div class='mut'>{e(fee)} · 옵션 {opts}개 · 재고 {p['stock'] if p['stock'] is not None else ''}</div></td>"
                   f"<td style='text-align:right'>{cost:,.0f}</td><td style='text-align:right;color:{'#16a34a' if mg > 0 else '#dc2626'}'>{mg:+,.0f}<div class='mut'>{(mg / cost * 100 if cost else 0):.0f}%</div></td>"
                   f"<td><input name='price_{p['id']}' value='{sale:.0f}' style='width:90px;text-align:right'></td></tr>")
    nav = "".join(f'<a class="btn sm {"" if i == pg else "gray"}" href="{_rv_url(d, i)}">{i}</a> ' for i in range(1, (len(rows) + per - 1) // per + 1))
    acc_sel, ch_sel = kind_targets("consign")
    names = ", ".join(f"{MARKETS[a['market']].name}·{a['label']}" for a in RA(q("SELECT * FROM accounts WHERE active=1")) if a["id"] in acc_sel) or "선택된 쇼핑몰 없음(B2B상품 화면에서 체크)"
    hid = "".join(f'<input type="hidden" name="{k}" value="{e(v)}">' for k, v in d.items())
    pers = "".join(f'<option value="{n}" {"selected" if n == per else ""}>{n}개씩 보기</option>' for n in (100, 200, 300, 500, 1000))
    def _no_ph(p):
        try:
            return not (json.loads(p["import_json"] or "{}").get("as_phone") or "").strip()
        except ValueError:
            return True
    miss = _naver_phone_missing(RA([a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (i,), one=True) for i in acc_sel) if a])) if any(_no_ph(p) for p in allrows) else []
    basics = (f"""<div class="card" style="border:2px solid #dc2626"><h2>⚠️ 등록 전에 꼭 필요한 정보</h2><form method="post" action="/b2b/review/basics" class="row">{hid}
<span>A/S·고객센터 전화번호</span><input name="as_phone" placeholder="예: 010-1234-5678" style="max-width:200px"><button class="btn green">저장</button></form>
<p class="mut">엑셀에 A/S 전화번호가 비어 있는 상품이 있습니다. 네이버가 필수로 요구합니다. 한 번만 넣으면 모든 네이버 계정에 저장됩니다(구매자에게 보이는 번호이니 실제 번호를 넣으세요).</p></div>""") if miss else ""
    body = f"""<h1>올리기 전 확인 <span class="mut">({len(rows)}개{f' / 전체 {len(allrows)}개' if len(rows) != len(allrows) else ''})</span></h1>
{basics}<div class="card"><h2>🔎 가격 범위로 골라 보기</h2><form method="get" action="/b2b/review" class="row">
<span class="mut">공급가</span><input name="cmin" value="{e(d.get('cmin', ''))}" placeholder="최저" style="max-width:100px"> ~ <input name="cmax" value="{e(d.get('cmax', ''))}" placeholder="최고" style="max-width:100px">
<span class="mut">판매가</span><input name="smin" value="{e(d.get('smin', ''))}" placeholder="최저" style="max-width:100px"> ~ <input name="smax" value="{e(d.get('smax', ''))}" placeholder="최고" style="max-width:100px">
<select name="per" style="max-width:140px">{pers}</select><button class="btn">적용</button> <a class="btn gray" href="/b2b/review">초기화</a></form>
<p class="mut">비워 두면 제한 없음입니다. 보이는 상품만 아래 마진·등록 대상이 됩니다. 한 페이지에 최대 1000개까지 볼 수 있습니다.</p></div>
<form method="post" action="/b2b/review/save" data-busy><input type="hidden" name="page" value="{pg}">{hid}
<div class="card"><h2>마진 한 번에 정하기</h2><div class="row">
<select name="mode" style="max-width:200px"><option value="won">정액(원) 더하기</option><option value="pct">정률(%) 더하기</option></select>
<input name="val" placeholder="예: 300 또는 30" style="max-width:140px">
<select name="target" style="max-width:200px"><option value="checked">체크한 상품만</option><option value="all">조건에 맞는 전체(모든 페이지)</option></select>
<button class="btn" formaction="/b2b/review/margin">마진 적용</button></div>
<p class="mut">공급가(엑셀 금액)에 마진을 더한 값을 10원 단위로 올려 판매가로 만듭니다. 190원짜리는 정액 300원처럼 따로 정하세요. 판매가 칸을 직접 고쳐도 됩니다.</p></div>
<div class="card tbl"><table><tr><th><input type="checkbox" data-all="pid" style="width:auto" checked></th><th>사진</th><th>상품번호</th><th>상품명 · 배송비</th><th>{_rv_sorthdr(d, "cost", "공급가")}</th><th>마진</th><th>{_rv_sorthdr(d, "sale", "판매가")}</th></tr>{''.join(trs) or '<tr><td colspan=7>확인할 상품이 없습니다. <a href="/suppliers/csv">엑셀·zip 올리기</a>에서 파일을 올리세요.</td></tr>'}</table></div>
<p>{nav}</p>
<div class="card"><p class="mut">올릴 쇼핑몰: <b>{e(names)}</b></p>
<button class="btn" name="do" value="save">판매가 저장</button> <button class="btn" name="do" value="trial">1개만 시험 등록(에러가 나면 이유가 바로 보입니다)</button> <button class="btn green" name="do" value="register">체크한 상품 등록하기</button> <button class="btn red" name="do" value="delete" onclick="return confirm('체크한 상품을 이 목록에서 지울까요?')">체크한 상품 지우기</button></div></form>"""
    return page("올리기 전 확인", body, h.user, "/b2b/review", h.flash, h.flash_err)

def _naver_phone_missing(accs):
    """전화번호가 없는(또는 가짜 기본값인) 네이버 계정 목록"""
    out = []
    for a in accs:
        if a["market"] != "naver":
            continue
        ph = (json.loads(a["extra"] or "{}").get("as_phone") or "").strip()
        if ph in ("", "010-0000-0000", "01000000000"):
            out.append(a)
    return out

@route("POST", "/b2b/review/basics")
def b2b_review_basics(h):
    f = h.form_multi()
    d = _rv_params(lambda k: (f.get(k) or [""])[0]); back = _rv_url(d)
    ph = (f.get("as_phone") or [""])[0].strip()
    if not re.fullmatch(r"[0-9\-]{8,14}", ph) or ph in ("010-0000-0000", "01000000000"):
        go(back, "전화번호를 정확히 넣으세요(예: 010-1234-5678 또는 02-123-4567)", True)
    for a in q("SELECT * FROM accounts WHERE market='naver'"):
        ex = json.loads(a["extra"] or "{}"); ex["as_phone"] = ph
        x("UPDATE accounts SET extra=? WHERE id=?", (json.dumps(ex, ensure_ascii=False), a["id"]))
    go(back, "A/S·고객센터 전화번호를 저장했습니다. 이제 등록할 수 있습니다.")

@route("POST", "/jobfail")
def jobfail(h):
    f = h.form_multi()
    back = (f.get("back") or ["/b2b"])[0]
    back = back if back.startswith("/") and "//" not in back else "/b2b"
    do = (f.get("do") or ["close"])[0]
    pids = list(CSV_JOB.get("fail_pids") or [])
    n = 0
    if do == "delete":
        live = {r[0] for r in q("SELECT product_id FROM listings WHERE market='naver' AND dry=0 AND COALESCE(market_id,'')<>''")}
        for pid in pids:
            if pid not in live:   # 실패 후 다시 올라간 상품은 지우지 않음
                x("DELETE FROM listings WHERE product_id=?", (pid,))
                x("DELETE FROM products WHERE id=?", (pid,))
                n += 1
        log(h.user["username"], "등록 실패 상품 삭제", f"{n}개")
    CSV_JOB.pop("end", None); CSV_JOB.pop("fails", None); CSV_JOB.pop("fail_pids", None)
    go(back, f"등록에 실패했던 상품 {n}개를 지웠습니다." if do == "delete" else "결과를 닫았습니다.")

@route("POST", "/navercheck")
def navercheck(h):
    f = h.form_multi()
    back = (f.get("back") or ["/b2b"])[0]
    back = back if back in ("/b2b", "/own") else "/b2b"
    r = naver_sync_check(h.user["username"])
    if r["error"]:
        go(back, "네이버 연동 확인 실패: " + r["error"], True)
    go(back, f"네이버 스토어 {r['store']}개 · 프로그램 기록 {r['mine']}개를 맞춰 봤습니다. 스토어에 없는 기록 {r['removed']}개 정리, 상태 바뀐 것 {r['status_changed']}개.")

@route("POST", "/autoclean")
def autoclean_set(h):
    f = h.form_multi()
    back = (f.get("back") or ["/b2b"])[0]
    back = back if back in ("/b2b", "/own") else "/b2b"
    on = bool(f.get("on"))
    set_setting("auto_clean", on)
    n = auto_clean(h.user["username"]) if on else 0
    go(back, "자동 정리를 " + ("켰습니다" + (f". 지금 해외배송 상품 {n}개를 지웠습니다" if n else "") if on else "껐습니다"))

@route("POST", "/shipfix")
def shipfix(h):
    f = h.form_multi()
    back = (f.get("back") or ["/b2b"])[0]
    back = back if back in ("/b2b", "/own") else "/b2b"
    fee = num((f.get("fee") or [""])[0], int)
    if fee is None or fee < 0:
        go(back, "택배비를 숫자로 넣으세요(무료는 0)", True)
    typ = "위탁" if back == "/b2b" else "사입"
    n = 0
    for p in q("SELECT id, import_json FROM products WHERE COALESCE(supply_type,'사입')=? AND import_json IS NOT NULL AND import_json<>''", (typ,)):
        try:
            ii = json.loads(p["import_json"])
        except ValueError:
            continue
        ii.update({"fee_type": "무료" if fee == 0 else "유료", "base_fee": fee, "repeat": 0, "free_over": 0})
        x("UPDATE products SET import_json=?, ship=? WHERE id=?", (json.dumps(ii, ensure_ascii=False), float(fee), p["id"]))
        n += 1
    log(h.user["username"], "택배비 일괄 지정", f"{typ} {n}개 {fee}원")
    go(back, f"{typ} 상품 {n}개의 택배비를 {'무료' if fee == 0 else format(fee, ',') + '원'}으로 바꿨습니다. 아직 네이버에 안 올린 상품부터 적용되고, 이미 올린 상품은 스마트스토어에서 바꿔야 합니다.")

@route("POST", "/b2b/review/margin")
def b2b_review_margin(h):
    f = h.form_multi()
    mode = (f.get("mode") or ["won"])[0]; val = num((f.get("val") or [""])[0], float)
    if val is None:
        go(_rv_url(_rv_params(lambda k: (f.get(k) or [""])[0])), "마진 값을 숫자로 넣으세요", True)
    d = _rv_params(lambda k: (f.get(k) or [""])[0]); back = _rv_url(d)
    ids = [int(i) for i in f.get("pid", [])] if (f.get("target") or ["checked"])[0] == "checked" else [p["id"] for p in _rv_filter(_review_rows(), d)]
    if not ids:
        go(back, "상품을 체크하세요(체크 후 다시 누르거나 '목록 전체'를 고르세요)", True)
    for i in ids:
        p = q("SELECT supply_price FROM products WHERE id=? AND status='검토대기'", (i,), one=True)
        if not p:
            continue
        c = float(p["supply_price"] or 0)
        sale = _rnd10(c * (1 + val / 100) if mode == "pct" else c + val)
        x("UPDATE products SET price_override=?, updated=? WHERE id=?", (sale, time.time(), i))
    go(back, f"{len(ids)}개에 마진을 적용했습니다")

@route("POST", "/b2b/review/save")
def b2b_review_save(h):
    f = h.form_multi()
    do = (f.get("do") or ["save"])[0]
    ids = [int(i) for i in f.get("pid", [])]
    for k, v in f.items():
        if k.startswith("price_") and k[6:].isdigit():
            pv = num(v[0], float)
            if pv is not None and pv > 0:
                x("UPDATE products SET price_override=? WHERE id=? AND status='검토대기'", (pv, int(k[6:])))
    pg = (f.get("page") or ["1"])[0]
    d = _rv_params(lambda k: (f.get(k) or [""])[0]); back = _rv_url(d, int(pg) if pg.isdigit() else 1)
    if do == "save":
        go(back, "판매가를 저장했습니다")
    if not ids:
        go(back, "상품을 체크하세요", True)
    if do == "trial":   # 1개만 바로 올려서 결과·에러 문구를 그대로 보여줌
        acc_ids, ch_codes = kind_targets("consign")
        accs = RA([a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (i,), one=True) for i in acc_ids) if a])
        if not accs:
            go(back, "올릴 쇼핑몰(마켓 계정)이 선택돼 있지 않습니다. B2B상품 화면의 「올릴 쇼핑몰」에서 체크하고 저장하세요.", True)
        pid = ids[0]
        try:
            ok, ms, bad = publish([pid], accs, [], h.user["username"])
        except Exception as ex:
            go(back, f"시험 등록 실패: {ex}", True)
        if ok and not bad:
            x("UPDATE products SET status='준비' WHERE id=? AND status='검토대기'", (pid,))
            go(back, f"✅ 시험 등록 성공: {product(pid)['name'][:30]}  (이 상품은 등록됐습니다. 나머지를 체크하고 등록하세요)")
        go(back, "❌ 시험 등록 실패\n" + "\n".join(dict.fromkeys(ms))[:1800], True)
    if do == "delete":
        for i in ids:
            x("DELETE FROM products WHERE id=? AND status='검토대기'", (i,))
        go(back, f"{len(ids)}개를 지웠습니다")
    # 등록
    if CSV_JOB.get("running"):
        go("/b2b/review", "앞 작업이 아직 진행 중입니다. 끝나면 다시 누르세요.", True)
    acc_ids, ch_codes = kind_targets("consign")
    accs = RA([a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (i,), one=True) for i in acc_ids) if a])
    chans = [c for c in (chs.get(k) for k in ch_codes) if c]
    if not accs and not chans:
        go(back, "올릴 쇼핑몰이 선택돼 있지 않습니다. B2B 상품 화면의 「올릴 쇼핑몰」에서 체크하고 저장한 뒤 다시 누르세요.", True)
    for i in ids:
        x("UPDATE products SET status='준비' WHERE id=? AND status='검토대기'", (i,))
    user = h.user["username"]
    threading.Thread(target=csv_job, args=(None, accs, chans, user, f"확인한 상품 {len(ids)}개", lambda: ([], ids)), daemon=True).start()
    time.sleep(0.5)
    go("/b2b", f"{len(ids)}개를 등록하는 중입니다. 진행 상황은 이 화면 위에 나옵니다.")

def _products_xlsx(h, kind, ids=None, kw=""):
    typ = "위탁" if kind == "consign" else "사입"
    if ids:
        rows = [p for p in (q("SELECT * FROM products WHERE id=?", (i,), one=True) for i in ids) if p]
    else:
        rows = q("SELECT * FROM products WHERE COALESCE(supply_type,'사입')=? AND id IN (SELECT product_id FROM listings) AND (name LIKE ? OR theme LIKE ? OR keyword LIKE ?) ORDER BY id", (typ,) + (f"%{kw}%",) * 3)
    lst = {}
    for l in q("SELECT l.product_id, l.market, l.channel, l.market_id, l.price, l.status, a.label FROM listings l LEFT JOIN accounts a ON a.id=l.account_id"):
        lst.setdefault(l["product_id"], []).append(f"{l['market'] or l['channel'] or '?'}{'·' + l['label'] if l['label'] else ''} {l['market_id'] or ''} {l['price'] or ''}원 {l['status'] or ''}".strip())
    data = [["내부번호", "상품번호(공급처)", "상품명", "공급가", "판매가", "마진", "재고", "상태", "올라간 판매처(상품번호·가격)", "공급처 주소"]]
    for p in rows:
        cost = float(p["supply_price"] or p["cost_krw"] or 0); sale = float(p["price_override"] or 0)
        data.append([p["id"], p["supplier_key"] or "", p["name"] or "", cost, sale or "", (sale - cost) if sale else "", p["stock"] if p["stock"] is not None else "",
                     p["supplier_status"] or p["status"] or "", " / ".join(lst.get(p["id"], [])), p["source_url"] or ""])
    log(h.user["username"], "상품 엑셀 받기", f"{typ} {len(rows)}개")
    h.extra_headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(typ + '_상품_' + time.strftime('%Y%m%d_%H%M'))}.xlsx",
                       "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
    return xlsx.write(data)

@route("GET", "/products/export.xlsx")
def products_export_get(h):
    return _products_xlsx(h, "own" if h.qs.get("kind") == "own" else "consign", kw=h.qs.get("q", ""))

@route("POST", "/products/export.xlsx")
def products_export_post(h):
    f = h.form_multi()
    ids = [int(i) for i in f.get("pid", [])]
    if not ids:
        go((f.get("back") or ["/b2b"])[0], "엑셀로 받을 상품을 체크하세요", True)
    return _products_xlsx(h, (f.get("kind") or ["consign"])[0], ids=ids)

@route("POST", "/b2b/targets")
def b2b_targets(h):
    save_targets(h, "consign")

@route("POST", "/own/targets")
def own_targets(h):
    save_targets(h, "own")

# ---------- 상품 ----------
@route("GET", "/products")
def products(h):
    kw = h.qs.get("q", "")
    typ = h.qs.get("type", "")
    rows = q("SELECT * FROM products WHERE (name LIKE ? OR theme LIKE ? OR keyword LIKE ?) AND (?='' OR COALESCE(supply_type,'사입')=?) ORDER BY id DESC LIMIT 500", (f"%{kw}%",) * 3 + (typ, typ))
    accs = RA(q("SELECT * FROM accounts WHERE active=1 ORDER BY market,id"))
    lst = {}
    allch = chs.all_channels()
    chmap = {c["code"]: c for c in chs.all_channels(False)}
    for l in q("SELECT product_id, market, channel, dry FROM listings"):
        mark = "G·A" if l["market"] == "esm" else (short_of(chmap[l["channel"]]) if l["channel"] in chmap else (l["channel"] or l["market"] or "?"))
        lst.setdefault(l["product_id"], set()).add(("🟡" if l["dry"] else "🟢") + mark)
    pol_opts = "".join(f'<option value="{i}">{e(n)}</option>' for i, n in pricing.policies())
    trs = []
    for p in rows:
        im = local_img_urls(p)
        th = f'<img class="thumb" src="{e(im[0])}">' if im else '<div class="thumb"></div>'
        pc = pricing.policy_for(p)
        pr = "<br>".join(f"<span class='mut'>{e(short_of(ch))}</span> {chs.fmt(pricing.price_for(p, ch, pc), ch)}" for ch in allch)
        trs.append(f"<tr><td><input type='checkbox' name='pid' value='{p['id']}'></td><td>{th}</td><td><a href='/products/{p['id']}'><b>{e(p['name'])}</b></a> <span class='tag'>{e(p['supply_type'] or '사입')}</span>{' <span class=tag>' + e(p['status']) + '</span>' if (p['status'] or '').startswith('품절') else ''}<div class='mut'>{e(p['theme'] or '')} · {e(p['set_desc'] or '')}</div></td>"
                   f"<td class='hide-m'>{pr}</td><td>{' '.join(sorted(lst.get(p['id'], [])))}</td><td class='hide-m'>{'✅' if p['detail_html'] else '—'}</td></tr>")
    acc_opts = "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' name='acc' value='{a['id']}' style='width:auto' checked> {e(MARKETS[a['market']].name)} · {e(a['label'])}</label>" for a in accs)
    acc_opts += "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' name='ch' value='{e(c['code'])}' style='width:auto'> {e(c['name'])} <span class='mut'>(엑셀)</span></label>" for c in allch if not c["api"])
    acc_opts = acc_opts or "<span class='mut'>마켓 계정이나 판매처를 먼저 추가하세요</span>"
    body = f"""<h1>상품</h1><div class="row" style="margin-bottom:12px"><form class="row" style="flex:1"><input name="q" value="{e(kw)}" placeholder="상품명·테마 검색" style="max-width:280px"><select name="type" style="max-width:120px"><option value="">사입+위탁</option><option {'selected' if typ == '사입' else ''}>사입</option><option {'selected' if typ == '위탁' else ''}>위탁</option></select><button class="btn gray">검색</button></form>
<a class="btn gray" href="/finder">잘 팔릴 상품 찾기</a><a class="btn gray" href="/suppliers">도매매 위탁상품 가져오기</a>
<a class="btn" href="/products/new">+ 직접 추가</a><a class="btn gray" href="/products/import">엑셀 불러오기</a></div>
<form method="post" action="/bulk" data-busy><div class="card"><div class="row" style="margin-bottom:8px">{acc_opts}</div><div class="row">
<button class="btn" name="do" value="detail" data-autoimg="bulk">선택 상품 상세페이지 자동 제작</button><button class="btn" name="do" value="detail_ai" data-autoimg="bulk">AI 문구로 제작</button><span class="mut" id="autoimg_note">사진도 자동으로 가져와 가공합니다</span>
<button class="btn green" name="do" value="register">선택 판매처에 등록</button><button class="btn red" name="do" value="delete" onclick="return confirm('삭제할까요?')">삭제</button></div>
<div class="row" style="margin-top:10px"><select name="bulk_policy" style="max-width:180px"><option value="">기본 정책</option>{pol_opts}</select><input name="bulk_margin" placeholder="개별 마진(비우면 정책값)" style="max-width:190px">
<button class="btn gray" name="do" value="price">가격 정책·마진 적용</button><button class="btn gray" name="do" value="sync">등록된 마켓 가격 동기화</button>
<button class="btn gray" name="do" value="soldout" onclick="return confirm('재고 0 + 모든 마켓 판매중지할까요?')">품절 처리</button><button class="btn gray" name="do" value="resume">판매 재개</button></div></div>
<div class="card tbl"><table><tr><th><input type="checkbox" data-all="pid" style="width:auto"></th><th></th><th>상품</th><th class="hide-m">판매가(판매처별)</th><th>등록</th><th class="hide-m">상세</th></tr>
{''.join(trs) or '<tr><td colspan=6>상품이 없습니다</td></tr>'}</table></div></form><p class="mut">등록 표시: 🟢 실제 등록(또는 엑셀 내보냄) · 🟡 미리보기 · N 네이버 · C 쿠팡 · G 지마켓 · A 옥션. 해외몰 등 직접 추가한 판매처는 <a href="/channels">판매처</a>에서 엑셀로 받아 각 사이트 대량등록에 올립니다.</p>"""
    return page("상품", body, h.user, "/products", h.flash, h.flash_err)

FIELDS = [("name", "상품명(마켓 노출)"), ("theme", "테마/분류"), ("keyword", "검색 키워드"), ("set_desc", "세트 구성(예: 4개 컬러 세트)"),
          ("set_qty", "세트 수량(개)"), ("cost_cny", "단가(위안)"), ("cost_krw", "단가(원, 입력 시 위안보다 우선)"), ("moq", "MOQ"),
          ("stock", "재고"), ("margin", "개별 마진(비우면 정책값)"), ("price_override", "판매가 직접 지정(비우면 자동)"), ("naver_cat", "네이버 카테고리 ID"),
          ("coupang_cat", "쿠팡 카테고리 코드"), ("esm_cat", "지마켓/옥션 카테고리 코드"), ("source_url", "소싱 링크"), ("source_name", "원문 상품명"),
          ("supplier_key", "위탁: 도매매 상품코드(W...)"), ("supplier_option", "위탁: 도매매 옵션값(/로 구분)"), ("supply_price", "위탁: 공급가(원)"),
          ("supply_ship", "위탁: 공급처 배송비(원)"), ("fixed_price", "위탁: 소비자가 준수가(원, 이 아래로 안 팖)")]
NUM = {"set_qty", "cost_cny", "cost_krw", "stock", "price_override", "margin", "supply_price", "supply_ship", "fixed_price"}

def num(v, typ=float):
    try:
        return typ(str(v).replace(",", "")) if str(v).strip() not in ("", "None") else None
    except ValueError:
        return None

@route("GET", "/products/new")
def product_new(h):
    pid = x("INSERT INTO products(name,set_qty,stock,updated,updated_by) VALUES('새 상품',1,100,?,?)", (time.time(), h.user["username"]))
    go(f"/products/{pid}")

@route("GET", r"/products/(\d+)")
def product_get(h, pid):
    p = product(pid)
    c = pricing.cfg()
    inputs = "".join(f'<div><label>{lab}</label><input name="{k}" value="{e("" if p[k] is None else (f"{p[k]:g}" if isinstance(p[k], float) else str(p[k])))}"></div>' for k, lab in FIELDS if k != "margin")
    themes = "".join(f'<option value="{k}" {"selected" if (p["template"] or "clean") == k else ""}>{v["label"]}</option>' for k, v in detail.THEMES.items())
    pts = p["points"] or ""
    try:
        pts = "\n".join(json.loads(pts))
    except ValueError:
        pass
    c = pricing.policy_for(p)
    pol_opts = '<option value="">기본 정책</option>' + "".join(f'<option value="{i}" {"selected" if p["policy_id"] == i else ""}>{e(n)}</option>' for i, n in pricing.policies())
    unit = "원" if c["margin_mode"] == "won" else "%"
    pcm, pcs = pricing.pj(p, "ch_margin"), pricing.pj(p, "ch_ship")
    fv = lambda d, k: "" if d.get(k) in (None, "") else f"{d[k]:g}"
    bd = "".join(f"<tr><td>{e(ch['name'])}<div class='mut'>수수료 {ch['fee']:g}%</div></td>"
                 f"<td><input name='pm_{ch['code']}' value='{fv(pcm, ch['code'])}' placeholder='{b['target']:g}' style='width:90px'><div class='mut'>지금 {b['target']:g}{unit} ({b['source']})</div></td>"
                 f"<td><input name='ps_{ch['code']}' value='{fv(pcs, ch['code'])}' placeholder='{b['ship']:,}' style='width:90px'><div class='mut'>지금 {b['ship']:,}원</div></td>"
                 f"<td><b>{b['price_text']}</b>{'' if ch['currency'] == 'KRW' else '<div class=mut>≈' + format(b['price_krw'], ',') + '원</div>'}</td><td>{b['total_cost']:,}</td><td>{b['fee']:,}</td><td>{b['profit']:,}</td><td>{b['margin_on_cost']}%</td><td>{b['margin_on_price']}%</td></tr>"
                 for ch in chs.all_channels() for b in [pricing.breakdown(p, ch, c)])
    imgs = "".join(f'<div style="text-align:center"><img src="{e(u)}"><br><button class="btn sm red" name="del_img" value="{i}">삭제</button></div>' for i, u in enumerate(local_img_urls(p)))
    lst = "".join(f"<tr><td>{e(where_label(l['market'], l['channel']))}</td><td>{e(l['label'] or '엑셀')}</td><td>{e(l['market_id'] or '')}</td><td>{'미리보기' if l['dry'] else '실제'}</td><td>{e(l['status'] or '')}</td></tr>"
                  for l in q("SELECT l.*, a.label FROM listings l LEFT JOIN accounts a ON a.id=l.account_id WHERE product_id=?", (pid,)))
    st = p["supply_type"] or "사입"
    stsel = f"""<div><label>판매 방식</label><select name="supply_type"><option value="사입">사입(우리가 재고 보유·직접 발송)</option><option value="위탁" {'selected' if st == '위탁' else ''}>위탁(도매매이 발송)</option></select></div>"""
    ocinfo = (f"<p class='mut'>위탁 상품: 도매매 {e(p['supplier_key'] or '')} · 상태 {e(p['supplier_status'] or '확인 전')} · 마지막 확인 {time.strftime('%m-%d %H:%M', time.localtime(p['supplier_checked'])) if p['supplier_checked'] else '없음'} · "
              f"총원가 = 공급가 × 세트수량 + 공급처 배송비(사입 부대비용·포장비 없음)</p>") if st == "위탁" else ""
    body = f"""<h1>{e(p['name'])} <span class="tag">{e(st)}</span></h1><form method="post" enctype="multipart/form-data" data-busy>
<div class="card"><h2>기본 정보</h2>{ocinfo}<div class="grid">{stsel}{inputs}</div>
<label>셀링 포인트(한 줄에 하나, 비우면 자동)</label><textarea name="points">{e(pts)}</textarea>
<label>주의사항(한 줄에 하나, 비우면 기본 문구)</label><textarea name="cautions">{e(p['cautions'] or '')}</textarea>
<label>메모(AI 문구 참고용)</label><textarea name="memo" style="min-height:60px">{e(p['memo'] or '')}</textarea>
<br><button class="btn" name="do" value="save">저장</button></div>
<div class="card"><h2>사진</h2><div class="imgs">{imgs or '<span class="mut">사진이 없습니다. 첫 번째 사진이 대표 이미지가 됩니다.</span>'}</div>
<label>사진 추가(여러 장 선택 가능)</label><input type="file" name="images" multiple accept="image/*"><label>또는 이미지 주소(한 줄에 하나)</label><textarea name="img_urls" style="min-height:50px"></textarea>
<br><button class="btn" name="do" value="save">사진 올리기</button></div>
<div class="card"><h2>판매가 계산</h2><div class="row"><div style="flex:1;min-width:200px"><label>가격 정책</label><select name="policy_id">{pol_opts}</select></div>
<div style="flex:1;min-width:200px"><label>이 상품만 마진 ({pricing.MODE_LABEL[c['margin_mode']]}, 비우면 정책값)</label><input name="margin" value="{'' if p['margin'] is None else f"{p['margin']:g}"}"></div>
<div style="flex:1;min-width:200px"><label>이 상품 배송비(원, 모든 판매처, 비우면 기본)</label><input name="ship" value="{'' if p['ship'] is None else f"{p['ship']:g}"}"></div>
<div style="align-self:flex-end"><button class="btn" name="do" value="save">적용</button></div></div><br><div class="tbl"><table>
<tr><th>판매처</th><th>이 상품 마진({'원' if c['margin_mode'] == 'won' else '%'})</th><th>이 상품 배송비(원)</th><th>판매가</th><th>총원가(원)</th><th>수수료(원)</th><th>이익(원)</th><th>원가 대비</th><th>판매가 대비</th></tr>{bd}</table></div>
<p class="mut">판매처마다 마진·배송비를 넣고 <b>적용</b>을 누르면 판매가가 다시 계산됩니다. 빈 칸은 위의 '이 상품만 마진' → 가격 정책 → 판매처 기본값 순서로 채워집니다. 이미 올린 마켓에 반영하려면 상품 목록에서 '등록된 마켓 가격 동기화'를 누르세요.</p>
<p class="mut">정책: {e(c['name'])} · 총원가 = 단가×{c['landed_mult']}(사입 부대비용) × 세트수량 + 포장 {c['pack_cost']:,} + 택배. 정책은 <a href="/policies">가격 정책</a>, 수수료·통화·환율은 <a href="/channels">판매처</a>에서 바꿉니다. 마켓 등록명 미리보기: {e(naming.process(p['name'], 'naver'))}</p></div>
<div class="card"><h2>상세페이지</h2><div class="row"><select name="template" style="max-width:200px">{themes}</select>
<button class="btn" name="do" value="detail" data-autoimg="{pid}">자동 제작</button><button class="btn" name="do" value="detail_ai" data-autoimg="{pid}">AI 문구로 제작</button>
<a class="btn gray" href="/products/{pid}/preview" target="_blank">새 창으로 보기</a><a class="btn gray" href="/products/{pid}/download">HTML 저장</a></div>
<label style="display:flex;gap:6px;align-items:center;margin-top:10px"><input type="checkbox" id="autoimg" checked style="width:auto">사진 자동으로 가져와서 가공하기(흰 배경 정사각형 대표 사진·여백 자르기·밝기 보정)</label>
<p class="mut" id="autoimg_note">사진이 없으면 이미지 주소 → 도매매 상품 사진 → 소싱 링크 페이지 순서로 찾아옵니다. 이미 가공한 사진은 다시 가공하지 않습니다.</p>
{f'<iframe src="/products/{pid}/preview"></iframe>' if p['detail_html'] else '<p class="mut">아직 만들지 않았습니다.</p>'}</div></form>
<div class="card"><h2>마켓 등록 기록</h2><div class="tbl"><table><tr><th>마켓</th><th>계정</th><th>마켓 상품번호</th><th>구분</th><th>상태</th></tr>{lst or '<tr><td colspan=5>없음</td></tr>'}</table></div></div>"""
    return page(p["name"], body, h.user, "/products", h.flash, h.flash_err)

def save_images(h, p, files, urls):
    imgs = img_list(p)
    for fn, data in files:
        if not data:
            continue
        ext = os.path.splitext(fn)[1].lower() or ".jpg"
        if ext not in (".jpg", ".jpeg", ".png", ".gif", ".webp"):
            continue
        name = f"p{p['id']}_{uuid.uuid4().hex[:8]}{ext}"
        with open(os.path.join(IMAGES, name), "wb") as f:
            f.write(data)
        imgs.append(name)
    imgs += [u.strip() for u in urls.splitlines() if u.strip().startswith("http")]
    return imgs

@route("POST", r"/products/(\d+)")
def product_post(h, pid):
    p = product(pid)
    f, files = h.multipart()
    vals = {}
    for k, _ in FIELDS:
        v = f.get(k, "")
        vals[k] = (num(v, int if k in ("set_qty", "stock", "price_override") else float) if k in NUM else v.strip())
    pts = [x_.strip() for x_ in f.get("points", "").splitlines() if x_.strip()]
    imgs = save_images(h, p, files.get("images", []), f.get("img_urls", ""))
    if "del_img" in f:
        i = int(f["del_img"])
        if 0 <= i < len(imgs):
            imgs.pop(i)
    vals["policy_id"] = num(f.get("policy_id"), int)
    vals["supply_type"] = "위탁" if f.get("supply_type") == "위탁" else "사입"
    vals["ship"] = num(f.get("ship"), float)
    allc = chs.all_channels(False)
    old_m, old_s = pricing.pj(p, "ch_margin"), pricing.pj(p, "ch_ship")
    for ch in allc:   # 화면에 없는(꺼진) 판매처 값은 그대로 둠
        if "pm_" + ch["code"] in f:
            old_m[ch["code"]] = num(f.get("pm_" + ch["code"]), float)
            old_s[ch["code"]] = num(f.get("ps_" + ch["code"]), float)
    vals["ch_margin"] = json.dumps({k: v for k, v in old_m.items() if v is not None})
    vals["ch_ship"] = json.dumps({k: v for k, v in old_s.items() if v is not None})
    sets = ", ".join(f"{k}=?" for k in vals)
    x(f"UPDATE products SET {sets}, points=?, cautions=?, memo=?, images=?, template=?, updated=?, updated_by=? WHERE id=?",
      (*vals.values(), json.dumps(pts, ensure_ascii=False) if pts else "", f.get("cautions", ""), f.get("memo", ""),
       json.dumps(imgs, ensure_ascii=False), f.get("template", "clean"), time.time(), h.user["username"], pid))
    do = f.get("do", "save")
    am = auto_stock(int(pid), h.user["username"])
    if do in ("detail", "detail_ai"):
        p = product(pid)
        try:
            copy, htm = make_detail(p, do == "detail_ai")
        except Exception as ex:
            go(f"/products/{pid}", f"AI 문구 생성 실패: {ex}", True)
        x("UPDATE products SET detail_html=?, points=CASE WHEN points='' OR points IS NULL THEN ? ELSE points END WHERE id=?",
          (htm, json.dumps(copy["points"], ensure_ascii=False), pid))
        log(h.user["username"], "상세페이지 제작", p["name"])
        go(f"/products/{pid}", "상세페이지를 만들었습니다")
    go(f"/products/{pid}", "저장했습니다" + ("\n" + am if am else ""))

def oc_item_for(p):
    if (p["supply_type"] or "") != "위탁" or not p["supplier_key"]:
        return None
    try:
        oc = ocmod.OwnerClan()
        return None if oc.dry else oc.item(p["supplier_key"])
    except Exception:
        return None

def gather_images(p, user):
    """사진 자동 수집 후 저장. 안내 문구 목록을 돌려줌"""
    imgs, notes = imgmod.collect(p, oc_item_for(p))
    x("UPDATE products SET images=? WHERE id=?", (json.dumps(imgs, ensure_ascii=False), p["id"]))
    log(user, "사진 자동 수집", f"{p['name']} {len(imgs)}장 " + "; ".join(notes)[:300])
    return imgs, notes

@route("POST", r"/products/(\d+)/fetch_images")
def product_fetch_images(h, pid):
    p = product(pid)
    imgs, notes = gather_images(p, h.user["username"])
    h.extra_headers = {"Content-Type": "application/json; charset=utf-8"}
    return json.dumps({"imgs": [{"i": i, "url": u if u.startswith("http") else "/img/" + quote(u), "done": u.startswith("http") or os.path.basename(u).startswith("px")}
                                for i, u in enumerate(imgs)], "notes": notes}, ensure_ascii=False)

@route("POST", r"/products/(\d+)/processed")
def product_processed(h, pid):
    """브라우저에서 가공한 사진으로 바꿔 끼움(원본 파일은 남겨 둠)"""
    p = product(pid)
    _, files = h.multipart()
    imgs = img_list(p)
    n = 0
    for k, lst in files.items():
        m = re.match(r"f(\d+)$", k or "")
        if not m or not lst or not lst[0][1]:
            continue
        i = int(m.group(1))
        data = lst[0][1]
        if i >= len(imgs) or data[:2] != b"\xff\xd8":
            continue
        name = f"px_p{p['id']}_{uuid.uuid4().hex[:8]}.jpg"
        with open(os.path.join(IMAGES, name), "wb") as f:
            f.write(data)
        imgs[i] = name
        n += 1
    x("UPDATE products SET images=? WHERE id=?", (json.dumps(imgs, ensure_ascii=False), p["id"]))
    h.extra_headers = {"Content-Type": "application/json"}
    return json.dumps({"ok": n})

@route("GET", r"/products/(\d+)/preview")
def product_preview(h, pid):
    p = product(pid)
    return f'<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;background:#eee">{p["detail_html"] or "아직 없음"}</body></html>'

@route("GET", r"/products/(\d+)/download")
def product_download(h, pid):
    p = product(pid)
    h.extra_headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(p['name'][:40])}.html"}
    return f'<!doctype html><html><head><meta charset="utf-8"></head><body>{p["detail_html"] or ""}</body></html>'

# ---------- 엑셀 불러오기 ----------
COLMAP = {"name": ["한국어 상품명", "상품명", "name"], "theme": ["테마", "분류", "카테고리"], "keyword": ["아이템스카우트 검색어", "검색어", "키워드"],
          "source_name": ["원문 상품명(이우고)", "원문 상품명", "영문상품명"], "cost_cny": ["최저가(위안)", "단가(위안)"], "cost_krw": ["최저가(원)", "단가(원)"],
          "moq": ["MOQ"], "set_desc": ["세트 구성 예시", "세트 구성"], "source_url": ["상품 링크", "링크", "소싱 링크"],
          "set_qty": ["세트 수량"], "stock": ["재고"], "naver_cat": ["네이버 카테고리"], "coupang_cat": ["쿠팡 카테고리"], "esm_cat": ["지마켓 카테고리"]}

@route("GET", "/products/import")
def import_get(h):
    body = """<h1>엑셀 불러오기</h1><div class="card"><form method="post" enctype="multipart/form-data" data-busy>
<label>파일(.xlsx 또는 .csv)</label><input type="file" name="file" accept=".xlsx,.csv" required>
<label>시트 이름(비우면 '추천 상품' → 첫 시트 순서로 찾음)</label><input name="sheet" placeholder="추천 상품">
<label>최대 불러올 개수</label><input name="limit" value="200"><br><br><button class="btn">불러오기</button></form></div>
<div class="card"><h2>알아보는 열 이름</h2><p class="mut">한국어 상품명(또는 상품명) · 테마 · 아이템스카우트 검색어 · 원문 상품명 · 최저가(위안) · 최저가(원) · MOQ · 세트 구성 예시 · 세트 수량 · 재고 · 상품 링크 · 네이버 카테고리 · 쿠팡 카테고리 · 지마켓 카테고리.<br>
한국_판매추천_소비자검토_2026-11.xlsx 를 그대로 넣으면 됩니다. '4개 컬러 세트'처럼 구성에 숫자가 있으면 세트 수량을 자동으로 잡습니다.</p>
<a class="btn gray" href="/products/template.csv">빈 양식 받기(CSV)</a></div>"""
    return page("엑셀 불러오기", body, h.user, "/products", h.flash, h.flash_err)

@route("GET", "/products/template.csv")
def template_csv(h):
    h.extra_headers = {"Content-Disposition": "attachment; filename=product_template.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿상품명,테마,검색어,세트 구성,세트 수량,단가(위안),단가(원),MOQ,재고,상품 링크,네이버 카테고리,쿠팡 카테고리,지마켓 카테고리\n털 집게핀 4개 세트,헤어,털 집게핀,4개 컬러 세트,4,0.8,,3,100,https://...,,,\n"

@route("POST", "/products/import")
def import_post(h):
    f, files = h.multipart()
    own = f.get("kind") == "own"
    back_err = "/own" if own else "/products/import"
    fn, data = (files.get("file") or [("", b"")])[0]
    if not data:
        go(back_err, "파일을 골라 주세요", True)
    if fn.lower().endswith(".csv"):
        rows = list(csv.reader(io.StringIO(data.decode("utf-8-sig", "replace"))))
    else:
        sheets = xlsx.read(io.BytesIO(data))
        want = f.get("sheet", "").strip()
        name = want if want in sheets else ("추천 상품" if "추천 상품" in sheets else next(iter(sheets)))
        rows = sheets[name]
    hdr_i = next((i for i, r in enumerate(rows[:10]) if any(str(c or "").strip() in sum(COLMAP.values(), []) for c in r)), None)
    if hdr_i is None:
        go(back_err, "열 이름(상품명 등)을 찾지 못했습니다", True)
    hdr = [str(c or "").strip() for c in rows[hdr_i]]
    idx = {k: next((hdr.index(n) for n in names if n in hdr), None) for k, names in COLMAP.items()}
    if idx["name"] is None:
        go(back_err, "상품명 열이 없습니다", True)
    limit = num(f.get("limit"), int) or 200
    n = 0
    for r in rows[hdr_i + 1:]:
        get = lambda k: (r[idx[k]] if idx[k] is not None and idx[k] < len(r) else None)
        name = str(get("name") or "").strip()
        if not name:
            continue
        set_desc = str(get("set_desc") or "")
        sq = num(get("set_qty"), int) or (int(m.group(1)) if (m := re.search(r"(\d+)\s*(개|장|pcs|입)", set_desc)) else 1)
        cny, krw = num(get("cost_cny")), num(get("cost_krw"))
        x("""INSERT INTO products(name,theme,keyword,source_name,source_url,cost_cny,cost_krw,set_qty,set_desc,moq,stock,naver_cat,coupang_cat,esm_cat,updated,updated_by,supply_type)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'사입')""",
          (name, get("theme"), get("keyword"), get("source_name"), get("source_url"), cny, None if cny else krw, sq, set_desc,
           str(get("moq") or ""), num(get("stock"), int) or 100, str(get("naver_cat") or ""), str(get("coupang_cat") or ""), str(get("esm_cat") or ""),
           time.time(), h.user["username"]))
        n += 1
        if n >= limit:
            break
    log(h.user["username"], "엑셀 불러오기", f"{fn} {n}개")
    go("/own" if own else "/products", f"{n}개 상품을 불러왔습니다")

# ---------- 일괄 작업 / 등록 ----------
def register_one(p, acc, user):
    _o = overseas_hit(p)
    if _o:
        raise MarketError(f"해외배송 상품이라 등록하지 않았습니다(「{_o}」 표시). 국내배송만 올립니다.")
    m = market_for(acc)
    p = naming.fill_categories(p)
    if acc["market"] == "naver" and not p.get("naver_cat"):
        try:
            p["naver_cat"] = m.auto_category(f"{p.get('name') or ''} {p.get('keyword') or ''} {p.get('theme') or ''}")   # 비어 있으면 상품명으로 네이버 카테고리를 자동으로 찾음
        except Exception as ex:
            log(user, "네이버 카테고리 자동 찾기 실패", str(ex)[:200])
    p["name"] = naming.process(p["name"], acc["market"])
    price = acc_price(p, acc["market"])
    imgs = img_list(p)
    local = [os.path.join(IMAGES, i) for i in imgs if not i.startswith("http")]
    remote = [i for i in imgs if i.startswith("http")]
    urls = remote
    if local:
        up = m.upload_images(local) if acc["market"] == "naver" else []
        if not up and not m.dry:
            # 쿠팡·ESM은 공개 이미지 주소가 필요 → 같은 상품의 네이버 업로드 주소를 재사용
            nv = q("SELECT a.* FROM accounts a WHERE a.market='naver' AND a.active=1 LIMIT 1", one=True)
            if nv:
                up = market_for(nv).upload_images(local)
        urls = (up or []) + remote
    if m.dry and not urls:
        urls = ["/img/" + i for i in imgs]
    imported = (p.get("template") == "imported") and bool(p.get("detail_html"))   # 엑셀 양식으로 올린 상품: 상세·배송비를 파일 그대로
    if imported:
        htm = p["detail_html"]
    else:
        _, htm = make_detail(p, False, urls) if not p.get("detail_html") or local else (None, p["detail_html"])
    pc_ = pricing.policy_for(p)
    chx = chs.get("gmarket" if acc["market"] == "esm" else acc["market"])
    m.extra = dict(m.extra or {})
    if imported:
        try:
            _ii = json.loads(p.get("import_json") or "{}")
        except ValueError:
            _ii = {}
        m.extra["delivery_fee"] = 0 if _ii.get("fee_type") == "무료" else int(_ii.get("base_fee") or 0)
    else:
        m.extra["delivery_fee"] = int(pricing.ship_of(chx, pc_, p)) if pc_.get("ship_mode") == "separate" else 0   # 택배비 포함이면 무료배송
    payload = m.build_product(p, price, htm, urls)
    r = m.register(payload)
    x("INSERT INTO listings(product_id,account_id,market,channel,market_id,sub_id,price,stock,status,last_result,dry,updated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
      (p["id"], acc["id"], acc["market"], "gmarket" if acc["market"] == "esm" else acc["market"], r.get("market_id"), r.get("sub_id"), price_num(price), p["stock"], "미리보기" if r.get("dry") else "등록요청",
       json.dumps(r.get("raw") or r.get("file"), ensure_ascii=False)[:4000], 1 if r.get("dry") else 0, time.time()))
    x("UPDATE products SET status='등록', naver_cat=?, coupang_cat=?, esm_cat=? WHERE id=?", (p["naver_cat"], p["coupang_cat"], p["esm_cat"], p["id"]))
    log(user, ("미리보기 " if r.get("dry") else "") + "마켓 등록", f"{MARKETS[acc['market']].name} {p['name']} {price_txt(price)}")
    return r

def register_channel(p, ch, user):
    """API가 없는 판매처(해외몰 등): 등록 목록에 올려 두고 판매처 화면에서 엑셀로 받음"""
    price = pricing.price_for(p, ch)
    old = q("SELECT id FROM listings WHERE product_id=? AND channel=? AND account_id IS NULL", (p["id"], ch["code"]), one=True)
    if old:
        x("UPDATE listings SET price=?, stock=?, status='엑셀 대기', updated=? WHERE id=?", (price, p["stock"], time.time(), old["id"]))
    else:
        x("INSERT INTO listings(product_id,account_id,market,channel,price,stock,status,dry,updated) VALUES(?,?,?,?,?,?,?,?,?)",
          (p["id"], None, "", ch["code"], price, p["stock"], "엑셀 대기", 0, time.time()))
    x("UPDATE products SET status='등록' WHERE id=?", (p["id"],))
    log(user, "판매처 등록(엑셀)", f"{ch['name']} {p['name']} {chs.fmt(price, ch)}")
    return price

AUTO_OUT = "품절(재고없음)"

def auto_stock(pid, user="자동"):
    """재고가 0 이하가 되면 등록된 모든 판매처 자동 품절, 재고를 다시 넣으면 자동 판매 재개. (설정에서 끌 수 있음)"""
    if not get_setting("auto_soldout_stock", True):
        return ""
    p = q("SELECT * FROM products WHERE id=?", (pid,), one=True)
    if not p:
        return ""
    has = q("SELECT 1 FROM listings WHERE product_id=? LIMIT 1", (pid,), one=True)
    st = p["status"] or ""
    if (p["stock"] or 0) <= 0 and not st.startswith("품절"):
        if not has:
            x("UPDATE products SET status=? WHERE id=?", (AUTO_OUT, pid))
            return "재고 0 → 품절"
        n, ms = push_listings(pid, "soldout", AUTO_OUT)
        notify.send("재고 0 → 자동 품절", f"{p['name']} ({n}곳 판매중지)", "soldout")
        log(user, "재고 0 → 자동 품절", f"{p['name']} {n}곳" + ("; " + "; ".join(ms)[:300] if ms else ""))
        return f"재고가 0이라 {n}곳 판매처를 품절 처리했습니다" + ("\n" + "\n".join(ms) if ms else "")
    if (p["stock"] or 0) > 0 and st == AUTO_OUT:
        x("UPDATE products SET status=? WHERE id=?", ("등록" if has else "준비", pid))
        if not has:
            return ""
        n, ms = push_listings(pid, "resume")
        push_listings(pid, "sync")
        log(user, "재고 입고 → 자동 판매 재개", f"{p['name']} {n}곳")
        return f"재고가 들어와 {n}곳 판매처 판매를 다시 열었습니다" + ("\n" + "\n".join(ms) if ms else "")
    return ""

def stock_sweep():
    """재고 0인데 아직 판매 중인 상품을 찾아 품절 처리(엑셀로 재고를 바꾼 경우 등)"""
    for r in q("SELECT id FROM products WHERE COALESCE(stock,0)<=0 AND COALESCE(status,'') NOT LIKE '품절%' AND id IN (SELECT product_id FROM listings)"):
        try:
            auto_stock(r["id"])
        except Exception:
            traceback.print_exc()

def push_listings(pid, do, status_label="품절"):
    """등록된 모든 판매처에 가격 동기화(sync)·품절(soldout)·재개(resume) 반영. (반영 건수, 오류 목록)"""
    p = product(pid)
    n, msgs = 0, []
    if do == "soldout":
        x("UPDATE products SET stock=0, status=? WHERE id=?", (status_label, pid))
    for l in q("SELECT * FROM listings WHERE product_id=?", (pid,)):
        if not l["account_id"]:   # 엑셀 판매처: 기록만 바꾸고 다음 엑셀에 반영
            ch = chs.get(l["channel"])
            if not ch:
                continue
            if do == "sync":
                x("UPDATE listings SET price=?, stock=?, status='엑셀 대기', updated=? WHERE id=?", (pricing.price_for(p, ch), p["stock"], time.time(), l["id"]))
            else:
                x("UPDATE listings SET stock=?, status=?, updated=? WHERE id=?", (0 if do == "soldout" else p["stock"], "품절" if do == "soldout" else "엑셀 대기", time.time(), l["id"]))
            n += 1
            continue
        acc = q("SELECT * FROM accounts WHERE id=?", (l["account_id"],), one=True)
        if not acc:
            continue
        try:
            m = market_for(acc, force_dry=bool(l["dry"]))
        except Exception as ex:
            msgs.append(f"[실패] {MARKETS[acc['market']].name} {acc['label']}: {ex}")
            continue
        try:
            if do == "sync":
                price = acc_price(p, l["market"])
                m.update_price_stock(l, price, int(p["stock"] or 0))
                x("UPDATE listings SET price=?, stock=?, updated=? WHERE id=?", (price_num(price), p["stock"], time.time(), l["id"]))
            else:
                m.set_sale(l, do == "resume")
                x("UPDATE listings SET status=?, updated=? WHERE id=?", ("판매중" if do == "resume" else "품절", time.time(), l["id"]))
            n += 1
        except Exception as ex:
            msgs.append(f"{where_label(l['market'], l['channel'])} · {p['name']}: {ex}")
    return n, msgs

def publish(pids, accs, chans, user):
    """상품들을 마켓 계정(API)·엑셀 판매처에 등록. 상세페이지 없으면 먼저 만듦. (건수, 메시지, 실패 여부)"""
    ok, msgs, bad = 0, [], False
    for pid in pids:
        p = product(pid)
        if not p["detail_html"]:
            if not img_list(p):
                gather_images(p, user); p = product(pid)
            _, htm = make_detail(p)
            x("UPDATE products SET detail_html=? WHERE id=?", (htm, pid))
            p = product(pid)
        for a in accs:
            try:
                r = register_one(p, a, user)
                ok += 1
                if r.get("dry"):
                    msgs.append(f"[미리보기] {MARKETS[a['market']].name} · {p['name']} → {os.path.basename(r['file'])}")
            except (MarketError, Exception) as ex:
                bad = True
                msgs.append(f"[실패] {MARKETS[a['market']].name} · {p['name']}: {ex}")
                log(user, "등록 실패", f"{MARKETS[a['market']].name} {p['name']}: {ex}")
        for ch in chans:
            register_channel(p, ch, user)
            ok += 1
    if chans:
        msgs.append("엑셀 판매처(" + ", ".join(c["name"] for c in chans) + ")는 판매처 화면에서 엑셀을 받아 각 사이트에 올리세요.")
    return ok, msgs, bad

NAVER_PURGE = {"running": False}

def naver_purge_job(pids, user):
    """상품을 프로그램에서 지울 때 네이버 스마트스토어 상품도 같이 삭제(되돌릴 수 없음). 네이버 삭제가 실패한 상품은 프로그램에 남겨 둠"""
    J = NAVER_PURGE
    J.update({"running": True, "total": len(pids), "done": 0, "naver": 0, "fail": 0, "errors": [], "start": time.time()})
    markets = {}
    for pid in pids:
        p = q("SELECT id, name FROM products WHERE id=?", (pid,), one=True)
        if not p:
            J["done"] += 1
            continue
        ok = True
        for l in q("SELECT * FROM listings WHERE product_id=? AND market='naver' AND dry=0 AND COALESCE(market_id,'')<>''", (pid,)):
            try:
                a = q("SELECT * FROM accounts WHERE id=?", (l["account_id"],), one=True)
                if a is None:
                    raise MarketError("마켓 계정을 찾을 수 없습니다")
                m = markets.get(a["id"]) or markets.setdefault(a["id"], store_market(a))
                try:
                    m.delete_store({"origin": l["market_id"]})
                except MarketError as ex:
                    if "404" not in str(ex) and "찾을 수 없" not in str(ex) and "NotFound" not in str(ex):   # 이미 스토어에 없으면 성공으로 봄
                        raise
                x("DELETE FROM listings WHERE id=?", (l["id"],))
                J["naver"] += 1
            except Exception as ex:
                ok = False
                J["fail"] += 1
                J["errors"].append(f"{p['name'][:30]}: {str(ex)[:150]}")
            time.sleep(0.4)
        if ok:
            x("DELETE FROM listings WHERE product_id=?", (pid,))
            x("DELETE FROM products WHERE id=?", (pid,))
        J["done"] += 1
    J["running"] = False
    log(user, "상품 삭제(네이버 포함)", f"{len(pids)}개 중 네이버 {J['naver']}개 삭제, 실패 {J['fail']}개")
    notify.send("상품 삭제 끝", f"네이버 {J['naver']}개 삭제, 실패 {J['fail']}개", "upload")

def start_purge(pids, user, back, what):
    if NAVER_PURGE.get("running"):
        go(back, "앞의 삭제 작업이 아직 진행 중입니다. 끝나면 다시 누르세요.", True)
    n_live = q("SELECT COUNT(DISTINCT product_id) FROM listings WHERE market='naver' AND dry=0 AND COALESCE(market_id,'')<>'' AND product_id IN (%s)" % ",".join(str(int(i)) for i in pids), one=True)[0] if pids else 0
    threading.Thread(target=naver_purge_job, args=(list(pids), user), daemon=True).start()
    go(back, f"{what} {len(pids)}개 삭제를 시작했습니다(네이버 스마트스토어에 올라간 상품 {n_live}개는 스토어에서도 지웁니다). 아래 진행 상황을 확인하세요.")

@route("POST", "/bulk")
def bulk(h):
    f = h.form_multi()
    back = (f.get("back") or ["/products"])[0]
    back = back if back in ("/b2b", "/own") else "/products"
    pids = [int(i) for i in f.get("pid", [])]
    do = (f.get("do") or ["detail"])[0]
    if do == "del_not_naver":
        # 이 목록(사입/위탁)에서 네이버에 실제 등록된 기록이 없는 상품만 프로그램에서 지웁니다(스마트스토어 상품은 건드리지 않음)
        typ = "위탁" if back == "/b2b" else "사입"
        ids = [r[0] for r in q("SELECT id FROM products WHERE COALESCE(supply_type,'사입')=? AND NOT EXISTS (SELECT 1 FROM listings l WHERE l.product_id=products.id AND l.market='naver' AND l.dry=0 AND COALESCE(l.market_id,'')<>'')", (typ,))]
        for pid in ids:
            x("DELETE FROM products WHERE id=?", (pid,))
        log(h.user["username"], "네이버 미등록 상품 삭제", f"{typ} {len(ids)}개")
        go(back, f"네이버에 등록되지 않은 {typ} 상품 {len(ids)}개를 지웠습니다. 네이버에 올라간 상품은 그대로입니다.")
    if do == "del_overseas":
        # 해외배송으로 보는 상품을 한 번에 지움. 네이버에 올라간 상품은 스마트스토어에서도 삭제(되돌릴 수 없음)
        typ = "위탁" if back == "/b2b" else "사입"
        ids = [p["id"] for p in q("SELECT * FROM products WHERE COALESCE(supply_type,'사입')=?", (typ,)) if overseas_hit(p)]
        if not ids:
            go(back, "지울 해외배송 상품이 없습니다")
        start_purge(ids, h.user["username"], back, "해외배송 상품")
    if not pids:
        go(back, "상품을 하나 이상 고르세요", True)
    msgs, bad = [], False
    if do == "delete":
        start_purge(pids, h.user["username"], back, "선택한 상품")
    if do == "ship_text":
        from .detail import scrub_ship
        n = 0
        for pid in pids:
            r = q("SELECT detail_html FROM products WHERE id=?", (pid,), one=True)
            if r and r[0]:
                new = scrub_ship(r[0])
                if new != r[0]:
                    x("UPDATE products SET detail_html=? WHERE id=?", (new, pid)); n += 1
        go(back, f"{len(pids)}개 중 {n}개의 상세페이지 당일발송 문구를 「{'2~3일 내 도착'}」으로 바꿨습니다. 이미 올린 상품은 마켓에 다시 올려야 반영됩니다.")
    if do == "margin":
        mv = num((f.get("mval") or [""])[0], float)
        if mv is None:
            go(back, "마진 값을 숫자로 넣으세요(예: 300)", True)
        for pid in pids:
            p = q("SELECT supply_price, cost_krw FROM products WHERE id=?", (pid,), one=True)
            c = float((p["supply_price"] or p["cost_krw"] or 0) if p else 0)
            sale = _rnd10(c * (1 + mv / 100) if (f.get("mmode") or ["won"])[0] == "pct" else c + mv)
            x("UPDATE products SET price_override=?, updated=?, updated_by=? WHERE id=?", (sale, time.time(), h.user["username"], pid))
        go(back, f"{len(pids)}개에 마진을 적용했습니다. 판매가 칸을 확인하고 「등록」을 누르세요.")
    if do == "price":
        pol = num((f.get("bulk_policy") or [""])[0], int)
        mg = num((f.get("bulk_margin") or [""])[0], float)
        for pid in pids:
            x("UPDATE products SET policy_id=?, margin=?, updated=?, updated_by=? WHERE id=?", (pol, mg, time.time(), h.user["username"], pid))
        log(h.user["username"], "가격 정책 일괄 적용", f"{len(pids)}개 정책={pol} 마진={mg}")
        go(back, f"{len(pids)}개 상품에 가격 정책을 적용했습니다. 마켓에 반영하려면 '등록된 마켓 가격 동기화'를 누르세요.")
    if do in ("sync", "soldout", "resume"):
        n = 0
        for pid in pids:
            k, ms = push_listings(pid, do)
            n += k; msgs += ms; bad = bad or bool(ms)
        log(h.user["username"], {"sync": "가격 동기화", "soldout": "품절 처리", "resume": "판매 재개"}[do], f"{n}건")
        go(back, f"{n}건 마켓에 반영했습니다\n" + "\n".join(msgs[:30]), bad)
    if do in ("detail", "detail_ai"):
        for pid in pids:
            p = product(pid)
            try:
                if not img_list(p):
                    gather_images(p, h.user["username"]); p = product(pid)
                copy, htm = make_detail(p, do == "detail_ai")
                x("UPDATE products SET detail_html=? WHERE id=?", (htm, pid))
            except Exception as ex:
                bad = True; msgs.append(f"{p['name']}: {ex}")
        log(h.user["username"], "상세페이지 일괄 제작", f"{len(pids)}개")
        go(back, f"{len(pids)}개 상세페이지를 만들었습니다\n" + "\n".join(msgs), bad)
    accs = [q("SELECT * FROM accounts WHERE id=?", (int(a),), one=True) for a in f.get("acc", [])]
    accs = [a for a in accs if a]
    chans = [c for c in (chs.get(k) for k in f.get("ch", [])) if c]
    if not accs and not chans:
        go(back, "등록할 마켓 계정이나 판매처를 고르세요", True)
    ok, ms, b2 = publish(pids, accs, chans, h.user["username"])
    msgs += ms; bad = bad or b2
    if (f.get("from") or [""])[0] == "finder":   # 상품 찾기에서 올렸으면 결과 확인 화면으로
        go("/finder/published?pids=" + ",".join(str(i) for i in pids), f"{ok}건 처리했습니다\n" + "\n".join(msgs[:30]), bad)
    go(back, f"{ok}건 처리했습니다\n" + "\n".join(msgs[:30]), bad)

# ---------- 등록 현황 ----------
@route("GET", "/listings")
def listings(h):
    rows = q("""SELECT l.*, p.name, a.label FROM listings l LEFT JOIN products p ON p.id=l.product_id LEFT JOIN accounts a ON a.id=l.account_id
                ORDER BY l.id DESC LIMIT 500""")
    trs = "".join(f"""<tr><td>{e(where_label(l['market'], l['channel']))}<div class="mut">{e(l['label'] or ('엑셀 내보내기' if not l['account_id'] else ''))}</div></td><td><a href="/products/{l['product_id']}">{e(l['name'] or '(삭제됨)')}</a><div class="mut">{e(l['market_id'] or '')}</div></td>
<td><span class="tag {'dry' if l['dry'] else 'ok'}">{'미리보기' if l['dry'] else e(l['status'] or '')}</span></td>
<td><form method="post" action="/listings/{l['id']}" class="row" data-busy><input name="price" value="{l['price'] or ''}" style="width:90px"><input name="stock" value="{l['stock'] or ''}" style="width:70px">
<button class="btn sm" name="do" value="update">반영</button><button class="btn sm gray" name="do" value="off">판매중지</button><button class="btn sm green" name="do" value="on">재개</button><button class="btn sm red" name="do" value="forget">기록삭제</button></form></td></tr>""" for l in rows)
    body = f"""<h1>등록 현황</h1><div class="card tbl"><table><tr><th>판매처</th><th>상품</th><th>상태</th><th>가격 · 재고</th></tr>{trs or '<tr><td colspan=4>아직 등록한 상품이 없습니다</td></tr>'}</table></div>
<p class="mut">쿠팡은 등록 후 승인(보통 수 시간~1일)이 끝나야 가격·재고를 바꿀 수 있습니다.</p>"""
    return page("등록 현황", body, h.user, "/listings", h.flash, h.flash_err)

@route("POST", r"/listings/(\d+)")
def listing_post(h, lid):
    l = q("SELECT * FROM listings WHERE id=?", (lid,), one=True)
    f = h.form()
    do = f.get("do")
    if do == "forget":
        x("DELETE FROM listings WHERE id=?", (lid,))
        go("/listings", "기록을 지웠습니다(마켓의 상품은 그대로)")
    if not l["account_id"]:   # 엑셀 판매처
        if do == "update":
            pr = num(f.get("price"), float)
            st = num(f.get("stock"), int)
            x("UPDATE listings SET price=?, stock=?, status='엑셀 대기', updated=? WHERE id=?", (l["price"] if pr is None else pr, l["stock"] if st is None else st, time.time(), lid))
        else:
            x("UPDATE listings SET status=?, updated=? WHERE id=?", ("판매중지" if do == "off" else "엑셀 대기", time.time(), lid))
        go("/listings", "바꿨습니다. 판매처 화면에서 엑셀을 다시 받아 올리세요.")
    acc = q("SELECT * FROM accounts WHERE id=?", (l["account_id"],), one=True)
    if not acc:
        go("/listings", "계정이 삭제되었습니다", True)
    m = market_for(acc, force_dry=bool(l["dry"]))
    try:
        if do == "update":
            price, stock = num(f.get("price"), int) or l["price"], num(f.get("stock"), int)
            stock = l["stock"] if stock is None else stock
            m.update_price_stock(l, price, stock)
            x("UPDATE listings SET price=?, stock=?, updated=? WHERE id=?", (price, stock, time.time(), lid))
        else:
            m.set_sale(l, do == "on")
            x("UPDATE listings SET status=?, updated=? WHERE id=?", ("판매중" if do == "on" else "판매중지", time.time(), lid))
    except MarketError as ex:
        go("/listings", str(ex), True)
    log(h.user["username"], f"등록상품 {do}", f"{l['market']} {l['market_id']}")
    go("/listings", "반영했습니다" + (" (미리보기)" if m.dry else ""))

# ---------- 주문 ----------
PAID = {"PAYED", "ACCEPT", "INSTRUCT", "결제완료"}   # 발주·발송 대상 상태

def product_by_code(code):
    m = re.match(r"MM(\d+)", str(code or ""))
    return q("SELECT * FROM products WHERE id=?", (int(m.group(1)),), one=True) if m else None

def save_order(acc, o):
    p = product_by_code(o.get("seller_code"))
    st = (p["supply_type"] or "사입") if p else "사입"
    po = ("발주대기" if st == "위탁" else "발송대기") if str(o.get("status")) in PAID else ""
    mk = acc["market"] if acc else o.get("market", "naver")
    is_new = not q("SELECT 1 FROM orders WHERE market=? AND order_id=?", (mk, o["order_id"]), one=True)
    x("""INSERT INTO orders(account_id,market,order_id,product_name,qty,amount,buyer,status,ordered_at,raw,product_id,supply_type,seller_code,option_text,rcv,ship_ref,po_status,collected)
         VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
         ON CONFLICT(market,order_id) DO UPDATE SET status=excluded.status,
           po_status=CASE WHEN COALESCE(orders.po_status,'')='' THEN excluded.po_status ELSE orders.po_status END""",
      (acc["id"] if acc else None, acc["market"] if acc else o.get("market", "naver"), o["order_id"], o["product_name"], o["qty"], o["amount"], o["buyer"],
       o["status"], o["ordered_at"], json.dumps(o.get("raw"), ensure_ascii=False)[:8000], p["id"] if p else None, st, o.get("seller_code", ""),
       o.get("option", ""), json.dumps(o.get("rcv") or {}, ensure_ascii=False), json.dumps(o.get("ship_ref") or {}, ensure_ascii=False), po, time.time()))
    if is_new and p and st == "사입" and po:   # 사입 상품: 팔린 만큼 재고 빼고, 0이 되면 자동 품절
        x("UPDATE products SET stock=MAX(COALESCE(stock,0)-?,0) WHERE id=?", (int(o.get("qty") or 1), p["id"]))
        auto_stock(p["id"])
    return is_new

def collect_orders(user="자동"):
    n, errs, new = 0, [], []
    for a in q("SELECT * FROM accounts WHERE active=1"):
        try:
            m = market_for(a)
        except Exception as ex:
            errs.append(f"{MARKETS[a['market']].name} {a['label']}: {ex}")
            continue
        if m.dry:
            continue
        try:
            for o in m.fetch_orders():
                if save_order(a, o):
                    new.append(f"{MARKETS[a['market']].name} · {o.get('product_name') or ''} {o.get('qty') or 1}개 {int(float(o.get('amount') or 0)):,}원")
                n += 1
        except Exception as ex:
            errs.append(f"{MARKETS[a['market']].name} {a['label']}: {ex}")
    log(user, "주문 수집", f"{n}건 {'; '.join(errs)[:500]}")
    if new:
        notify.send(f"새 주문 {len(new)}건", "\n".join(new[:15]) + (f"\n외 {len(new) - 15}건" if len(new) > 15 else ""), "order")
    if errs:
        notify.send("주문 수집 오류", "\n".join(errs)[:1000], "error")
    if get_setting("auto_order", False):
        auto_place_orders(user)
    return n, errs

@route("GET", "/orders")
def orders(h):
    rows = q("SELECT o.*, a.label FROM orders o LEFT JOIN accounts a ON a.id=o.account_id ORDER BY ordered_at DESC LIMIT 500")
    trs = "".join(f"<tr><td>{e(where_label(o['market']))}<div class='mut'>{e(o['label'] or '')}</div></td><td>{e(str(o['ordered_at'] or '')[:16])}</td><td>{e(o['product_name'] or '')}</td><td>{o['qty'] or ''}</td><td>{(o['amount'] or 0):,}</td><td>{e(mask(o['buyer'] or ''))}</td><td><span class='tag'>{e(o['status'] or '')}</span><div class='mut'>{e(o['supply_type'] or '')} {e(o['po_status'] or '')}</div></td></tr>" for o in rows)
    mins = get_setting("order_interval", 30)
    auto = get_setting("auto_order", False); ph = notify.conf().get("on_order", True)
    tg = lambda what, on, label: f'<form method="post" action="/orders/toggle" style="margin:0"><input type="hidden" name="what" value="{what}"><button class="btn {"green" if on else "gray"}">{label}: {"켜짐" if on else "꺼짐"} (누르면 {"끄기" if on else "켜기"})</button></form>'
    ctl = f'''<div class="card"><h2>자동 · 알람</h2><div class="row">{tg("auto", auto, "도매매 자동 주문")}{tg("phone", ph, "폰 알림")}<button class="btn gray" type="button" id="pcAlarmBtn" onclick="mmAlarmToggle()">PC 소리 알람</button></div>
<p class="mut">자동 주문을 켜면 새 위탁 주문이 올 때 폰으로 알리고 도매매 주문용 목록(<a href="/fulfill">발주·송장</a>)에 모읍니다. 도매매 주문 API를 <a href="/suppliers">도매매 위탁</a> 화면 맨 아래 칸에 입력하면 도매매에 직접 주문합니다. 비어 있으면 알림·목록만 합니다. PC 알람은 이 화면이나 프로그램 창이 열려 있을 때 소리와 알림으로 알려 줍니다.</p></div>'''
    body = f"""<h1>주문</h1>{ctl}<div class="row" style="margin-bottom:12px"><form method="post" action="/orders/collect" data-busy><button class="btn">지금 주문 모으기</button></form>
<a class="btn gray" href="/orders.csv">엑셀(CSV) 받기</a><span class="mut">자동 수집: {mins}분마다 (설정에서 변경)</span></div>
<div class="card tbl"><table><tr><th>마켓</th><th>주문일</th><th>상품</th><th>수량</th><th>금액</th><th>주문자</th><th>상태</th></tr>{trs or '<tr><td colspan=7>주문이 없습니다</td></tr>'}</table></div>"""
    return page("주문", body, h.user, "/orders", h.flash, h.flash_err)

@route("GET", "/api/orders/poll")
def api_orders_poll(h):
    after = num(h.qs.get("after"), int) or 0
    mx = q("SELECT COALESCE(MAX(id),0) m FROM orders", one=True)["m"]
    new = [f"{o['product_name'] or ''} ×{o['qty'] or 1}" for o in q("SELECT product_name, qty FROM orders WHERE id>? ORDER BY id LIMIT 10", (after,))] if after else []
    h.extra_headers = {"Content-Type": "application/json; charset=utf-8"}
    return json.dumps({"max": mx, "new": new}, ensure_ascii=False)

@route("POST", "/orders/toggle")
def orders_toggle(h):
    f = h.form()
    w = f.get("what")
    if w == "auto":
        v = not get_setting("auto_order", False)
        set_setting("auto_order", v)
        log(h.user["username"], "도매매 자동 주문 " + ("켬" if v else "끔"))
        go("/orders", "자동 주문을 " + ("켰습니다. 새 위탁 주문이 오면 폰으로 알리고 주문용 목록에 모읍니다." if v else "껐습니다."))
    if w == "phone":
        c = notify.conf(); c["on_order"] = not c.get("on_order", True)
        set_setting("notify", c)
        go("/orders", "폰 주문 알림을 " + ("켰습니다" if c["on_order"] else "껐습니다"))
    go("/orders")

@route("POST", "/orders/collect")
def orders_collect(h):
    n, errs = collect_orders(h.user["username"])
    go("/orders", f"{n}건 모았습니다" + ("\n" + "\n".join(errs) if errs else ""), bool(errs))

@route("GET", "/orders.csv")
def orders_csv(h):
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["마켓", "주문번호", "주문일", "상품", "수량", "금액", "주문자", "상태"])
    for o in q("SELECT * FROM orders ORDER BY ordered_at DESC"):
        w.writerow([where_label(o["market"]), o["order_id"], o["ordered_at"], o["product_name"], o["qty"], o["amount"], o["buyer"], o["status"]])
    h.extra_headers = {"Content-Disposition": "attachment; filename=orders.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿" + out.getvalue()

# ---------- 마켓 계정 ----------
def markets_table():
    accs = q("SELECT market, COUNT(*) n, SUM(CASE WHEN COALESCE(creds,'')<>'' THEN 1 ELSE 0 END) k FROM accounts WHERE active=1 GROUP BY market")
    have = {r["market"]: (r["n"], r["k"] or 0) for r in accs}
    head = "".join(f"<th style='text-align:center'>{FEAT_NAMES[f]}</th>" for f in FEATS)
    rows = ""
    for label, code in MARKET_ROWS:
        m = MARKETS[code]; done = getattr(m, "done", []); plan = getattr(m, "plan", FEATS)
        cell = lambda f: ("<td style='text-align:center;color:#16a34a'>✔</td>" if f in done else
                          ("<td style='text-align:center;color:#d97706' title='준비 중'>준비 중</td>" if f in plan else "<td style='text-align:center' class='mut'>—</td>"))
        n, k = have.get(code, (0, 0))
        st = ('<span class="tag ok">키 있음</span>' if k else ('<span class="tag dry">키 없음</span>' if n else ''))
        btn = f'<a class="btn sm {"" if k else "green"}" href="/accounts/new/{code}">{"계정 추가" if k else "키 넣기"}</a>'
        rows += f"<tr><td><b>{label}</b> {st}</td>{''.join(cell(f) for f in FEATS)}<td>{btn}</td></tr>"
    return f"""<h2>14개 마켓 연동 칸</h2>
<p class="mut">✔ 지금 됨 · 준비 중 = 연동 코드를 만드는 중(완성되면 자동 업데이트로 켜짐) · — 그 마켓이 제공하지 않음</p>
<div class="card tbl"><table><tr><th>마켓</th>{head}<th></th></tr>{rows}</table></div>
<div class="card"><h2>키는 미리 넣어 두세요</h2><p class="mut">준비 중인 마켓도 키를 먼저 저장할 수 있습니다. 옥션·G마켓은 ESM 계정 하나로 같이 연동됩니다. SSG·CJ온스타일·홈앤쇼핑·W쇼핑·SK스토아·GS SHOP은 입점(판매자 승인)이 먼저 되어야 API 키를 받을 수 있습니다.</p></div>"""

@route("GET", "/markets")
def markets_page(h):
    go("/accounts")

@route("GET", "/accounts")
def accounts(h):
    rows = q("SELECT * FROM accounts ORDER BY market, id")
    trs = "".join(f"""<tr><td>{MARKETS[a['market']].name}</td><td><a href="/accounts/{a['id']}"><b>{e(a['label'])}</b></a><div class="mut">담당: {e(a['owner'] or '')}</div></td>
<td>{'<span class="tag ok">사용</span>' if a['active'] else '<span class="tag bad">꺼짐</span>'} {'<span class="tag">키 있음</span>' if a['creds'] else '<span class="tag dry">키 없음</span>'}</td>
<td><div class="row"><form method="post" action="/accounts/{a['id']}/test" data-busy><button class="btn sm gray">연결 확인</button></form>{f'<a class="btn sm" href="/accounts/{a["id"]}/store">스토어 상품 보기·삭제</a>' if a['market'] == 'naver' else ''}</div></td></tr>""" for a in rows)
    opts = "".join(f'<a class="btn {"" if getattr(m, "ready", False) else "gray"}" href="/accounts/new/{k}">+ {m.name}</a>' for k, m in MARKETS.items())
    body = f"""<h1>마켓 계정</h1>{markets_table()}<h2>등록한 계정</h2><div class="card tbl"><table><tr><th>마켓</th><th>계정</th><th>상태</th><th></th></tr>{trs or '<tr><td colspan=4>계정이 없습니다</td></tr>'}</table></div>
<div class="card"><h2>API 키 받는 곳</h2><ul class="mut" style="line-height:1.9"><li>네이버: 커머스API센터(apicenter.commerce.naver.com) → 애플리케이션 등록 → ID·시크릿, 호출 IP에 서버 IP 등록</li>
<li>쿠팡: Wing → 판매자정보 → 추가판매정보 → OPEN API 키 발급(업체코드·Access·Secret), 허용 IP에 서버 IP 등록</li>
<li>지마켓·옥션: ESM+ → 판매자정보 → API 사용 신청(승인 필요) → 마스터 ID·시크릿 키</li></ul>
<p class="mut">키는 이 서버에만 저장됩니다(Windows에서는 암호화). 한 마켓에 계정을 여러 개 넣을 수 있습니다.</p></div>"""
    return page("마켓 계정", body, h.user, "/accounts", h.flash, h.flash_err)

def account_form(h, m, a=None):
    creds = json.loads(unseal(a["creds"]) or "{}") if a and a["creds"] else {}
    extra = json.loads(a["extra"] or "{}") if a else {}
    cf = "".join(f'<div><label>{lab}{" (바꿀 때만 입력)" if sec and creds.get(k) else ""}</label><input name="c_{k}" value="{"" if sec else e(creds.get(k, ""))}" {"type=password" if sec else ""} autocomplete="off"></div>' for k, lab, sec in m.cred_fields)
    ef = "".join(f'<div><label>{lab}</label><input name="x_{k}" value="{e(extra.get(k, d))}"></div>' for k, lab, d in m.extra_fields)
    delb = f'<button class="btn red" name="do" value="delete" onclick="return confirm(\'계정을 지울까요?\')">삭제</button>' if a else ""
    cat = f"""<div class="card"><h2>카테고리 찾기</h2><form method="post" action="/accounts/{a['id']}/category" class="row" data-busy><input name="kw" placeholder="예: 헤어핀" style="max-width:260px"><button class="btn gray">찾기</button></form>
{h.qs.get('cat_result','')}</div>""" if a else ""
    return page(m.name, f"""<h1>{m.name} 계정</h1><form method="post" class="card"><div class="grid"><div><label>계정 이름(구분용)</label><input name="label" value="{e(a['label'] if a else '')}" required></div>
<div><label>담당자</label><input name="owner" value="{e((a['owner'] if a else '') or h.user['name'] or '')}"></div>
<div><label>사용</label><select name="active"><option value="1">사용</option><option value="0" {"selected" if a and not a['active'] else ""}>끄기</option></select></div></div>
<h2 style="margin-top:18px">API 키</h2>{('<p class="flash">이 마켓은 연동 준비 중입니다. 키를 먼저 저장해 두면 연동이 들어올 때 자동으로 씁니다.<br>키 받는 곳: ' + e(m.where) + '</p>') if not getattr(m, "ready", False) else ""}<div class="grid">{cf}</div><h2 style="margin-top:18px">기본값</h2><div class="grid">{ef}</div><br>
<div class="row"><button class="btn" name="do" value="save">저장</button>{delb}</div></form>{cat}""", h.user, "/accounts", h.flash, h.flash_err)

@route("GET", r"/accounts/new/(\w+)")
def account_new(h, market):
    return account_form(h, MARKETS[market])

@route("GET", r"/accounts/(\d+)")
def account_get(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    return account_form(h, MARKETS[a["market"]], a)

def account_save(h, market, a=None):
    f = h.form()
    m = MARKETS[market]
    if f.get("do") == "delete" and a:
        x("DELETE FROM accounts WHERE id=?", (a["id"],))
        log(h.user["username"], "마켓 계정 삭제", a["label"])
        go("/accounts", "삭제했습니다")
    old = json.loads(unseal(a["creds"]) or "{}") if a and a["creds"] else {}
    creds = {k: (f.get("c_" + k, "").strip() or old.get(k, "")) for k, _, _ in m.cred_fields}
    extra = {k: f.get("x_" + k, "").strip() for k, _, _ in m.extra_fields}
    sealed = seal(json.dumps(creds)) if any(creds.values()) else ""
    if a:
        x("UPDATE accounts SET label=?, creds=?, extra=?, active=?, owner=? WHERE id=?", (f["label"], sealed, json.dumps(extra, ensure_ascii=False), int(f.get("active", 1)), f.get("owner"), a["id"]))
        aid = a["id"]
    else:
        aid = x("INSERT INTO accounts(market,label,creds,extra,active,owner,created) VALUES(?,?,?,?,?,?,?)",
                (market, f["label"], sealed, json.dumps(extra, ensure_ascii=False), int(f.get("active", 1)), f.get("owner"), time.time()))
    log(h.user["username"], "마켓 계정 저장", f"{m.name} {f['label']}")
    go(f"/accounts/{aid}", "저장했습니다")

@route("POST", r"/accounts/new/(\w+)")
def account_create(h, market):
    account_save(h, market)

@route("POST", r"/accounts/(\d+)")
def account_update(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    account_save(h, a["market"], a)

@route("POST", r"/accounts/(\d+)/test")
def account_test(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    m = MARKETS[a["market"]](json.loads(unseal(a["creds"]) or "{}") if a["creds"] else {}, json.loads(a["extra"] or "{}"))
    back = h.form().get("back"); back = back if back in ("/", "/b2b", "/own") else "/accounts"
    try:
        go(back, f"{m.name} {a['label']}: {m.test()}")
    except MarketError as ex:
        go(back, str(ex), True)

# ---------- 스토어에 이미 올라가 있는 상품 (불러오기·삭제) ----------
STORE_CACHE = {}   # account_id → (시각, 상품 목록)
STORE_JOB = {}     # account_id → 진행 상황

def store_market(a):
    return MARKETS[a["market"]](json.loads(unseal(a["creds"]) or "{}") if a["creds"] else {}, json.loads(a["extra"] or "{}"))

@route("GET", r"/accounts/(\d+)/store")
def account_store(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    if not a:
        go("/accounts", "계정이 없습니다", True)
    aid = int(aid); m = store_market(a); job = STORE_JOB.get(aid) or {}
    ld = STORE_LOAD.get(aid) or {}
    if (h.qs.get("reload") or aid not in STORE_CACHE) and not ld.get("running") and not (ld.get("error") and not h.qs.get("reload")):
        ld = STORE_LOAD[aid] = {"running": True, "count": 0, "error": ""}
        threading.Thread(target=store_load_job, args=(aid, a), daemon=True).start()
    if ld.get("running") or aid not in STORE_CACHE:
        if ld.get("error"):
            return page("스토어 상품", f'<h1>{e(a["label"])} 스토어 상품</h1><div class="flash err">불러오지 못했습니다: {e(ld["error"])}</div><p class="mut">네이버가 "요청이 많다"고 하면 1~2분 뒤 다시 불러오기를 눌러 주세요. 키 오류라면 마켓계정에서 연결 확인을 해 보세요.</p><a class="btn" href="/accounts/{aid}/store?reload=1">다시 불러오기</a> <a class="btn gray" href="/accounts">마켓계정으로</a>', h.user, "/accounts")
        return page("스토어 상품", f'<h1>{e(a["label"])} 스토어 상품</h1><div class="flash">스토어 상품을 불러오는 중입니다… 지금까지 {ld.get("count", 0):,}개. 네이버가 천천히 보내라고 하면 잠깐씩 쉬었다 이어서 받습니다. 이 화면은 3초마다 새로고침됩니다.</div><meta http-equiv="refresh" content="3">', h.user, "/accounts")
    at, items = STORE_CACHE[aid]
    mine = {r["market_id"] for r in q("SELECT market_id FROM listings WHERE account_id=?", (aid,))}
    st = {"SALE": "판매중", "SUSPENSION": "판매중지", "OUTOFSTOCK": "품절", "WAIT": "판매대기", "UNADMISSION": "승인대기", "REJECTION": "승인거부", "PROHIBITION": "판매금지", "CLOSE": "판매종료"}
    trs = "".join(f"""<tr><td><input type="checkbox" name="pick" value="{e(it['origin'])}" style="width:auto"></td><td>{f'<img class="thumb" src="{e(it["image"])}" loading="lazy">' if it['image'] else ''}</td>
<td>{e(it['name'])}<div class="mut">원상품번호 {e(it['origin'])}{' · ' + e(it['code']) if it['code'] else ''}{' · <span class="tag ok">우리 프로그램에서 올림</span>' if it['origin'] in mine else ''}</div></td>
<td>{st.get(it['status'], e(it['status']))}</td><td>{(f"{int(it['price']):,}원") if it['price'] else ''}</td><td>{'' if it['stock'] is None else it['stock']}</td></tr>""" for it in items)
    prog = ""
    if job:
        prog = f"""<div class="flash {'err' if job.get('fail') else ''}">{'삭제 중… ' if job.get('running') else '삭제 끝: '}{job.get('done', 0)}/{job.get('total', 0)}개 지움{', 실패 ' + str(job.get('fail')) + '개' if job.get('fail') else ''}
{e(chr(10).join(job.get('errors', [])[:10]))}</div>{'<meta http-equiv="refresh" content="3">' if job.get('running') else ''}"""
    dry_note = '<div class="flash err">API 키가 없어 <b>예시 상품</b>만 보입니다. 마켓계정에 애플리케이션 ID·시크릿을 넣어 주세요.</div>' if m.dry else ""
    body = f"""<h1>{e(a['label'])} 스토어 상품</h1>{dry_note}{prog}
<div class="card"><div class="row"><div><div class="mut">스토어에 올라가 있는 상품</div><div class="stat">{len(items):,}개</div></div>
<div class="mut" style="margin-left:auto">불러온 시각 {time.strftime('%m-%d %H:%M', time.localtime(at))} <a class="btn sm gray" href="/accounts/{aid}/store?reload=1">다시 불러오기</a></div></div>
<div class="row" style="margin-top:10px"><a class="btn green" href="/accounts/{aid}/store.xlsx">⬇ 지금 스토어에 올라가 있는 상품 엑셀로 받기</a></div>
<p class="mut">내가 스마트스토어에서 지운 상품은 빠지고, 지금 남아 있는 상품만 담깁니다(위 「다시 불러오기」로 최신 상태를 먼저 받으세요).</p>
<p class="mut">우리 프로그램 밖(스마트스토어센터 등)에서 올린 상품도 모두 보입니다.</p></div>
<form method="post" action="/accounts/{aid}/store/delete" id="sf"><div class="card"><h2>삭제</h2>
<p><b>삭제하면 스마트스토어에서 완전히 지워지고 되돌릴 수 없습니다.</b> 진행 중인 주문이 있는 상품은 네이버가 삭제를 막을 수 있어요(실패로 표시됩니다).</p>
<div class="row"><select name="scope" style="max-width:260px"><option value="pick">아래에서 체크한 상품만</option><option value="all">스토어 상품 전체 ({len(items):,}개)</option></select>
<input name="confirm" placeholder="확인: 삭제 개수를 숫자로 입력" style="max-width:260px" autocomplete="off"><button class="btn red" {'disabled' if job.get('running') else ''}>삭제하기</button></div>
<p class="mut">실수 방지: 지울 개수를 숫자로 똑같이 입력해야 지워집니다. 예) 전체 {len(items)}개를 지우려면 <b>{len(items)}</b> 입력.</p></div>
<div class="card tbl"><table><tr><th><input type="checkbox" data-all="pick" style="width:auto"></th><th></th><th>상품명</th><th>상태</th><th>판매가</th><th>재고</th></tr>{trs or '<tr><td colspan=6>스토어에 상품이 없습니다</td></tr>'}</table></div></form>"""
    return page("스토어 상품", body, h.user, "/accounts", h.flash, h.flash_err)

@route("GET", r"/accounts/(\d+)/store\.xlsx")
def account_store_xlsx(h, aid):
    aid = int(aid)
    if aid not in STORE_CACHE:
        go(f"/accounts/{aid}/store", "먼저 스토어 상품을 불러온 뒤 엑셀 받기를 누르세요", True)
    at, items = STORE_CACHE[aid]
    a = q("SELECT label FROM accounts WHERE id=?", (aid,), one=True)
    mine = {r["market_id"]: r["product_id"] for r in q("SELECT market_id, product_id FROM listings WHERE account_id=?", (aid,))}
    st = {"SALE": "판매중", "SUSPENSION": "판매중지", "OUTOFSTOCK": "품절", "WAIT": "판매대기", "UNADMISSION": "승인대기", "REJECTION": "승인거부", "PROHIBITION": "판매금지", "CLOSE": "판매종료"}
    data = [["원상품번호", "채널상품번호", "상품명", "상태", "판매가", "재고", "판매자 관리코드", "우리 프로그램에서 올림", "대표이미지"]]
    for it in items:
        data.append([it["origin"], it["channel"], it["name"], st.get(it["status"], it["status"]), it["price"] if it["price"] is not None else "",
                     it["stock"] if it["stock"] is not None else "", it["code"], "예" if it["origin"] in mine else "", it["image"]])
    log(h.user["username"], "스토어 상품 엑셀 받기", f"{len(items)}개")
    h.extra_headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote((a['label'] if a else '스토어') + '_상품_' + time.strftime('%Y%m%d_%H%M'))}.xlsx",
                       "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}
    return xlsx.write(data, "스토어상품")

STORE_LOAD = {}    # account_id → 불러오기 진행 상황

def store_load_job(aid, a):
    ld = STORE_LOAD[aid]
    try:
        items = store_market(a).list_store(progress=lambda n: ld.update(count=n))
        STORE_CACHE[aid] = (time.time(), items)
    except Exception as ex:
        ld["error"] = str(ex)[:600]
    ld["running"] = False

def store_delete_job(aid, a, targets, user):
    job = STORE_JOB[aid]
    m = store_market(a)
    for it in targets:
        try:
            m.delete_store(it)
            job["done"] += 1
            x("DELETE FROM listings WHERE account_id=? AND market_id=?", (aid, it["origin"]))
        except Exception as ex:
            job["fail"] += 1
            job["errors"].append(f"{it['name'][:30]}: {str(ex)[:200]}")
        time.sleep(0.4)
    job["running"] = False
    STORE_CACHE.pop(aid, None)
    log(user, "스토어 상품 삭제", f"{a['label']} {job['done']}개 삭제, 실패 {job['fail']}개")
    notify.send("스토어 상품 삭제 끝", f"{a['label']}: {job['done']}개 삭제, 실패 {job['fail']}개", "upload")

@route("POST", r"/accounts/(\d+)/store/delete", admin=True)
def account_store_delete(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    aid = int(aid)
    if aid not in STORE_CACHE:
        go(f"/accounts/{aid}/store", "목록을 먼저 불러와 주세요", True)
    if (STORE_JOB.get(aid) or {}).get("running"):
        go(f"/accounts/{aid}/store", "이미 삭제 중입니다", True)
    items = STORE_CACHE[aid][1]
    fm = h.form_multi()
    scope = (fm.get("scope") or ["pick"])[0]
    picks = set(fm.get("pick") or [])
    targets = items if scope == "all" else [it for it in items if it["origin"] in picks]
    if not targets:
        go(f"/accounts/{aid}/store", "지울 상품을 체크해 주세요", True)
    want = re.sub(r"[^0-9]", "", (fm.get("confirm") or [""])[0])
    if want != str(len(targets)):
        go(f"/accounts/{aid}/store", f"확인 숫자가 다릅니다. {len(targets)}개를 지우려면 {len(targets)} 을 입력하세요. 아무것도 지우지 않았습니다.", True)
    STORE_JOB[aid] = {"running": True, "total": len(targets), "done": 0, "fail": 0, "errors": []}
    log(h.user["username"], "스토어 상품 삭제 시작", f"{a['label']} {len(targets)}개")
    threading.Thread(target=store_delete_job, args=(aid, a, targets, h.user["username"]), daemon=True).start()
    go(f"/accounts/{aid}/store", f"{len(targets)}개 삭제를 시작했습니다. 이 화면이 3초마다 새로고침됩니다.")

@route("POST", r"/accounts/(\d+)/category")
def account_category(h, aid):
    a = q("SELECT * FROM accounts WHERE id=?", (aid,), one=True)
    m = MARKETS[a["market"]](json.loads(unseal(a["creds"]) or "{}") if a["creds"] else {}, json.loads(a["extra"] or "{}"))
    kw = h.form().get("kw", "")
    try:
        res = m.search_category(kw)
    except MarketError as ex:
        go(f"/accounts/{aid}", str(ex), True)
    txt = "\n".join(f"{r['id']}  {r['name']}" for r in res) or ("키를 넣어야 찾을 수 있습니다" if m.dry else "결과 없음")
    go(f"/accounts/{aid}", f"'{kw}' 카테고리\n{txt}")

# ---------- 팀원 ----------
@route("GET", "/users", admin=True)
def users(h):
    trs = "".join(f"""<tr><td>{e(u['username'])}</td><td>{e(u['name'] or '')}</td><td>{'관리자' if u['role']=='admin' else '팀원'}</td>
<td><form method="post" action="/users/{u['id']}" class="row"><input name="pw" type="password" placeholder="새 비밀번호" style="width:140px"><button class="btn sm gray" name="do" value="pw">변경</button>
{'' if u['id']==h.user['id'] else '<button class="btn sm red" name="do" value="del" onclick="return confirm(&quot;삭제?&quot;)">삭제</button>'}</form></td></tr>""" for u in q("SELECT * FROM users"))
    body = f"""<h1>팀원</h1><div class="card tbl"><table><tr><th>아이디</th><th>이름</th><th>권한</th><th></th></tr>{trs}</table></div>
<form method="post" action="/users" class="card"><h2>팀원 추가</h2><div class="grid"><div><label>아이디</label><input name="username" required></div><div><label>이름</label><input name="name"></div>
<div><label>비밀번호</label><input name="pw" type="password" minlength="8" required></div><div><label>권한</label><select name="role"><option value="staff">팀원</option><option value="admin">관리자</option></select></div></div><br><button class="btn">추가</button></form>"""
    return page("팀원", body, h.user, "/users", h.flash, h.flash_err)

@route("POST", "/users", admin=True)
def users_add(h):
    f = h.form()
    try:
        auth.create_user(f["username"].strip(), f.get("name", ""), f["pw"], f.get("role", "staff"))
    except Exception:
        go("/users", "이미 있는 아이디입니다", True)
    log(h.user["username"], "팀원 추가", f["username"])
    go("/users", "추가했습니다")

@route("POST", r"/users/(\d+)", admin=True)
def users_edit(h, uid):
    f = h.form()
    if f.get("do") == "del":
        x("DELETE FROM users WHERE id=?", (uid,)); x("DELETE FROM sessions WHERE user_id=?", (uid,))
        go("/users", "삭제했습니다")
    if len(f.get("pw", "")) < 8:
        go("/users", "비밀번호는 8자 이상", True)
    x("UPDATE users SET pw=? WHERE id=?", (auth.hash_pw(f["pw"]), uid))
    go("/users", "비밀번호를 바꿨습니다")

@route("GET", "/me")
def me(h):
    return page("내 정보", """<h1>내 비밀번호 변경</h1><form method="post" class="card" style="max-width:420px"><label>현재 비밀번호</label><input name="old" type="password">
<label>새 비밀번호</label><input name="pw" type="password" minlength="8"><br><br><button class="btn">변경</button></form>""", h.user, "/me", h.flash, h.flash_err)

@route("POST", "/me")
def me_post(h):
    f = h.form()
    if not auth.check_pw(f.get("old", ""), h.user["pw"]) or len(f.get("pw", "")) < 8:
        go("/me", "현재 비밀번호가 틀렸거나 새 비밀번호가 8자 미만입니다", True)
    x("UPDATE users SET pw=? WHERE id=?", (auth.hash_pw(f["pw"]), h.user["id"]))
    go("/", "비밀번호를 바꿨습니다")

# ---------- 설정 ----------
@route("GET", "/settings")
def settings(h):
    c = pricing.cfg(); shop = get_setting("shop", {}) or {}; ai = get_setting("ai", {}) or {}; nr = naming.rules()
    dry = False; adm = h.user["role"] == "admin"
    dis = "" if adm else "disabled"
    body = f"""<h1>설정</h1>{'' if adm else '<div class="flash err">설정은 관리자만 바꿀 수 있습니다.</div>'}<form method="post"><fieldset {dis} style="border:0;padding:0;margin:0">
<div class="card"><h2>위탁·사입 판매 설정</h2><p class="mut">마진·배송비·자동 품절은 위탁과 사입을 나눠 <a href="/sell/consign">판매설정</a>에서 정합니다.</p><a class="btn sm" href="/sell/consign">🤝 위탁 설정</a> <a class="btn sm gray" href="/sell/own">📦 사입 설정</a></div>
<div class="card"><h2>상품명 가공 (마켓 등록 때 적용)</h2><div class="grid"><div><label>앞에 붙일 문구</label><input name="nr_prefix" value="{e(nr.get('prefix',''))}" placeholder="예: [국내발송]"></div>
<div><label>뒤에 붙일 문구</label><input name="nr_suffix" value="{e(nr.get('suffix',''))}"></div></div>
<label>금지어(쉼표로 구분, 상품명에서 지움)</label><input name="nr_banned" value="{e(nr.get('banned',''))}" placeholder="예: 최저가, 정품, 무료">
<label>단어 바꾸기(한 줄에 하나, 바꿀말=>새말)</label><textarea name="nr_replace" style="min-height:60px" placeholder="헤어클립=>집게핀">{e(nr.get('replace',''))}</textarea>
<p class="mut">길이 제한은 <a href="/channels">판매처</a>마다 정한 글자 수에서 자동으로 자릅니다(기본: 네이버·쿠팡 100자, 지마켓·옥션 50자).</p></div>
<div class="card"><h2>카테고리 자동 매칭</h2><p class="mut">한 줄에 하나: <b>테마나 상품명에 들어 있는 말 = 네이버ID, 쿠팡코드, 지마켓코드</b>. 상품에 카테고리가 비어 있으면 이 표로 채워서 등록합니다.</p>
<textarea name="category_map" placeholder="집게핀 = 50000805, 80284, 300024012">{e(get_setting('category_map', '') or '')}</textarea></div>
<div class="card"><h2>상점 정보(상세페이지에 들어감)</h2><div class="grid"><div><label>상점 이름</label><input name="shop_name" value="{e(shop.get('name',''))}"></div>
<div><label>상단 띠 문구</label><input name="shop_banner" value="{e(shop.get('banner',''))}" placeholder="오늘 주문 · 내일 도착"></div><div><label>고객센터 안내</label><input name="shop_cs" value="{e(shop.get('cs',''))}"></div></div></div>
<div class="card"><h2>AI 상세페이지 문구(선택)</h2><p class="mut">Claude API 키(console.anthropic.com)를 넣으면 'AI 문구로 제작'이 작동합니다. 없으면 기본 문구로 만듭니다.</p><div class="grid">
<div><label>API 키 {'(저장됨, 바꿀 때만 입력)' if ai.get('api_key') else ''}</label><input name="ai_key" type="password" autocomplete="off"></div><div><label>모델</label><input name="ai_model" value="{e(ai.get('model','claude-sonnet-5-5'))}"></div></div></div>
<div class="card"><h2>자동 주문 수집</h2><label>간격(분, 0 = 끔)</label><input name="order_interval" value="{get_setting('order_interval', 30)}" style="max-width:160px"></div>
{'<button class="btn">저장</button>' if adm else ''}</fieldset></form><p><a href="/me">내 비밀번호 바꾸기</a></p>"""
    return page("설정", body, h.user, "/settings", h.flash, h.flash_err)

def policy_form(c, kind=None):
    modes = "".join(f'<option value="{k}" {"selected" if c["margin_mode"] == k else ""}>{v}</option>' for k, v in pricing.MODE_LABEL.items())
    v = lambda x_: "" if x_ in (None, "") else f"{x_:g}" if isinstance(x_, (int, float)) else e(str(x_))
    per = "".join(f"""<tr><td>{e(ch['name'])}{'' if ch['active'] else ' <span class=mut>(꺼짐)</span>'}</td><td><input name="mm_{ch['code']}" value="{v(c['market_margin'].get(ch['code']))}" placeholder="{'판매처 기본 ' + format(ch['margin'], 'g') if ch['margin'] is not None else '정책 기본'}"></td>
<td class="mut">{ch['fee']:g}%</td><td><input name="ms_{ch['code']}" value="{v(c['market_ship'].get(ch['code']))}" placeholder="{'판매처 ' + format(ch['ship'], 'g') if ch['ship'] is not None else '기본값'}"></td></tr>""" for ch in chs.all_channels(False))
    return f"""<div class="grid"><div><label>마진 방식</label><select name="margin_mode">{modes}</select></div>
<div><label>기본 마진 (% 또는 원)</label><input name="margin" value="{v(c['margin'])}"></div>
{(f'<input type="hidden" name="cny_krw" value="{v(c["cny_krw"])}"><input type="hidden" name="landed_mult" value="1"><input type="hidden" name="pack_cost" value="0">'
  f'<div><label>공급처 배송비가 없을 때 배송비(건)</label><input name="ship_cost" value="{v(c["ship_cost"])}"></div>') if kind == "consign" else
 (f'<div><label>환율(1위안 = 원)</label><input name="cny_krw" value="{v(c["cny_krw"])}"></div><div><label>사입 부대비용 배수(단가×)</label><input name="landed_mult" value="{v(c["landed_mult"])}"></div>'
  f'<div><label>포장비(건)</label><input name="pack_cost" value="{v(c["pack_cost"])}"></div><div><label>기본 택배비(건)</label><input name="ship_cost" value="{v(c["ship_cost"])}"></div>')}
<div><label>택배비</label><select name="ship_mode"><option value="include">포함 (판매가에 넣고 무료배송)</option><option value="separate" {'selected' if c.get('ship_mode') == 'separate' else ''}>미포함 (구매자가 배송비 따로 냄)</option></select></div>
<div><label>올림 단위(원)</label><select name="round_to">{"".join(f'<option value="{u}" {"selected" if int(c["round_to"]) == u else ""}>{u}원</option>' for u in (10, 100, 1000))}</select></div>
<div><label>끝자리 900원 맞춤</label><select name="end_with_900"><option value="1">예</option><option value="0" {'' if c['end_with_900'] else 'selected'}>아니오</option></select></div>
<div><label>최저 판매가(원)</label><input name="min_price" value="{v(c.get('min_price') or 0)}"></div>
{('<div><label>도매매 소비자가(정가) 아래로 팔지 않기</label><select name="respect_fixed"><option value="1">예 (가격 준수 상품 보호)</option><option value="0" ' + ('' if c.get('respect_fixed', True) else 'selected') + '>아니오</option></select></div>') if kind == "consign" else '<input type="hidden" name="respect_fixed" value="1">'}</div>
<div class="tbl" style="margin-top:12px"><table><tr><th>판매처</th><th>이 정책의 판매처별 마진(비우면 기본)</th><th>수수료</th><th>택배·배송비(원, 비우면 기본)</th></tr>{per}</table></div>
<p class="mut">수수료·통화·환율과 판매처 기본 마진은 <a href="/channels">판매처</a>에서 정합니다. 해외몰은 국제배송비를 택배비 칸에 원화로 넣으세요.</p>
<p class="mut">예) 원가 대비 200% = 이익이 총원가의 2배 · 판매가 대비 50% = 판매가의 절반이 이익 · 정액 5000 = 한 건에 5,000원 남기기. 상품 화면에서 상품별 마진도 따로 넣을 수 있습니다.</p>"""

def parse_policy(f, name):
    n = lambda k, d=None: num(f.get(k), float) if num(f.get(k), float) is not None else d
    return {"name": name, "margin_mode": f.get("margin_mode", "pct"), "margin": n("margin", 200), "cny_krw": n("cny_krw", 200),
            "landed_mult": n("landed_mult", 1.5), "pack_cost": n("pack_cost", 300), "ship_cost": n("ship_cost", 3000),
            "round_to": int(n("round_to", 100)), "end_with_900": f.get("end_with_900") == "1", "min_price": n("min_price", 0), "respect_fixed": f.get("respect_fixed", "1") == "1", "ship_mode": "separate" if f.get("ship_mode") == "separate" else "include",
            "market_margin": {ch["code"]: n("mm_" + ch["code"]) for ch in chs.all_channels(False)},
            "market_ship": {ch["code"]: n("ms_" + ch["code"]) for ch in chs.all_channels(False)}}

def sell_tabs(kind):
    t = lambda k, u, lab: f'<a class="btn {"" if kind == k else "gray"}" href="{u}">{lab}</a>'
    return f'<div class="row" style="margin-bottom:12px">{t("consign", "/sell/consign", "🤝 위탁 설정 (도매매)")}{t("own", "/sell/own", "📦 사입 설정")}<a class="btn gray" href="/policies">💰 추가 가격 정책</a></div>'

def consign_policy():
    pid = consign_policy_id()
    r = q("SELECT data FROM policies WHERE id=?", (pid,), one=True) if pid else None
    return pricing._merge(json.loads(r["data"]) if r else {"name": "위탁 기본", "margin": 30, "landed_mult": 1, "pack_cost": 0})

def sell_example(c, consign):
    """화면에 보여 줄 계산 예시(네이버 기준)"""
    ch = chs.get("naver") or None
    fake = {"supply_type": "위탁" if consign else "사입", "supply_price": 5000, "cost_krw": 5000 if consign else None, "cost_cny": None if consign else 2,
            "set_qty": 1, "price_override": None, "policy_id": None, "margin": None, "ship": None, "ch_margin": "{}", "ch_ship": "{}", "supply_ship": 3000 if consign else None, "fixed_price": None}
    try:
        b = pricing.breakdown(fake, ch, c)
    except Exception:
        return ""
    what = "도매매 공급가 5,000원 + 공급처 배송비 3,000원" if consign else f"이우고 2위안(×{c['cny_krw']:g}원 ×{c['landed_mult']:g}) + 포장 {c['pack_cost']:g}원 + 택배"
    if c.get("ship_mode") == "separate":
        what += " (택배비 미포함: 판매가에 택배비를 넣지 않고 마켓 배송비로 구매자에게 받음)"
    return f'<p class="mut">예시(네이버): {what} → 판매가 <b>{b["price_krw"]:,}원</b> · 수수료 {b["fee"]:,}원 · 남는 돈 <b>{b["profit"]:,}원</b> (원가 대비 {b["margin_on_cost"]}%)</p>'

@route("GET", "/sell")
def sell_root(h):
    go("/sell/consign")

@route("GET", "/sell/consign")
def sell_consign(h):
    adm = h.user["role"] == "admin"; c = consign_policy(); oc = oc_conf()
    chk = lambda k, d=True: "checked" if oc.get(k, d) else ""
    n = q("SELECT COUNT(*) FROM products WHERE supply_type='위탁'", one=True)[0]
    body = f"""<h1>판매설정</h1>{sell_tabs("consign")}{'' if adm else '<div class="flash err">관리자만 바꿀 수 있습니다.</div>'}
<form method="post" action="/sell/consign"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0">
<div class="card"><h2>🤝 위탁 판매 가격 (도매매 상품 {n}개)</h2><p class="mut">원가 = 도매매 공급가 + 공급처 배송비. 포장·발송은 도매매이 하므로 포장비·부대비용은 넣지 않습니다.</p>{policy_form(c, "consign")}{sell_example(c, True)}</div>
<div class="card"><h2>도매매 자동 관리</h2><div class="grid"><div><label>품절·가격 확인 간격(시간, 0=끔)</label><input name="sync_hours" value="{oc.get('sync_hours', 3)}"></div></div>
<label style="display:flex;gap:8px;margin-top:10px"><input type="checkbox" name="auto_soldout" value="1" style="width:auto" {chk('auto_soldout')}> 도매매에서 품절되면 모든 마켓 판매중지, 재입고되면 다시 판매</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="auto_price" value="1" style="width:auto" {chk('auto_price')}> 공급가가 바뀌면 판매가를 다시 계산해 마켓에 반영</label>
<p class="mut">도매매 아이디·비밀번호 연결은 <a href="/suppliers">도매매</a> 화면에서 합니다. 상품은 <a href="/suppliers/csv">CSV 넣기</a>로 올립니다.</p></div>
{'<button class="btn">위탁 설정 저장</button>' if adm else ''}</fieldset></form>"""
    return page("위탁 설정", body, h.user, "/sell", h.flash, h.flash_err)

@route("POST", "/sell/consign", admin=True)
def sell_consign_post(h):
    f = h.form()
    data = parse_policy(f, "위탁 기본"); data.update({"landed_mult": 1, "pack_cost": 0})
    pid = consign_policy_id()
    if pid:
        x("UPDATE policies SET data=? WHERE id=?", (json.dumps(data, ensure_ascii=False), pid))
    else:
        x("INSERT INTO policies(name, data) VALUES(?,?)", ("위탁 기본", json.dumps(data, ensure_ascii=False)))
    oc = oc_conf()
    oc.update({"sync_hours": num(f.get("sync_hours"), float) or 0, "auto_soldout": f.get("auto_soldout") == "1",
               "auto_price": f.get("auto_price") == "1", "auto_order": False})
    set_setting("domeggook", oc)
    log(h.user["username"], "위탁 설정 저장", desc(pricing._merge(data)))
    go("/sell/consign", "위탁 설정을 저장했습니다. 이미 올린 위탁 상품은 등록현황에서 골라 '반영'을 누르면 새 가격으로 바뀝니다.")

@route("GET", "/sell/own")
def sell_own(h):
    adm = h.user["role"] == "admin"; c = pricing.cfg()
    n = q("SELECT COUNT(*) FROM products WHERE COALESCE(supply_type,'사입')<>'위탁'", one=True)[0]
    body = f"""<h1>판매설정</h1>{sell_tabs("own")}{'' if adm else '<div class="flash err">관리자만 바꿀 수 있습니다.</div>'}
<form method="post" action="/sell/own"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0">
<div class="card"><h2>📦 사입 판매 가격 (사입 상품 {n}개)</h2><p class="mut">원가 = 사입 단가(위안×환율 또는 원화) × 부대비용 배수(해운·통관·관세) + 포장비 + 택배비.</p>{policy_form(c, "own")}{sell_example(c, False)}</div>
<div class="card"><h2>사입 재고</h2><select name="auto_soldout_stock" style="max-width:420px"><option value="1">켜기: 재고 0이면 모든 판매처 자동 품절, 재고 넣으면 자동 재개</option><option value="0" {'' if get_setting('auto_soldout_stock', True) else 'selected'}>끄기</option></select>
<p class="mut">사입 상품은 주문이 들어올 때마다 재고가 자동으로 줄어듭니다. 송장 입력은 <a href="/fulfill">발주·송장</a>에서 합니다.</p></div>
{'<button class="btn">사입 설정 저장</button>' if adm else ''}</fieldset></form>"""
    return page("사입 설정", body, h.user, "/sell", h.flash, h.flash_err)

@route("POST", "/sell/own", admin=True)
def sell_own_post(h):
    f = h.form()
    set_setting("pricing", parse_policy(f, "사입 기본"))
    set_setting("auto_soldout_stock", f.get("auto_soldout_stock", "1") == "1")
    log(h.user["username"], "사입 설정 저장", desc(pricing.cfg()))
    go("/sell/own", "사입 설정을 저장했습니다")

@route("GET", "/policies")
def policies_page(h):
    rows = q("SELECT * FROM policies ORDER BY id")
    cnt = {r[0]: r[1] for r in q("SELECT policy_id, COUNT(*) FROM products GROUP BY policy_id")}
    trs = f"<tr><td><a href='/sell/own'><b>사입 기본</b></a></td><td>{cnt.get(None, 0)}</td><td>{e(desc(pricing.cfg()))}</td></tr>"
    trs += "".join(f"<tr><td><a href='{'/sell/consign' if r['name'] == '위탁 기본' else '/policies/' + str(r['id'])}'><b>{e(r['name'])}</b></a></td><td>{cnt.get(r['id'], 0)}</td><td>{e(desc(pricing._merge(json.loads(r['data']))))}</td></tr>" for r in rows)
    return page("가격 정책", f"""<h1>가격 정책</h1><div class="row" style="margin-bottom:12px"><a class="btn" href="/policies/new">+ 정책 만들기</a></div>
<div class="card tbl"><table><tr><th>정책</th><th>상품 수</th><th>내용</th></tr>{trs}</table></div>
<p class="mut">예: '저가 소모품' 정책은 원가 대비 300%, '선물용' 정책은 정액 6,000원처럼 나눠 두고, 상품 목록에서 여러 개 골라 한 번에 적용합니다.</p>""", h.user, "/policies", h.flash, h.flash_err)

def desc(c):
    unit = "원" if c["margin_mode"] == "won" else "%"
    mm = ", ".join(f"{chs.label(k)} {v:g}{unit}" for k, v in c["market_margin"].items() if v not in (None, ""))
    return f"{pricing.MODE_LABEL[c['margin_mode']]} {c['margin']:g}{unit}" + (f" (판매처별: {mm})" if mm else "")

@route("GET", r"/policies/(new|\d+)")
def policy_get(h, pid):
    r = None if pid == "new" else q("SELECT * FROM policies WHERE id=?", (pid,), one=True)
    c = pricing._merge(json.loads(r["data"])) if r else pricing.cfg()
    adm = h.user["role"] == "admin"
    delb = '<button class="btn red" name="do" value="delete" onclick="return confirm(\'정책을 지울까요? 쓰던 상품은 기본 정책으로 바뀝니다\')">삭제</button>' if r and adm else ""
    return page("가격 정책", f"""<h1>가격 정책</h1><form method="post" class="card"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0"><label>정책 이름</label><input name="pname" value="{e(r['name'] if r else '')}" required>
{policy_form(c)}<br><div class="row">{'<button class="btn" name="do" value="save">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}{delb}</div></fieldset></form>""", h.user, "/policies", h.flash, h.flash_err)

@route("POST", r"/policies/(new|\d+)", admin=True)
def policy_post(h, pid):
    f = h.form()
    if f.get("do") == "delete" and pid != "new":
        x("UPDATE products SET policy_id=NULL WHERE policy_id=?", (pid,)); x("DELETE FROM policies WHERE id=?", (pid,))
        go("/policies", "정책을 지웠습니다")
    data = json.dumps(parse_policy(f, f["pname"]), ensure_ascii=False)
    if pid == "new":
        pid = x("INSERT INTO policies(name, data) VALUES(?,?)", (f["pname"], data))
    else:
        x("UPDATE policies SET name=?, data=? WHERE id=?", (f["pname"], data, pid))
    log(h.user["username"], "가격 정책 저장", f["pname"])
    go("/policies", "저장했습니다")

# ---------- 판매처(국내·해외 자유 추가) ----------
CH_FIELDS = [("name", "판매처 이름"), ("fee", "수수료 %"), ("margin", "판매처 기본 마진(비우면 정책값)"), ("ship", "택배·국제배송비(원, 비우면 정책값)"),
             ("fx", "환율(1 통화 = 원)"), ("round_to", "올림 단위(판매처 통화)"), ("ending", "끝자리(900 / .99 / .90 / 0 / 비움)"), ("name_max", "상품명 최대 글자 수"), ("sort", "표시 순서")]

def ch_row_desc(c):
    m = "정책값" if c["margin"] is None else f"{c['margin']:g}"
    s = "정책값" if c["ship"] is None else f"{c['ship']:,.0f}원"
    cur = "원화" if c["currency"] == "KRW" else f"{c['currency']} (1 = {c['fx']:g}원)"
    return m, s, cur

@route("GET", "/channels")
def channels_page(h):
    adm = h.user["role"] == "admin"
    cnt = {r[0]: r[1] for r in q("SELECT channel, COUNT(*) FROM listings GROUP BY channel")}
    trs = ""
    pc = pricing.cfg()
    unit = "원" if pc["margin_mode"] == "won" else "%"
    fv = lambda x_: "" if x_ is None else f"{x_:g}"
    for c in chs.all_channels(False):
        m, s, cur = ch_row_desc(c)
        exp = f'<a class="btn sm gray" href="/channels/{c["id"]}/export.csv">엑셀 받기</a>' if not c["api"] else ""
        if adm:
            cells = (f"<td><input name='fee_{c['id']}' value='{fv(c['fee'])}' style='width:80px'></td>"
                     f"<td><input name='margin_{c['id']}' value='{fv(c['margin'])}' placeholder='정책 {pc['margin']:g}' style='width:100px'></td>"
                     f"<td><input name='ship_{c['id']}' value='{fv(c['ship'])}' placeholder='정책 {pc['ship_cost']:,.0f}' style='width:100px'></td>")
        else:
            cells = f"<td>{c['fee']:g}%</td><td>{m}</td><td>{s}</td>"
        trs += (f"<tr><td><a href='/channels/{c['id']}'><b>{e(c['name'])}</b></a>{'' if c['active'] else ' <span class=tag>꺼짐</span>'}<div class='mut'>{chs.API_LABEL.get(c['api'] or '', c['api'])} · <a href='/channels/{c['id']}'>통화·환율 등 더보기</a></div></td>"
                f"{cells}<td>{cur}</td><td>{c['name_max']}자</td><td>{cnt.get(c['code'], 0)} {exp}</td></tr>")
    presets = "".join(f'<option value="{i}">{e(p[0])} (수수료 {p[1]:g}% · {p[2]})</option>' for i, p in enumerate(chs.PRESETS))
    add = f"""<div class="card"><h2>판매처 추가</h2><form method="post" action="/channels/new" class="row">
<select name="preset" style="max-width:340px"><option value="">직접 입력(빈 칸에서 시작)</option>{presets}</select><button class="btn">+ 추가</button></form>
<p class="mut">예시 값(수수료·환율)은 대략적인 추정치입니다. 추가한 뒤 실제 계약 수수료와 오늘 환율로 고쳐 주세요. 이름은 '해외쇼핑몰1'처럼 마음대로 바꿔도 됩니다.</p></div>""" if adm else ""
    tbl = f"""<div class="card"><div class="tbl"><table><tr><th>판매처</th><th>수수료 %</th><th>기본 마진({unit})</th><th>배송비(원)</th><th>통화</th><th>상품명</th><th>등록 상품</th></tr>{trs}</table></div>"""
    if adm:
        tbl = f"""<form method="post" action="/channels/quick">{tbl}<br><button class="btn">수수료·마진·배송비 저장</button>
<p class="mut">빈 칸은 가격 정책 값(마진 {pc['margin']:g}{unit}, 배송비 {pc['ship_cost']:,.0f}원)을 씁니다. 상품마다 따로 정하려면 상품 화면의 '판매가 계산' 표에 넣으세요.</p></div></form>"""
    else:
        tbl += "</div>"
    body = f"""<h1>판매처</h1>{add}{tbl}
<div class="card"><h2>어떻게 쓰나요</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>네이버·쿠팡·지마켓·옥션은 <a href="/accounts">마켓 계정</a>에 API 키를 넣으면 바로 등록됩니다.</li>
<li>그 밖의 판매처(아마존·쇼피·큐텐·11번가·자사몰 등)는 여기서 추가하고 수수료·마진·통화를 정합니다.</li>
<li>상품 목록에서 상품을 골라 그 판매처에 체크 → <b>선택 판매처에 등록</b>.</li>
<li>이 화면의 <b>엑셀 받기</b>로 상품명·판매가(그 나라 통화)·재고·사진 주소·상세페이지가 든 파일을 받아 각 사이트 대량등록 메뉴에 올립니다.</li></ol>
<p class="mut">판매가는 (총원가 + 마진) ÷ (1 − 수수료)를 원화로 계산한 뒤 환율로 나눠 그 나라 통화로 바꾸고, 올림 단위·끝자리에 맞춥니다. 마진 우선순위: 상품 개별 > 가격 정책의 판매처별 > 판매처 기본 > 정책 기본.</p></div>"""
    return page("판매처", body, h.user, "/channels", h.flash, h.flash_err)

@route("POST", "/channels/quick", admin=True)
def channel_quick(h):
    f = h.form()
    n = 0
    for c in chs.all_channels(False):
        if f"fee_{c['id']}" not in f:
            continue
        fee = num(f.get(f"fee_{c['id']}"), float)
        x("UPDATE channels SET fee=?, margin=?, ship=? WHERE id=?",
          (c["fee"] if fee is None else fee, num(f.get(f"margin_{c['id']}"), float), num(f.get(f"ship_{c['id']}"), float), c["id"]))
        n += 1
    log(h.user["username"], "판매처 수수료·마진·배송비 저장", f"{n}곳")
    go("/channels", "저장했습니다. 이미 올린 상품에 반영하려면 상품 목록에서 '등록된 마켓 가격 동기화'를 누르세요.")

@route("POST", "/channels/new", admin=True)
def channel_new(h):
    f = h.form()
    i = num(f.get("preset"), int)
    if i is not None and 0 <= i < len(chs.PRESETS):
        name, fee, cur, fx, rt, end, nm = chs.PRESETS[i]
    else:
        n = q("SELECT COUNT(*) FROM channels WHERE api='' OR api IS NULL", one=True)[0] + 1
        name, fee, cur, fx, rt, end, nm = f"해외쇼핑몰{n}", 10, "USD", 1400, 0.01, ".99", 100
    sort = (q("SELECT MAX(sort) FROM channels", one=True)[0] or 0) + 1
    cid = x("INSERT INTO channels(code,name,api,fee,currency,fx,round_to,ending,name_max,active,sort) VALUES(?,?,?,?,?,?,?,?,?,1,?)",
            ("tmp" + uuid.uuid4().hex[:6], name, "", fee, cur, fx, rt, end, nm, sort))
    x("UPDATE channels SET code=? WHERE id=?", (f"ch{cid}", cid))
    log(h.user["username"], "판매처 추가", name)
    go(f"/channels/{cid}", f"'{name}' 판매처를 추가했습니다. 수수료·마진·환율을 확인하고 저장하세요.")

@route("GET", r"/channels/(\d+)")
def channel_get(h, cid):
    c = q("SELECT * FROM channels WHERE id=?", (cid,), one=True)
    if not c:
        go("/channels", "판매처가 없습니다", True)
    adm = h.user["role"] == "admin"
    builtin = bool(c["api"])
    v = lambda x_: "" if x_ is None else (f"{x_:g}" if isinstance(x_, float) else e(str(x_)))
    inputs = ""
    for k, lab in CH_FIELDS:
        if builtin and k in ("fx", "round_to", "ending"):
            continue
        inputs += f'<div><label>{lab}</label><input name="{k}" value="{v(c[k])}"></div>'
    curs = "".join(f'<option value="{k}" {"selected" if c["currency"] == k else ""}>{k} {n}</option>' for k, n in chs.CURRENCIES)
    cur = "" if builtin else f'<div><label>통화</label><select name="currency">{curs}</select></div>'
    act = f'<div><label>사용</label><select name="active"><option value="1">켜기</option><option value="0" {"" if c["active"] else "selected"}>끄기(목록·가격 계산에서 숨김)</option></select></div>'
    delb = "" if builtin or not adm else '<button class="btn red" name="do" value="delete" onclick="return confirm(\'판매처를 지울까요? 등록 기록도 같이 지워집니다\')">삭제</button>'
    note = ("<p class='mut'>API로 바로 등록하는 판매처라 원화·올림 단위는 가격 정책을 따릅니다. 수수료·기본 마진·배송비·상품명 길이만 바꿀 수 있습니다.</p>" if builtin else
            "<p class='mut'>예: 아마존 미국이면 통화 USD, 환율 1400, 올림 단위 0.01, 끝자리 .99 → 12.99달러처럼 맞춥니다. 일본은 JPY, 올림 단위 10, 끝자리 0.</p>")
    sample = ""
    p = q("SELECT * FROM products ORDER BY id DESC LIMIT 1", one=True)
    if p:
        b = pricing.breakdown(p, c)
        sample = f"<p>예시: <b>{e(p['name'])}</b> → 판매가 <b>{b['price_text']}</b> (원화 ≈{b['price_krw']:,}원, 이익 {b['profit']:,}원, 원가 대비 {b['margin_on_cost']}%)</p>"
    body = f"""<h1>{e(c['name'])}</h1><form method="post" class="card"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0">
<div class="mut">{chs.API_LABEL.get(c['api'] or '', c['api'])}</div><div class="grid">{inputs}{cur}{act}</div>{note}{sample}
<div class="row">{'<button class="btn" name="do" value="save">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}{delb}<a class="btn gray" href="/channels">목록</a></div></fieldset></form>"""
    return page(c["name"], body, h.user, "/channels", h.flash, h.flash_err)

@route("POST", r"/channels/(\d+)", admin=True)
def channel_post(h, cid):
    c = q("SELECT * FROM channels WHERE id=?", (cid,), one=True)
    if not c:
        go("/channels", "판매처가 없습니다", True)
    f = h.form()
    if f.get("do") == "delete" and not c["api"]:
        x("DELETE FROM listings WHERE channel=? AND account_id IS NULL", (c["code"],))
        x("DELETE FROM channels WHERE id=?", (cid,))
        log(h.user["username"], "판매처 삭제", c["name"])
        go("/channels", "지웠습니다")
    g = lambda k, d=None: num(f.get(k), float) if num(f.get(k), float) is not None else d
    vals = {"name": (f.get("name") or c["name"]).strip(), "fee": g("fee", c["fee"]), "margin": g("margin"), "ship": g("ship"),
            "name_max": int(g("name_max", c["name_max"] or 100)), "sort": int(g("sort", c["sort"] or 0)), "active": 1 if f.get("active", "1") == "1" else 0}
    if not c["api"]:
        vals.update({"currency": f.get("currency", "KRW"), "fx": 1 if f.get("currency") == "KRW" else g("fx", c["fx"] or 1),
                     "round_to": g("round_to", c["round_to"] or 100), "ending": (f.get("ending") or "").strip()})
    x(f"UPDATE channels SET {', '.join(k + '=?' for k in vals)} WHERE id=?", (*vals.values(), cid))
    log(h.user["username"], "판매처 저장", f"{vals['name']} 수수료 {vals['fee']:g}%")
    go(f"/channels/{cid}", "저장했습니다")

@route("GET", r"/channels/(\d+)/export\.csv")
def channel_export(h, cid):
    c = q("SELECT * FROM channels WHERE id=?", (cid,), one=True)
    if not c:
        go("/channels", "판매처가 없습니다", True)
    host = h.headers.get("Host", "localhost:8765")
    base = ("https://" if h.headers.get("X-Forwarded-Proto") == "https" else "http://") + host
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["상품번호", "상품명", f"판매가({c['currency']})", "원화 환산", "재고", "상태", "대표 이미지", "추가 이미지", "테마", "검색어", "세트 구성", "원문 상품명", "소싱 링크", "상세페이지 HTML"])
    rows = q("SELECT l.id lid, l.price lprice, l.stock lstock, l.status lstatus, p.* FROM listings l JOIN products p ON p.id=l.product_id WHERE l.channel=? AND l.account_id IS NULL ORDER BY l.id", (c["code"],))
    for r in rows:
        imgs = [i if i.startswith("http") else base + "/img/" + quote(i) for i in img_list(r)]
        price = r["lprice"]
        fx = c["fx"] if c["currency"] != "KRW" else 1
        w.writerow([r["id"], naming.process(r["name"], c["code"]), price, round(float(price or 0) * float(fx or 1)), 0 if r["lstatus"] in ("품절", "판매중지") else r["lstock"],
                    r["lstatus"], imgs[0] if imgs else "", " ".join(imgs[1:]), r["theme"] or "", r["keyword"] or "", r["set_desc"] or "",
                    r["source_name"] or "", r["source_url"] or "", (r["detail_html"] or "").replace("/img/", base + "/img/")])
    x("UPDATE listings SET status='엑셀 내보냄', updated=? WHERE channel=? AND account_id IS NULL AND status='엑셀 대기'", (time.time(), c["code"]))
    log(h.user["username"], "판매처 엑셀 받기", f"{c['name']} {len(rows)}개")
    h.extra_headers = {"Content-Disposition": f"attachment; filename*=UTF-8''{quote(c['name'])}_{time.strftime('%Y%m%d')}.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿" + buf.getvalue()

# ---------- 도매매 위탁 ----------
from . import domeggook as ocmod
from . import couriers

def oc_conf():
    return get_setting("domeggook", {}) or {}

def consign_policy_id():
    r = q("SELECT id FROM policies WHERE name='위탁 기본'", one=True)
    return r["id"] if r else None

def import_items(items, split, policy_id, user):
    """도매매 상품 → 우리 상품(위탁). 같은 코드·옵션이 있으면 정보만 갱신"""
    made, updated = 0, 0
    for it in items:
        if not it or not it.get("key"):
            continue
        opts = it.get("options") or []
        if split and len(opts) > 1:
            picks = opts
        else:
            live = [o for o in opts if (o.get("quantity") or 0) > 0]
            picks = [(live or opts)[0]] if opts else [None]
        for o in picks:
            vals = [a.get("value") for a in (o or {}).get("optionAttributes") or []]
            otext = " / ".join(str(v) for v in vals)
            name = it.get("name") or it["key"]
            if split and len(opts) > 1 and otext:
                name = f"{name} {otext}"
            price = ocmod.price_of(it, vals)
            stock = int((o or {}).get("quantity") or 0) if o else 99
            soldout = ocmod.is_soldout(it, vals or None)
            imgs = ocmod.images_of(it)
            old = q("SELECT * FROM products WHERE supplier='domeggook' AND supplier_key=? AND COALESCE(supplier_option,'')=?", (it["key"], otext), one=True)
            if old:
                x("UPDATE products SET supply_price=?, cost_krw=?, supply_ship=?, fixed_price=?, supplier_status=?, supplier_checked=?, stock=? WHERE id=?",
                  (price, price, it.get("shippingFee"), it.get("fixedPrice") or None, "품절" if soldout else "판매중", time.time(), 0 if soldout else min(stock, 999), old["id"]))
                updated += 1
                continue
            x("""INSERT INTO products(name,theme,keyword,source_name,source_url,cost_krw,set_qty,set_desc,stock,images,detail_html,status,updated,updated_by,
                   supply_type,supplier,supplier_key,supplier_option,supply_price,supply_ship,fixed_price,supplier_status,supplier_checked,policy_id)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
              (name, "위탁", "", it.get("name"), ocmod.item_url(it['key'], oc_conf().get('market', 'supply')), price, 1, otext,
               0 if soldout else min(stock, 999), json.dumps(imgs, ensure_ascii=False), it.get("content") or None, "품절" if soldout else "준비",
               time.time(), user, "위탁", "domeggook", it["key"], otext, price, it.get("shippingFee"), it.get("fixedPrice") or None,
               "품절" if soldout else "판매중", time.time(), policy_id))
            made += 1
    log(user, "도매매 상품 가져오기", f"새로 {made}개, 갱신 {updated}개")
    return made, updated

def sync_domeggook(user="자동"):
    """위탁 상품의 공급가·품절을 도매매에서 다시 읽어 반영"""
    c = oc_conf()
    oc = ocmod.OwnerClan()
    rows = q("SELECT * FROM products WHERE supply_type='위탁' AND supplier='domeggook' AND supplier_key!=''")
    if not rows:
        return "위탁 상품이 없습니다"
    items = {it["key"]: it for it in oc.items(sorted({r["supplier_key"] for r in rows})) if it}
    changed, out, back, gone, errs = 0, 0, 0, 0, []
    held = 0
    for p in rows:
        it = items.get(p["supplier_key"])
        if not it:
            gone += 1
            continue
        vals = [v.strip() for v in (p["supplier_option"] or "").split("/") if v.strip()]
        price = ocmod.price_of(it, vals or None)
        soldout = ocmod.is_soldout(it, vals or None)
        oldp = float(p["supply_price"] or 0)
        if oldp > 0 and price > 0 and abs(price / oldp - 1) > 0.3:
            # 공급가가 한 번에 30% 넘게 바뀌면 자동으로 덮어쓰지 않고 보류 (판매가가 갑자기 변하는 것을 막음)
            held += 1
            log(user, "도매매 가격 급변 보류", f"{p['name']} {oldp:,.0f} → {price:,.0f}원 (적용 안 함, 확인 필요)")
            x("UPDATE products SET supplier_status=?, supplier_checked=? WHERE id=?", ("품절" if soldout else "판매중", time.time(), p["id"]))
            if soldout and p["status"] != "품절(공급처)" and c.get("auto_soldout", True):
                _, ms = push_listings(p["id"], "soldout", "품절(공급처)"); errs += ms; out += 1
            continue
        price_changed = abs(float(p["supply_price"] or 0) - price) >= 1 or (it.get("shippingFee") is not None and float(p["supply_ship"] or 0) != float(it.get("shippingFee") or 0))
        x("UPDATE products SET supply_price=?, cost_krw=?, supply_ship=?, fixed_price=?, supplier_status=?, supplier_checked=? WHERE id=?",
          (price, price, it.get("shippingFee") if it.get("shippingFee") is not None else p["supply_ship"], it.get("fixedPrice") or p["fixed_price"],
           "품절" if soldout else "판매중", time.time(), p["id"]))
        if price_changed:
            changed += 1
            log(user, "도매매 가격 변경", f"{p['name']} {p['supply_price'] or 0:,.0f} → {price:,.0f}원")
            if c.get("auto_price", True) and not soldout:
                _, ms = push_listings(p["id"], "sync"); errs += ms
        if soldout and p["status"] != "품절(공급처)" and c.get("auto_soldout", True):
            _, ms = push_listings(p["id"], "soldout", "품절(공급처)"); errs += ms
            out += 1
            log(user, "도매매 품절 → 판매중지", p["name"])
        elif not soldout and p["status"] == "품절(공급처)" and c.get("auto_soldout", True):
            x("UPDATE products SET stock=?, status='등록' WHERE id=?", (99, p["id"]))
            _, ms = push_listings(p["id"], "resume"); errs += ms
            back += 1
            log(user, "도매매 재입고 → 판매 재개", p["name"])
    msg = f"{len(rows)}개 확인 · 가격 변경 {changed} · 품절로 판매중지 {out} · 재입고로 재개 {back}" + (f" · 도매매에서 못 찾음 {gone}" if gone else "") + (f" · 가격 급변 보류 {held}" if held else "")
    log(user, "도매매 동기화", msg + ("; " + "; ".join(errs)[:400] if errs else ""))
    if out or back or changed:
        notify.send("도매매 품절·가격 변경", msg, "soldout")
    set_setting("domeggook_last_sync", time.time())
    return msg + ("\n" + "\n".join(errs[:20]) if errs else "")

def place_order(o, user):
    """위탁 주문 1건을 도매매에 발주"""
    p = q("SELECT * FROM products WHERE id=?", (o["product_id"],), one=True) if o["product_id"] else None
    if not p or (p["supply_type"] or "") != "위탁" or not p["supplier_key"]:
        raise ocmod.OCError("도매매 상품번호가 연결되지 않은 주문입니다(상품 화면에서 위탁·상품번호를 넣어 주세요)")
    rcv = json.loads(o["rcv"] or "{}")
    for k, lab in (("name", "받는 분"), ("phone", "연락처"), ("zip", "우편번호"), ("addr1", "주소")):
        if not rcv.get(k):
            raise ocmod.OCError(f"주문에 {lab}이(가) 없습니다")
    vals = [v.strip() for v in (p["supplier_option"] or "").split("/") if v.strip()]
    qty = int(o["qty"] or 1) * int(p["set_qty"] or 1)
    oc = ocmod.OwnerClan(force_dry=False)
    inp = oc.order_input([(p["supplier_key"], vals, qty)], rcv, rcv.get("memo", ""))
    r = oc.create_order(inp)
    x("UPDATE orders SET po_status=?, po_key=?, po_msg=? WHERE id=?",
      ("발주완료(미리보기)" if r.get("dry") else "발주완료", r["key"], os.path.basename(r.get("file", "")) if r.get("dry") else "", o["id"]))
    log(user, "도매매 발주" + (" 미리보기" if r.get("dry") else ""), f"{p['name']} ×{qty} → {r['key']}")
    return r

def auto_place_orders(user="자동"):
    """자동 주문 ON. 도매매 주문 API가 설정돼 있으면 직접 주문하고, 없으면 폰으로 알리고 주문용 목록에 모음(주문한 것처럼 표시하지 않음)."""
    rows = q("SELECT o.*, p.source_url FROM orders o LEFT JOIN products p ON p.id=o.product_id WHERE o.po_status='발주대기' AND o.supply_type='위탁' AND COALESCE(o.po_msg,'')=''")
    if not rows:
        return
    if ocmod.Dome.order_api_ready():
        done, fail = [], []
        for o in rows:
            try:
                r = place_order(o, user)
                done.append(f"{o['product_name'] or ''} ×{o['qty'] or 1} → 도매매 주문번호 {r['key']}")
            except Exception as ex:
                x("UPDATE orders SET po_status='발주실패', po_msg=? WHERE id=?", (str(ex)[:500], o["id"]))
                fail.append(f"{o['product_name'] or ''}: {ex}"[:150])
        if done:
            notify.send(f"도매매 자동 주문 {len(done)}건 완료", "\n".join(done[:15]), "order")
        if fail:
            notify.send(f"도매매 자동 주문 실패 {len(fail)}건", "\n".join(fail[:10]) + "\n발주·송장 화면에서 확인하세요", "order")
        return
    lines = []
    for o in rows:
        r = json.loads(o["rcv"] or "{}")
        lines.append(f"{o['product_name'] or ''} ×{o['qty'] or 1} → {r.get('name', '')} {r.get('addr1', '')}"[:120])
        x("UPDATE orders SET po_msg='주문 알림 보냄' WHERE id=?", (o["id"],))
    notify.send(f"도매매 주문 필요 {len(rows)}건", "\n".join(lines[:15]) + "\n발주·송장 화면에서 도매매 주문용 CSV를 받아 도매매에 넣으세요", "order")

def send_tracking(o, user):
    """송장을 마켓에 보내고 발송완료로"""
    if not o["tracking"]:
        raise MarketError("송장번호가 없습니다")
    acc = q("SELECT * FROM accounts WHERE id=?", (o["account_id"],), one=True) if o["account_id"] else None
    if not acc:   # 예시 주문 등
        x("UPDATE orders SET po_status='발송완료(예시)', shipped_at=? WHERE id=?", (time.time(), o["id"]))
        return
    code = couriers.code(o["courier"], acc["market"])
    if not code:
        raise MarketError(f"택배사 '{o['courier']}'의 {MARKETS[acc['market']].name} 코드를 모릅니다")
    m = market_for(acc)
    r = m.ship(json.loads(o["ship_ref"] or "{}"), code, o["tracking"])
    x("UPDATE orders SET po_status=?, shipped_at=?, po_msg=? WHERE id=?",
      ("발송완료(미리보기)" if isinstance(r, dict) and r.get("dry") else "발송완료", time.time(), "", o["id"]))
    log(user, "송장 전송", f"{MARKETS[acc['market']].name} {o['order_id']} {o['courier']} {o['tracking']}")

def check_tracking(user="자동"):
    """도매매 발주 건의 송장을 확인해 마켓으로 보냄"""
    oc = ocmod.OwnerClan()
    got, sent, errs = 0, 0, []
    for o in q("SELECT * FROM orders WHERE po_status IN ('발주완료','발주완료(미리보기)','송장받음') AND po_key!=''"):
        try:
            if o["po_status"] != "송장받음":
                od = oc.order(o["po_key"])
                tr = next((pp for pp in (od.get("products") or []) if pp.get("trackingNumber")), None)
                if not tr:
                    continue
                x("UPDATE orders SET courier=?, tracking=?, po_status='송장받음' WHERE id=?",
                  (tr.get("shippingCompanyName") or tr.get("shippingCompanyCode") or "", tr["trackingNumber"], o["id"]))
                got += 1
                o = q("SELECT * FROM orders WHERE id=?", (o["id"],), one=True)
            send_tracking(o, user)
            sent += 1
        except Exception as ex:
            errs.append(f"{o['order_id']}: {ex}")
            x("UPDATE orders SET po_msg=? WHERE id=?", (str(ex)[:500], o["id"]))
    if got or sent or errs:
        log(user, "송장 확인", f"새 송장 {got} · 마켓 전송 {sent}" + ("; " + "; ".join(errs)[:400] if errs else ""))
    return got, sent, errs

def purge_personal():
    """발송 끝난 지 90일 지난 주문의 받는 분 정보 지우기"""
    x("UPDATE orders SET rcv='{}', buyer='' WHERE shipped_at IS NOT NULL AND shipped_at < ? AND rcv!='{}'", (time.time() - 90 * 86400,))

def mask(name):
    name = name or ""
    return name[:1] + "*" * max(0, len(name) - 2) + name[-1:] if len(name) > 1 else name

@route("GET", "/suppliers")
def suppliers_page(h):
    c = oc_conf(); adm = h.user["role"] == "admin"
    last = get_setting("domeggook_last_sync")
    n = q("SELECT COUNT(*) FROM products WHERE supply_type='위탁'", one=True)[0]
    pol_opts = "".join(f'<option value="{i}" {"selected" if i == consign_policy_id() else ""}>{e(nm)}</option>' for i, nm in pricing.policies())
    chk = lambda k, d=True: "checked" if c.get(k, d) else ""
    results = ""
    if h.qs.get("q"):
        try:
            its = ocmod.OwnerClan().search(h.qs["q"], 50, num(h.qs.get("min"), int), num(h.qs.get("max"), int))
            results = "".join(f"<tr><td><input type='checkbox' name='key' value='{e(it['key'])}' style='width:auto'></td><td>{e(it['key'])}</td><td>{e(it.get('name') or '')}</td>"
                              f"<td>{float(it.get('price') or 0):,.0f}원</td><td>{len(it.get('options') or [])}</td><td>{'품절' if ocmod.is_soldout(it) else '판매중'}</td></tr>" for it in its)
            results = f"""<form method="post" action="/suppliers/import" data-busy><div class="tbl"><table><tr><th><input type="checkbox" data-all="key" style="width:auto"></th><th>코드</th><th>상품명</th><th>공급가</th><th>옵션</th><th>상태</th></tr>{results or '<tr><td colspan=6>결과 없음</td></tr>'}</table></div>
<input type="hidden" name="policy_id" value="{consign_policy_id() or ''}"><label style="display:inline-flex;gap:6px;margin:10px 0"><input type="checkbox" name="split" value="1" style="width:auto"> 옵션마다 상품을 따로 만들기</label><br><button class="btn green">선택 상품 가져오기</button></form>"""
        except Exception as ex:
            results = f'<div class="flash err">{e(str(ex))}</div>'
    raw = get_setting("domeggook_last_raw") or ""
    setform = f"""<div class="card"><h2>도매매 연결</h2><form method="post" action="/suppliers/save"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0"><div class="grid">
<div><label>도매매 오픈API 키 {'(저장됨, 바꿀 때만 입력)' if c.get('api_key') else ''}</label><input name="api_key" type="password" autocomplete="off"></div>
<div><label>가져올 곳</label><select name="market"><option value="supply" {'selected' if c.get('market', 'supply') == 'supply' else ''}>도매매 (위탁·1개부터)</option><option value="dome" {'selected' if c.get('market') == 'dome' else ''}>도매꾹 (도매가)</option></select></div>
<div><label>품절·가격 확인 간격(시간, 0=끔)</label><input name="sync_hours" value="{c.get('sync_hours', 3)}"></div></div>
<label style="display:flex;gap:8px;margin-top:10px"><input type="checkbox" name="auto_soldout" value="1" style="width:auto" {chk('auto_soldout')}> 도매매에서 품절되면 모든 마켓 판매중지, 재입고되면 다시 판매</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="auto_price" value="1" style="width:auto" {chk('auto_price')}> 공급가가 바뀌면 판매가를 다시 계산해 마켓에 반영</label>
<br>{'<button class="btn">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}</fieldset></form>
<form method="post" action="/suppliers/test" class="row" style="margin-top:8px" data-busy><button class="btn gray">연결 확인</button></form>
<form method="post" action="/suppliers/revert" class="row" style="margin-top:8px" data-busy onsubmit="return confirm('최근 3일 동기화에서 공급가가 30% 넘게 바뀐 상품을 이전 값으로 되돌릴까요?')"><button class="btn gray">급변한 공급가 되돌리기</button></form>
<p class="mut">키 받는 곳: 도매꾹·도매매 공용 오픈API(openapi.domeggook.com) → 로그인 후 API 키 발급 → API 키 발급. 키가 없으면 미리보기 모드로 예시 상품만 보입니다.
도매매은 구매(발주) API가 없어서, 주문이 들어오면 <a href="/fulfill">발주·송장</a>에서 도매매 상품 링크를 눌러 직접 주문하고 송장을 넣습니다.</p>
{('<details><summary class="mut" style="cursor:pointer">마지막 도매매 응답 보기(연동 확인용)</summary><pre style="white-space:pre-wrap;font-size:11px;max-height:300px;overflow:auto">' + e(raw[:3000]) + '</pre></details>') if raw else ''}</div>"""
    oo = get_setting("domeggook_order", {}) or {}
    ordform = f"""<div class="card"><h2>도매매 주문 API 연결 (프라이빗 API를 받으면 여기에 입력)</h2><form method="post" action="/suppliers/order_api"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0">
<p class="mut">상태: <b>{'연결 설정됨 — 자동 주문을 켜면 이 양식대로 도매매에 주문합니다' if ocmod.Dome.order_api_ready() else '아직 비어 있음(비어 있으면 자동 주문은 폰 알림·주문용 목록만 합니다)'}</b></p>
<div class="grid"><div><label>주문 API 주소(URL)</label><input name="url" value="{e(oo.get('url', ''))}" placeholder="https://..."></div>
<div><label>방식</label><select name="method"><option {'selected' if oo.get('method', 'POST') == 'POST' else ''}>POST</option><option {'selected' if oo.get('method') == 'GET' else ''}>GET</option></select></div>
<div><label>본문 형식</label><select name="body_type"><option value="json" {'selected' if oo.get('body_type', 'json') == 'json' else ''}>JSON</option><option value="form" {'selected' if oo.get('body_type') == 'form' else ''}>폼(a=1&amp;b=2)</option></select></div>
<div><label>키 전달 방법</label><select name="key_in"><option value="query" {'selected' if oo.get('key_in', 'query') == 'query' else ''}>주소 뒤 파라미터</option><option value="header" {'selected' if oo.get('key_in') == 'header' else ''}>헤더</option></select></div>
<div><label>키 이름(파라미터명 또는 헤더명)</label><input name="key_name" value="{e(oo.get('key_name', 'aid'))}"></div>
<div><label>헤더일 때 키 앞에 붙일 말(예: Bearer )</label><input name="key_prefix" value="{e(oo.get('key_prefix', ''))}"></div></div>
<label>요청 본문 양식 — 쓸 수 있는 자리표시: {{code}} 상품번호 · {{qty}} 수량 · {{option}} 옵션 · {{name}} 받는분 · {{phone}} 연락처 · {{zip}} 우편번호 · {{addr1}} 주소 · {{addr2}} 상세주소 · {{memo}} 배송메모</label>
<textarea name="body" style="min-height:120px;font-family:monospace">{e(oo.get('body', ''))}</textarea>
<div class="grid"><div><label>성공 확인 위치(응답 JSON 경로, 예: result.code) — 비워도 됨</label><input name="ok_path" value="{e(oo.get('ok_path', ''))}"></div>
<div><label>성공일 때 값(예: 0 또는 OK)</label><input name="ok_value" value="{e(oo.get('ok_value', ''))}"></div>
<div><label>도매매 주문번호 위치(예: result.orderNo)</label><input name="no_path" value="{e(oo.get('no_path', ''))}"></div></div>
<br>{'<button class="btn">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}</fieldset></form>
{('<details><summary class="mut" style="cursor:pointer">마지막 주문 응답 보기</summary><pre style="white-space:pre-wrap;font-size:11px;max-height:300px;overflow:auto">' + e((get_setting("domeggook_order_last") or "")[:3000]) + '</pre></details>') if get_setting("domeggook_order_last") else ''}</div>"""
    blk = get_setting("domeggook_blocked")
    body = (f'<div class="flash err">도매매 보안이 {time.strftime("%m-%d %H:%M", time.localtime(blk))}에 서버 접속을 막아 자동 품절·가격 확인을 멈춰 두었습니다. 아래 <b>연결 확인</b>이 성공하면 다시 켜집니다. CSV 넣기는 그대로 쓸 수 있습니다.</div>' if blk else "") + f"""<h1>도매매 위탁</h1><div class="grid"><div class="card"><div class="mut">위탁 상품</div><div class="stat">{n}</div></div>
<div class="card"><div class="mut">마지막 품절·가격 확인</div><div class="stat" style="font-size:18px">{time.strftime('%m-%d %H:%M', time.localtime(last)) if last else '아직 없음'}</div>
<form method="post" action="/suppliers/sync" data-busy><button class="btn sm">지금 확인</button></form></div></div>
<div class="card"><h2>도매매 CSV 파일로 자동 등록</h2><p class="mut">도매매에서 받은 상품 파일을 넣으면 상품을 만들고 마켓에 바로 올린 뒤 폰으로 알려 드립니다.</p><a class="btn green" href="/suppliers/csv">CSV 넣기</a></div>
<div class="card"><h2>상품코드로 가져오기</h2><form method="post" action="/suppliers/import" data-busy><label>도매매 상품번호 또는 상품 주소(한 줄에 하나)</label><textarea name="keys" placeholder="12345678&#10;https://domeggook.com/12345678"></textarea>
<div class="row"><div style="flex:1;min-width:180px"><label>가격 정책</label><select name="policy_id">{pol_opts}</select></div>
<label style="display:inline-flex;gap:6px;align-self:flex-end"><input type="checkbox" name="split" value="1" style="width:auto"> 옵션마다 상품을 따로 만들기</label>
<button class="btn green" style="align-self:flex-end">가져오기</button></div></form></div>
<div class="card"><h2>도매매에서 찾기</h2><form class="row"><input name="q" value="{e(h.qs.get('q', ''))}" placeholder="검색어" style="max-width:240px"><input name="min" value="{e(h.qs.get('min', ''))}" placeholder="최저 공급가" style="max-width:120px"><input name="max" value="{e(h.qs.get('max', ''))}" placeholder="최고 공급가" style="max-width:120px"><button class="btn gray">찾기</button></form><br>{results}</div>
{setform}
{ordform}
<div class="card"><h2>사입·위탁 같이 쓰는 법</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>가져온 상품은 '위탁'으로 표시되고 <a href="/sell/consign">위탁 설정</a>(공급가 + 공급처 배송비 기준 마진)으로 판매가를 계산합니다.</li>
<li>상품 목록에서 사입 상품과 똑같이 상세페이지를 만들고 마켓에 올립니다.</li>
<li>주문이 들어오면 <a href="/fulfill">발주·송장</a>에서 위탁 주문은 도매매 발주, 사입 주문은 송장 입력으로 나뉘어 보입니다.</li>
<li>도매매 송장이 나오면 자동으로 받아 마켓에 보냅니다.</li></ol></div>"""
    return page("도매매 위탁", body, h.user, "/suppliers", h.flash, h.flash_err)

@route("POST", "/suppliers/order_api", admin=True)
def suppliers_order_api(h):
    f = h.form()
    keys = ("url", "method", "body_type", "key_in", "key_name", "key_prefix", "body", "ok_path", "ok_value", "no_path")
    c = {k: (f.get(k) or "").strip() if k not in ("key_prefix", "body") else (f.get(k) or "") for k in keys}
    if c["url"] and not c["url"].startswith("https://"):
        go("/suppliers", "주문 API 주소는 https:// 로 시작해야 합니다", True)
    set_setting("domeggook_order", c)
    log(h.user["username"], "도매매 주문 API 설정 저장", c["url"][:80])
    go("/suppliers", "저장했습니다" + (" — 자동 주문을 켜면 이 양식대로 주문합니다" if c["url"] and c["body"] else ""))

@route("POST", "/suppliers/save", admin=True)
def suppliers_save(h):
    f = h.form(); c = oc_conf()
    c.update({"market": f.get("market", "supply"), "sync_hours": num(f.get("sync_hours"), float) or 0,
              "auto_soldout": f.get("auto_soldout") == "1", "auto_price": f.get("auto_price") == "1", "auto_order": False})
    if f.get("api_key", "").strip():
        c["api_key"] = seal(f["api_key"].strip())
    set_setting("domeggook", c); 
    log(h.user["username"], "도매매 설정 저장", c.get("market", "supply"))
    go("/suppliers", "저장했습니다")

@route("POST", "/suppliers/test")
def suppliers_test(h):
    try:
        msg = ocmod.OwnerClan().test()
        set_setting("domeggook_blocked", None)   # 연결되면 자동 확인 다시 켬
        go("/suppliers", msg)
    except ocmod.OCError as ex:
        go("/suppliers", str(ex), True)

def revert_supply(user="자동"):
    """최근 3일 동기화에서 30% 넘게 바뀐 공급가를 이력의 이전 값으로 되돌리고 판매가를 다시 반영. (복구 수, 실패 수)"""
    since = time.time() - 3 * 86400
    n = fail = 0
    seen = set()
    for r in q("SELECT detail FROM logs WHERE action='도매매 가격 변경' AND ts>=? ORDER BY ts ASC", (since,)):
        m = re.match(r"(.+) ([\d,]+) → ([\d,]+)원$", r["detail"] or "")
        if not m:
            continue
        name, o, nw = m.group(1), float(m.group(2).replace(",", "")), float(m.group(3).replace(",", ""))
        if o <= 0 or abs(nw / o - 1) <= 0.3 or name in seen:
            continue
        seen.add(name)
        rows = q("SELECT id FROM products WHERE supplier='domeggook' AND name=? AND ABS(COALESCE(supply_price,0)-?)<1", (name, nw))
        for pr in rows:
            x("UPDATE products SET supply_price=?, cost_krw=? WHERE id=?", (o, o, pr["id"]))
            try:
                _, ms = push_listings(pr["id"], "sync")
                if ms:
                    fail += 1
                else:
                    n += 1
            except Exception:
                fail += 1
    log(user, "공급가 되돌리기", f"{n}개 복구, 실패 {fail}개")
    return n, fail

@route("POST", "/suppliers/revert", admin=True)
def suppliers_revert(h):
    n, fail = revert_supply(h.user["username"])
    go("/suppliers", f"급변한 공급가 {n}개를 이전 값으로 되돌리고 판매가를 다시 반영했습니다" + (f" (실패 {fail}개)" if fail else ""))

@route("POST", "/suppliers/sync")
def suppliers_sync(h):
    try:
        go("/suppliers", sync_domeggook(h.user["username"]))
    except ocmod.OCError as ex:
        go("/suppliers", str(ex), True)

@route("POST", "/suppliers/import")
def suppliers_import(h):
    f = h.form_multi()
    keys = [re.sub(r"\D", "", k.split("/")[-1].split("?")[0]) for k in re.split(r"[\s,]+", " ".join(f.get("keys", [])) + " " + " ".join(f.get("key", []))) if k.strip()]
    keys = [k for k in keys if k]
    if not keys:
        go("/suppliers", "상품코드를 넣거나 골라 주세요", True)
    try:
        items = ocmod.OwnerClan().items(list(dict.fromkeys(keys)))
    except ocmod.OCError as ex:
        go("/suppliers", str(ex), True)
    pol = num((f.get("policy_id") or [""])[0], int) or consign_policy_id()
    made, upd = import_items(items, (f.get("split") or [""])[0] == "1", pol, h.user["username"])
    miss = len(set(keys) - {it.get("key") for it in items if it})
    go("/products?type=" + quote("위탁"), f"위탁 상품 {made}개를 새로 만들고 {upd}개를 갱신했습니다" + (f". 도매매에서 못 찾은 코드 {miss}개" if miss else "") + ". 상세페이지를 만들고 마켓에 올리세요.")

# ---------- 도매매 CSV → 자동 등록 ----------
def csv_import(items, policy_id, user):
    """도매매 CSV 상품 → 우리 위탁 상품. 같은 코드·옵션이면 가격·재고만 갱신. (새 상품 번호, 갱신된 상품 번호)"""
    new, upd = [], []
    for it in items:
        opt = it["option"] if len(it["option"]) <= 60 else ""
        price, stock = float(it["price"] or 0), (0 if it["soldout"] else max(0, min(int(it["stock"]), 999)))
        old = q("SELECT * FROM products WHERE supplier='domeggook' AND supplier_key=? AND COALESCE(supplier_option,'')=?", (it["key"], opt), one=True)
        cats = it.get("cats") or {}
        if old:
            x("UPDATE products SET naver_cat=COALESCE(NULLIF(naver_cat,''),?), coupang_cat=COALESCE(NULLIF(coupang_cat,''),?), esm_cat=COALESCE(NULLIF(esm_cat,''),?) WHERE id=?",
              (cats.get("naver") or None, cats.get("coupang") or None, cats.get("esm") or None, old["id"]))
            x("UPDATE products SET supply_price=?, cost_krw=?, supply_ship=COALESCE(?,supply_ship), fixed_price=COALESCE(?,fixed_price), supplier_status=?, supplier_checked=?, stock=?, "
              "status=CASE WHEN ?=0 AND status='품절' THEN '준비' ELSE status END WHERE id=?",
              (price, price, it["ship"], it["fixed"], "품절" if it["soldout"] else "판매중", time.time(), stock, 1 if it["soldout"] else 0, old["id"]))
            upd.append(old["id"])
            continue
        detail_html = it["detail"] if "<" in it["detail"] else None
        theme = (it["category"].split(">")[-1].strip() if it["category"] else "") or "위탁"
        x("""INSERT INTO products(name,theme,keyword,source_name,source_url,cost_krw,set_qty,set_desc,stock,images,detail_html,status,updated,updated_by,
               supply_type,supplier,supplier_key,supplier_option,supply_price,supply_ship,fixed_price,supplier_status,supplier_checked,policy_id,naver_cat,coupang_cat,esm_cat)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
          (it["name"], theme, it["keyword"], it["name"],
           ocmod.item_url(it["key"], oc_conf().get("market", "supply")) if it["key"].isdigit() else "", price, 1, opt, stock,
           json.dumps(it["images"], ensure_ascii=False), detail_html, "품절" if it["soldout"] else "준비", time.time(), user,
           "위탁", "domeggook", it["key"], opt, price, it["ship"], it["fixed"], "품절" if it["soldout"] else "판매중", time.time(), policy_id,
           cats.get("naver", ""), cats.get("coupang", ""), cats.get("esm", "")))
        new.append(q("SELECT last_insert_rowid()", one=True)[0])
    log(user, "도매매 CSV 가져오기", f"새로 {len(new)}개, 갱신 {len(upd)}개")
    return new, upd

CSV_JOB = {"running": False}
updater.busy = lambda: bool(CSV_JOB.get("running"))

def csv_job(items, accs, chans, user, fname, pre=None):
    CSV_JOB.update({"running": True, "start": time.time(), "file": fname, "total": len(items or []), "done": 0, "msg": "상품 만드는 중"})
    lines, fails, fail_pids = [], [], []
    try:
        new, upd = pre() if pre else csv_import(items, consign_policy_id(), user)
        _n0 = len(new)
        if get_setting("auto_clean", True):
            auto_clean(user)
            new = [i for i in new if q("SELECT 1 FROM products WHERE id=?", (i,), one=True)]
            upd = [i for i in upd if q("SELECT 1 FROM products WHERE id=?", (i,), one=True)]
            if _n0 != len(new):
                lines.append(f"해외배송 상품 {_n0 - len(new)}개는 자동으로 지우고 올리지 않았습니다")
        n_new, n_upd = len(new), len(upd)
        listed = lambda pid: q("SELECT 1 FROM listings WHERE product_id=? LIMIT 1", (pid,), one=True)
        # 새 상품 + 전에 품절이라 못 올렸다가 이번에 재고가 생긴 상품
        to_reg = [pid for pid in new + [u for u in upd if not listed(u)] if (product(pid)["supplier_status"] or "") != "품절"]
        upd = [u for u in upd if u not in to_reg]
        CSV_JOB.update({"total": len(to_reg), "done": 0, "msg": f"상품 {n_new + n_upd}개를 만들었습니다. 마켓에 올리는 중 0/{len(to_reg)}"})
        ok = 0; ok_before = 0; streak = 0
        for i, pid in enumerate(to_reg):
            CSV_JOB.update({"done": i, "msg": f"마켓에 올리는 중 {i + 1}/{len(to_reg)} (성공 {ok}건, 실패 {len(fails)}건)"})
            nf = len(fails)
            try:
                k, ms, bad = publish([pid], accs, chans, user)
                ok += k
                fails += [m for m in ms if m.startswith("[실패]")]
            except Exception as ex:
                fails.append(f"[실패] {product(pid)['name']}: {ex}")
            if len(fails) > nf:
                fail_pids.append(pid)
            streak = streak + 1 if (len(fails) > nf and ok == ok_before) else 0
            ok_before = ok
            if streak >= 15 and ok == 0:   # 하나도 못 올리고 계속 실패(키·IP 문제 등)하면 멈춰서 이유를 보여 줌. 일부라도 올라가면 끝까지 가서 모든 에러 종류를 한 번에 모은다
                fails.append(f"⛔ 연속 15건 실패로 멈췄습니다(남은 {len(to_reg) - i - 1}개는 올리지 않음). 위 이유(API 키·IP 허용·카테고리 등)를 고친 뒤 다시 올리세요.")
                break
        synced = 0
        for pid in upd:      # 이미 올린 상품: 가격·재고만 마켓에 반영
            if q("SELECT 1 FROM listings WHERE product_id=? AND account_id IS NOT NULL LIMIT 1", (pid,), one=True):
                p = product(pid)
                if (p["supplier_status"] or "") == "품절":
                    k, ms = push_listings(pid, "soldout", "품절(공급처)")
                else:
                    k, ms = push_listings(pid, "sync")
                synced += k; fails += ms
        soldout_new = len([pid for pid in new if pid not in to_reg])
        dry = False
        lines = [f"파일: {fname}", f"새 상품 {n_new}개 · 이미 있던 상품 {n_upd}개(가격·재고 갱신)",
                 f"마켓 등록 {ok}건" + (" (미리보기 모드라 실제로는 안 올라감)" if dry else "") + (f" · 품절이라 건너뜀 {soldout_new}개" if soldout_new else ""),
                 f"이미 올린 상품 가격·재고 반영 {synced}건" if upd else "", f"실패 {len(fails)}건" if fails else "실패 없음"]
        if not accs and not chans:
            lines.append("⚠️ 올릴 쇼핑몰이 선택되지 않아 상품만 만들었습니다. 「올릴 쇼핑몰」에 체크하고 저장한 뒤 상품을 골라 「선택 상품을 위 쇼핑몰에 등록」을 누르세요.")
            fails.append("올릴 쇼핑몰 없음")
        elif ok == 0 and to_reg and not fails:
            lines.append("⚠️ 등록된 건이 없습니다. 상품이 모두 품절이거나 이미 등록된 상품입니다.")
        lines = [l for l in lines if l]
        # 실패를 원인별로 묶어 '종류별 1건 + 개수'로 보여 준다(한 번 돌려서 모든 에러 종류를 한눈에)
        import re as _re2
        grp = {}
        for m_ in fails:
            if not m_.startswith("[실패]"):
                continue
            fields = _re2.findall(r"originProduct\.[A-Za-z0-9_.\[\]]+|imageFiles\[\d+\]", m_)
            sig = ",".join(sorted(set(fields))) or _re2.sub(r"[\s\d]+", " ", m_.split(": ", 1)[-1])[:100]
            g = grp.setdefault(sig, [0, m_])
            g[0] += 1
        if grp:
            summ = [f"▣ 원인 {len(grp)}종류 — {n_}건: {m_[:420]}" for n_, m_ in sorted(grp.values(), key=lambda v: -v[0])]
            fails = summ + [f for f in fails if not f.startswith("[실패]")]
        CSV_JOB.update({"msg": "\n".join(lines), "fails": fails[:50], "fail_pids": fail_pids})
        log(user, "도매매 CSV 자동 등록", " · ".join(lines)[:500])
        notify.send("상품 자동 등록 " + ("완료" if not fails else f"완료(실패 {len(fails)}건)"), "\n".join(lines + fails[:10]), "upload")
    except Exception as ex:
        traceback.print_exc()
        CSV_JOB.update({"msg": f"오류로 멈췄습니다: {ex}", "fails": fails[:50]})
        notify.send("상품 자동 등록 오류", f"{fname}: {ex}", "error")
    finally:
        CSV_JOB.update({"running": False, "end": time.time()})

def job_card(back):
    """올리기 작업 진행·결과 카드(진행 중이면 5초마다 새로고침)"""
    j = CSV_JOB
    if j.get("running"):
        tot, done = int(j.get("total") or 0), int(j.get("done") or 0)
        bar = f'<div style="background:#e5e7eb;border-radius:6px;height:14px;margin:8px 0"><div style="background:#16a34a;height:14px;border-radius:6px;width:{min(100, int(done * 100 / tot)) if tot else 5}%"></div></div>' if tot else ""
        return (f'<div class="card" style="border:2px solid #16a34a"><h2>⏳ 올리는 중입니다</h2><p>{e(j.get("msg", ""))}</p>{bar}<p class="mut">파일: {e(j.get("file", ""))} · 이 화면은 5초마다 저절로 새로고침됩니다. 닫아도 서버에서 계속 진행되고, 끝나면 폰으로 알려 드립니다.</p></div>'
                '<script>setTimeout(function(){location.reload()},5000)</script>')
    if j.get("end"):
        fl = "".join(f"<li>{e(m)}</li>" for m in (j.get("fails") or [])[:10])
        bad = bool(j.get("fails"))
        return (f'<div class="card" style="border:2px solid {"#dc2626" if bad else "#16a34a"}"><h2>{"⚠️ 일부 실패" if bad else "✅ 올리기 끝"} ({time.strftime("%m-%d %H:%M", time.localtime(j["end"]))})</h2>'
                f'<pre style="white-space:pre-wrap;margin:0">{e(j.get("msg", ""))}</pre>{"<p><b>실패 이유(앞 10건)</b></p><ul>" + fl + "</ul>" if fl else ""}'
                + '<form method="post" action="/jobfail" class="row" data-busy><input type="hidden" name="back" value="' + e(back) + '">'
                + (f'<button class="btn red sm" name="do" value="delete" onclick="return confirm(\'이번에 등록 실패한 상품 {len(j.get("fail_pids") or [])}개를 목록에서 지웁니다(네이버에 올라간 상품은 건드리지 않음). 계속할까요?\')">실패한 상품 {len(j.get("fail_pids") or [])}개 지우기</button>' if j.get("fail_pids") else "")
                + '<button class="btn gray sm" name="do" value="close">이 결과 닫기</button> <a class="btn sm" href="/listings">등록현황 보기</a></form></div>')
    return ""

def csv_targets():
    c = get_setting("csv_targets", None)
    accs = RA(q("SELECT * FROM accounts WHERE active=1 ORDER BY id"))
    if c is None:
        return [a["id"] for a in accs], []
    return c.get("accs", []), c.get("chans", [])

@route("GET", "/suppliers/csv")
def suppliers_csv_get(h):
    acc_sel, ch_sel = csv_targets()
    accs = RA(q("SELECT * FROM accounts WHERE active=1 ORDER BY id"))
    acc_html = "".join(f'<label style="display:flex;gap:8px"><input type="checkbox" name="acc" value="{a["id"]}" style="width:auto" {"checked" if a["id"] in acc_sel else ""}> {e(MARKETS[a["market"]].name)} · {e(a["label"] or "")}</label>' for a in accs) \
        or '<p class="mut">아직 마켓 계정이 없습니다. <a href="/accounts">마켓 계정</a>에서 먼저 넣으세요. 없으면 상품만 만들어 둡니다.</p>'
    ch_html = "".join(f'<label style="display:flex;gap:8px"><input type="checkbox" name="ch" value="{e(c["code"])}" style="width:auto" {"checked" if c["code"] in ch_sel else ""}> {e(c["name"])} (엑셀)</label>' for c in chs.all_channels() if not c["api"])
    status = job_card('/suppliers/csv')
    dry = False
    nc = notify.conf()
    pol_opts = "".join(f'<option value="{i}" {"selected" if i == consign_policy_id() else ""}>{e(n)}</option>' for i, n in pricing.policies())
    body = f"""<h1>엑셀·zip 올리기</h1>{status}
{'<div class="flash err">지금은 <b>미리보기 모드</b>라 마켓에 실제로 올라가지 않습니다. 실제로 올리려면 <a href="/settings">설정</a>에서 등록 모드를 <b>실제 등록 모드</b>로 바꾸세요.</div>' if dry else ''}
<form method="post" enctype="multipart/form-data" class="card" data-busy><h2>1. 파일 넣기</h2>
<label>도매매에서 받은 상품 파일(.csv·.xlsx). <b>스마트스토어 양식이면 엑셀들과 이미지 zip을 한꺼번에</b> 고르세요(여러 개 선택 가능). <b>이미지 zip만 올리면</b> 이미 올려 둔 상품에 상품번호로 사진을 자동으로 붙입니다.</label><input type="file" name="file" accept=".csv,.xlsx,.txt,.zip" multiple required>
<label style="display:flex;gap:8px;margin-top:12px"><input type="checkbox" name="review" value="1" style="width:auto" checked> <b>올리기 전에 목록을 보고 마진을 정한 뒤 등록</b> (끄면 바로 등록)</label>
<h2 style="margin-top:16px">2. 가격</h2>
<label style="display:flex;gap:8px"><input type="radio" name="price_mode" value="sale" style="width:auto" checked> 엑셀 판매가 = 우리 판매가</label>
<label style="display:flex;gap:8px"><input type="radio" name="price_mode" value="cost" style="width:auto"> 엑셀 판매가 = 공급가(아래 정책으로 마진 붙임)</label>
<label>가격 정책(마진·수수료·택배비 포함 여부)</label><select name="policy_id">{pol_opts}</select>
<p class="mut">정책은 <a href="/sell/consign">B2B 판매설정</a>·<a href="/policies">추가 가격 정책</a>에서 만들고 고칩니다. 스마트스토어 양식이면 배송비·제주/도서산간·태그·옵션·상세페이지는 파일 그대로 올라갑니다.</p>
<h2 style="margin-top:16px">3. 올릴 곳</h2>{acc_html}{ch_html}
<p class="mut">고른 곳은 기억해 두었다가 다음에도 똑같이 씁니다.</p>
<button class="btn green">넣고 자동으로 올리기</button></form>
<div class="card"><h2>이렇게 처리됩니다</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>파일의 상품을 '위탁' 상품으로 만듭니다. 가격은 '위탁 기본' <a href="/policies">가격 정책</a>(마진)으로 계산합니다.</li>
<li>상세페이지가 파일에 있으면 그대로, 없으면 사진으로 자동 제작합니다.</li>
<li>고른 마켓에 바로 올립니다. 품절 상품은 건너뜁니다.</li>
<li>같은 상품코드가 이미 있으면 새로 올리지 않고 가격·재고만 마켓에 반영합니다. 그래서 도매매 파일을 매일 다시 넣어도 됩니다.</li>
<li>끝나면 폰으로 결과 알림이 갑니다. (알림: {'켜짐' if nc.get('ntfy_topic') or nc.get('tg_chat') else '꺼짐'} · <a href="/notify">폰 알림 설정</a>)</li></ol>
<p class="mut">열 이름은 상품코드·상품명·도매매판매가(공급가)·소비자가·배송비·재고수량·옵션·대표이미지·상세설명 등을 알아서 찾습니다.</p></div>"""
    return page("엑셀·zip 올리기", body, h.user, "/suppliers/csv", h.flash, h.flash_err)

@route("POST", "/suppliers/csv")
def suppliers_csv_post(h):
    import shutil
    try:
        f, files, tmp = h.multipart_stream()
    except ValueError as ex:
        go("/suppliers/csv", str(ex), True)
    back = f.get("back") if f.get("back") in ("/", "/b2b") else "/suppliers/csv"
    if CSV_JOB.get("running"):
        shutil.rmtree(tmp, ignore_errors=True)
        go(back, "앞 작업이 아직 진행 중입니다. 끝나면 다시 넣어 주세요.", True)
    flist = [(a, b) for a, b in (files.get("file") or []) if b and os.path.getsize(b) > 0]
    if not flist:
        shutil.rmtree(tmp, ignore_errors=True)
        go(back, "파일을 골라 주세요", True)
    def targets():
        if f.get("use_saved"):
            return csv_targets()
        acc_ids = [int(v) for v in h.multi_values("acc") if v.isdigit()]
        ch_codes = h.multi_values("ch")
        set_setting("csv_targets", {"accs": acc_ids, "chans": ch_codes})
        return acc_ids, ch_codes
    fn, path = flist[0]
    ss_mode = len(flist) > 1 or any(a.lower().endswith(".zip") for a, _ in flist)
    if flist and all(a.lower().endswith(".zip") for a, _ in flist):   # 이미지 zip만: 이미 올린 상품에 사진 적용
        acc_ids, ch_codes = targets()
        accs = RA([a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (i,), one=True) for i in acc_ids) if a])
        chans = [c for c in (chs.get(k) for k in ch_codes) if c]
        user = h.user["username"]
        zps = [b for _, b in flist]
        def run_img():
            try:
                csv_job(None, accs, chans, user, f"이미지 {len(zps)}개", lambda: attach_images(zps, user)[:2])
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
        threading.Thread(target=run_img, daemon=True).start()
        time.sleep(0.5)
        go(back, "이미지를 상품에 붙이는 중입니다. 사진이 붙은 상품 중 아직 마켓에 안 올린 것은 선택한 쇼핑몰에 자동으로 올립니다. 이 화면에서 진행을 볼 수 있습니다.")
    if ss_mode and f.get("review") == "1":   # 올리기 전에 목록 확인(기본)
        user = h.user["username"]
        src = [(a, b if a.lower().endswith(".zip") else open(b, "rb").read()) for a, b in flist]
        try:
            new, upd, msg = ss_import(src, False, user, num(f.get("policy_id"), int) or consign_policy_id(), staging=True)
        except Exception as ex:
            shutil.rmtree(tmp, ignore_errors=True)
            go(back, f"파일을 읽지 못했습니다: {ex}", True)
        shutil.rmtree(tmp, ignore_errors=True)
        go("/b2b/review", msg + " 마진을 정하고 등록하세요.")
    if ss_mode:   # 도매매 스마트스토어 양식(엑셀들 + 이미지 zip): zip은 경로로, 엑셀은 내용으로 넘김(메모리 절약)
        cost_mode = f.get("price_mode") == "cost"
        pol = num(f.get("policy_id"), int) or consign_policy_id()
        acc_ids, ch_codes = targets()
        accs = RA([a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (i,), one=True) for i in acc_ids) if a])
        chans = [c for c in (chs.get(k) for k in ch_codes) if c]
        user = h.user["username"]
        src = [(a, b if a.lower().endswith(".zip") else open(b, "rb").read()) for a, b in flist]
        label = f"{len(flist)}개 파일({', '.join(a for a, _ in flist)[:60]})"
        def run():
            try:
                csv_job(None, accs, chans, user, label, lambda: ss_import(src, cost_mode, user, pol)[:2])
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
        threading.Thread(target=run, daemon=True).start()
        time.sleep(0.5)
        go(back, "파일을 읽고 상품·상세페이지를 만들어 선택한 마켓에 올리는 중입니다. 끝나면 폰으로 알려 드립니다. 이 화면에서 진행을 볼 수 있습니다.")
    data = open(path, "rb").read()
    shutil.rmtree(tmp, ignore_errors=True)
    try:
        items, found = occsv.parse(fn, data)
    except Exception as ex:
        go(back, f"파일을 읽지 못했습니다: {ex}", True)
    if not items:
        go(back, "상품을 찾지 못했습니다. 첫 줄에 '상품명' 같은 열 이름이 있는 파일인지 확인해 주세요.", True)
    acc_ids, ch_codes = targets()
    accs = RA([a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (i,), one=True) for i in acc_ids) if a])
    chans = [c for c in (chs.get(k) for k in ch_codes) if c]
    log(h.user["username"], "도매매 CSV 넣음", f"{fn} {len(items)}개 · 찾은 열: {found}"[:500])
    threading.Thread(target=csv_job, args=(items, accs, chans, h.user["username"], fn), daemon=True).start()
    time.sleep(0.5)
    go(back, f"{len(items)}개 상품을 읽었습니다. 지금 서버에서 마켓에 올리는 중이고, 끝나면 폰으로 알려 드립니다.\n찾은 열: {found}")

# ---------- 폰 알림 ----------
@route("GET", "/notify")
def notify_get(h):
    c = notify.conf(); adm = h.user["role"] == "admin"
    chk = lambda k: "checked" if c.get(k, True) else ""
    topic = c.get("ntfy_topic", "")
    body = f"""<h1>폰 알림</h1>
<div class="card"><h2>방법 1. ntfy 앱 (가입 없음, 추천)</h2><ol style="margin:0;padding-left:20px;line-height:1.9">
<li>폰에서 앱스토어·플레이스토어에 <b>ntfy</b> 를 검색해 설치합니다.</li>
<li>앱에서 <b>+</b> (Subscribe to topic) 를 누르고 아래 이름을 그대로 넣습니다.</li>
<li>아래 <b>시험 알림 보내기</b> 를 눌러 폰에 알림이 오는지 봅니다.</li></ol>
<p style="font-size:20px;margin:12px 0"><b>{e(topic)}</b></p><p class="mut">이 이름을 아는 사람은 알림을 볼 수 있으니 남에게 알려 주지 마세요. 팀원도 같은 이름을 넣으면 함께 받습니다.</p></div>
<form method="post" class="card"><fieldset {'' if adm else 'disabled'} style="border:0;padding:0;margin:0"><h2>설정</h2>
<div class="grid"><div><label>ntfy 알림 이름(topic)</label><input name="ntfy_topic" value="{e(topic)}"></div>
<div><label>ntfy 서버</label><input name="ntfy_server" value="{e(c.get('ntfy_server', 'https://ntfy.sh'))}"></div></div>
<h2 style="margin-top:16px">방법 2. 텔레그램 (선택)</h2><div class="grid">
<div><label>봇 토큰 {'(저장됨, 바꿀 때만 입력)' if c.get('tg_token') else ''}</label><input name="tg_token" type="password" autocomplete="off" placeholder="@BotFather 에서 받은 토큰"></div>
<div><label>채팅 ID</label><input name="tg_chat" value="{e(c.get('tg_chat', ''))}" placeholder="숫자"></div></div>
<h2 style="margin-top:16px">어떤 알림을 받을까요</h2>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_upload" value="1" style="width:auto" {chk('on_upload')}> 상품 자동 등록 결과(CSV 넣은 뒤)</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_order" value="1" style="width:auto" {chk('on_order')}> 새 주문</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_soldout" value="1" style="width:auto" {chk('on_soldout')}> 품절·재입고·공급가 변경</label>
<label style="display:flex;gap:8px"><input type="checkbox" name="on_error" value="1" style="width:auto" {chk('on_error')}> 오류</label>
<br>{'<button class="btn">저장</button>' if adm else '<span class="mut">관리자만 바꿀 수 있습니다</span>'}</fieldset></form>
<form method="post" action="/notify/test" data-busy><button class="btn gray">시험 알림 보내기</button></form>"""
    return page("폰 알림", body, h.user, "/notify", h.flash, h.flash_err)

@route("POST", "/notify", admin=True)
def notify_post(h):
    f = h.form(); c = notify.conf()
    c.update({"ntfy_topic": re.sub(r"[^A-Za-z0-9_-]", "", f.get("ntfy_topic", ""))[:64], "ntfy_server": (f.get("ntfy_server") or "https://ntfy.sh").strip(),
              "tg_chat": f.get("tg_chat", "").strip()})
    for k in ("on_upload", "on_order", "on_soldout", "on_error"):
        c[k] = f.get(k) == "1"
    if f.get("tg_token"):
        c["tg_token"] = seal(f["tg_token"].strip())
    set_setting("notify", c)
    log(h.user["username"], "폰 알림 설정 저장")
    go("/notify", "저장했습니다")

@route("POST", "/notify/test")
def notify_test(h):
    sent = notify.send("멀티마켓 시험 알림", "알림이 잘 옵니다. " + time.strftime("%m-%d %H:%M"), wait=True)
    if sent:
        go("/notify", "보냈습니다. 폰에 알림이 왔는지 확인하세요.")
    go("/notify", "보내지 못했습니다. 알림 이름(topic)이나 텔레그램 설정을 확인하세요. 자세한 내용은 작업 이력에 있습니다.", True)

# ---------- 잘 팔릴 상품 자동 찾기 ----------
def finder_import(fids, user):
    """추천 후보 → 우리 위탁 상품. 만들어진 상품 번호 목록"""
    rows = [q("SELECT * FROM finds WHERE id=?", (i,), one=True) for i in fids]
    rows = [r for r in rows if r]
    if not rows:
        return []
    keys = list(dict.fromkeys(r["item_key"] for r in rows))
    items = ocmod.OwnerClan().items(keys)
    fc = finder.conf()
    mode = fc.get("price_mode") or "policy"
    pol = consign_policy_id()
    if mode in ("pct", "price_pct", "won") or fc.get("price_ship") not in (None, ""):
        # 화면에서 고른 마진·배송비를 '상품찾기 마진' 정책으로 저장해 가져온 상품에 적용
        data = json.dumps(finder.price_policy(fc, pol), ensure_ascii=False)
        old = q("SELECT id FROM policies WHERE name='상품찾기 마진'", one=True)
        if old:
            x("UPDATE policies SET data=? WHERE id=?", (data, old["id"])); pol = old["id"]
        else:
            pol = x("INSERT INTO policies(name,data) VALUES('상품찾기 마진',?)", (data,))
    import_items(items, False, pol, user)
    pids = []
    for r in rows:
        pr = q("SELECT id FROM products WHERE supplier='domeggook' AND supplier_key=? ORDER BY id LIMIT 1", (r["item_key"],), one=True)
        if pr:
            if r["price_fixed"] and r["our_price"]:
                x("UPDATE products SET price_override=? WHERE id=?", (int(r["our_price"]), pr["id"]))
            pids.append(pr["id"])
            x("UPDATE finds SET status='가져옴', product_id=? WHERE id=?", (pr["id"], r["id"]))
    return list(dict.fromkeys(pids))

def finder_auto(user="자동"):
    """자동 찾기(켜져 있을 때) + 자동 등록(켜져 있을 때)"""
    c = finder.conf()
    if not c.get("auto_find"):
        return
    if time.time() - (get_setting("finder_last") or 0) < float(c.get("find_hours") or 24) * 3600:
        return
    try:
        finder.run(user)
    except Exception as ex:
        set_setting("finder_last", time.time())
        log(user, "상품 자동 찾기 실패", str(ex)[:300]); return
    if not c.get("auto_register"):
        return
    day0 = time.mktime(time.localtime()[:3] + (0, 0, 0, 0, 0, -1))
    done = q("SELECT COUNT(*) FROM finds WHERE status IN ('가져옴','등록됨') AND found_at>=?", (day0,), one=True)[0]
    left = int(c.get("max_per_day") or 0) - done
    if left <= 0:
        return
    fids = [r["id"] for r in q("SELECT id FROM finds WHERE status='추천' AND score>=? ORDER BY score DESC LIMIT ?", (float(c.get("min_score") or 0), left))]
    if not fids:
        return
    accs = RA([a for a in (q("SELECT * FROM accounts WHERE id=? AND active=1", (int(i),), one=True) for i in c.get("reg_accs") or []) if a])
    chans = [ch for ch in (chs.get(k) for k in c.get("reg_chans") or []) if ch]
    pids = finder_import(fids, user)
    if pids and (accs or chans):
        ok, ms, _ = publish(pids, accs, chans, user)
        for pid in pids:
            x("UPDATE finds SET status='등록됨' WHERE product_id=?", (pid,))
        log(user, "자동 찾기 → 자동 등록", f"{len(pids)}개 상품 {ok}건 " + "; ".join(ms)[:300])

PC_TOKEN_SHA256 = "423abebfe70ec5f8365665f538c07ab3ef3c6fb2b7d6ba1cf94b1fa5eac086b6"

def _pc_ok(h):
    import hashlib, hmac
    t = (h.headers.get("X-PC-Token") or h.qs.get("token") or "")
    return hmac.compare_digest(hashlib.sha256(t.encode()).hexdigest(), PC_TOKEN_SHA256)

@route("GET", "/api/finds", public=True)
def api_finds(h):
    """PC 프로그램이 읽는 목록: 최저가가 비어 있는 추천 후보의 키워드. 토큰(해시 비교)이 있어야만 응답"""
    h.extra_headers = {"Content-Type": "application/json; charset=utf-8"}
    if not _pc_ok(h):
        h.status = 403
        return json.dumps({"error": "forbidden"})
    stored = get_setting("mins_by_key", {}) or {}
    fresh = time.time() - 3 * 86400
    rows = q("SELECT id, keyword, item_name, item_key, supply_price FROM finds WHERE status='추천' ORDER BY found_at DESC, score DESC LIMIT 150")   # 방금 찾은 상품부터
    rush = get_setting("pc_rush") or 0
    if rush and time.time() - float(rush) < 6 * 3600:
        h.extra_headers["X-Rush"] = "1"   # CHOI가 「지금 조회 요청」을 눌렀음 → PC가 다음 실행 때 바로 조회
    return json.dumps([{"id": r["id"], "key": r["item_key"], "keyword": r["keyword"], "name": r["item_name"], "supply": r["supply_price"],
                        "has": 1 if (stored.get(str(r["item_key"])) or {}).get("t", 0) > fresh else 0} for r in rows], ensure_ascii=False)

@route("POST", "/api/mins", public=True)
def api_mins(h):
    """PC 프로그램이 보내는 {id: 네이버 최저가}. 저장하고 판매가·이익 재계산"""
    h.extra_headers = {"Content-Type": "application/json; charset=utf-8"}
    if not _pc_ok(h):
        h.status = 403
        return json.dumps({"error": "forbidden"})
    try:
        d = json.loads(h._body().decode("utf-8", "replace") or "{}")
    except Exception:
        return json.dumps({"error": "bad json"})
    n = 0
    skipped = 0
    for k, v in (d.get("mins") or {}).items():
        if str(k).isdigit() and isinstance(v, (int, float)) and v > 0:
            r = q("SELECT supply_price FROM finds WHERE id=?", (int(k),), one=True)
            if r and r["supply_price"] and v < float(r["supply_price"]) * 0.5:
                skipped += 1   # 최저가가 공급가의 절반 미만이면 같은 상품이 아닐 가능성이 커서 제외
                continue
            x("UPDATE finds SET mkt_min=? WHERE id=?", (int(v), int(k))); n += 1
    stored = get_setting("mins_by_key", {}) or {}
    srcmap = d.get("src_by_key") if isinstance(d.get("src_by_key"), dict) else {}
    for k, v in (d.get("mins_by_key") or {}).items():   # 도매매번호 기준: 후보가 다시 만들어져도 값이 남음
        if isinstance(v, (int, float)) and v > 0:
            r = q("SELECT supply_price FROM finds WHERE item_key=? ORDER BY id DESC LIMIT 1", (str(k),), one=True)
            if r and r["supply_price"] and v < float(r["supply_price"]) * 0.5:
                skipped += 1
                continue
            stored[str(k)] = {"v": int(v), "t": time.time(), "src": str(srcmap.get(k) or srcmap.get(str(k)) or "")[:10]}
            x("UPDATE finds SET mkt_min=? WHERE item_key=? AND status='추천'", (int(v), str(k))); n += 1
    set_setting("mins_by_key", stored)
    ns = d.get("naver_status")
    if isinstance(ns, dict):   # PC가 알려 주는 조회 상태(막힘·재시도 시각·남은 개수)
        keep = {k: ns.get(k) for k in ("state", "until", "why", "checked", "found", "remaining", "rush_done") if isinstance(ns.get(k), (int, float, str))}
        keep["t"] = time.time()
        if isinstance(ns.get("sources"), list):   # 막혀 있는 조회처(이름·재시도 시각)
            keep["sources"] = [{"name": str(s_.get("name"))[:10], "until": float(s_.get("until") or 0)} for s_ in ns["sources"][:6] if isinstance(s_, dict)]
        if keep.pop("rush_done", None):
            set_setting("pc_rush", 0)   # 요청한 조회를 마침
        set_setting("naver_status", keep)
    cnt = finder.recalc_all(finder.conf())
    set_setting("finder_min_last", time.time())
    log("PC", "시중 최저가 입력", f"{n}개 저장, 공급가 절반 미만 제외 {skipped}개, {cnt}개 재계산")
    return json.dumps({"saved": n, "skipped": skipped, "recalc": cnt})

@route("GET", "/compete")
def compete_get(h):
    """내 상품과 같은 상품을 네이버쇼핑에서 남들이 얼마에 파는지 비교 (공식 검색 API, 읽기 전용)"""
    fc = finder.conf()
    page_no = max(1, int(h.qs.get("p") or 1)) if str(h.qs.get("p") or "1").isdigit() else 1
    PER = 20
    total = q("SELECT COUNT(*) n FROM products WHERE status NOT IN ('삭제')", one=True)["n"]
    rows = q("SELECT * FROM products WHERE status NOT IN ('삭제') ORDER BY id DESC LIMIT ? OFFSET ?", (PER, (page_no - 1) * PER))
    if not (fc.get("naver_id") and fc.get("naver_secret")):
        body = '<h1>경쟁가 보기</h1><div class="card">경쟁가 보기는 네이버 쇼핑 검색 API가 종료돼 쓸 수 없습니다. 최저가는 「잘 팔릴 상품 찾기」 목록에서 PC가 자동으로 채웁니다.</div>'
        return page("경쟁가 보기", body, h.user, "/compete", h.flash, h.flash_err)
    out, err = [], ""
    for p in rows:
        kw = " ".join(re.sub(r"[\[\]()/,]", " ", p["name"] or "").split()[:6])
        try:
            d = finder._get("https://openapi.naver.com/v1/search/shop.json?" + urllib.parse.urlencode({"query": kw, "display": 30, "sort": "sim"}),
                            {"X-Naver-Client-Id": fc["naver_id"], "X-Naver-Client-Secret": finder._sec(fc, "naver_secret")})
        except finder.FindError as ex:
            err = str(ex); break
        items = [(finder.num(i.get("lprice")), re.sub(r"<[^>]+>", "", i.get("title") or ""), i.get("mallName") or "", i.get("link") or "") for i in d.get("items") or []]
        items = sorted(i for i in items if i[0] > 0)
        mine = float(p["price_override"] or 0) or pricing.price_for(p, "naver")
        cost = float(p["supply_price"] or p["cost_krw"] or 0)
        out.append((p, kw, mine, cost, items, int(d.get("total") or 0)))
    trs = ""
    for p, kw, mine, cost, items, tot in out:
        low = items[0][0] if items else 0
        mid = items[len(items) // 2][0] if items else 0
        flag = "" if not items else ("<b style='color:#dc2626'>내가 비쌈</b>" if mine > mid * 1.1 else ("<b style='color:#16a34a'>내가 쌈</b>" if mine < low else "비슷"))
        top = "<br>".join(f"{pr:,}원 · {e(mall)}" for pr, _t, mall, _l in items[:3])
        trs += f"<tr><td>{e(p['name'])[:50]}<div class='mut'>검색어: {e(kw)}</div></td><td>{cost:,.0f}</td><td>{mine:,.0f}</td><td>{low:,}</td><td>{mid:,}</td><td>{tot:,}</td><td>{flag}</td><td style='font-size:12px'>{top}</td></tr>"
    pages = (total + PER - 1) // PER
    nav = " ".join(f'<a class="btn gray" href="/compete?p={i}">{i}</a>' for i in range(1, pages + 1))
    body = f"""<h1>경쟁가 보기</h1><p class="mut">네이버쇼핑에서 같은 이름으로 검색한 상위 30개 가격입니다. 같은 상품이 아닐 수 있으니 이름·링크는 눈으로 확인하세요. (읽기 전용, 가격은 바꾸지 않음)</p>
{('<div class="card" style="color:#dc2626">' + e(err) + '</div>') if err else ''}
<div class="card" style="overflow:auto"><table><tr><th>상품</th><th>공급가</th><th>내 판매가</th><th>최저</th><th>중간값</th><th>검색 결과 수</th><th>판정</th><th>싼 순 3곳</th></tr>{trs}</table></div><div class="row">{nav}</div>"""
    return page("경쟁가 보기", body, h.user, "/compete", h.flash, h.flash_err)

FPUB_JS = """
document.getElementById('fpub').onclick=async()=>{
 const f=document.getElementById('ff'),note=document.getElementById('autoimg_note');const fids=[...f.querySelectorAll('input[name=fid]:checked')].map(c=>c.value);
 if(!fids.length){alert('상품을 하나 이상 고르세요');return}
 const tg=[...f.querySelectorAll('input[name=acc]:checked,input[name=ch]:checked')];if(!tg.length){alert('올릴 마켓이나 판매처를 고르세요');return}
 f.querySelectorAll('button').forEach(b=>b.disabled=true);note.textContent='도매매에서 가져오는 중…';
 const fd=new URLSearchParams();fids.forEach(i=>fd.append('fid',i));
 const r=await fetch('/finder/import',{method:'POST',body:fd});const j=await r.json();if(j.error){note.textContent=j.error;f.querySelectorAll('button').forEach(b=>b.disabled=false);return}
 for(let i=0;i<j.pids.length;i++){try{await mmAutoImg(j.pids[i],{set textContent(t){note.textContent=(i+1)+'/'+j.pids.length+' 상품 · '+t}})}catch(e){}}
 note.textContent='마켓에 올리는 중…';const g=document.createElement('form');g.method='post';g.action='/bulk';
 const add=(n,v)=>{const h=document.createElement('input');h.type='hidden';h.name=n;h.value=v;g.appendChild(h)};
 add('do','register');j.pids.forEach(p=>add('pid',p));tg.forEach(c=>add(c.name,c.value));add('from','finder');document.body.appendChild(g);g.submit();
};
"""

def finder_acc_opts(c, accs, allch):
    ck = lambda on: "checked" if on else ""
    tag = lambda a: "<span style='color:#16a34a'>[실제 등록]</span>" if acc_mode(a)[0] else "<span style='color:#dc2626'>[미리보기]</span>"
    o = "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' style='width:auto' name='acc' value='{a['id']}' {ck(not c.get('reg_accs') or str(a['id']) in map(str, c.get('reg_accs') or []))}> {e(MARKETS[a['market']].name)} · {e(a['label'])} {tag(a)}</label>" for a in accs)
    o += "".join(f"<label style='display:inline-flex;gap:6px;align-items:center;margin-right:14px;color:inherit'><input type='checkbox' style='width:auto' name='ch' value='{e(ch['code'])}' {ck(ch['code'] in (c.get('reg_chans') or []))}> {e(ch['name'])} <span class='mut'>(엑셀)</span></label>" for ch in allch if not ch["api"])
    return o or "<span class='mut'>마켓 계정이나 판매처를 먼저 추가하세요</span>"

@route("GET", "/finder")
def finder_page(h):
    c = finder.conf()
    st = h.qs.get("st", "추천")
    _mu, _mm = int(c.get("match_undercut", 100) or 100), int(c.get("match_min_profit", c.get("min_profit", 2000)) or 0)
    try:
        finder.apply_seed()   # 후보가 새로 만들어져도 PC에서 조회해 둔 값을 도매매번호로 다시 채움
    except Exception as ex:
        log("자동", "PC 최저가 입력 오류", str(ex)[:300])
    if not get_setting("price_fix_1951"):
        set_setting("price_fix_1951", True)
        try:
            finder.recalc_all(c)   # 마진 칸 값이 무시되던 문제 수정 후 한 번 다시 계산
        except Exception as ex:
            log("자동", "판매가 재계산 오류", str(ex)[:300])
    if not get_setting("low_excl_1956"):
        set_setting("low_excl_1956", True)
        try:
            finder.recalc_all(c)   # 이미 쌓여 있던 시세 낮은 후보를 한 번 「제외」로 옮김
        except Exception as ex:
            log("자동", "시세 낮은 후보 제외 오류", str(ex)[:300])
    _res = _match_rows(c, _mu, _mm)
    if st == "시세낮음":
        st = "제외"   # 예전 주소 호환: 시세가 낮은 상품은 이제 「제외」 탭에 사유와 함께 있음
    rows = q("SELECT * FROM finds WHERE status=? ORDER BY score DESC, id DESC LIMIT 300", (st,))
    accs = RA(q("SELECT * FROM accounts WHERE active=1 ORDER BY market,id"))
    allch = chs.all_channels()
    ck = lambda on: "checked" if on else ""
    acc_opts = finder_acc_opts(c, accs, allch)
    _queue = {r["id"]: i + 1 for i, r in enumerate(q("SELECT id FROM finds WHERE status='추천' AND (mkt_min IS NULL OR mkt_min=0) ORDER BY found_at DESC, score DESC"))}
    _rush = get_setting("pc_rush") or 0
    _srcs = {k_: (v_ or {}).get("src") or "" for k_, v_ in (get_setting("mins_by_key", {}) or {}).items() if isinstance(v_, dict)}
    def fv(v):
        return "" if v in (None, "") else f"{v:,.0f}" if isinstance(v, (int, float)) else e(str(v))
    trs = "".join(f"""<tr><td><input type="checkbox" name="fid" value="{r['id']}" style="width:auto"></td><td>{f'<img class="thumb" src="{e(r["image"])}" loading="lazy" referrerpolicy="no-referrer">' if r['image'] else '<div class="thumb"></div>'}</td>
<td><b>{e(r['item_name'] or '')}</b><div class="mut">{e(r['item_key'])} · 키워드 <b>{e(r['keyword'])}</b>{f" · 월 검색 {r['volume']:,}" if r['volume'] else ''}</div><div class="mut">{e(r['why'] or '')}</div>{f"<div class='mut' style='color:#dc2626'>제외 사유: {e(r['skip_why'])}</div>" if st == "제외" and r['skip_why'] else ''}</td>
<td><b style="font-size:18px">{r['score']:g}</b></td><td>{fv(r['supply_price'])}원</td><td><input name="min_{r['id']}" value="{r['mkt_min'] or ''}" placeholder="조회 전" inputmode="numeric" style="width:90px">{f"<div class='mut'>{e(_srcs[str(r['item_key'])])} 기준</div>" if r['mkt_min'] and (_srcs.get(str(r['item_key'])) or '') else ''}{f"<div class='mut'>PC 대기 {_queue[r['id']]}번째</div>" if r['id'] in _queue and not r['mkt_min'] else ''}</td><td><b>{fv(r['our_price'])}원</b><div class='mut'>{'시중 최저가 −' + str(int(c.get('match_undercut', 100) or 0)) + '원' if r['mkt_min'] and r['our_price'] and r['our_price'] <= r['mkt_min'] and r['mkt_min'] - r['our_price'] == int(c.get('match_undercut', 100) or 0) else ('최저가 미확인 · 바닥 가격' if not r['mkt_min'] else '시세가 바닥보다 낮음')} · 수수료 별도</div>{f"<div class='mut'>시장 {fv(r['mkt_low'])}~{fv(r['mkt_avg'])}</div>" if r['mkt_avg'] else ''}</td><td>{fv(r['profit'])}원</td>
<td>{f"<a href='/products/{r['product_id']}'>상품 보기</a>" if r['product_id'] else ''}</td></tr>""" for r in rows)
    _cnt = lambda t: q("SELECT COUNT(*) FROM finds WHERE status=?", (t,), one=True)[0]
    tabs = " ".join(f"<a class='btn sm {'' if st == t else 'gray'}' href='/finder?st={quote(t)}'>{t} {_cnt(t)}</a>" for t in ("추천", "가져옴", "등록됨", "제외"))
    last = get_setting("finder_last")
    sel = lambda name, on: f"<select name='{name}' style='max-width:260px'><option value='1'>켜기</option><option value='0' {'' if on else 'selected'}>끄기</option></select>"
    keyinfo = lambda k: " (저장됨, 바꿀 때만 입력)" if c.get(k) else ""
    _lm = get_setting("finder_min_last")
    _tot = q("SELECT COUNT(*) FROM finds WHERE status='추천'", one=True)[0]
    _fil = q("SELECT COUNT(*) FROM finds WHERE status='추천' AND mkt_min>0", one=True)[0]
    _blk = get_setting("finder_min_block") or ""
    _neg = q("SELECT COUNT(*) FROM finds WHERE status='제외' AND skip_why LIKE '시세가%'", one=True)[0]; _few = 0
    _sd = finder.seed_stats()
    MIN_STAT = (f"<span style='font-size:17px'>{_tot}개 중 시중 최저가 확인 <b>{_fil}</b>개 · 이익 남아 바뀔 상품 <b>{len(_res['ok'])}</b>개</span><br>"
                f"시세가 원가보다 낮아 자동으로 뺀 상품 {_neg}개 (「제외」 탭에 사유가 남아 있고 되돌릴 수 있음) · 최저가 미확인(바닥 가격으로 표시) {_res['none']}개<br>"
                f"PC 조회값 {_sd[0]}개 중 이 목록과 번호가 맞는 것 {_sd[1]}개@@EX@@" + (f" · 서버 직접 조회는 네이버가 막음({e(str(_blk))})" if _blk else ""))
    _pm = c.get("price_mode") or "policy"
    if _pm == "policy" and c.get("price_margin") not in (None, ""):
        _pm = "pct"
    PM_TXT = {"policy": "위탁 기본 설정(원가 대비 30% 등)", "pct": f"원가(공급가+택배비) 대비 마진 {fv(c.get('price_margin'))}%", "price_pct": f"판매가 대비 마진 {fv(c.get('price_margin'))}%",
              "won": f"건당 이익 {fv(c.get('price_margin'))}원"}.get(_pm, "위탁 기본 설정")
    _ex = ""
    try:
        _r0 = q("SELECT supply_price, supply_ship FROM finds WHERE status='추천' AND supply_price>0 ORDER BY score DESC, id DESC LIMIT 1", one=True)
        if _r0:
            _p, _pf = finder.calc({"name": "x", "price": _r0["supply_price"], "shippingFee": _r0["supply_ship"]}, c, finder.consign_pol())
            _ex = f"<br>지금 적용: <b>{PM_TXT}</b> · 예) 공급가 {_r0['supply_price']:,.0f}원 → 판매가 {_p:,}원 (이익 {_pf:,}원 = 판매가의 {(_pf * 100 // _p) if _p else 0}%, 수수료·택배비 뺀 뒤)"
    except Exception:
        pass
    MIN_STAT = MIN_STAT.replace("@@EX@@", _ex)
    _ns = get_setting("naver_status") or {}
    if _ns:
        _hm = lambda t: time.strftime("%m-%d %H:%M", time.localtime(float(t)))
        if _ns.get("state") == "blocked" and float(_ns.get("until") or 0) > time.time():
            MIN_STAT += f"<br><b>조회처 모두 점검 대기</b> · {_hm(_ns['until'])} 이후 PC가 이어서 조회합니다 (남은 조회 {int(_ns.get('remaining') or 0)}개)"
        else:
            MIN_STAT += f"<br>PC 조회: 마지막 {_hm(_ns.get('t') or 0)} · 이번에 {int(_ns.get('checked') or 0)}개 조회, 최저가 {int(_ns.get('found') or 0)}개 확인 · 남은 조회 {int(_ns.get('remaining') or 0)}개 (「지금 찾기」를 누르면 PC가 1분 안에 이어서 조회)"
        _bs = [x_ for x_ in (_ns.get("sources") or []) if float(x_.get("until") or 0) > time.time()]
        if _bs:
            MIN_STAT += "<br>쉬는 조회처: " + ", ".join(f"{e(x_['name'])}({_hm(x_['until'])}까지, 나머지 곳으로 계속 조회)" for x_ in _bs)
    body = f"""<h1>잘 팔릴 상품 자동 찾기</h1>
<div class="card"><div class="row"><form method="post" action="/finder/run" data-busy class="row" style="flex:1"><input name="seeds" value="{e(c.get('seeds') or '')}" placeholder="찾을 분야(쉼표로): 집게핀, 키링, 다꾸, 반려견 간식" style="flex:1;min-width:240px"><button class="btn">지금 찾기</button></form></div>
<p class="mut">자동 찾기: <b>{'켜짐' if c.get('auto_find') else '꺼짐'}</b>({c.get('find_hours')}시간마다) · 자동 등록: <b>{'켜짐' if c.get('auto_register') else '꺼짐'}</b>(하루 최대 {c.get('max_per_day')}개, {c.get('min_score')}점 이상) · 마지막 찾기 {time.strftime('%m-%d %H:%M', time.localtime(last)) if last else '없음'}</p>
<p class="mut">점수 = 수요(네이버 월 검색량) 40 + 경쟁(네이버 쇼핑 상품 수 ÷ 검색량) 30 + 가격(우리 판매가가 시장가보다 싼지) 30. 이익이 {fv(c.get('min_profit'))}원 미만인 상품과 이미 가져온 상품은 뺍니다.</p></div>
<div class="card"><h2 style="margin-top:0">판매가·이익 정하기</h2>
<form method="post" action="/finder/price" data-busy><div class="grid">
<div><label>판매가 정하는 방식</label><select name="price_mode">{''.join(f"<option value='{v}' {'selected' if (('pct' if (c.get('price_mode') or 'policy') == 'policy' and c.get('price_margin') not in (None, '') else (c.get('price_mode') or 'policy')) == v) else ''}>{t}</option>" for v, t in (('policy', '위탁 판매설정 그대로 (마진 칸을 비울 때)'), ('pct', '원가(공급가+택배비) 대비 마진 %'), ('price_pct', '판매가 대비 마진 %'), ('won', '건당 이익금(원)')))}</select></div>
<div><label>이익률 % (공급가 기준, 택배·수수료 별도)</label><input name="price_margin" value="{fv(c.get('price_margin'))}"></div>
<div><label>배송비 원가(원, 비우면 위탁 설정값)</label><input name="price_ship" value="{fv(c.get('price_ship'))}"></div>
</div>
<div class="row" style="margin-top:8px"><button class="btn">적용하고 목록 다시 계산</button><button class="btn gray" formaction="/finder/seednow" formmethod="post">PC 조회값 반영</button> <button class="btn" formaction="/finder/rush" formmethod="post">지금 조회 요청 (PC가 1분 안에 시작)</button></div>
{('<p class="mut"><b>지금 조회 요청됨</b> — PC가 1분 안에 조회를 시작합니다.</p>' if _rush and time.time() - float(_rush) < 6 * 3600 else '')}
<p class="mut">{MIN_STAT}</p>
<details><summary class="mut">자세한 설명</summary><p class="mut">지금 기준: {PM_TXT} · 판매가 = 시중 최저가 −100원, 단 공급가×(1+마진)보다 낮으면 제외(최저가를 모르면 그 바닥 가격으로 표시). 택배비·수수료는 가격에 넣지 않고 별도입니다. 이 가격이 목록·최저가 맞추기·등록에 같이 쓰입니다. 시중 최저가는 PC가 에누리(여러 쇼핑몰 모음)·네이버·롯데ON에서 조회해 그중 가장 싼 값을 넣고, 어느 곳 값인지 칸 아래에 표시합니다. 쿠팡·G마켓·SSG·다나와는 이 PC에서도 막혀 읽지 못합니다. 칸이 비어 있으면 PC 조회값이 없는 것이고, 직접 입력해도 됩니다.</p></details></form></div>
<div class="card"><h2 style="margin-top:0">최저가 맞추기</h2>
<form method="post" action="/finder/match" data-busy><div class="grid">
<div><label>시중 최저가보다 얼마 싸게(원)</label><input name="undercut" value="{fv(c.get('match_undercut', 100))}"></div>
</div>
<div class="row" style="margin-top:8px"><button class="btn green">최저가 맞추기 (먼저 몇 개 바뀌는지 보여줌)</button></div>
<details><summary class="mut">자세한 설명</summary><p class="mut">시중 최저가가 (공급가 + 택배비 포함 원가 + 판매처 수수료)보다 높아 이익이 남는 상품만 판매가를 최저가보다 싸게 맞춥니다. 이익이 안 남는 상품은 건드리지 않고 「시세가 원가보다 낮음」 탭으로 접어 둡니다. 쿠팡 가격은 가져올 수 없어 <b>에누리·네이버·롯데ON 중 최저가 기준</b>입니다.</p></details></form></div>
{mode_banner(accs)}
<div class="row" style="margin-bottom:10px">{tabs} <a class="btn sm gray" href="/rotate">안 팔리는 상품 순환</a> <a class="btn sm gray" href="/pc/installer.bat">PC 설치 파일 받기(시중 최저가 자동 조회)</a></div>
<form id="ff" method="post" action="/finder/act" data-busy><div class="card"><div class="row" style="margin-bottom:8px">{acc_opts}</div>
<div class="row"><button class="btn green" type="button" id="fpub">선택 상품 가져와서 등록(사진 가공·상세페이지 포함)</button><button class="btn" name="do" value="import">가져오기만</button><button class="btn gray" name="do" value="skip">제외</button><button class="btn gray" name="do" value="back">추천으로 되돌리기</button><button class="btn gray" formaction="/finder/mins" formmethod="post">직접 입력한 최저가 저장·다시 계산</button><span class="mut" id="autoimg_note"></span></div></div>
<div class="card tbl"><table><tr><th><input type="checkbox" data-all="fid" style="width:auto"></th><th></th><th>상품 · 근거</th><th>점수</th><th>공급가</th><th>시중 최저가(조회처)</th><th>우리 판매가</th><th>이익</th><th></th></tr>{trs or '<tr><td colspan=9>아직 후보가 없습니다. 위에서 분야를 넣고 지금 찾기를 누르세요.</td></tr>'}</table></div></form>
<form method="post" action="/finder/save"><div class="card"><h2>자동 켜기·끄기</h2><div class="grid">
<div><label>자동 찾기</label>{sel('auto_find', c.get('auto_find'))}</div><div><label>몇 시간마다</label><input name="find_hours" value="{fv(c.get('find_hours'))}"></div>
<div><label>자동 등록(찾은 상품을 바로 마켓에 올림)</label>{sel('auto_register', c.get('auto_register'))}</div><div><label>하루 최대 등록 수</label><input name="max_per_day" value="{fv(c.get('max_per_day'))}"></div>
<div><label>자동 등록 최소 점수</label><input name="min_score" value="{fv(c.get('min_score'))}"></div><div><label>최소 이익(원)</label><input name="min_profit" value="{fv(c.get('min_profit'))}"></div>
<div><label>도매매 공급가 범위(원)</label><div class="row"><input name="min_price" value="{fv(c.get('min_price'))}" style="width:45%"><input name="max_price" value="{fv(c.get('max_price'))}" style="width:45%"></div></div>
<div><label>최소 월 검색량</label><input name="min_volume" value="{fv(c.get('min_volume'))}"></div><div><label>한 번에 볼 키워드 수</label><input name="max_keywords" value="{fv(c.get('max_keywords'))}"></div><div><label>키워드당 도매매 상품 수</label><input name="per_keyword" value="{fv(c.get('per_keyword'))}"></div></div>
<p class="mut">자동 등록은 위 표의 마켓·판매처 체크 상태를 따릅니다(저장할 때 같이 저장). 자동 등록된 상품의 사진은 가공 없이 원본으로 올라갑니다. 가공하려면 상품 화면에서 자동 제작을 다시 누르세요.</p>
<h2>네이버 API 키</h2><div class="grid">
<div><label>네이버 개발자센터 Client ID (검색 API용)</label><input name="naver_id" value="{e(c.get('naver_id') or '')}" autocomplete="off" data-lpignore="true" data-1p-ignore></div><div><label>Client Secret{keyinfo('naver_secret')}</label><input name="naver_secret" type="password" autocomplete="new-password" data-lpignore="true" data-1p-ignore></div>
<div><label>검색광고 CUSTOMER_ID</label><input name="ad_customer" value="{e(c.get('ad_customer') or '')}"></div><div><label>검색광고 액세스라이선스{keyinfo('ad_key')}</label><input name="ad_key" type="password" autocomplete="off"></div><div><label>검색광고 비밀키{keyinfo('ad_secret')}</label><input name="ad_secret" type="password" autocomplete="off"></div></div>
<p class="mut">① developers.naver.com → Application 등록 → 사용 API '검색' 선택 → Client ID·Secret (쇼핑 경쟁 상품 수·시장가). ② searchad.naver.com 가입 → 도구 → API 사용 관리 → 액세스라이선스·비밀키·CUSTOMER_ID (월 검색량·연관 키워드). 둘 다 무료입니다. 없어도 작동하지만 점수가 덜 정확합니다.</p>
<input type="hidden" name="acc_from" value="ff"><button class="btn">저장</button> <button class="btn gray" formaction="/finder/keytest" formmethod="post">저장된 검색 API 키 확인</button> <button class="btn gray" formaction="/finder/probe" formmethod="post">네이버 검색 API 진단(키 없이)</button></div></form>
<script>
document.querySelector('form[action="/finder/save"]').addEventListener('submit',ev=>{{const f=ev.target;document.querySelectorAll('#ff input[name=acc]:checked,#ff input[name=ch]:checked').forEach(c=>{{const h=document.createElement('input');h.type='hidden';h.name=c.name;h.value=c.value;f.appendChild(h)}})}});
{FPUB_JS}
</script>"""
    return page("상품 찾기", body, h.user, "/finder", h.flash, h.flash_err)

def _match_rows(c, undercut, min_profit):
    pol = finder.consign_pol()
    out = {"ok": [], "no": [], "none": 0}
    for r in q("SELECT * FROM finds WHERE status='추천'"):
        if not r["mkt_min"]:
            out["none"] += 1; continue
        our, profit, ok = finder.match_calc({"name": r["item_name"], "price": r["supply_price"], "shippingFee": r["supply_ship"]}, c, pol, r["mkt_min"], undercut, min_profit)
        (out["ok"] if ok else out["no"]).append((r, our, profit))
    return out

def _match_vals(f):
    g = lambda k, d="": (f.get(k) or [d])[0]
    u = num(g("undercut", "100").replace(",", ""), float); m = num(g("min_profit", "0").replace(",", ""), float)
    return int(u if u is not None else 100), 0   # 최소 이익 기준은 쓰지 않음(바닥 가격 기준)

@route("POST", "/finder/match")
def finder_match(h):
    f = h.form_multi(); u, mp = _match_vals(f)
    c = finder.conf(); res = _match_rows(c, u, mp)
    rows_ok = "".join(f"<tr><td>{e(r['item_name'] or '')[:50]}</td><td>{r['supply_price']:,.0f}</td><td>{r['mkt_min']:,}</td><td>{r['our_price']:,}</td><td><b>{our:,}</b></td><td>{profit:,}</td></tr>" for r, our, profit in res["ok"])
    rows_no = "".join(f"<tr><td>{e(r['item_name'] or '')[:50]}</td><td>{r['supply_price']:,.0f}</td><td>{r['mkt_min']:,}</td><td colspan=3 class='mut'>시세가 바닥 가격보다 낮아 제외 (최저가−{u:,}원 = {our:,}원 → 이익 {profit:,}원, 바닥 가격은 이보다 높음)</td></tr>" for r, our, profit in res["no"])
    _neg = len(res["no"]); _few = 0
    _tot = len(res["ok"]) + len(res["no"]) + res["none"]
    summary = f"<p style='font-size:17px'><b>요약: {_tot}개 중 {len(res['ok'])}개 변경 · {_neg}개는 시중 최저가−{u:,}원이 바닥 가격보다 낮아 제외 · {res['none']}개는 최저가 미확인</b></p>"
    body = f"""<h1>최저가 맞추기 확인</h1>
<div class="card">{summary}<p><b>{len(res['ok'])}개</b>의 판매가가 바뀝니다 · 제외 {len(res['no'])}개 · 최저가 미조회 {res['none']}개(건드리지 않음)<br>
조건: 시중 최저가보다 {u:,}원 싸게 · 바닥 가격 = 공급가×(1+마진), 택배비·수수료는 별도 · 쿠팡 가격은 반영되지 않음(에누리·네이버·롯데ON 기준)</p>
<form method="post" action="/finder/match/apply"><input type="hidden" name="undercut" value="{u}"><input type="hidden" name="min_profit" value="{mp}">
<button class="btn green" {'disabled' if not res['ok'] else ''}>이대로 적용하고 마켓 등록 단계로 ({len(res['ok'])}개)</button> <a class="btn gray" href="/finder">취소</a>
<p class="mut">적용하면 바로 「마켓에 올리기」 화면이 열립니다. 거기서 올릴 계정을 고르고 등록하면 끝입니다.{'' if res['ok'] else ' (지금은 바뀌는 상품이 없습니다. 목록 그대로 올리려면 「취소」 후 목록에서 상품을 체크해 등록하세요)'}</p></form></div>
<div class="card tbl"><table><tr><th>상품</th><th>공급가</th><th>시중 최저가(조회처)</th><th>지금 판매가</th><th>바뀔 판매가</th><th>이익</th></tr>{rows_ok}{rows_no}</table></div>"""
    return page("최저가 맞추기 확인", body, h.user, "/finder", h.flash, h.flash_err)

@route("POST", "/finder/match/apply")
def finder_match_apply(h):
    f = h.form_multi(); u, mp = _match_vals(f)
    c = get_setting("finder", {}) or {}
    c["match_undercut"], c["match_min_profit"] = u, mp
    set_setting("finder", c)
    fc = finder.conf(); res = _match_rows(fc, u, mp)
    for r, our, profit in res["ok"]:
        x("UPDATE finds SET our_price=?, profit=?, price_fixed=1 WHERE id=?", (our, profit, r["id"]))
    for r, our, profit in res["no"]:
        pass   # 제외 상품도 바닥 가격(price_fixed=1)을 그대로 유지
    log(h.user["username"], "최저가 맞추기", f"{len(res['ok'])}개 적용, 제외 {len(res['no'])}개, 싸게 {u}원, 최소이익 {mp}원")
    ids = ",".join(str(r["id"]) for r, _o, _p in res["ok"])
    go("/finder/publish?ids=" + ids, f"{len(res['ok'])}개 판매가를 시중 최저가보다 {u:,}원 싸게 맞췄습니다. 아직 마켓에는 올라가지 않았습니다 — 아래에서 바로 등록하세요")

@route("GET", "/finder/publish")
def finder_publish(h):
    """최저가 맞추기 적용 직후의 다음 단계: 맞춘 상품을 그대로 골라 마켓에 등록"""
    c = finder.conf()
    ids = [int(i) for i in (h.qs.get("ids") or "").split(",") if i.strip().isdigit()]
    rows = [r for r in (q("SELECT * FROM finds WHERE id=?", (i,), one=True) for i in ids) if r and r["status"] == "추천"]
    accs = RA(q("SELECT * FROM accounts WHERE active=1 ORDER BY market,id"))
    allch = chs.all_channels()
    fv = lambda v: "" if v in (None, "") else f"{v:,.0f}" if isinstance(v, (int, float)) else e(str(v))
    trs = "".join(f"""<tr><td><input type="checkbox" name="fid" value="{r['id']}" style="width:auto" checked></td><td>{f'<img class="thumb" src="{e(r["image"])}" loading="lazy" referrerpolicy="no-referrer">' if r['image'] else '<div class="thumb"></div>'}</td>
<td><b>{e(r['item_name'] or '')}</b></td><td>{fv(r['supply_price'])}원</td><td>{fv(r['mkt_min'])}원</td><td><b>{fv(r['our_price'])}원</b></td><td>{fv(r['profit'])}원</td></tr>""" for r in rows)
    body = f"""<h1>다음 단계: 마켓에 올리기</h1>
<div class="card" style="border-left:6px solid #2563eb;font-size:17px"><b>① 판매가 맞추기 완료 → ② 지금 마켓에 등록</b><br>아래 {len(rows)}개는 판매가만 바뀌었고 <b>아직 마켓에는 올라가지 않았습니다.</b> 올릴 계정을 확인하고 「등록」을 누르세요. 상품 가져오기·사진 가공·상세페이지 만들기·등록이 한 번에 진행됩니다(상품당 1분 안팎, 창을 닫지 마세요).</div>
{mode_banner(accs)}
<form id="ff" method="post" action="/finder/act" data-busy><div class="card"><div class="row" style="margin-bottom:8px">{finder_acc_opts(c, accs, allch)}</div>
<div class="row"><button class="btn green" type="button" id="fpub" style="font-size:18px;padding:12px 20px">이 상품들 마켓에 등록하기 ({len(rows)}개)</button><a class="btn gray" href="/finder">나중에 하기</a><span class="mut" id="autoimg_note"></span></div></div>
<div class="card tbl"><table><tr><th><input type="checkbox" data-all="fid" style="width:auto" checked></th><th></th><th>상품</th><th>공급가</th><th>시중 최저가(조회처)</th><th>바뀐 판매가</th><th>이익</th></tr>{trs or '<tr><td colspan=7>올릴 상품이 없습니다(바뀐 상품이 없거나 이미 가져온 상품입니다). <a href="/finder">목록으로</a></td></tr>'}</table></div></form>
<script>{FPUB_JS}</script>"""
    return page("마켓에 올리기", body, h.user, "/finder", h.flash, h.flash_err)

@route("POST", "/finder/rush")
def finder_rush(h):
    """「지금 조회 요청」: PC가 30분마다 서버를 확인하다가 이 표시를 보면 평소 간격(2시간)을 건너뛰고 바로 조회함"""
    set_setting("pc_rush", time.time())
    log(h.user["username"], "PC 네이버 최저가 지금 조회 요청", "")
    go("/finder", "PC에 지금 조회를 요청했습니다. PC가 켜져 있으면 1분 안에 조회를 시작합니다(네이버가 막으면 쉬었다가 이어서 합니다)")

@route("GET", "/finder/published")
def finder_published(h):
    """상품 찾기에서 마켓에 올린 직후 결과 화면: 상품별로 올라갔는지 실패했는지, 다음에 할 일"""
    pids = [int(i) for i in (h.qs.get("pids") or "").split(",") if i.strip().isdigit()]
    trs, n_ok, n_prev, n_fail = "", 0, 0, 0
    for pid in pids:
        p = q("SELECT * FROM products WHERE id=?", (pid,), one=True)
        if not p:
            continue
        ls = q("SELECT l.*, a.label FROM listings l LEFT JOIN accounts a ON a.id=l.account_id WHERE l.product_id=? ORDER BY l.id DESC", (pid,))
        if not ls:
            n_fail += 1
            st = "<b style='color:#dc2626'>실패 — 올라가지 않았습니다 (위 빨간 안내의 이유를 확인하세요)</b>"
        else:
            parts = []
            for l in ls:
                if l["dry"]:
                    n_prev += 1; parts.append(f"<span style='color:#dc2626'>미리보기(실제로 안 올라감) · {e(l['label'] or l['market'])}</span>")
                else:
                    n_ok += 1; parts.append(f"<span style='color:#16a34a'><b>등록 요청됨</b> · {e(l['label'] or l['market'])} · {int(l['price'] or 0):,}원</span>")
            st = "<br>".join(parts)
        trs += f"<tr><td><a href='/products/{pid}'>{e(p['name'] or '')[:60]}</a></td><td>{st}</td></tr>"
    head = (f"<div class='card' style='border-left:6px solid {'#16a34a' if n_ok and not (n_prev or n_fail) else '#dc2626'};font-size:17px'>"
            f"<b>결과: 등록 요청 {n_ok}개 · 미리보기 {n_prev}개 · 실패 {n_fail}개</b><br>"
            + ("스마트스토어 판매자센터 「상품관리」에서 보이는지 확인하세요. 심사·반영에 몇 분 걸릴 수 있습니다." if n_ok else "실제로 올라간 상품이 없습니다. 위 안내의 이유를 고친 뒤 「잘 팔릴 상품 찾기」에서 다시 올리세요.")
            + "</div>")
    body = f"""<h1>마켓 등록 결과</h1>{head}
<div class="card tbl"><table><tr><th>상품</th><th>결과</th></tr>{trs or '<tr><td colspan=2>결과가 없습니다</td></tr>'}</table></div>
<div class="row"><a class="btn" href="/finder">잘 팔릴 상품 찾기로 돌아가기</a> <a class="btn gray" href="/b2b">위탁 상품 목록 보기</a></div>"""
    return page("마켓 등록 결과", body, h.user, "/finder", h.flash, h.flash_err)

@route("POST", "/finder/seednow")
def finder_seednow(h):
    n = finder.apply_seed()
    go("/finder", f"PC에서 조회한 최저가 {n}개를 넣었습니다" if n else "새로 넣을 값이 없습니다(이미 채워졌거나, 번호가 맞는 후보가 없음)")

@route("POST", "/finder/mins")
def finder_mins(h):
    """CHOI가 네이버에서 직접 확인한 최저가를 목록에 저장하고 판매가·이익을 다시 계산 (네이버 쇼핑 API 종료 대응)"""
    f = h.form_multi()
    n = 0
    for k, v in f.items():
        if k.startswith("min_") and k[4:].isdigit():
            val = num((v[0] if v else "").replace(",", "").strip(), float) if (v and v[0].strip()) else None
            x("UPDATE finds SET mkt_min=? WHERE id=?", (int(val) if val else None, int(k[4:])))
            n += 1
    cnt = finder.recalc_all(finder.conf())
    go("/finder", f"최저가 {n}칸을 저장하고 {cnt}개 판매가·이익을 다시 계산했습니다")

@route("POST", "/finder/fillnow")
def finder_fillnow(h):
    if get_setting("finder_min_running"):
        go("/finder", "이미 조회 중입니다. 잠시 뒤 새로고침하세요")
    set_setting("finder_min_running", True)
    def _fill():
        try:
            n, why = finder.server_fill_lowest()
            finder.recalc_all(finder.conf())
            log(h.user["username"], "네이버 최저가 서버 조회", f"{n}개 채움" + (f", 중단: {why}" if why else ""))
        except Exception as ex:
            log("자동", "네이버 최저가 서버 조회 오류", str(ex)[:300])
        finally:
            set_setting("finder_min_running", False)
    threading.Thread(target=_fill, daemon=True).start()
    go("/finder", "서버가 네이버 최저가를 조회하기 시작했습니다(키워드당 8~14초). 몇 분 뒤 새로고침하세요")

@route("POST", "/finder/probe")
def finder_probe(h):
    msg = finder.probe()
    log(h.user["username"], "네이버 검색 API 진단", msg[:900])
    go("/finder", msg)

@route("POST", "/finder/keytest")
def finder_keytest(h):
    c = finder.conf()
    msg = finder.key_check(c)
    go("/finder", msg, ("정상" not in msg))

@route("POST", "/finder/price")
def finder_price(h):
    f = h.form_multi()
    g = lambda k, d="": (f.get(k) or [d])[0]
    c = get_setting("finder", {}) or {}
    mode = g("price_mode", "policy")
    c["price_mode"] = mode if mode in ("policy", "pct", "price_pct", "won", "match_low") else "policy"
    for k in ("price_margin", "price_ship", "price_undercut"):
        raw = g(k).replace(",", "").strip()
        c[k] = (num(raw, float) if raw else None)
    if c["price_mode"] in ("policy", "match_low") and c.get("price_margin") not in (None, ""):
        c["price_mode"] = "pct"   # 마진 칸에 값을 넣었으면 그 마진으로 계산
    set_setting("finder", c)
    fc = finder.conf()
    msg = ""
    try:
        if g("lowest") == "1":
            msg = f"네이버 최저가 {finder.refresh_lowest(fc)}개 키워드 조회. "
        msg += f"판매가·이익 {finder.recalc_all(fc)}개 다시 계산했습니다"
    except finder.FindError as ex:
        finder.recalc_all(fc)
        go("/finder", str(ex), True)
    log(h.user["username"], "상품 찾기 판매가 설정", f"{c['price_mode']} {c.get('price_margin')} 배송 {c.get('price_ship')} 할인 {c.get('price_undercut')}")
    go("/finder", msg)

@route("POST", "/finder/run")
def finder_run(h):
    f = h.form()
    c = get_setting("finder", {}) or {}
    c["seeds"] = f.get("seeds", "").strip()
    set_setting("finder", c)
    try:
        n, msg, notes = finder.run(h.user["username"])
    except (finder.FindError, ocmod.OCError) as ex:
        go("/finder", str(ex), True)
    set_setting("pc_rush", time.time())   # 찾은 직후 PC가 바로 시중 최저가를 조회하도록 자동 요청
    go("/finder", msg + ("\n" + "\n".join(notes) if notes else "") + "\n시중 최저가는 PC가 1분 안에 조회를 시작해 채웁니다(PC가 켜져 있어야 함).")

@route("POST", "/finder/import")
def finder_import_api(h):
    f = h.form_multi()
    h.extra_headers = {"Content-Type": "application/json; charset=utf-8"}
    try:
        pids = finder_import([int(i) for i in f.get("fid", [])], h.user["username"])
    except Exception as ex:
        return json.dumps({"error": f"가져오기 실패: {ex}"}, ensure_ascii=False)
    for pid in pids:
        x("UPDATE finds SET status='등록됨' WHERE product_id=?", (pid,))
    return json.dumps({"pids": pids})

@route("POST", "/finder/act")
def finder_act(h):
    f = h.form_multi()
    fids = [int(i) for i in f.get("fid", [])]
    do = (f.get("do") or [""])[0]
    if not fids:
        go("/finder", "상품을 하나 이상 고르세요", True)
    if do in ("skip", "back"):
        for i in fids:
            x("UPDATE finds SET status=?, skip_why=? WHERE id=?", ("제외" if do == "skip" else "추천", "직접 제외" if do == "skip" else "복원", i))   # 복원한 것은 자동 제외 대상에서 뺌
        go("/finder", f"{len(fids)}개를 {'제외했습니다' if do == 'skip' else '추천으로 되돌렸습니다'}")
    try:
        pids = finder_import(fids, h.user["username"])
    except Exception as ex:
        go("/finder", f"가져오기 실패: {ex}", True)
    go("/products?type=" + quote("위탁"), f"{len(pids)}개를 위탁 상품으로 가져왔습니다. 상세페이지를 만들고 마켓에 올리세요.")

@route("POST", "/finder/save")
def finder_save(h):
    f = h.form_multi()
    g = lambda k, d="": (f.get(k) or [d])[0]
    c = get_setting("finder", {}) or {}
    for k in ("find_hours", "max_per_day", "min_score", "min_profit", "min_price", "max_price", "min_volume", "max_keywords", "per_keyword"):
        v = num(g(k).replace(",", ""), float)
        c[k] = v if v is not None else finder.DEFAULT[k]
    c["auto_find"] = g("auto_find") == "1"
    c["auto_register"] = g("auto_register") == "1"
    c["reg_accs"] = f.get("acc", [])
    c["reg_chans"] = f.get("ch", [])
    c["naver_id"] = g("naver_id").strip(); c["ad_customer"] = g("ad_customer").strip()
    for k in ("naver_secret", "ad_key", "ad_secret"):
        if g(k).strip():
            c[k] = seal(g(k).strip())
    set_setting("finder", c)
    log(h.user["username"], "상품 찾기 설정 저장", f"자동 찾기 {'켜짐' if c['auto_find'] else '꺼짐'} · 자동 등록 {'켜짐' if c['auto_register'] else '꺼짐'}")
    go("/finder", "저장했습니다")

# ---------- 발주·송장 ----------
def order_link(o):
    if o["source_url"]:
        return '<a class="btn sm" target="_blank" href="' + e(o["source_url"]) + '">도매매에서 주문 →</a>'
    return e(o["supplier_key"] or "연결 안 됨")

@route("GET", "/fulfill")
def fulfill(h):
    def rows(sql, args=()):
        return q("SELECT o.*, p.name pname, p.source_url, p.supplier_key, p.supply_price, p.supply_ship, p.set_qty, a.label FROM orders o LEFT JOIN products p ON p.id=o.product_id LEFT JOIN accounts a ON a.id=o.account_id " + sql, args)
    cour = "".join(f"<option>{e(n)}</option>" for n in couriers.names())
    def rcv_txt(o):
        r = json.loads(o["rcv"] or "{}")
        return f"{e(mask(r.get('name', '')))}<div class='mut'>{e((r.get('addr1') or '')[:18])}</div>"
    def base(o):
        return (f"<td>{e(where_label(o['market']))}<div class='mut'>{e(o['label'] or '예시')}</div></td><td>{e(o['pname'] or o['product_name'] or '')}"
                f"<div class='mut'>{e(o['option_text'] or '')} · {e(str(o['order_id']))}</div></td><td>{o['qty'] or 1}</td><td>{(o['amount'] or 0):,}</td><td>{rcv_txt(o)}</td>")
    wait = rows("WHERE o.po_status IN ('발주대기','발주실패') ORDER BY o.id")
    t1 = "".join(f"<tr><td><input type='checkbox' name='oid' value='{o['id']}' style='width:auto'></td>{base(o)}<td>{order_link(o)}"
                 f"<div class='mut'>공급 {(float(o['supply_price'] or 0) * int(o['qty'] or 1) * int(o['set_qty'] or 1) + float(o['supply_ship'] or 0)):,.0f}원</div>"
                 f"{('<div style=color:#dc2626>' + e(o['po_msg'] or '') + '</div>') if o['po_status'] == '발주실패' else ''}</td></tr>" for o in wait)
    sent = rows("WHERE o.po_status IN ('발주완료','발주완료(미리보기)','송장받음') ORDER BY o.id")
    t2 = "".join(f"<tr>{base(o)}<td>{e(o['po_key'] or '')}<div class='mut'>{e(o['po_status'])} {e(o['courier'] or '')} {e(o['tracking'] or '')}</div>"
                 f"{('<div class=mut>' + e(o['po_msg']) + '</div>') if o['po_msg'] else ''}"
                 f"<details><summary class='mut' style='cursor:pointer'>송장 직접 넣기</summary><form method='post' action='/fulfill/{o['id']}/ship' class='row' data-busy><select name='courier' style='width:120px'>{cour}</select>"
                 f"<input name='tracking' placeholder='송장번호' style='width:130px'><button class='btn sm green'>보내기</button></form></details></td></tr>" for o in sent)
    own = rows("WHERE o.po_status IN ('발송대기') ORDER BY o.id")
    t3 = "".join(f"<tr>{base(o)}<td><form method='post' action='/fulfill/{o['id']}/ship' class='row' data-busy><select name='courier' style='width:120px'>{cour}</select>"
                 f"<input name='tracking' placeholder='송장번호' style='width:130px'><button class='btn sm green'>보내기</button></form>"
                 f"{'' if o['product_id'] else '<div class=mut>상품 연결 안 됨</div>'}{('<div class=mut>' + e(o['po_msg']) + '</div>') if o['po_msg'] else ''}</td></tr>" for o in own)
    done = rows("WHERE o.po_status LIKE '발송완료%' ORDER BY o.shipped_at DESC LIMIT 50")
    t4 = "".join(f"<tr>{base(o)}<td>{e(o['supply_type'] or '')} · {e(o['courier'] or '')} {e(o['tracking'] or '')}<div class='mut'>{e(o['po_status'])} {time.strftime('%m-%d %H:%M', time.localtime(o['shipped_at'])) if o['shipped_at'] else ''}</div></td></tr>" for o in done)
    th = "<tr><th>마켓</th><th>상품</th><th>수량</th><th>결제액</th><th>받는 분</th>"
    demo = ""
    if h.user["role"] == "admin" and False:
        opts = "".join(f"<option value='{p['id']}'>[{e(p['supply_type'] or '사입')}] {e(p['name'][:30])}</option>" for p in q("SELECT id,name,supply_type FROM products ORDER BY supply_type DESC, id DESC LIMIT 200"))
        demo = f"""<div class="card"><h2>예시 주문 만들기(미리보기 모드에서 흐름 연습용)</h2><form method="post" action="/fulfill/demo" class="row"><select name="pid" style="max-width:360px">{opts}</select><button class="btn gray">예시 주문 추가</button></form></div>"""
    auto = "도매매에서 직접 주문한 뒤 아래 버튼으로 표시"
    body = f"""<h1>발주·송장</h1>
<div class="card"><h2>① 위탁 발주 대기 <span class="mut">({len(wait)}건 · {auto})</span></h2><form method="post" action="/fulfill/order" data-busy><div class="tbl"><table>
<tr><th><input type="checkbox" data-all="oid" style="width:auto"></th>{th[4:]}<th>도매매</th></tr>{t1 or '<tr><td colspan=7>없음</td></tr>'}</table></div><br>
<button class="btn green">선택 주문을 '도매매에서 주문함'으로 표시</button> <a class="btn gray" href="/fulfill/domeme.csv">도매매 주문용 엑셀(CSV) 받기</a></form></div>
<div class="card"><h2>② 도매매 송장 기다리는 중 <span class="mut">({len(sent)}건)</span></h2><form method="post" action="/fulfill/check" data-busy><button class="btn sm">지금 송장 확인</button></form><br>
<div class="tbl"><table>{th}<th>발주번호 · 송장</th></tr>{t2 or '<tr><td colspan=6>없음</td></tr>'}</table></div><p class="mut">송장이 나오면 자동으로 마켓에 보내고 ④로 옮깁니다(주문 수집 때마다 확인).</p></div>
<div class="card"><h2>③ 사입 발송 대기 <span class="mut">({len(own)}건)</span></h2><div class="row" style="margin-bottom:8px"><a class="btn sm gray" href="/fulfill/ship.csv">택배 접수용 엑셀(CSV) 받기</a>
<form method="post" action="/fulfill/upload" enctype="multipart/form-data" class="row" data-busy><input type="file" name="file" accept=".csv" style="max-width:220px"><button class="btn sm gray">송장 엑셀 올리기</button></form></div>
<div class="tbl"><table>{th}<th>송장 입력</th></tr>{t3 or '<tr><td colspan=6>없음</td></tr>'}</table></div>
<p class="mut">송장 엑셀은 '주문번호, 택배사, 송장번호' 세 열이면 됩니다(받은 CSV에 송장만 채워서 올려도 됨).</p></div>
<div class="card"><h2>④ 발송 완료(최근 50건)</h2><div class="tbl"><table>{th}<th>송장</th></tr>{t4 or '<tr><td colspan=6>없음</td></tr>'}</table></div>
<p class="mut">받는 분 정보는 발송 후 90일이 지나면 자동으로 지웁니다.</p></div>{demo}"""
    return page("발주·송장", body, h.user, "/fulfill", h.flash, h.flash_err)

@route("GET", "/fulfill/domeme.csv")
def fulfill_domeme_csv(h):
    """도매매 주문용: 발주 대기 위탁 주문을 한 파일로(받는 분 정보 포함)"""
    out = io.StringIO(); w = csv.writer(out)
    w.writerow(["우리주문번호", "도매매상품번호", "상품명", "옵션", "수량", "받는분", "연락처", "우편번호", "주소", "상세주소", "배송메모"])
    for o in q("SELECT o.*, p.name pname, p.supplier_key, p.set_qty FROM orders o LEFT JOIN products p ON p.id=o.product_id WHERE o.po_status IN ('발주대기','발주실패') ORDER BY o.id"):
        r = json.loads(o["rcv"] or "{}")
        w.writerow([o["order_id"], o["supplier_key"] or "", o["pname"] or o["product_name"] or "", o["option_text"] or "", int(o["qty"] or 1) * int(o["set_qty"] or 1),
                    r.get("name", ""), r.get("phone", ""), r.get("zip", ""), r.get("addr1", ""), r.get("addr2", ""), r.get("memo", "")])
    h.extra_headers = {"Content-Disposition": "attachment; filename=domeme_orders.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "\ufeff" + out.getvalue()

@route("POST", "/fulfill/order")
def fulfill_order(h):
    f = h.form_multi()
    ids = [int(i) for i in f.get("oid", [])]
    if not ids:
        go("/fulfill", "주문을 고르세요", True)
    ok, msgs = 0, []
    for i in ids:
        o = q("SELECT * FROM orders WHERE id=?", (i,), one=True)
        try:
            r = place_order(o, h.user["username"]); ok += 1
            if r.get("dry"):
                msgs.append(f"[미리보기] {o['product_name']} → {os.path.basename(r.get('file', ''))}")
        except Exception as ex:
            x("UPDATE orders SET po_status='발주실패', po_msg=? WHERE id=?", (str(ex)[:500], i))
            msgs.append(f"[실패] {o['product_name']}: {ex}")
    go("/fulfill", f"{ok}건 발주했습니다\n" + "\n".join(msgs[:30]), ok < len(ids))

@route("POST", "/fulfill/check")
def fulfill_check(h):
    try:
        got, sent, errs = check_tracking(h.user["username"])
    except ocmod.OCError as ex:
        go("/fulfill", str(ex), True)
    go("/fulfill", f"새 송장 {got}건, 마켓 전송 {sent}건\n" + "\n".join(errs[:20]), bool(errs))

@route("POST", r"/fulfill/(\d+)/ship")
def fulfill_ship(h, oid):
    f = h.form()
    if not f.get("tracking", "").strip():
        go("/fulfill", "송장번호를 넣어 주세요", True)
    x("UPDATE orders SET courier=?, tracking=? WHERE id=?", (f.get("courier", ""), re.sub(r"[^0-9A-Za-z]", "", f["tracking"]), oid))
    try:
        send_tracking(q("SELECT * FROM orders WHERE id=?", (oid,), one=True), h.user["username"])
    except Exception as ex:
        x("UPDATE orders SET po_msg=? WHERE id=?", (str(ex)[:500], oid))
        go("/fulfill", f"송장 전송 실패: {ex}", True)
    go("/fulfill", "송장을 보냈습니다")

@route("GET", "/fulfill/ship.csv")
def fulfill_csv(h):
    buf = io.StringIO(); w = csv.writer(buf)
    w.writerow(["주문번호", "택배사", "송장번호", "마켓", "상품", "옵션", "수량", "받는 분", "연락처", "우편번호", "주소", "상세주소", "배송 메모"])
    for o in q("SELECT o.*, p.name pname FROM orders o LEFT JOIN products p ON p.id=o.product_id WHERE o.po_status='발송대기' ORDER BY o.id"):
        r = json.loads(o["rcv"] or "{}")
        w.writerow([o["order_id"], "", "", where_label(o["market"]), o["pname"] or o["product_name"], o["option_text"] or "", o["qty"],
                    r.get("name", ""), r.get("phone", ""), r.get("zip", ""), r.get("addr1", ""), r.get("addr2", ""), r.get("memo", "")])
    log(h.user["username"], "택배 접수용 엑셀 받기")
    h.extra_headers = {"Content-Disposition": f"attachment; filename=ship_{time.strftime('%Y%m%d')}.csv", "Content-Type": "text/csv; charset=utf-8"}
    return "﻿" + buf.getvalue()

@route("POST", "/fulfill/upload")
def fulfill_upload(h):
    _, files = h.multipart()
    fn, data = (files.get("file") or [("", b"")])[0]
    if not data:
        go("/fulfill", "파일을 골라 주세요", True)
    rows = list(csv.reader(io.StringIO(data.decode("utf-8-sig", "replace"))))
    ok, msgs = 0, []
    for r in rows[1:]:
        if len(r) < 3 or not r[0].strip() or not r[2].strip():
            continue
        o = q("SELECT * FROM orders WHERE order_id=? AND po_status='발송대기'", (r[0].strip(),), one=True)
        if not o:
            continue
        x("UPDATE orders SET courier=?, tracking=? WHERE id=?", (r[1].strip() or "CJ대한통운", re.sub(r"[^0-9A-Za-z]", "", r[2]), o["id"]))
        try:
            send_tracking(q("SELECT * FROM orders WHERE id=?", (o["id"],), one=True), h.user["username"]); ok += 1
        except Exception as ex:
            msgs.append(f"{r[0]}: {ex}")
            x("UPDATE orders SET po_msg=? WHERE id=?", (str(ex)[:500], o["id"]))
    go("/fulfill", f"{ok}건 송장을 보냈습니다\n" + "\n".join(msgs[:30]), bool(msgs))

@route("POST", "/fulfill/demo", admin=True)
def fulfill_demo(h):
    p = product(num(h.form().get("pid"), int))
    oid = f"DEMO-{uuid.uuid4().hex[:8]}"
    save_order(None, {"market": "naver", "order_id": oid, "product_name": p["name"], "qty": 1, "amount": pricing.price_krw(p, "naver"), "buyer": "홍길동",
                      "status": "PAYED", "ordered_at": time.strftime("%Y-%m-%d %H:%M"), "raw": {}, "seller_code": f"MM{p['id']}", "option": p["supplier_option"] or "",
                      "rcv": {"name": "홍길동", "phone": "010-0000-0000", "zip": "06236", "addr1": "서울특별시 강남구 테헤란로 1", "addr2": "101호", "memo": "문 앞"},
                      "ship_ref": {}})
    go("/fulfill", f"예시 주문({p['supply_type'] or '사입'})을 만들었습니다")

@route("GET", "/history")
def history(h):
    kw = h.qs.get("q", "")
    rows = q("SELECT * FROM logs WHERE action LIKE ? OR detail LIKE ? OR user LIKE ? ORDER BY id DESC LIMIT 1000", (f"%{kw}%",) * 3)
    trs = "".join(f"<tr><td class='mut'>{time.strftime('%m-%d %H:%M', time.localtime(r['ts']))}</td><td>{e(r['user'] or '')}</td><td>{e(r['action'])}</td><td>{e(r['detail'] or '')}</td></tr>" for r in rows)
    return page("작업 이력", f"""<h1>작업 이력</h1><form class="row" style="margin-bottom:12px"><input name="q" value="{e(kw)}" placeholder="예: 마켓 등록, 실패, 팀원 이름" style="max-width:300px"><button class="btn gray">검색</button></form>
<div class="card tbl"><table><tr><th>시간</th><th>누가</th><th>작업</th><th>내용</th></tr>{trs or '<tr><td colspan=4>없음</td></tr>'}</table></div>""", h.user, "/history")

@route("POST", "/settings", admin=True)
def settings_post(h):
    f = h.form()
    fl = lambda k, d: num(f.get(k), float) if num(f.get(k), float) is not None else d
    set_setting("name_rules", {"prefix": f.get("nr_prefix", ""), "suffix": f.get("nr_suffix", ""), "banned": f.get("nr_banned", ""), "replace": f.get("nr_replace", "")})
    set_setting("category_map", f.get("category_map", ""))
    set_setting("shop", {"name": f.get("shop_name", ""), "banner": f.get("shop_banner", ""), "cs": f.get("shop_cs", "")})
    ai = get_setting("ai", {}) or {}
    if f.get("ai_key"):
        ai["api_key"] = seal(f["ai_key"].strip())
    ai["model"] = f.get("ai_model") or "claude-sonnet-5-5"
    set_setting("ai", ai)
    set_setting("dry_run", False)
    set_setting("order_interval", int(fl("order_interval", 30)))
    log(h.user["username"], "설정 저장")
    go("/settings", "저장했습니다")

@route("GET", "/more")
def more(h):
    groups = [("상품 올리기·찾기", [("/suppliers/csv", "📥 엑셀·zip 올려서 자동 등록"), ("/suppliers", "🤝 도매매에서 찾기·API 키·주문 API"), ("/compete", "💹 경쟁가 보기(남들은 얼마에 파나)"), ("/products", "📦 전체 상품")]),
              ("쇼핑몰·가격 설정", [("/accounts", "🔑 마켓 계정(스마트스토어 키)"), ("/sell/consign", "💰 B2B 판매설정(마진)"), ("/sell/own", "💰 사입 판매설정(마진)"), ("/policies", "💰 추가 가격 정책"), ("/channels", "🌏 해외몰 판매처")]),
              ("알림·관리", [("/notify", "🔔 폰 알림"), ("/history", "📜 작업 이력"), ("/settings", "⚙️ 설정"), ("/me", "🔒 내 비밀번호")])]
    if h.user["role"] == "admin":
        groups[2][1].extend([("/users", "👥 팀원 관리"), ("/admin", "🛠 백업·업데이트")])
    groups[2][1].append(("/logout", "↩ 로그아웃"))
    body = "<h1>메뉴</h1>" + "".join(f'<h2 style="margin:18px 0 8px">{g}</h2><div class="grid">' + "".join(f'<a class="card" style="display:block;color:inherit;margin:0" href="{u}">{t}</a>' for u, t in its) + "</div>" for g, its in groups)
    return page("메뉴", body, h.user, "/more")

@route("GET", "/admin", admin=True)
def admin_page(h):
    from . import VERSION
    return page("백업·업데이트", f"""<h1>백업·업데이트</h1><div class="card"><h2>백업</h2><p class="mut">상품·계정·주문 데이터 전체(app.db)를 내려받습니다. 일주일에 한 번 받아 두세요.</p><a class="btn" href="/admin/backup">백업 파일 받기</a></div>
<div class="card"><h2>자동 업데이트</h2>
<p>현재 버전 <b>{VERSION}</b> · 업데이트 위치의 최신 버전 <b>{e(updater.state['latest'] or '확인 안 됨')}</b> {'<span class="tag ok">새 버전 있음</span>' if updater.available() else ''}</p>
{f'<p class="mut">바뀐 점: {e(updater.state["notes"])}</p>' if updater.state['notes'] else ''}{f'<p class="mut" style="color:#b91c1c">{e(updater.state["error"])}</p>' if updater.state['error'] else ''}
<form method="post" action="/admin/updater" class="row" data-busy><button class="btn gray" name="do" value="check">지금 확인</button>{'<button class="btn green" name="do" value="apply">지금 업데이트</button>' if updater.available() else ''}</form>
<form method="post" action="/admin/updater"><label>업데이트 위치(폴더 경로 또는 https 주소, 비우면 프로그램 옆 update 폴더)</label><input name="src" value="{e(get_setting('update_source', '') or '')}" placeholder="{e(updater.source())}">
<label>자동 업데이트</label><select name="auto" style="max-width:420px"><option value="1">켜기 (켤 때 바로, 켜져 있으면 새벽 4시에 교체)</option><option value="0" {'' if updater.auto_on() else 'selected'}>끄기 (알림만, 버튼으로 직접)</option></select>
<br><br><button class="btn" name="do" value="save">저장</button></form>
<p class="mut">팀 전체를 한 번에 올리려면: 공유 드라이브(구글드라이브·원드라이브)에 폴더를 하나 만들어 모든 PC의 업데이트 위치로 지정하고, 새 버전이 나오면 그 폴더에 version.json·MultiMarket.exe 를 넣으면 됩니다.</p></div>
<div class="card"><h2>직접 업데이트(zip 올리기)</h2><p class="mut">서버·파이썬 설치본용. 새 버전 zip(mmtool_update.zip)을 올리면 교체 후 다시 켜집니다.</p>
<form method="post" action="/admin/update" enctype="multipart/form-data" data-busy><input type="file" name="file" accept=".zip" required><br><br><button class="btn">업데이트</button></form></div>""", h.user, "/admin", h.flash, h.flash_err)

@route("GET", "/admin/backup", admin=True)
def admin_backup(h):
    import sqlite3, tempfile
    from .paths import DB_PATH
    tmp = os.path.join(tempfile.gettempdir(), "mm_backup.db")
    src = sqlite3.connect(DB_PATH); dst = sqlite3.connect(tmp); src.backup(dst); dst.close(); src.close()
    h.extra_headers = {"Content-Type": "application/octet-stream", "Content-Disposition": f"attachment; filename=multimarket_{time.strftime('%Y%m%d')}.db"}
    with open(tmp, "rb") as f:
        return f.read()

@route("POST", "/admin/updater", admin=True)
def admin_updater(h):
    f = h.form()
    do = f.get("do")
    if do == "save":
        from .db import set_setting
        set_setting("update_source", f.get("src", "").strip())
        set_setting("auto_update", f.get("auto") == "1")
        updater.check()
        go("/admin", "저장했습니다")
    if do == "apply":
        log(h.user["username"], "자동 업데이트 실행", updater.state["latest"])
        def run():
            time.sleep(1)
            try:
                updater.apply()
            except Exception as ex:
                updater.state["error"] = f"업데이트 실패: {ex}"
        threading.Thread(target=run, daemon=True).start()
        go("/admin", f"{updater.state['latest']} 버전으로 바꾸는 중입니다. 20초 뒤 새로고침하세요.")
    updater.check()
    go("/admin", "새 버전이 있습니다" if updater.available() else (updater.state["error"] or "최신 버전입니다"), bool(updater.state["error"]))

@route("POST", "/admin/update", admin=True)
def admin_update(h):
    import zipfile, sys
    _, files = h.multipart()
    fn, data = (files.get("file") or [("", b"")])[0]
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if getattr(sys, "frozen", False):
        go("/admin", ".exe 버전은 새 .exe 파일로 바꿔 끼우면 됩니다", True)
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        names = [n for n in z.namelist() if n.endswith(".py") and ".." not in n and not n.startswith("/")]
        if "main.py" not in names:
            raise ValueError("main.py가 없는 zip입니다")
        for n in names:
            os.makedirs(os.path.dirname(os.path.join(root, n)) or root, exist_ok=True)
            with open(os.path.join(root, n), "wb") as f:
                f.write(z.read(n))
    except Exception as ex:
        go("/admin", f"업데이트 실패: {ex}", True)
    log(h.user["username"], "프로그램 업데이트", fn)
    threading.Timer(1.5, lambda: os._exit(0)).start()   # systemd가 다시 켭니다
    go("/admin", "업데이트했습니다. 10초 뒤 새로고침하세요.")

# ---------- 정적 ----------
def _png(size):
    rows = []
    for y in range(size):
        row = bytearray([0])
        for x_ in range(size):
            inner = size * .22 < x_ < size * .78 and size * .38 < y < size * .78
            handle = (abs(((x_ - size / 2) ** 2 + (y - size * .38) ** 2) ** .5 - size * .14) < size * .03) and y < size * .38
            row += bytes((47, 111, 237) if inner else (255, 255, 255) if handle else (17, 24, 39))
        rows.append(bytes(row))
    raw = zlib.compress(b"".join(rows))
    ch = lambda t, d: struct.pack(">I", len(d)) + t + d + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    return b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)) + ch(b"IDAT", raw) + ch(b"IEND", b"")

_ICONS = {}
@route("GET", r"/icon(-512)?\.png", public=True)
def icon_png(h, big):
    s = 512 if big else 192
    if s not in _ICONS:
        _ICONS[s] = _png(s)
    h.extra_headers = {"Content-Type": "image/png", "Cache-Control": "max-age=86400"}
    return _ICONS[s]

@route("GET", "/icon.svg", public=True)
def icon_svg(h):
    h.extra_headers = {"Content-Type": "image/svg+xml"}
    return ICON_SVG

@route("GET", "/manifest.json", public=True)
def manifest(h):
    h.extra_headers = {"Content-Type": "application/manifest+json"}
    return MANIFEST

@route("GET", "/sw.js", public=True)
def sw(h):
    h.extra_headers = {"Content-Type": "application/javascript"}
    return SW

@route("GET", r"/img/(.+)", public=True)
def img(h, name):
    from urllib.parse import unquote
    name = os.path.basename(unquote(name))
    path = os.path.join(IMAGES, name)
    if not os.path.isfile(path):
        h.status = 404
        return "없음"
    h.extra_headers = {"Content-Type": mimetypes.guess_type(name)[0] or "application/octet-stream", "Cache-Control": "max-age=86400"}
    with open(path, "rb") as f:
        return f.read()

# ---------- HTTP 처리 ----------
class Handler(BaseHTTPRequestHandler):
    server_version = "MultiMarket/1.0"

    def log_message(self, fmt, *args):
        pass

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        if n > 60 * 1024 * 1024:
            raise ValueError("파일이 너무 큽니다(60MB 초과)")
        return self.rfile.read(n) if n else b""

    def form(self):
        return {k: v[0] for k, v in parse_qs(self._body().decode("utf-8", "replace"), keep_blank_values=True).items()}

    def form_multi(self):
        return parse_qs(self._body().decode("utf-8", "replace"), keep_blank_values=True)

    def multipart_stream(self):
        """큰 업로드용: 메모리에 통째로 올리지 않고 파일을 임시 폴더에 바로 저장. (필드, {이름: [(파일이름, 임시경로)]}, 임시폴더)"""
        import tempfile
        ct = self.headers.get("Content-Type", "")
        m = re.search(r'boundary=("?)([^";]+)\1', ct)
        n = int(self.headers.get("Content-Length") or 0)
        if n > 60 * 1024 * 1024:
            raise ValueError("파일이 너무 큽니다(60MB 초과)")
        tmp = tempfile.mkdtemp(prefix="mmup_")
        fields, files = {}, {}
        self._mvals = {}
        if not m:
            return fields, files, tmp
        delim = b"\r\n--" + m.group(2).encode()
        keep = len(delim) + 4
        buf, left, state = b"\r\n", n, "BODY"
        out, cur = None, None   # out: 파일 객체, cur: (name, fn, path) 또는 (name, None, bytearray)
        k = 0
        def finish():
            nonlocal out, cur
            if cur is None:
                return
            if out:
                out.close(); out = None
                files.setdefault(cur[0], []).append((cur[1], cur[2]))
            elif cur[1] is None:
                v = bytes(cur[2]).decode("utf-8", "replace")
                fields[cur[0]] = v; self._mvals.setdefault(cur[0], []).append(v)
            cur = None
        while True:
            if state == "BODY":
                i = buf.find(delim)
                if i >= 0:
                    chunk, buf = buf[:i], buf[i + len(delim):]
                    if cur is not None:
                        (out.write(chunk) if out else cur[2].extend(chunk))
                    finish(); state = "AFTER"; continue
                if len(buf) > keep:
                    chunk, buf = buf[:-keep], buf[-keep:]
                    if cur is not None:
                        (out.write(chunk) if out else cur[2].extend(chunk))
            elif state == "AFTER":
                if len(buf) >= 2:
                    if buf[:2] == b"--":
                        break
                    buf = buf[2:]; state = "HEAD"; continue
            elif state == "HEAD":
                i = buf.find(b"\r\n\r\n")
                if i >= 0:
                    head, buf = buf[:i].decode("utf-8", "replace"), buf[i + 4:]
                    nm = re.search(r'name="([^"]*)"', head); fm = re.search(r'filename="([^"]*)"', head)
                    if fm:
                        k += 1
                        path = os.path.join(tmp, f"{k}_" + re.sub(r"[^\w.\-]", "_", os.path.basename(fm.group(1)))[:80])
                        out = open(path, "wb"); cur = (nm.group(1) if nm else "", fm.group(1), path)
                    else:
                        cur = (nm.group(1) if nm else "", None, bytearray())
                    state = "BODY"; continue
            if left <= 0:
                break
            chunk = self.rfile.read(min(1 << 20, left))
            if not chunk:
                break
            left -= len(chunk); buf += chunk
        finish()
        return fields, files, tmp

    def multipart(self):
        ct = self.headers.get("Content-Type", "")
        body = self._body()
        if "multipart" not in ct:
            return {k: v[0] for k, v in parse_qs(body.decode(), keep_blank_values=True).items()}, {}
        msg = BytesParser(policy=email_policy).parsebytes(b"Content-Type: " + ct.encode() + b"\r\n\r\n" + body)
        fields, files = {}, {}
        self._mvals = {}
        for part in msg.iter_parts():
            name = part.get_param("name", header="content-disposition")
            fn = part.get_filename()
            data = part.get_payload(decode=True) or b""
            if fn is not None:
                files.setdefault(name, []).append((fn, data))
            else:
                fields[name] = data.decode("utf-8", "replace")
                self._mvals.setdefault(name, []).append(fields[name])
        return fields, files

    def multi_values(self, name):
        """multipart 양식에서 같은 이름의 값 여러 개(체크박스)"""
        return list(getattr(self, "_mvals", {}).get(name, []))

    def handle_any(self, method):
        u = urlparse(self.path)
        self.qs = {k: v[0] for k, v in parse_qs(u.query).items()}
        ck = SimpleCookie(self.headers.get("Cookie", ""))
        self.token = ck["mm_s"].value if "mm_s" in ck else None
        self.flash = unquote_c(ck["mm_f"].value) if "mm_f" in ck else None
        self.flash_err = "mm_fe" in ck
        self.user = auth.user_for(self.token)
        self.set_cookie, self.extra_headers, self.status = None, {}, 200
        clear_flash = bool(self.flash)
        for m, rx, fn, public, admin in ROUTES:
            mt = rx.match(u.path)
            if m == method and mt:
                break
        else:
            return self.send(404, page("없음", "<h1>페이지가 없습니다</h1>", self.user))
        try:
            if not public and not self.user:
                go("/login")
            if admin and self.user["role"] != "admin":
                go("/", "관리자만 할 수 있습니다", True)
            out = fn(self, *mt.groups())
            self.send(self.status, out, clear_flash)
        except Redirect as r:
            self.send_response(303)
            self.send_header("Location", r.to)
            if self.set_cookie:
                self.send_header("Set-Cookie", self.set_cookie)
            if r.flash:
                self.send_header("Set-Cookie", "mm_f=" + quote(r.flash[:1500]) + "; Path=/; Max-Age=60")
                self.send_header("Set-Cookie", "mm_fe=1; Path=/; Max-Age=60" if r.err else "mm_fe=; Path=/; Max-Age=0")
            self.end_headers()
        except Exception as ex:
            traceback.print_exc()
            self.send(500, page("오류", f"<h1>오류</h1><div class='flash err'>{e(str(ex))}</div><a href='javascript:history.back()'>뒤로</a>", self.user))

    def send(self, code, out, clear_flash=False):
        data = out if isinstance(out, bytes) else str(out or "").encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", self.extra_headers.pop("Content-Type", "text/html; charset=utf-8") if hasattr(self, "extra_headers") else "text/html; charset=utf-8")
        for k, v in (getattr(self, "extra_headers", {}) or {}).items():
            self.send_header(k, v)
        if getattr(self, "set_cookie", None):
            self.send_header("Set-Cookie", self.set_cookie)
        if clear_flash:
            self.send_header("Set-Cookie", "mm_f=; Path=/; Max-Age=0")
            self.send_header("Set-Cookie", "mm_fe=; Path=/; Max-Age=0")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self.handle_any("GET")

    def do_POST(self):
        self.handle_any("POST")

def unquote_c(v):
    from urllib.parse import unquote
    return unquote(v)

STORE_STATUS = {"SALE": "판매중", "OUTOFSTOCK": "품절", "SUSPENSION": "판매중지", "PROHIBITION": "판매금지", "CLOSE": "판매종료"}

def naver_sync_check(user="자동확인", fix=True):
    """네이버 스마트스토어의 실제 상품 목록과 프로그램 기록을 맞춰 봄.
    - 스토어에 없는 상품(스토어에서 지웠거나 안 올라간 것)의 등록 기록을 정리 → 목록에서 '미등록'이 되어 다시 올릴 수 있음
    - 스토어의 판매 상태(판매중·품절·판매중지·판매금지)를 목록에 반영
    네이버 조회가 실패하거나 결과가 이상하면(0개 등) 아무것도 바꾸지 않고 이유만 기록함"""
    res = {"t": time.time(), "accounts": 0, "store": 0, "mine": 0, "removed": 0, "only_store": 0, "status_changed": 0, "error": ""}
    try:
        for a in q("SELECT * FROM accounts WHERE market='naver' AND active=1"):
            if not a["creds"]:
                continue
            m = store_market(a)
            if getattr(m, "dry", False):
                continue
            items = m.list_store()
            res["accounts"] += 1
            res["store"] += len(items)
            mine = q("SELECT id, product_id, market_id, status FROM listings WHERE account_id=? AND market='naver' AND dry=0 AND COALESCE(market_id,'')<>''", (a["id"],))
            res["mine"] += len(mine)
            if not items and mine:
                res["error"] = "스토어 목록이 비어 있어 변경하지 않았습니다(조회 오류 가능성)"
                continue
            by = {it["origin"]: it for it in items}
            for l in mine:
                it = by.get(l["market_id"])
                if it is None:
                    if fix:
                        x("DELETE FROM listings WHERE id=?", (l["id"],))
                    res["removed"] += 1
                    continue
                ns = STORE_STATUS.get(it.get("status") or "")
                if ns and ns != l["status"] and not (ns == "판매중" and l["status"] == "등록요청"):
                    if fix:
                        x("UPDATE listings SET status=?, updated=? WHERE id=?", (ns, time.time(), l["id"]))
                    res["status_changed"] += 1
            known = {l["market_id"] for l in mine}
            res["only_store"] += sum(1 for o in by if o not in known)
    except Exception as ex:
        res["error"] = str(ex)[:300]
    set_setting("naver_sync", res)
    if res["removed"] or res["error"] or res["only_store"] or res["store"] != res["mine"] - res["removed"] + res["only_store"]:
        log(user, "네이버 연동 확인", json.dumps(res, ensure_ascii=False))
        try:
            notify.send("네이버 연동 확인: 어긋남", (res["error"] or f"스토어 {res['store']}개 / 프로그램 기록 {res['mine']}개. 스토어에 없는 기록 {res['removed']}개 정리, 프로그램 밖 상품 {res['only_store']}개"), "upload")
        except Exception:
            pass
    return res

def auto_clean(user="자동정리", force=False):
    """해외배송 표시가 있는 상품을 알아서 지움(네이버에 올라간 상품은 남김). 설정이 꺼져 있으면 안 함. 지운 개수를 돌려줌"""
    if not force and not get_setting("auto_clean", True):
        return 0
    live = {r[0] for r in q("SELECT product_id FROM listings WHERE market='naver' AND dry=0 AND COALESCE(market_id,'')<>''")}
    ids = [p["id"] for p in q("SELECT * FROM products") if p["id"] not in live and overseas_hit(p)]
    for pid in ids:
        x("DELETE FROM products WHERE id=?", (pid,))
    if ids:
        log(user, "자동 정리(해외배송)", f"{len(ids)}개")
        set_setting("auto_clean_last", {"t": time.time(), "n": len(ids)})
    return len(ids)


# ---------- 안 팔리는 자동 등록 상품 순환 ----------
ROT_DEFAULT = {"on": False, "mode": "preview", "days": 7, "action": "suspend", "max_per_day": 5, "refill": True}

def rot_conf():
    c = dict(ROT_DEFAULT); c.update(get_setting("rotate", {}) or {}); return c

def rot_candidates(days):
    """이 도구(상품 찾기)로 등록한 상품 중, 실제 마켓에 올린 지 N일이 지났고 주문이 0건인 것. 직접 올린 상품은 finds에 없어 제외됨"""
    out = []
    limit = time.time() - float(days) * 86400
    for f in q("SELECT * FROM finds WHERE status='등록됨' AND product_id IS NOT NULL"):
        ls = q("SELECT * FROM listings WHERE product_id=? AND COALESCE(dry,0)=0 AND COALESCE(market_id,'')<>'' AND COALESCE(status,'')<>'판매중지'", (f["product_id"],))
        if not ls:
            continue
        since = min((l["updated"] or time.time()) for l in ls)
        if since > limit:
            continue
        if q("SELECT COUNT(*) FROM orders WHERE product_id=?", (f["product_id"],), one=True)[0] > 0:
            continue
        out.append({"find": f, "listings": ls, "days": int((time.time() - since) // 86400)})
    return out

def rot_run(user="자동", limit=None):
    c = rot_conf(); done, errs = [], []
    cands = rot_candidates(c["days"])
    day0 = time.mktime(time.localtime()[:3] + (0, 0, 0, 0, 0, -1))
    used = q("SELECT COUNT(*) FROM logs WHERE action='순환 내림' AND ts>=?", (day0,), one=True)[0]
    cap = max(0, int(c["max_per_day"] or 0) - used) if limit is None else limit
    for cd in cands[:cap]:
        f = cd["find"]; ok = True
        for l in cd["listings"]:
            try:
                a = q("SELECT * FROM accounts WHERE id=?", (l["account_id"],), one=True)
                m = store_market(a)
                if c["action"] == "delete":
                    m.delete_store({"origin": l["market_id"]}); x("DELETE FROM listings WHERE id=?", (l["id"],))
                else:
                    m.set_sale(l, False); x("UPDATE listings SET status='판매중지' WHERE id=?", (l["id"],))
            except Exception as ex:
                ok = False; errs.append(f"{(f['item_name'] or '')[:20]}: {str(ex)[:80]}")
        if ok:
            x("UPDATE finds SET status='내림', why=? WHERE id=?", (f"{cd['days']}일간 주문 0건으로 {'삭제' if c['action'] == 'delete' else '판매중지'}", f["id"]))
            log(user, "순환 내림", f"{f['item_name']} ({cd['days']}일간 주문 0건 → {'삭제' if c['action'] == 'delete' else '판매중지'})")
            done.append(f["item_name"] or "")
    if done and c.get("refill"):
        set_setting("finder_last", 0)   # 다음 자동 찾기 때 새 상품을 찾아 채움(자동 찾기·자동 등록 설정을 따름)
    if done or errs:
        notify.send(f"안 팔리는 상품 {len(done)}개 내림", "\n".join(done[:10]) + (("\n오류: " + "; ".join(errs[:3])) if errs else ""), "info")
    return done, errs


BAT_HEAD = r"""@echo off
chcp 65001 >nul
setlocal
set "DIR=%USERPROFILE%\MultiMarket"
if not exist "%DIR%" mkdir "%DIR%"
echo 시중 최저가 자동 조회를 설치합니다 (PC가 켜져 있는 동안 1분마다 확인, 지금 찾기 직후 바로 조회)
where python >nul 2>nul
if errorlevel 1 goto nopy
for /f "delims=" %%P in ('where python') do (
  set "PY=%%P"
  goto :got
)
:got
powershell -NoProfile -Command "$t=[IO.File]::ReadAllText('%~f0'); $b=(($t -split '::PYB64::')[-1] -split [char]10 | ForEach-Object { $_.Trim() -replace '^::','' }) -join ''; [IO.File]::WriteAllBytes('%DIR%\naver_lowest.py',[Convert]::FromBase64String($b))"
if not exist "%DIR%\naver_lowest.py" goto fail
if exist "%DIR%\pc_token.txt" goto havetok
echo.
echo 처음 한 번만: 채팅으로 받은 PC 토큰을 붙여넣고 엔터를 누르세요.
set /p TOK=토큰: 
>"%DIR%\pc_token.txt" echo %TOK%
:havetok
set "PYW=%PY:python.exe=pythonw.exe%"
if not exist "%PYW%" set "PYW=%PY%"
schtasks /end /tn "MultiMarket NaverLowest" >nul 2>nul
schtasks /create /tn "MultiMarket NaverLowest" /tr "\"%PYW%\" -I \"%DIR%\naver_lowest.py\"" /sc minute /mo 1 /f
schtasks /run /tn "MultiMarket NaverLowest"
echo.
echo 설치 끝. 지금부터 PC가 켜져 있는 동안 1분마다 서버를 확인해서, 지금 찾기 직후 바로 최저가를 조회합니다 (창은 안 뜹니다).
echo 결과 기록: %DIR%\naver_lowest.log
pause
exit /b 0
:nopy
echo python 을 찾을 수 없습니다. 이 창을 캡처해서 알려 주세요.
pause
exit /b 1
:fail
echo 설치 파일을 만들지 못했습니다. 이 창을 캡처해서 알려 주세요.
pause
exit /b 1
::PYB64::
"""

def pc_installer_bat():
    import base64
    from . import pc_files
    b = base64.b64encode(pc_files.SCRIPT.encode("utf-8")).decode()
    lines = "\r\n".join("::" + b[i:i + 76] for i in range(0, len(b), 76))
    return (BAT_HEAD.replace("\r\n", "\n").replace("\n", "\r\n") + lines + "\r\n").encode("utf-8")

@route("GET", "/pc/installer.bat")
def pc_installer(h):
    h.extra_headers = {"Content-Type": "application/octet-stream", "Content-Disposition": "attachment; filename=\"mm_naver_lowest_install.bat\""}
    return pc_installer_bat()

@route("GET", "/rotate")
def rotate_page(h):
    c = rot_conf()
    cands = rot_candidates(c["days"])
    sel = lambda k, opts: "".join(f"<option value='{v}' {'selected' if str(c.get(k)) == v else ''}>{t}</option>" for v, t in opts)
    trs = "".join(f"<tr><td>{e((cd['find']['item_name'] or '')[:60])}</td><td>{cd['days']}일</td><td>{cd['find']['our_price'] or 0:,}원</td></tr>" for cd in cands)
    hist = "".join(f"<tr><td>{time.strftime('%m-%d %H:%M', time.localtime(r['ts']))}</td><td>{e(r['detail'] or '')}</td></tr>" for r in q("SELECT * FROM logs WHERE action='순환 내림' ORDER BY ts DESC LIMIT 30"))
    ex = q("SELECT COUNT(*) FROM finds WHERE status='내림'", one=True)[0]
    body = f"""<h1>안 팔리는 상품 순환</h1>
<div class="card"><p style="font-size:17px"><b>지금 내릴 상품 {len(cands)}개</b> · 이 도구로 등록한 상품만 대상(직접 올린 상품은 건드리지 않음) · 내린 상품 {ex}개는 다시 올리지 않음</p>
<form method="post" action="/rotate/save" class="row"><div><label>동작</label><select name="on"><option value="0">꺼짐</option><option value="1" {'selected' if c['on'] else ''}>켜짐</option></select></div>
<div><label>실행 방식</label><select name="mode">{sel('mode', (('preview', '확인 후 실행(알림만)'), ('auto', '자동 실행')))}</select></div>
<div><label>주문 0건 기간(일)</label><input name="days" value="{c['days']}" style="width:80px"></div>
<div><label>내리는 방법</label><select name="action">{sel('action', (('suspend', '판매중지(기본)'), ('delete', '삭제')))}</select></div>
<div><label>하루 최대(개)</label><input name="max_per_day" value="{c['max_per_day']}" style="width:80px"></div>
<div><label>내린 만큼 새로 찾기</label><select name="refill"><option value="1">예</option><option value="0" {'' if c['refill'] else 'selected'}>아니오</option></select></div>
<div style="align-self:end"><button class="btn">저장</button></div></form>
<p class="mut">기준: 실제 마켓(미리보기 아님)에 올린 지 N일 지났고 주문이 한 건도 없는 상품. 내린 상품은 목록에서 「내림」으로 남아 다시 추천되지 않습니다. 새 상품은 「잘 팔릴 상품 찾기」의 자동 찾기·자동 등록 설정에 따라 채워집니다.</p></div>
<div class="card"><h2>내릴 상품</h2><div class="tbl"><table><tr><th>상품</th><th>올린 지</th><th>판매가</th></tr>{trs or '<tr><td colspan=3>지금 내릴 상품이 없습니다</td></tr>'}</table></div>
<form method="post" action="/rotate/run" data-busy><button class="btn green" {'disabled' if not cands else ''}>지금 내리기 (하루 최대 {c['max_per_day']}개까지)</button></form></div>
<div class="card"><h2>처리 기록</h2><div class="tbl"><table><tr><th>시각</th><th>내용</th></tr>{hist or '<tr><td colspan=2>아직 없습니다</td></tr>'}</table></div></div>"""
    return page("상품 순환", body, h.user, "/rotate", h.flash, h.flash_err)

@route("POST", "/rotate/save")
def rotate_save(h):
    f = h.form(); c = rot_conf()
    c["on"] = f.get("on") == "1"; c["mode"] = f.get("mode") if f.get("mode") in ("preview", "auto") else "preview"
    c["action"] = f.get("action") if f.get("action") in ("suspend", "delete") else "suspend"
    c["refill"] = f.get("refill", "1") == "1"
    for k, lo in (("days", 1), ("max_per_day", 0)):
        v = num(str(f.get(k, "")).replace(",", ""), float)
        c[k] = int(v) if v is not None and v >= lo else ROT_DEFAULT[k]
    set_setting("rotate", c)
    log(h.user["username"], "순환 설정", json.dumps(c, ensure_ascii=False))
    go("/rotate", "저장했습니다")

@route("POST", "/rotate/run")
def rotate_run_now(h):
    done, errs = rot_run(h.user["username"])
    go("/rotate", f"{len(done)}개 내렸습니다" + (f" (오류 {len(errs)}개: {errs[0]})" if errs else ""), bool(errs and not done))

def scheduler():
    last = 0
    while True:
        time.sleep(30)
        try:
            if not get_setting("revert_1933_done", False):
                # 1.9.33: 11-25 동기화로 급변한 공급가를 한 번 자동 복구
                set_setting("revert_1933_done", True)
                rn, rf = revert_supply("자동")
                notify.send("공급가 자동 복구", f"급변했던 공급가 {rn}개를 되돌리고 판매가를 다시 반영했습니다 (실패 {rf}개)", None)
        except Exception as ex:
            log("자동", "공급가 자동 복구 오류", str(ex)[:300])
        try:
            _rc = rot_conf()
            if _rc["on"] and time.time() - (get_setting("rotate_last") or 0) > 86400:
                set_setting("rotate_last", time.time())
                if _rc["mode"] == "auto":
                    rot_run("자동")
                else:
                    _n = len(rot_candidates(_rc["days"]))
                    if _n:
                        notify.send(f"안 팔리는 상품 {_n}개 확인 필요", "「상품 순환」 화면에서 확인 후 내려 주세요", "info")
        except Exception as ex:
            log("자동", "상품 순환 오류", str(ex)[:300])
        try:
            _sn = finder.apply_seed()
            if _sn:
                set_setting("finder_min_last", time.time())
                log("자동", "네이버 최저가 입력(PC 조회분)", f"{_sn}개 저장 후 재계산")
        except Exception as ex:
            log("자동", "PC 최저가 입력 오류", str(ex)[:300])
        try:
            _last = get_setting("finder_min_last") or 0
            if time.time() - _last > 86400 and not get_setting("finder_min_block") and q("SELECT 1 FROM finds WHERE status='추천' AND (mkt_min IS NULL OR mkt_min=0) LIMIT 1") and not get_setting("finder_min_running"):
                set_setting("finder_min_running", True)
                def _fill():
                    try:
                        n, why = finder.server_fill_lowest()
                        finder.recalc_all(finder.conf())
                        log("자동", "네이버 최저가 서버 조회", f"{n}개 채움" + (f", 중단: {why}" if why else ""))
                    except Exception as ex:
                        log("자동", "네이버 최저가 서버 조회 오류", str(ex)[:300])
                    finally:
                        set_setting("finder_min_running", False)
                threading.Thread(target=_fill, daemon=True).start()
        except Exception as ex:
            log("자동", "최저가 조회 시작 오류", str(ex)[:300])
        try:
            mins = get_setting("order_interval", 30) or 0
            if mins and time.time() - last > mins * 60:
                last = time.time()
                if q("SELECT 1 FROM accounts WHERE active=1 AND creds!='' LIMIT 1") and not False:
                    collect_orders()
                if q("SELECT 1 FROM orders WHERE po_status IN ('발주완료','송장받음') LIMIT 1"):
                    check_tracking()
                purge_personal()
            if time.time() - ((get_setting("naver_sync") or {}).get("t") or 0) > 1800 and q("SELECT 1 FROM accounts WHERE market='naver' AND active=1 AND creds!='' LIMIT 1") and not NAVER_PURGE.get("running"):
                naver_sync_check()
            if time.time() - (get_setting("auto_clean_ts") or 0) > 3600:
                set_setting("auto_clean_ts", time.time())
                auto_clean()
            stock_sweep()
            pass  # 1.9.35: 자동 찾기·자동 등록은 프로그램에서 뺌 (CHOI 요청)
            oc = oc_conf()
            hrs = float(oc.get("sync_hours", 3) or 0)
            if hrs and oc.get("api_key") and not get_setting("domeggook_blocked") and time.time() - (get_setting("domeggook_last_sync") or 0) > hrs * 3600:
                set_setting("domeggook_last_sync", time.time())
                sync_domeggook()
        except Exception:
            traceback.print_exc()

def serve(host="0.0.0.0", port=8765):
    threading.Thread(target=scheduler, daemon=True).start()
    updater.start_background()
    srv = ThreadingHTTPServer((host, port), Handler)
    return srv
