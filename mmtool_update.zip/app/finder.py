"""잘 팔릴 위탁상품 자동 찾기.
1) 씨앗 키워드 → 네이버 검색광고 API(연관 키워드·월 검색량)
2) 키워드별 네이버 쇼핑 검색 API(경쟁 상품 수·시장 가격)
3) 도매매에서 그 키워드로 상품 검색 → 우리 판매가·이익 계산
4) 점수(수요 40 + 경쟁 30 + 가격 30) 높은 순으로 finds 표에 저장
공식 API만 씁니다. 쿠팡·도매매 인기순위는 공식 API가 없어 쓰지 않습니다."""
import base64, hashlib, hmac, json, math, re, time, uuid, urllib.parse, urllib.request, urllib.error
from .db import q, x, get_setting, set_setting, log
from .secret import unseal
from . import pricing
from . import domeggook as ocmod

DEFAULT = {"seeds": "", "min_volume": 1000, "max_keywords": 30, "per_keyword": 10, "min_score": 60, "min_profit": 2000,
           "min_price": 0, "max_price": 50000, "auto_find": False, "find_hours": 24, "auto_register": False,
           "reg_accs": [], "reg_chans": [], "max_per_day": 5, "price_channel": "naver",
           "price_mode": "policy", "price_margin": 30, "price_ship": None, "price_undercut": 0}

class FindError(Exception):
    pass

NAVER_SHOP_ENDED = ("네이버가 쇼핑 검색 API를 2026-07-31에 종료해(대체 API 없음) 최저가를 자동으로 가져올 수 없습니다. "
                    "목록의 「네이버 최저가」 칸에 직접 입력하고 「입력한 최저가 저장·다시 계산」을 누르세요.")

def conf():
    c = dict(DEFAULT)
    c.update(get_setting("finder", {}) or {})
    return c

def _sec(c, k):
    return unseal(c[k]) if c.get(k) else ""

def _get(url, headers, timeout=20):
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8", "replace"))
    except urllib.error.HTTPError as e:
        host = urlparse_host(url)
        if e.code == 401 and host == "openapi.naver.com":
            raise FindError(NAVER_SHOP_ENDED)
        if e.code == 401 and host == "api.searchad.naver.com":
            raise FindError("네이버 검색광고 키(CUSTOMER_ID·액세스라이선스·비밀키)가 맞지 않습니다. 다시 확인하세요.")
        raise FindError(f"{host} {e.code}: {e.read().decode('utf-8', 'replace')[:300]}")
    except urllib.error.URLError as e:
        raise FindError(f"{urlparse_host(url)} 접속 실패: {e.reason}")

def urlparse_host(u):
    return urllib.parse.urlparse(u).netloc

def num(v):
    """'< 10' 같은 값도 숫자로"""
    if isinstance(v, (int, float)):
        return int(v)
    m = re.sub(r"[^\d]", "", str(v or ""))
    return int(m) if m else 0

# ---------- 네이버 검색광고: 연관 키워드·검색량 ----------
def keyword_tool(c, hints):
    cust, key, sec = c.get("ad_customer", ""), _sec(c, "ad_key"), _sec(c, "ad_secret")
    if not (cust and key and sec):
        return None
    out = {}
    hints = [h.replace(" ", "") for h in hints if h.strip()]
    for i in range(0, len(hints), 5):
        ts = str(int(time.time() * 1000))
        sig = base64.b64encode(hmac.new(sec.encode(), f"{ts}.GET./keywordstool".encode(), hashlib.sha256).digest()).decode()
        url = "https://api.searchad.naver.com/keywordstool?" + urllib.parse.urlencode({"hintKeywords": ",".join(hints[i:i + 5]), "showDetail": 1})
        d = _get(url, {"X-Timestamp": ts, "X-API-KEY": key, "X-Customer": str(cust), "X-Signature": sig})
        for k in d.get("keywordList") or []:
            vol = num(k.get("monthlyPcQcCnt")) + num(k.get("monthlyMobileQcCnt"))
            out[k.get("relKeyword")] = {"volume": vol, "comp": k.get("compIdx") or ""}
        time.sleep(0.3)
    return out

# ---------- 네이버 쇼핑 검색: 경쟁 상품 수·시장 가격 ----------
def shop_stats(c, kw):
    cid, sec = (c.get("naver_id") or "").strip(), _sec(c, "naver_secret").strip()
    if not (cid and sec):
        return None
    url = "https://openapi.naver.com/v1/search/shop.json?" + urllib.parse.urlencode({"query": kw, "display": 40, "sort": "sim"})
    d = _get(url, {"X-Naver-Client-Id": cid, "X-Naver-Client-Secret": sec})
    prices = sorted(num(i.get("lprice")) for i in d.get("items") or [] if num(i.get("lprice")) > 0)
    mid = prices[len(prices) // 2] if prices else 0
    low = prices[max(0, len(prices) // 10)] if prices else 0   # 아래 10% 가격(극단값 제외)
    return {"total": int(d.get("total") or 0), "low": low, "avg": mid, "min": prices[0] if prices else 0}

# ---------- 점수 ----------
def score(volume, ratio, our, low, avg, have_vol, have_shop):
    why = []
    s_d = min(40.0, 10 * math.log10(volume)) if have_vol and volume > 0 else 20.0
    why.append(f"수요 {s_d:.0f}/40" + ("" if have_vol else "(검색량 키 없음)"))
    if have_shop and ratio is not None:
        s_c = 30 if ratio < 1 else 22 if ratio < 3 else 14 if ratio < 10 else 6 if ratio < 30 else 0
    else:
        s_c = 15
    why.append(f"경쟁 {s_c}/30" + ("" if have_shop else "(쇼핑 키 없음)"))
    if have_shop and avg:
        s_p = 30 if our <= low else 22 if our <= avg else 10 if our <= avg * 1.2 else 0
    else:
        s_p = 15
    why.append(f"가격 {s_p}/30")
    return round(s_d + s_c + s_p, 1), " · ".join(why)

_COLS = None
def fake_product(it, opt_vals, policy_id):
    """가격 계산용 임시 상품"""
    global _COLS
    if _COLS is None:
        _COLS = [r[1] for r in q("PRAGMA table_info(products)")]
    p = {k: None for k in _COLS}
    price = ocmod.price_of(it, opt_vals)
    p.update({"name": it.get("name"), "supply_type": "위탁", "supply_price": price, "cost_krw": price, "set_qty": 1,
              "supply_ship": it.get("shippingFee"), "fixed_price": it.get("fixedPrice") or None, "policy_id": policy_id,
              "ch_margin": "{}", "ch_ship": "{}", "price_override": None, "margin": None, "ship": None})
    return p

def price_policy(c, pol):
    """판매가 정책: 기본은 '위탁 기본' 정책 그대로, 화면에서 마진 방식·값·배송비를 고르면 그 값으로 덮어씀"""
    pc = json.loads(json.dumps(pricing.policy_for({"policy_id": pol})))
    mode = c.get("price_mode") or "policy"
    if mode in ("pct", "price_pct", "won"):
        pc["margin_mode"] = mode
        pc["margin"] = float(c.get("price_margin") or 0)
    if c.get("price_ship") not in (None, ""):
        pc["ship_cost"] = float(c["price_ship"])
    return pc

def calc(it, c, pol, mkt_min=0):
    """(우리 판매가, 이익). '네이버 최저가에 맞춤' 방식이면 최저가 - 할인액을 판매가로 함"""
    ch = c.get("price_channel") or "naver"
    pc = price_policy(c, pol)
    fp = fake_product(it, None, pol)
    if (c.get("price_mode") == "match_low") and mkt_min:
        fp["price_override"] = max(int(mkt_min) - int(c.get("price_undercut") or 0), 100)
    b = pricing.breakdown(fp, ch, pc)
    return int(b["price_krw"]), int(b["profit"])

def recalc_all(c):
    """추천 목록의 판매가·이익을 현재 설정으로 다시 계산"""
    pol = consign_pol()
    n = 0
    for r in q("SELECT * FROM finds WHERE status='추천'"):
        if r["supply_ship"] is None and (c.get("price_mode") or "policy") == "policy":
            continue   # 예전에 찾은 후보는 도매매 배송비를 저장하지 않아 기본 방식에서는 값을 바꾸지 않음
        our, profit = calc({"name": r["item_name"], "price": r["supply_price"], "shippingFee": r["supply_ship"]}, c, pol, r["mkt_min"] or 0)
        x("UPDATE finds SET our_price=?, profit=? WHERE id=?", (our, profit, r["id"]))
        n += 1
    return n

def consign_pol():
    from .server import consign_policy_id
    return consign_policy_id()

def key_check(c):
    """저장된 네이버 검색 API 키 상태와 시험 호출 결과를 한국어로"""
    cid = (c.get("naver_id") or "").strip()
    sec = _sec(c, "naver_secret").strip()
    if not cid or not sec:
        return NAVER_SHOP_ENDED
    info = f"저장된 Client ID: {cid[:4]}…({len(cid)}자) · Secret {len(sec)}자"
    warn = ""
    if "@" in cid or " " in cid or len(cid) < 10:
        warn = " ⚠ Client ID 모양이 이상합니다(로그인 아이디가 자동으로 들어갔을 수 있음)."
    try:
        shop_stats(c, "테스트")
    except FindError as ex:
        return f"{info}{warn} → 실패: {ex}"
    return f"{info} → 정상입니다. 네이버 쇼핑 검색이 됩니다."

def refresh_lowest(c):
    """추천 목록 키워드별 네이버 현재 최저가를 다시 조회 (공식 쇼핑 검색 API)"""
    kws = [r["keyword"] for r in q("SELECT DISTINCT keyword FROM finds WHERE status='추천'")]
    got = 0
    for kw in kws:
        st = shop_stats(c, kw)
        if st is None:
            raise FindError(NAVER_SHOP_ENDED)
        x("UPDATE finds SET mkt_min=?, mkt_low=?, mkt_avg=?, comp_total=? WHERE keyword=? AND status='추천'", (st["min"], st["low"], st["avg"], st["total"], kw))
        got += 1
        time.sleep(0.2)
    return got

def run(user="자동", seeds=None):
    """한 번 찾기. (저장한 후보 수, 안내 메시지)"""
    c = conf()
    seeds = [s.strip() for s in re.split(r"[,\n]+", seeds if seeds is not None else c.get("seeds", "")) if s.strip()]
    if not seeds:
        raise FindError("찾을 분야(씨앗 키워드)를 먼저 넣어 주세요. 예: 집게핀, 키링, 다꾸")
    notes = []
    try:
        kt = keyword_tool(c, seeds)
    except FindError as ex:
        kt = None; notes.append(f"검색량 조회 실패: {ex}")
    have_vol = kt is not None and bool(kt)
    if have_vol:
        kws = sorted(((k, v) for k, v in kt.items() if v["volume"] >= int(c["min_volume"] or 0)), key=lambda kv: -kv[1]["volume"])
        kws = kws[:int(c["max_keywords"] or 30)] or [(s, {"volume": 0, "comp": ""}) for s in seeds]
    else:
        if not notes:
            notes.append("네이버 검색광고 키가 없어 넣은 키워드만 그대로 씁니다(검색량 점수는 중간값).")
        kws = [(s, {"volume": 0, "comp": ""}) for s in seeds]
    from .server import consign_policy_id   # 순환 import 방지
    pol = consign_policy_id()
    ch = c.get("price_channel") or "naver"
    oc = ocmod.OwnerClan()
    if oc.dry:
        notes.append("도매매 아이디가 없어 예시 상품으로 보여 줍니다.")
    have = {r["supplier_key"] for r in q("SELECT supplier_key FROM products WHERE supplier_key!=''")}
    run_id = uuid.uuid4().hex[:8]
    best = {}
    shop_fail = False
    for kw, info in kws:
        st = None
        if not shop_fail:
            try:
                st = shop_stats(c, kw)
            except FindError as ex:
                shop_fail = True; notes.append(f"쇼핑 검색 실패: {ex}")
        ratio = (st["total"] / max(info["volume"], 1)) if (st and have_vol and info["volume"]) else None
        try:
            items = oc.search(kw, first=int(c["per_keyword"] or 10), min_price=int(c["min_price"] or 0) or None, max_price=int(c["max_price"] or 0) or None)
        except ocmod.OCError as ex:
            notes.append(f"도매매 검색 실패({kw}): {ex}")
            continue
        for it in items:
            if not it or not it.get("key") or it["key"] in have or ocmod.is_soldout(it):
                continue
            opts = [o for o in (it.get("options") or []) if (o.get("quantity") or 0) > 0]
            vals = [a.get("value") for a in (opts[0].get("optionAttributes") or [])] if opts else None
            our, profit = calc({"name": it.get("name"), "price": ocmod.price_of(it, vals), "shippingFee": it.get("shippingFee"), "fixedPrice": it.get("fixedPrice")}, c, pol, st["min"] if st else 0)
            if profit < int(c["min_profit"] or 0):
                continue
            sc, why = score(info["volume"], ratio, our, st["low"] if st else 0, st["avg"] if st else 0, have_vol, bool(st))
            if st:
                why += f" · 네이버 경쟁 {st['total']:,}개, 시장가 {st['low']:,}~{st['avg']:,}원"
            row = dict(keyword=kw, volume=info["volume"], comp_total=st["total"] if st else None, ratio=ratio, mkt_low=st["low"] if st else None,
                       mkt_avg=st["avg"] if st else None, mkt_min=st["min"] if st else None, supply_ship=it.get("shippingFee"), item_key=it["key"], item_name=it.get("name"), supply_price=ocmod.price_of(it, vals),
                       our_price=our, profit=profit, score=sc, why=why, image=(ocmod.images_of(it) or [""])[0])
            if it["key"] not in best or best[it["key"]]["score"] < sc:
                best[it["key"]] = row
        time.sleep(0.2)
    # 같은 상품이 이미 '추천'으로 있으면 새 값으로 바꿈(등록됨·제외는 그대로)
    saved = 0
    for r in best.values():
        old = q("SELECT id, status FROM finds WHERE item_key=?", (r["item_key"],), one=True)
        if old and old["status"] != "추천":
            continue
        if old:
            x("DELETE FROM finds WHERE id=?", (old["id"],))
        x("INSERT INTO finds(keyword,volume,comp_total,ratio,mkt_low,mkt_avg,mkt_min,supply_ship,item_key,item_name,supply_price,our_price,profit,score,why,image,status,found_at,run_id) "
          "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'추천',?,?)",
          (r["keyword"], r["volume"], r["comp_total"], r["ratio"], r["mkt_low"], r["mkt_avg"], r["mkt_min"], r["supply_ship"], r["item_key"], r["item_name"], r["supply_price"],
           r["our_price"], r["profit"], r["score"], r["why"], r["image"], time.time(), run_id))
        saved += 1
    set_setting("finder_last", time.time())
    msg = f"키워드 {len(kws)}개 · 도매매 후보 {saved}개 저장"
    log(user, "상품 자동 찾기", msg + ("; " + "; ".join(notes)[:300] if notes else ""))
    return saved, msg, notes
