import html
e = html.escape

CSS = """
:root{--bg:#f5f6f8;--card:#fff;--fg:#1d2330;--mut:#6b7280;--line:#e5e7eb;--acc:#2f6fed;--ok:#16a34a;--bad:#dc2626}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font-family:'Malgun Gothic','Apple SD Gothic Neo','Noto Sans KR',sans-serif;font-size:15px}
a{color:var(--acc);text-decoration:none}header{background:#111827;color:#fff;display:flex;align-items:center;gap:18px;padding:0 20px;height:54px;position:sticky;top:0;z-index:5}
header b{font-size:17px;white-space:nowrap}header nav{display:flex;gap:4px;overflow-x:auto}header nav a{color:#cbd5e1;padding:8px 12px;border-radius:8px;white-space:nowrap}
header nav a.on,header nav a:hover{background:#1f2937;color:#fff}header .me{margin-left:auto;color:#9ca3af;font-size:13px;white-space:nowrap}
.wrap{display:flex;align-items:flex-start}.side{width:190px;flex:none;position:sticky;top:54px;height:calc(100vh - 54px);overflow-y:auto;background:#fff;border-right:1px solid var(--line);padding:10px 8px}.side a{display:block;color:#1f2937;padding:8px 10px;border-radius:8px;font-size:14px;margin:1px 0}.side a:hover{background:#f3f4f6}.side a.on{background:#2f6fed;color:#fff}.side summary{cursor:pointer;list-style:none;padding:8px 10px;border-radius:8px;font-size:14px;font-weight:600;color:#111827}.side summary:hover{background:#f3f4f6}.side summary::-webkit-details-marker{display:none}.side summary::after{content:'▸';float:right;color:#9ca3af}.side details[open]>summary::after{content:'▾'}.side a.d0{font-weight:600}.side .d1{padding-left:22px}.side summary.d1{font-weight:500}.side a.d2{padding-left:36px;font-size:13px}.side a.d1{font-size:13.5px}main{flex:1;min-width:0;max-width:1200px;margin:0 auto;padding:20px 16px 90px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:16px}
h1{font-size:22px;margin:4px 0 16px}h2{font-size:17px;margin:0 0 12px}table{width:100%;border-collapse:collapse}th,td{padding:9px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{font-size:13px;color:var(--mut);font-weight:600;background:#fafafa}.tbl{overflow-x:auto}input,select,textarea{width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:8px;font:inherit;background:#fff}
textarea{min-height:90px}label{display:block;font-size:13px;color:var(--mut);margin:10px 0 4px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
.btn{display:inline-block;background:var(--acc);color:#fff;border:0;border-radius:8px;padding:9px 16px;font:inherit;cursor:pointer;white-space:nowrap}.btn.gray{background:#6b7280}.btn.red{background:var(--bad)}.btn.green{background:var(--ok)}.btn.sm{padding:5px 10px;font-size:13px}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.mut{color:var(--mut);font-size:13px}.tag{display:inline-block;padding:2px 8px;border-radius:99px;background:#eef2ff;color:#3730a3;font-size:12px;margin:1px}
.tag.ok{background:#dcfce7;color:#166534}.tag.bad{background:#fee2e2;color:#991b1b}.tag.dry{background:#fef9c3;color:#854d0e}.flash{padding:12px 14px;border-radius:10px;background:#ecfdf5;border:1px solid #a7f3d0;margin-bottom:14px;white-space:pre-wrap}
.flash.err{background:#fef2f2;border-color:#fecaca}.stat{font-size:28px;font-weight:800}.thumb{width:56px;height:56px;object-fit:cover;border-radius:8px;background:#eee}
.imgs{display:flex;gap:8px;flex-wrap:wrap}.imgs img{width:96px;height:96px;object-fit:cover;border-radius:8px;border:1px solid var(--line)}
iframe{width:100%;height:720px;border:1px solid var(--line);border-radius:10px;background:#fff}
.bnav{display:none}
@media (max-width:760px){.side{display:none}main{padding:14px 10px 90px}.bnav{display:flex;position:fixed;bottom:0;left:0;right:0;background:#111827;z-index:9;justify-content:space-around;padding:6px 0 calc(6px + env(safe-area-inset-bottom))}
.bnav a{color:#cbd5e1;font-size:11px;text-align:center;flex:1;padding:4px}.bnav a span{display:block;font-size:20px}.bnav a.on{color:#fff}th,td{font-size:13px;padding:7px 5px}iframe{height:560px}.hide-m{display:none}}
"""

NAV = [("/", "홈", "🏠"), ("/b2b", "B2B상품", "🤝"), ("/own", "사입상품", "📦"), ("/orders", "주문", "🧾"), ("/more", "메뉴", "☰")]   # 폰 아래 메뉴
# 왼쪽 메뉴: 대분류 > 중분류 > 소분류. ("이름", "주소") 또는 ("이름", [하위...])
SIDE = [("🏠 홈", "/"),
        ("📦 상품", [("🤝 B2B(위탁)", [("상품 목록", "/b2b"), ("엑셀·zip 올리기", "/suppliers/csv"), ("올리기 전 확인·마진", "/b2b/review"), ("도매매 찾기", "/suppliers"), ("마진 설정", "/sell/consign")]),
                    ("📦 사입", [("상품 목록", "/own"), ("마진 설정", "/sell/own")]),
                    ("🔎 잘 팔릴 상품 찾기", "/finder")]),
        ("🧾 판매", [("주문", "/orders"), ("발주·송장", "/fulfill"), ("등록현황", "/listings")]),
        ("⚙️ 설정", [("🔑 쇼핑몰", [("마켓 계정(키)", "/accounts"), ("해외몰", "/channels")]),
                    ("🏷 가격", [("가격 정책", "/policies")]),
                    ("🔔 알림", [("폰 알림", "/notify")]),
                    ("프로그램 설정", "/settings")]),
        ("🛠 관리", [("작업 이력", "/history"), ("팀원", "/users"), ("업데이트·백업", "/admin")])]

from . import VERSION

def page(title, body, user=None, path="/", flash=None, err=False):
    def _links(nodes):
        for _, t in nodes:
            if isinstance(t, str):
                yield t
            else:
                yield from _links(t)
    _all = [t for t in _links(SIDE)]
    _best = max([t for t in _all if path == t or (t != "/" and path.startswith(t))], key=len, default="")   # 가장 구체적인 메뉴 하나만 켜기
    def on(h):
        return h == _best
    def has(node):
        return on(node[1]) if isinstance(node[1], str) else any(has(c) for c in node[1])
    def draw(node, depth, admin):
        name, tgt = node
        if isinstance(tgt, str):
            if tgt in ("/users", "/admin") and not admin:
                return ""
            return f'<a href="{tgt}" class="d{depth}{" on" if on(tgt) else ""}">{name}</a>'
        kids = "".join(draw(c, depth + 1, admin) for c in tgt)
        if not kids:
            return ""
        return f'<details class="sd{depth}"{" open" if has(node) else ""}><summary class="d{depth}">{name}</summary>{kids}</details>'
    side = "".join(draw(n, 0, user["role"] == "admin") for n in SIDE) if user else ""
    bnav = "".join(f'<a href="{h}" class="{"on" if (path == h or (h != "/" and path.startswith(h))) else ""}"><span>{i}</span>{t}</a>' for h, t, i in NAV)
    me = f'<span class="me">{e(user["name"] or user["username"])} · <a href="/logout" style="color:#9ca3af">로그아웃</a></span>' if user else ""
    fl = f'<div class="flash {"err" if err else ""}">{e(flash)}</div>' if flash else ""
    head = f'<header><b>멀티마켓 매니저</b><span style="color:#9ca3af;font-size:12px">v{VERSION}</span>{me}</header>' if user else ""
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{e(title)} · 멀티마켓 매니저</title><link rel="manifest" href="/manifest.json"><meta name="theme-color" content="#111827">
<meta name="apple-mobile-web-app-capable" content="yes"><link rel="apple-touch-icon" href="/icon.png"><link rel="icon" href="/icon.svg">
<style>{CSS}</style></head><body>{head}<div class="wrap">{('<aside class="side">' + side + '</aside>') if user else ''}<main>{fl}{body}</main></div>{('<nav class="bnav">' + bnav + '</nav>') if user else ''}
<script>if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js');
document.querySelectorAll('[data-all]').forEach(b=>b.onclick=()=>document.querySelectorAll('input[name="'+b.dataset.all+'"]').forEach(c=>c.checked=b.checked));
document.querySelectorAll('form[data-busy]').forEach(f=>f.addEventListener('submit',ev=>{{if(ev.submitter&&ev.submitter.hasAttribute('data-dl'))return;mmKeep(f,ev.submitter);f.querySelectorAll('button').forEach(b=>{{b.disabled=true;b.textContent='처리 중…'}})}}));
{IMG_JS}
var MMA={{on:(function(){{try{{return localStorage.getItem('mmAlarm')!=='0'}}catch(e){{return true}}}})()}};
function mmBeep(){{try{{var c=new (window.AudioContext||window.webkitAudioContext)(),t=0;[880,1175,880,1175].forEach(function(f){{var o=c.createOscillator(),g=c.createGain();o.frequency.value=f;o.connect(g);g.connect(c.destination);g.gain.setValueAtTime(0.25,c.currentTime+t);o.start(c.currentTime+t);o.stop(c.currentTime+t+0.18);t+=0.22}})}}catch(e){{}}}}
function mmAlarmLabel(){{var b=document.getElementById('pcAlarmBtn');if(b){{b.textContent='PC 소리 알람: '+(MMA.on?'켜짐 (누르면 끄기)':'꺼짐 (누르면 켜기)');b.className='btn '+(MMA.on?'green':'gray')}}}}
function mmAlarmToggle(){{MMA.on=!MMA.on;try{{localStorage.setItem('mmAlarm',MMA.on?'1':'0')}}catch(e){{}}if(MMA.on){{mmBeep();try{{Notification.requestPermission()}}catch(e){{}}}}mmAlarmLabel()}}
mmAlarmLabel();
if(document.querySelector('nav')){{setInterval(function(){{fetch('/api/orders/poll?after='+(localStorage.getItem('mmLastOrder')||0)).then(function(r){{return r.json()}}).then(function(j){{var last=localStorage.getItem('mmLastOrder');localStorage.setItem('mmLastOrder',j.max);if(last===null||!j.new.length)return;if(MMA.on){{mmBeep();try{{if(Notification.permission==='granted')new Notification('새 주문 '+j.new.length+'건',{{body:j.new.join(', ')}})}}catch(e){{}}}}document.title='🔔 새 주문 '+j.new.length+'건 · '+document.title.replace(/^🔔[^·]*· /,'')}}).catch(function(){{}})}},20000)}}
</script></body></html>"""

ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="96" fill="#111827"/>
<path d="M120 190h272l-24 190H144z" fill="#2f6fed"/><path d="M190 190v-30a66 66 0 0 1 132 0v30" stroke="#fff" stroke-width="28" fill="none"/>
<text x="256" y="335" font-size="120" text-anchor="middle" fill="#fff" font-family="Arial" font-weight="700">M</text></svg>"""

MANIFEST = """{"name":"멀티마켓 매니저","short_name":"멀티마켓","start_url":"/","display":"standalone","background_color":"#111827","theme_color":"#111827",
"icons":[{"src":"/icon.svg","sizes":"any","type":"image/svg+xml"},{"src":"/icon.png","sizes":"192x192","type":"image/png"},{"src":"/icon-512.png","sizes":"512x512","type":"image/png"}]}"""

SW = "self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('fetch',e=>{});"

# 상세페이지 만들 때 사진 자동 가공(브라우저에서 처리 → 추가 설치 없음)
# 대표 사진: 흰 배경 1000×1000 정사각형, 여백 자르고 가운데 배치 / 나머지: 가로 860px 로 맞춤 / 둘 다 어두우면 밝기·대비 자동 보정
IMG_JS = r"""
function mmKeep(f,b){if(b&&b.name){let h=f.querySelector('input[type=hidden][data-keep]');if(!h){h=document.createElement('input');h.type='hidden';h.dataset.keep=1;f.appendChild(h)}h.name=b.name;h.value=b.value}}
function mmLoad(u){return new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=()=>no(new Error('사진 열기 실패'));i.src=u+(u.includes('?')?'&':'?')+'t='+Date.now()})}
async function mmProcess(url,first){
 const img=await mmLoad(url);const w=img.naturalWidth,h=img.naturalHeight;
 const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');
 x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(img,0,0);
 const d=x.getImageData(0,0,w,h).data;const st=Math.max(1,Math.floor(Math.min(w,h)/500));
 let x0=w,y0=h,x1=-1,y1=-1;const hist=new Uint32Array(256);let cnt=0;
 for(let y=0;y<h;y+=st)for(let X=0;X<w;X+=st){const k=(y*w+X)*4,r=d[k],g=d[k+1],b=d[k+2];hist[(r*299+g*587+b*114)/1000|0]++;cnt++;
  if(r<240||g<240||b<240){if(X<x0)x0=X;if(X>x1)x1=X;if(y<y0)y0=y;if(y>y1)y1=y}}
 if(x1<0||(x1-x0)<w*0.25||(y1-y0)<h*0.25){x0=0;y0=0;x1=w-1;y1=h-1}else{const m=st*3;x0=Math.max(0,x0-m);y0=Math.max(0,y0-m);x1=Math.min(w-1,x1+m);y1=Math.min(h-1,y1+m)}
 const bw=x1-x0+1,bh=y1-y0+1;let lo=0,hi=255,a=0;
 for(let i=0;i<256;i++){a+=hist[i];if(a>cnt*0.005){lo=i;break}}a=0;for(let i=255;i>=0;i--){a+=hist[i];if(a>cnt*0.005){hi=i;break}}
 lo=Math.min(lo,40);hi=Math.max(hi,200);
 const o=document.createElement('canvas');let ow,oh,dx,dy,dw,dh;
 if(first){ow=oh=1000;const s=Math.min(900/bw,900/bh);dw=Math.round(bw*s);dh=Math.round(bh*s);dx=(1000-dw)>>1;dy=(1000-dh)>>1}
 else{const s=Math.min(860/bw,4000/bh);dw=Math.round(bw*s);dh=Math.round(bh*s);ow=860;oh=dh;dx=(860-dw)>>1;dy=0}
 o.width=ow;o.height=oh;const ox=o.getContext('2d');ox.imageSmoothingQuality='high';ox.fillStyle='#fff';ox.fillRect(0,0,ow,oh);
 ox.drawImage(c,x0,y0,bw,bh,dx,dy,dw,dh);
 if(hi-lo<250){const id=ox.getImageData(0,0,ow,oh),p=id.data,lut=new Uint8ClampedArray(256);
  for(let i=0;i<256;i++)lut[i]=(i-lo)*255/(hi-lo);for(let i=0;i<p.length;i+=4){p[i]=lut[p[i]];p[i+1]=lut[p[i+1]];p[i+2]=lut[p[i+2]]}ox.putImageData(id,0,0)}
 return await new Promise(ok=>o.toBlob(ok,'image/jpeg',0.9));
}
async function mmAutoImg(pid,note){
 const say=t=>{if(note)note.textContent=t};say('사진 찾는 중…');
 const r=await fetch('/products/'+pid+'/fetch_images',{method:'POST'});const j=await r.json();
 const fd=new FormData();let n=0,todo=j.imgs.filter(i=>!i.done);
 for(const it of todo){try{const b=await mmProcess(it.url,it.i===0);fd.append('f'+it.i,b,'px.jpg');n++;say('사진 가공 중… '+n+'/'+todo.length)}catch(e){}}
 if(n){say('가공한 사진 저장 중…');await fetch('/products/'+pid+'/processed',{method:'POST',body:fd})}
 return j;
}
document.querySelectorAll('button[data-autoimg]').forEach(b=>b.addEventListener('click',async ev=>{
 const f=b.form,chk=document.getElementById('autoimg');if(chk&&!chk.checked)return;
 ev.preventDefault();const note=document.getElementById('autoimg_note');
 const pids=b.dataset.autoimg==='bulk'?[...f.querySelectorAll('input[name=pid]:checked')].map(c=>c.value):[b.dataset.autoimg];
 if(!pids.length){alert('상품을 하나 이상 고르세요');return}
 f.querySelectorAll('button').forEach(x=>x.disabled=true);
 for(let i=0;i<pids.length;i++){try{await mmAutoImg(pids[i],{set textContent(t){if(note)note.textContent=(pids.length>1?(i+1)+'/'+pids.length+' 상품 · ':'')+t}})}catch(e){}}
 if(note)note.textContent='상세페이지 만드는 중…';mmKeep(f,b);f.submit();
}));
"""
