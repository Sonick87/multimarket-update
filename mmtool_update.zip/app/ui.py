import html
e = html.escape

CSS = """
:root{--bg:#f5f6f8;--card:#fff;--fg:#1d2330;--mut:#6b7280;--line:#e5e7eb;--acc:#2f6fed;--ok:#16a34a;--bad:#dc2626}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font-family:'Malgun Gothic','Apple SD Gothic Neo','Noto Sans KR',sans-serif;font-size:15px}
a{color:var(--acc);text-decoration:none}header{background:#111827;color:#fff;display:flex;align-items:center;gap:18px;padding:0 20px;height:54px;position:sticky;top:0;z-index:5}
header b{font-size:17px;white-space:nowrap}header nav{display:flex;gap:4px;overflow-x:auto}header nav a{color:#cbd5e1;padding:8px 12px;border-radius:8px;white-space:nowrap}
header nav a.on,header nav a:hover{background:#1f2937;color:#fff}header .me{margin-left:auto;color:#9ca3af;font-size:13px;white-space:nowrap}
main{max-width:1200px;margin:0 auto;padding:20px 16px 90px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:18px;margin-bottom:16px}
h1{font-size:22px;margin:4px 0 16px}h2{font-size:17px;margin:0 0 12px}table{width:100%;border-collapse:collapse}th,td{padding:9px 8px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{font-size:13px;color:var(--mut);font-weight:600;background:#fafafa}.tbl{overflow-x:auto}input,select,textarea{width:100%;padding:9px 10px;border:1px solid var(--line);border-radius:8px;font:inherit;background:#fff}
textarea{min-height:90px}label{display:block;font-size:13px;color:var(--mut);margin:10px 0 4px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
.btn{display:inline-block;background:var(--acc);color:#fff;border:0;border-radius:8px;padding:9px 16px;font:inherit;cursor:pointer;white-space:nowrap}.btn.gray{background:#6b7280}.btn.red{background:var(--bad)}.btn.green{background:var(--ok)}.btn.sm{padding:5px 10px;font-size:13px}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.mut{color:var(--mut);font-size:13px}.tag{display:inline-block;padding:2px 8px;border-radius:99px;background:#eef2ff;color:#3730a3;font-size:12px;margin:1px}
.tag.ok{background:#dcfce7;color:#166534}.tag.bad{background:#fee2e2;color:#991b1b}.tag.dry{background:#fef9c3;color:#854d0e}.flash{padding:12px 14px;border-radius:10px;background:#ecfdf5;border:1px solid #a7f3d0;margin-bottom:14px;white-space:pre-wrap}
.flash.err{background:#fef2f2;border-color:#fecaca}.stat{font-size:28px;font-weight:800}.thumb{width:56px;height:56px;object-fit:cover;border-radius:8px;background:#eee}
.imgs{display:flex;gap:8px;flex-wrap:wrap}.imgs img{width:96px;height:96px;object-fit:cover;border-radius:8px;border:1px solid var(--line)}
iframe{width:100%;height:720px;border:1px solid var(--line);border-radius:10px;background:#fff}
.bnav{display:none}
@media (max-width:760px){header nav{display:none}main{padding:14px 10px 90px}.bnav{display:flex;position:fixed;bottom:0;left:0;right:0;background:#111827;z-index:9;justify-content:space-around;padding:6px 0 calc(6px + env(safe-area-inset-bottom))}
.bnav a{color:#cbd5e1;font-size:11px;text-align:center;flex:1;padding:4px}.bnav a span{display:block;font-size:20px}.bnav a.on{color:#fff}th,td{font-size:13px;padding:7px 5px}iframe{height:560px}.hide-m{display:none}}
"""

NAV = [("/", "홈", "🏠"), ("/products", "상품", "📦"), ("/finder", "상품찾기", "🔎"), ("/orders", "주문", "🧾"), ("/fulfill", "발주·송장", "🚚"), ("/listings", "등록현황", "🛒"), ("/suppliers", "도매꾹", "🤝"),
       ("/channels", "판매처", "🌏"), ("/accounts", "마켓계정", "🔑"), ("/sell", "판매설정", "💰"), ("/settings", "설정", "⚙️"), ("/more", "더보기", "☰")]

def page(title, body, user=None, path="/", flash=None, err=False):
    nav = "".join(f'<a href="{h}" class="{"on" if (path == h or (h != "/" and path.startswith(h))) else ""}">{t}</a>' for h, t, _ in NAV[:-1])
    if user and user["role"] == "admin":
        nav += f'<a href="/users" class="{"on" if path.startswith("/users") else ""}">팀원</a>'
        nav += f'<a href="/admin" class="{"on" if path.startswith("/admin") else ""}">업데이트</a>'
    nav += f'<a href="/more" class="{"on" if path.startswith("/more") else ""}">더보기</a>'
    bnav = "".join(f'<a href="{h}" class="{"on" if (path == h or (h != "/" and path.startswith(h))) else ""}"><span>{i}</span>{t}</a>' for h, t, i in NAV[:4] + NAV[-1:])
    me = f'<span class="me">{e(user["name"] or user["username"])} · <a href="/logout" style="color:#9ca3af">로그아웃</a></span>' if user else ""
    fl = f'<div class="flash {"err" if err else ""}">{e(flash)}</div>' if flash else ""
    head = f'<header><b>멀티마켓 매니저</b><nav>{nav}</nav>{me}</header>' if user else ""
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>{e(title)} · 멀티마켓 매니저</title><link rel="manifest" href="/manifest.json"><meta name="theme-color" content="#111827">
<meta name="apple-mobile-web-app-capable" content="yes"><link rel="apple-touch-icon" href="/icon.png"><link rel="icon" href="/icon.svg">
<style>{CSS}</style></head><body>{head}<main>{fl}{body}</main>{('<nav class="bnav">' + bnav + '</nav>') if user else ''}
<script>if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js');
document.querySelectorAll('[data-all]').forEach(b=>b.onclick=()=>document.querySelectorAll('input[name="'+b.dataset.all+'"]').forEach(c=>c.checked=b.checked));
document.querySelectorAll('form[data-busy]').forEach(f=>f.addEventListener('submit',ev=>{{mmKeep(f,ev.submitter);f.querySelectorAll('button').forEach(b=>{{b.disabled=true;b.textContent='처리 중…'}})}}));
{IMG_JS}</script></body></html>"""

ICON_SVG = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><rect width="512" height="512" rx="96" fill="#111827"/>
<path d="M120 190h272l-24 190H144z" fill="#2f6fed"/><path d="M190 190v-30a66 66 0 0 1 132 0v30" stroke="#fff" stroke-width="28" fill="none"/>
<text x="256" y="335" font-size="120" text-anchor="middle" fill="#fff" font-family="Arial" font-weight="700">M</text></svg>"""

MANIFEST = """{"name":"멀티마켓 매니저","short_name":"멀티마켓","start_url":"/","display":"standalone","background_color":"#111827","theme_color":"#111827",
"icons":[{"src":"/icon.svg","sizes":"any","type":"image/svg+xml"},{"src":"/icon.png","sizes":"192x192","type":"image/png"},{"src":"/icon-512.png","sizes":"512x512","type":"image/png"}]}"""

SW = "self.addEventListener('install',e=>self.skipWaiting());self.addEventListener('fetch',e=>{});"

# 상세페이지 만들 때 사진 자동 가공(브라우저에서 처리 → 추가 설치 없음)
# 대표 사진: 흰 배경 1000×1000 정사각형, 여백 자르고 가운데 배치 / 나머지: 가로 860px 로 맞춤 / 둘 다 어두우면 밝기·대비 자동 보정
IMG_JS = r"""
function mmKeep(f,b){if(b&&b.name){let h=f.querySelector('input[type=hidden][data-keep]');if(!h){h=document.createElement('input');h.type='hidden';h.dataset.keep=1;f.appendChild(h)}h.name=b.name;h.value=b.value}}
function mmLoad(u){return new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=()=>no(new Error('사진 열기 실패'));i.src=u+(u.includes('?')?'&':'?')+'t='+Date.now()})}
async function mmProcess(url,first){
 const img=await mmLoad(url);const w=img.naturalWidth,h=img.naturalHeight;
 const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');
 x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(img,0,0);
 const d=x.getImageData(0,0,w,h).data;const st=Math.max(1,Math.floor(Math.min(w,h)/500));
 let x0=w,y0=h,x1=-1,y1=-1;const hist=new Uint32Array(256);let cnt=0;
 for(let y=0;y<h;y+=st)for(let X=0;X<w;X+=st){const k=(y*w+X)*4,r=d[k],g=d[k+1],b=d[k+2];hist[(r*299+g*587+b*114)/1000|0]++;cnt++;
  if(r<240||g<240||b<240){if(X<x0)x0=X;if(X>x1)x1=X;if(y<y0)y0=y;if(y>y1)y1=y}}
 if(x1<0||(x1-x0)<w*0.25||(y1-y0)<h*0.25){x0=0;y0=0;x1=w-1;y1=h-1}else{const m=st*3;x0=Math.max(0,x0-m);y0=Math.max(0,y0-m);x1=Math.min(w-1,x1+m);y1=Math.min(h-1,y1+m)}
 const bw=x1-x0+1,bh=y1-y0+1;let lo=0,hi=255,a=0;
 for(let i=0;i<256;i++){a+=hist[i];if(a>cnt*0.005){lo=i;break}}a=0;for(let i=255;i>=0;i--){a+=hist[i];if(a>cnt*0.005){hi=i;break}}
 lo=Math.min(lo,40);hi=Math.max(hi,200);
 const o=document.createElement('canvas');let ow,oh,dx,dy,dw,dh;
 if(first){ow=oh=1000;const s=Math.min(900/bw,900/bh);dw=Math.round(bw*s);dh=Math.round(bh*s);dx=(1000-dw)>>1;dy=(1000-dh)>>1}
 else{const s=Math.min(860/bw,4000/bh);dw=Math.round(bw*s);dh=Math.round(bh*s);ow=860;oh=dh;dx=(860-dw)>>1;dy=0}
 o.width=ow;o.height=oh;const ox=o.getContext('2d');ox.imageSmoothingQuality='high';ox.fillStyle='#fff';ox.fillRect(0,0,ow,oh);
 ox.drawImage(c,x0,y0,bw,bh,dx,dy,dw,dh);
 if(hi-lo<250){const id=ox.getImageData(0,0,ow,oh),p=id.data,lut=new Uint8ClampedArray(256);
  for(let i=0;i<256;i++)lut[i]=(i-lo)*255/(hi-lo);for(let i=0;i<p.length;i+=4){p[i]=lut[p[i]];p[i+1]=lut[p[i+1]];p[i+2]=lut[p[i+2]]}ox.putImageData(id,0,0)}
 return await new Promise(ok=>o.toBlob(ok,'image/jpeg',0.9));
}
async function mmAutoImg(pid,note){
 const say=t=>{if(note)note.textContent=t};say('사진 찾는 중…');
 const r=await fetch('/products/'+pid+'/fetch_images',{method:'POST'});const j=await r.json();
 const fd=new FormData();let n=0,todo=j.imgs.filter(i=>!i.done);
 for(const it of todo){try{const b=await mmProcess(it.url,it.i===0);fd.append('f'+it.i,b,'px.jpg');n++;say('사진 가공 중… '+n+'/'+todo.length)}catch(e){}}
 if(n){say('가공한 사진 저장 중…');await fetch('/products/'+pid+'/processed',{method:'POST',body:fd})}
 return j;
}
document.querySelectorAll('button[data-autoimg]').forEach(b=>b.addEventListener('click',async ev=>{
 const f=b.form,chk=document.getElementById('autoimg');if(chk&&!chk.checked)return;
 ev.preventDefault();const note=document.getElementById('autoimg_note');
 const pids=b.dataset.autoimg==='bulk'?[...f.querySelectorAll('input[name=pid]:checked')].map(c=>c.value):[b.dataset.autoimg];
 if(!pids.length){alert('상품을 하나 이상 고르세요');return}
 f.querySelectorAll('button').forEach(x=>x.disabled=true);
 for(let i=0;i<pids.length;i++){try{await mmAutoImg(pids[i],{set textContent(t){if(note)note.textContent=(pids.length>1?(i+1)+'/'+pids.length+' 상품 · ':'')+t}})}catch(e){}}
 if(note)note.textContent='상세페이지 만드는 중…';mmKeep(f,b);f.submit();
}));
"""
