"""판매처(채널). 네이버·쿠팡·지마켓·옥션은 API로 바로 등록, 직접 추가한 판매처(해외몰 등)는 대량등록용 CSV로 내보냅니다."""
from .db import q, x

API_LABEL = {"naver": "네이버 API", "coupang": "쿠팡 API", "esm": "ESM(지마켓·옥션) API", "": "엑셀(CSV) 내보내기"}
CURRENCIES = [("KRW", "원"), ("USD", "달러"), ("JPY", "엔"), ("CNY", "위안"), ("EUR", "유로"), ("TWD", "대만달러"), ("SGD", "싱가포르달러"),
              ("MYR", "링깃"), ("THB", "바트"), ("VND", "동"), ("PHP", "페소"), ("GBP", "파운드"), ("AUD", "호주달러"), ("CAD", "캐나다달러")]
# 해외 판매처 예시(값은 추정, 추가할 때 고쳐 쓰세요)
PRESETS = [
    ("아마존 미국", 15, "USD", 1400, 0.01, ".99", 200),
    ("이베이", 13.25, "USD", 1400, 0.01, ".99", 80),
    ("엣시(Etsy)", 9.5, "USD", 1400, 0.01, ".99", 140),
    ("쇼피 싱가포르", 15, "SGD", 1050, 0.01, ".90", 120),
    ("큐텐 재팬(Qoo10)", 12, "JPY", 9.3, 10, "0", 100),
    ("라쿠텐", 10, "JPY", 9.3, 10, "0", 127),
    ("알리익스프레스", 8, "USD", 1400, 0.01, ".99", 128),
    ("틱톡샵", 8, "USD", 1400, 0.01, ".99", 255),
    ("11번가", 13, "KRW", 1, 100, "900", 100),
    ("위메프·티몬", 12, "KRW", 1, 100, "900", 100),
    ("카카오톡 선물하기", 12, "KRW", 1, 100, "900", 100),
    ("자사몰(카페24 등)", 3.5, "KRW", 1, 100, "900", 100),
]

def all_channels(active_only=True):
    return q("SELECT * FROM channels " + ("WHERE active=1 " if active_only else "") + "ORDER BY sort, id")

def get(code):
    return q("SELECT * FROM channels WHERE code=?", (code,), one=True)

def by_api(api):
    return q("SELECT * FROM channels WHERE api=? AND active=1 ORDER BY sort, id", (api,))

def label(code):
    c = get(code)
    return c["name"] if c else code

def new_code():
    n = (q("SELECT MAX(id) FROM channels", one=True)[0] or 0) + 1
    return f"ch{n}"

def fmt(price, ch):
    cur = ch["currency"] if ch else "KRW"
    if cur == "KRW":
        return f"{int(price):,}원"
    if cur in ("JPY", "VND", "TWD"):
        return f"{price:,.0f} {cur}"
    return f"{price:,.2f} {cur}"
