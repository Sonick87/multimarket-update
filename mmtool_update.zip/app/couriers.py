"""택배사 이름 → 마켓별 택배사 코드. 도매매이 돌려주는 택배사 이름을 마켓 코드로 바꿀 때 씁니다.
네이버·쿠팡은 공식 코드표 기준, 지마켓·옥션(ESM) 번호는 일부만 확인(나머지는 송장 보낼 때 마켓 오류로 확인)."""
COURIERS = [  # (표시 이름, 찾을 말들, 네이버, 쿠팡, ESM)
    ("CJ대한통운", ("cj", "대한통운"), "CJGLS", "CJGLS", "10013"),
    ("롯데택배", ("롯데", "현대택배"), "HYUNDAI", "HYUNDAI", "10008"),
    ("한진택배", ("한진",), "HANJIN", "HANJIN", "10007"),
    ("우체국택배", ("우체국", "epost"), "EPOST", "EPOST", "10001"),
    ("로젠택배", ("로젠",), "KGB", "KGB", "10002"),
    ("경동택배", ("경동",), "KDEXP", "KDEXP", "10024"),
    ("대신택배", ("대신",), "DAESIN", "DAESIN", "10025"),
    ("일양로지스", ("일양",), "ILYANG", "ILYANG", "10006"),
    ("합동택배", ("합동",), "HDEXP", "HDEXP", "10057"),
    ("CU편의점택배", ("cu",), "CUPOST", "CUPOST", "10086"),
    ("GS편의점택배", ("gs", "cvsnet", "편의점"), "CVSNET", "CVSNET", "10074"),
]

def names():
    return [c[0] for c in COURIERS]

def find(name):
    n = (name or "").lower().replace(" ", "")
    for c in COURIERS:
        if c[0].lower().replace(" ", "") == n or any(k in n for k in c[1]):
            return c
    return None

def code(name, market):
    c = find(name)
    if not c:
        return None
    return {"naver": c[2], "coupang": c[3], "esm": c[4]}.get(market)
