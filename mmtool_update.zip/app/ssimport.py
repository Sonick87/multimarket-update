"""스마트스토어 대량등록 양식(엑셀 여러 개 + 이미지 zip) 읽기.
- 본문 엑셀(SMARTSTORE_*.xlsx): 상품명·카테고리ID·판매가·재고·대표이미지 파일명·상세정보(HTML)·배송비·반품/교환비·판매자 상품코드
- 보조 엑셀: 제주·도서산간 배송비(상품번호), 태그·페이지타이틀(판매자상품코드), 옵션(상품코드·선택옵션·옵션가·재고)
- zip: <판매자 상품코드>.jpg 이미지
파일 이름이 아니라 첫 줄 제목으로 종류를 알아봅니다."""
import io, json, re, zipfile
from . import xlsx

def _s(v):
    v = "" if v is None else str(v).strip()
    return "" if v in ("None", "nan") else v

def _n(v):
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None

def _code(v):
    v = _s(v)
    return v[:-2] if v.endswith(".0") else v

def kind_of(rows):
    h = [_s(c) for c in (rows[0] if rows else [])]
    if "카테고리ID" in h and "상품명" in h and "판매가" in h:
        return "main"
    if "제주지역 배송비" in h:
        return "delivery"
    if "태그" in h and "판매자상품코드" in h:
        return "keyword"
    if "선택옵션" in h and "옵션형태" in h:
        return "option"
    return None

def read_book(data):
    sh = xlsx.read(io.BytesIO(data))
    return next(iter(sh.values()))

def split_option(text):
    """'핑크/130' → [('옵션1','핑크'),('옵션2','130')], '선택1 블루/선택2 특대형' → [('선택1','블루'),('선택2','특대형')]"""
    parts = [p.strip() for p in re.split(r"/", text) if p.strip()]
    out = []
    for i, p in enumerate(parts[:3]):
        m = re.match(r"^(선택\d+|옵션\d+)\s+(.+)$", p)
        out.append((m.group(1), m.group(2)) if m else ("옵션" if len(parts) == 1 else f"옵션{i + 1}", p))
    return out

def parse(files):
    """files: [(파일이름, bytes)] → {'items': [...], 'zip': ZipFile|None, 'notes': [...]}"""
    main = delivery = keyword = option = None
    zf = None
    notes = []
    for fn, data in files:
        if fn.lower().endswith(".zip"):
            zf = zipfile.ZipFile(data if isinstance(data, str) else io.BytesIO(data)); continue
        try:
            rows = read_book(data)
        except Exception as ex:
            notes.append(f"{fn}: 엑셀을 읽지 못함({ex})"); continue
        k = kind_of(rows)
        if k == "main": main = rows
        elif k == "delivery": delivery = rows
        elif k == "keyword": keyword = rows
        elif k == "option": option = rows
        else: notes.append(f"{fn}: 어떤 양식인지 알 수 없어 건너뜀")
    if main is None:
        raise ValueError("본문 엑셀(상품명·카테고리ID·판매가 열이 있는 SMARTSTORE_ 파일)이 없습니다")
    H = [_s(c) for c in main[0]]
    col = lambda name: H.index(name) if name in H else None
    dl = {}
    if delivery:
        for r in delivery[1:]:
            dl[_code(r[0])] = (_n(r[1]) or 0, _n(r[2]) or 0)
    kw = {}
    if keyword:
        for r in keyword[1:]:
            kw[_code(r[2])] = {"tags": [t.strip() for t in _s(r[3]).split(",") if t.strip()][:10], "title": _s(r[4])[:100], "meta": _s(r[5])[:160]}
    opts = {}
    if option:
        for r in option[1:]:
            c = _code(r[0])
            if c:
                opts.setdefault(c, []).append({"text": _s(r[2]), "price": int(_n(r[3]) or 0), "stock": int(_n(r[4]) or 0)})
    items = []
    for r in main[1:]:
        g = lambda name: _s(r[col(name)]) if col(name) is not None and col(name) < len(r) else ""
        code = g("판매자 상품코드")
        if not code or not g("상품명"):
            continue
        imgs = [x.strip() for x in ([g("대표 이미지 파일명")] + re.split(r"[,\n]", g("추가 이미지 파일명"))) if x.strip()]
        ftype = g("배송비 유형")
        it = {"code": code, "name": g("상품명"), "cat": g("카테고리ID"), "price": int(_n(g("판매가")) or 0), "stock": int(_n(g("재고수량")) or 999),
              "images": imgs, "detail": g("상품 상세정보") if col("상품 상세정보") is not None else "",
              "info": {"fee_type": ftype, "base_fee": int(_n(g("기본배송비")) or 0), "repeat": int(_n(g("수량별부과-수량")) or 0),
                       "free_over": int(_n(g("조건부무료-상품판매가합계")) or 0), "return_fee": int(_n(g("반품배송비")) or 3000), "exchange_fee": int(_n(g("교환배송비")) or 6000),
                       "area": list(dl.get(code, (None, None))) if code in dl else None, "as_phone": g("A/S 전화번호"), "as_text": g("A/S 안내내용"),
                       "origin": g("원산지 직접입력"), "maker": g("제조사"), "tax": g("부가세"), "minor": g("미성년자 구매") != "N",
                       "tags": kw.get(code, {}).get("tags", []), "page_title": kw.get(code, {}).get("title", ""), "meta": kw.get(code, {}).get("meta", ""),
                       "options": opts.get(code, [])}}
        items.append(it)
    return {"items": items, "zip": zf, "notes": notes, "counts": {"main": len(items), "delivery": len(dl), "keyword": len(kw), "option_products": len(opts)}}
