"""폰 알림. ntfy 앱(가입 없음, 추천) 또는 텔레그램 봇으로 보냅니다. 실패해도 프로그램은 멈추지 않습니다."""
import json, secrets, threading, urllib.request, urllib.parse
from .db import get_setting, set_setting, log
from .secret import unseal

def conf():
    c = get_setting("notify", None)
    if c is None:
        c = {"ntfy_topic": "mm-" + secrets.token_hex(6), "ntfy_server": "https://ntfy.sh", "on_upload": True, "on_order": True, "on_soldout": True, "on_error": True}
        set_setting("notify", c)
    return c

def _ntfy(c, title, msg):
    topic = (c.get("ntfy_topic") or "").strip()
    if not topic or not c.get("ntfy_on", True):
        return None
    url = (c.get("ntfy_server") or "https://ntfy.sh").rstrip("/") + "/" + urllib.parse.quote(topic)
    # 제목은 헤더라 한글이 깨지지 않도록 JSON 방식으로 보냅니다
    body = json.dumps({"topic": topic, "title": title, "message": msg[:3500]}, ensure_ascii=False).encode()
    req = urllib.request.Request((c.get("ntfy_server") or "https://ntfy.sh").rstrip("/"), data=body, headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=10).read()
    return url

def _telegram(c, title, msg):
    tok = unseal(c.get("tg_token") or "") if c.get("tg_token") else ""
    chat = (c.get("tg_chat") or "").strip()
    if not tok or not chat:
        return None
    data = urllib.parse.urlencode({"chat_id": chat, "text": f"[{title}]\n{msg}"[:4000]}).encode()
    urllib.request.urlopen(f"https://api.telegram.org/bot{tok}/sendMessage", data=data, timeout=10).read()
    return "telegram"

def send(title, msg, kind=None, wait=False):
    """kind: upload / order / soldout / error. 설정에서 끈 종류는 보내지 않음"""
    c = conf()
    if kind and not c.get("on_" + kind, True):
        return []
    def run():
        sent = []
        for fn in (_ntfy, _telegram):
            try:
                r = fn(c, title, msg)
                if r:
                    sent.append(r)
            except Exception as ex:
                log("자동", "폰 알림 실패", f"{fn.__name__}: {ex}"[:300])
        return sent
    if wait:
        return run()
    threading.Thread(target=run, daemon=True).start()
    return []
