"""판매가 계산 (다팔자식 '가격 정책' + 판매처별 수수료·통화).
마진 우선순위: 상품 개별 > 정책의 판매처별 마진 > 판매처 기본 마진 > 정책 기본 마진.
마진 방식: pct(원가 대비 %) / price_pct(판매가 대비 %) / won(건당 정액, 원)."""
import json, math
from .db import get_setting, q
from . import channels as chs

DEFAULTS = {
    "name": "기본 정책",
    "cny_krw": 200, "landed_mult": 1.5, "pack_cost": 300, "ship_cost": 3000,
    "margin_mode": "pct", "margin": 200,
    "market_margin": {}, "market_ship": {},
    "round_to": 100, "end_with_900": True, "min_price": 0, "respect_fixed": True,
    "ship_mode": "include",   # include=택배비 포함(무료배송) / separate=택배비 미포함(구매자가 배송비 따로 냄)
}

def _merge(d):
    c = json.loads(json.dumps(DEFAULTS))
    for k, v in (d or {}).items():
        if isinstance(v, dict) and isinstance(c.get(k), dict):
            c[k].update(v)
        else:
            c[k] = v
    if c.get("margin_basis") and c["margin"] < 10:   # 1.0 버전 형식
        c["margin"] = c["margin"] * 100
        c["margin_mode"] = "pct" if c.pop("margin_basis") == "cost" else "price_pct"
    for key in ("market_margin", "market_ship"):     # 1.1 버전 'esm' → 지마켓·옥션
        if "esm" in c[key]:
            v = c[key].pop("esm")
            c[key].setdefault("gmarket", v); c[key].setdefault("auction", v)
    return c

def cfg():
    return _merge(get_setting("pricing", {}))

def policy_for(p):
    pid = p["policy_id"] if "policy_id" in p.keys() else None
    if pid:
        r = q("SELECT data FROM policies WHERE id=?", (pid,), one=True)
        if r:
            return _merge(json.loads(r["data"]))
    if is_consign(p):   # 정책을 따로 안 고른 위탁 상품은 위탁 설정으로
        r = q("SELECT data FROM policies WHERE name='위탁 기본'", one=True)
        if r:
            return _merge(json.loads(r["data"]))
    return cfg()

def policies():
    return [(r["id"], r["name"]) for r in q("SELECT id, name FROM policies ORDER BY id")]

def _ch(code):
    if hasattr(code, "keys"):
        return code
    return chs.get("gmarket" if code == "esm" else code)

def blank(v):
    return v is None or v == ""

def is_consign(p):
    return (pv(p, "supply_type") or "사입") == "위탁"

def unit_cost(p, c):
    if is_consign(p):   # 위탁: 도매매 공급가 그대로(사입 부대비용 없음)
        return float(pv(p, "supply_price") or p["cost_krw"] or 0)
    base = float(p["cost_krw"]) if p["cost_krw"] else float(p["cost_cny"] or 0) * c["cny_krw"]
    return base * c["landed_mult"]

def pj(p, key):
    """상품의 판매처별 값(JSON) 읽기"""
    try:
        return json.loads(p[key] or "{}") if key in p.keys() else {}
    except (ValueError, TypeError):
        return {}

def pv(p, key):
    return p[key] if key in p.keys() else None

def ship_of(ch, c, p=None):
    if p is not None:
        v = pj(p, "ch_ship").get(ch["code"]) if ch else None
        if blank(v):
            v = pv(p, "ship")
        if not blank(v):
            return float(v)
        if is_consign(p) and not blank(pv(p, "supply_ship")):   # 위탁: 공급처 배송비
            return float(pv(p, "supply_ship"))
    v = c["market_ship"].get(ch["code"]) if ch else None
    if blank(v) and ch is not None:
        v = ch["ship"]
    return float(c["ship_cost"] if blank(v) else v)

def ship_in_price(ch, c, p=None):
    """판매가에 넣는 택배비(미포함이면 0 — 구매자가 마켓 배송비로 따로 냄)"""
    return 0.0 if c.get("ship_mode") == "separate" else ship_of(ch, c, p)

def total_cost(p, ch, c):
    if is_consign(p):   # 위탁은 공급처가 포장·발송
        return unit_cost(p, c) * int(p["set_qty"] or 1) + ship_in_price(ch, c, p)
    return unit_cost(p, c) * int(p["set_qty"] or 1) + c["pack_cost"] + ship_in_price(ch, c, p)

def margin_of(p, ch, c):
    if ch is not None:
        v = pj(p, "ch_margin").get(ch["code"])
        if not blank(v):
            return float(v), "상품·판매처별"
    pm = pv(p, "margin")
    if not blank(pm):
        return float(pm), "상품 개별"
    if ch is not None:
        v = c["market_margin"].get(ch["code"])
        if not blank(v):
            return float(v), "정책·판매처별"
        if not blank(ch["margin"]) and not pv(p, "policy_id"):   # 따로 고른 정책(예: 위탁 기본)이 있으면 그 정책 마진이 우선
            return float(ch["margin"]), "판매처 기본"
    return float(c["margin"]), "정책 기본"

def _round(v, step, ending, raw):
    step = step or 1
    v = math.ceil(raw / step - 1e-9) * step
    if ending == "900":
        if v % 1000 != 900:
            v = (v // 1000) * 1000 + 900
            if v < raw:
                v += 1000
    elif ending in (".99", ".90", ".95"):
        cents = float(ending)
        v = math.floor(raw) + cents
        if v < raw:
            v += 1
    return v

def price_krw(p, code, c=None):
    """원화 기준 판매가(API 등록·정수)"""
    ch = _ch(code)
    c = c or policy_for(p)
    if p["price_override"] and (ch is None or ch["currency"] == "KRW"):
        return int(p["price_override"])
    return int(round(_raw_price(p, ch, c)[0] * (ch["fx"] if ch and ch["currency"] != "KRW" else 1)))

def _raw_price(p, ch, c):
    tc = total_cost(p, ch, c)
    fee = (ch["fee"] if ch is not None and not blank(ch["fee"]) else 10) / 100
    m, _ = margin_of(p, ch, c)
    mode = c["margin_mode"]
    if mode == "won":
        raw = (tc + m) / (1 - fee)
    elif mode == "price_pct":
        denom = 1 - fee - m / 100
        raw = tc / denom if denom > 0.05 else tc * 20
    else:
        raw = tc * (1 + m / 100) / (1 - fee)
    if ch is None or ch["currency"] == "KRW":
        step = int(c["round_to"] or 10)
        ending = "900" if c["end_with_900"] else ""
        if ch is not None and not blank(ch["round_to"]) and ch["code"] not in ("naver", "coupang", "gmarket", "auction"):
            step, ending = ch["round_to"], ch["ending"] or ""
        floor = max(int(c.get("min_price") or 0), int(float(pv(p, "fixed_price") or 0)) if c.get("respect_fixed", True) else 0)   # 소비자가 준수 상품은 그 아래로 못 팖
        v = max(_round(0, step, ending, raw), floor)
        if floor and v == floor and ending == "900" and v % 1000 != 900:
            v = _round(0, step, ending, floor)
        return int(v), raw
    fx = float(ch["fx"] or 1)
    local_raw = raw / fx
    v = _round(0, float(ch["round_to"] or 0.01), ch["ending"] or "", local_raw)
    return round(v, 2), local_raw

def price_for(p, code, c=None):
    """판매처 통화 기준 판매가"""
    ch = _ch(code)
    c = c or policy_for(p)
    if p["price_override"] and (ch is None or ch["currency"] == "KRW"):
        return int(p["price_override"])
    return _raw_price(p, ch, c)[0]

def breakdown(p, code, c=None):
    ch = _ch(code)
    c = c or policy_for(p)
    price = price_for(p, ch, c)
    fx = float(ch["fx"] or 1) if ch and ch["currency"] != "KRW" else 1
    pk = price * fx
    tc = total_cost(p, ch, c)
    fee = pk * ((ch["fee"] if ch is not None and not blank(ch["fee"]) else 10) / 100)
    profit = pk - fee - tc
    m, src = margin_of(p, ch, c)
    return {"price": price, "price_text": chs.fmt(price, ch), "price_krw": round(pk), "total_cost": round(tc), "ship": round(ship_of(ch, c, p)), "fee": round(fee),
            "profit": round(profit), "margin_on_cost": round(profit / tc * 100) if tc else 0,
            "margin_on_price": round(profit / pk * 100) if pk else 0, "target": m, "source": src}

MODE_LABEL = {"pct": "원가 대비 %", "price_pct": "판매가 대비 %", "won": "건당 정액(원)"}
