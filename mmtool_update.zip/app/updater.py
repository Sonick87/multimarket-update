"""자동 업데이트.
업데이트 위치(폴더 경로 또는 https 주소)에 아래 파일을 두면 됩니다.
  version.json      {"version": "1.2.0", "notes": "바뀐 점"}
  MultiMarket.exe   (.exe 사용자용)
  mmtool_update.zip (파이썬/서버 설치본용)
기본 위치: 프로그램(.exe) 옆의 'update' 폴더. 설정에서 공유 원드라이브·구글드라이브 폴더나 인터넷 주소로 바꿀 수 있습니다."""
import io, json, os, subprocess, sys, threading, time, urllib.request, zipfile
from . import VERSION
from .paths import base_dir
from .db import get_setting

state = {"latest": None, "notes": "", "checked": 0, "error": ""}
# 서버·파이썬 설치본은 기본으로 이 인터넷 주소에서 새 버전을 받아 갑니다(설정에서 바꿀 수 있음)
DEFAULT_URL = "https://raw.githubusercontent.com/Sonick87/multimarket-update/main"
busy = lambda: False   # 작업 중(CSV 자동 등록 등)이면 업데이트를 잠시 미룸

def source():
    s = (get_setting("update_source", "") or "").strip()
    if s:
        return s
    return os.path.join(base_dir(), "update") if getattr(sys, "frozen", False) else DEFAULT_URL

def vtuple(v):
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return (0,)

def _read(name):
    src = source()
    if src.startswith(("http://", "https://")):
        with urllib.request.urlopen(src.rstrip("/") + "/" + name, timeout=60) as r:
            return r.read()
    with open(os.path.join(src, name), "rb") as f:
        return f.read()

def check():
    try:
        info = json.loads(_read("version.json").decode("utf-8-sig"))
        state.update(latest=str(info.get("version")), notes=info.get("notes", ""), launcher=info.get("launcher", 0), error="")
    except FileNotFoundError:
        state.update(latest=None, error="업데이트 폴더에 version.json 이 없습니다")
    except Exception as ex:
        state.update(latest=None, error=str(ex)[:300])
    state["checked"] = time.time()
    return available()

def bad_versions():
    try:
        return set(open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "_bad_version.txt")).read().split())
    except OSError:
        return set()

def available():
    return bool(state["latest"]) and vtuple(state["latest"]) > vtuple(VERSION) and state["latest"] not in bad_versions()

def apply(restart=True):
    """새 버전을 받아 교체하고 다시 켭니다. 성공하면 돌아오지 않습니다(프로세스 재시작)."""
    if getattr(sys, "frozen", False):
        exe = sys.executable
        need_exe = int(state.get("launcher") or 0) > int(os.environ.get("MM_LAUNCHER") or 0)
        if not need_exe:   # 보통은 프로그램 코드만 바꿈(exe는 그대로)
            _apply_code(os.path.join(os.path.dirname(exe), "code"))
            _restart_exe(exe)
        data = _read("MultiMarket.exe")
        if len(data) < 1_000_000:
            raise ValueError("MultiMarket.exe 파일이 이상합니다")
        new = exe + ".new"
        with open(new, "wb") as f:
            f.write(data)
        bat = os.path.join(os.path.dirname(exe), "_update.bat")
        args = " ".join(f'"{a}"' for a in sys.argv[1:])
        with open(bat, "w", encoding="cp949", errors="replace") as f:
            f.write(f'@echo off\r\nping 127.0.0.1 -n 3 >nul\r\n:retry\r\nmove /y "{new}" "{exe}" >nul 2>nul\r\n'
                    f'if exist "{new}" (ping 127.0.0.1 -n 2 >nul & goto retry)\r\nstart "" "{exe}" {args}\r\ndel "%~f0"\r\n')
        # PyInstaller 단일 exe의 환경변수를 넘기면 새 exe가 안 켜지므로 지우고 실행
        env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("_PYI_", "_MEI"))}
        env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
        subprocess.Popen(["cmd", "/c", bat], creationflags=0x00000008 | 0x00000200, close_fds=True, env=env)  # DETACHED
        os._exit(0)
    # 파이썬/서버 설치본: zip 풀어서 덮어쓰기
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    z = zipfile.ZipFile(io.BytesIO(_read("mmtool_update.zip")))
    names = [n for n in z.namelist() if n.endswith(".py") and ".." not in n and not n.startswith("/")]
    if "main.py" not in names:
        raise ValueError("mmtool_update.zip 에 main.py가 없습니다")
    import shutil
    prev = os.path.join(root, "_prev")   # 새 버전이 안 켜지면 main.py가 이 백업으로 되돌립니다
    shutil.rmtree(prev, ignore_errors=True)
    for n in names:
        p = os.path.join(root, n)
        if os.path.exists(p):
            os.makedirs(os.path.dirname(os.path.join(prev, n)), exist_ok=True)
            shutil.copy2(p, os.path.join(prev, n))
    with open(os.path.join(prev, "_version.txt"), "w") as f:
        f.write(VERSION + "\n" + str(state.get("latest")))
    for n in names:
        p = os.path.join(root, n)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as f:
            f.write(z.read(n))
    for d, ds, _ in os.walk(root):
        if "__pycache__" in ds:
            shutil.rmtree(os.path.join(d, "__pycache__"), ignore_errors=True)
    if restart:
        os.environ["MM_JUST_UPDATED"] = "1"
        if os.environ.get("INVOCATION_ID"):   # systemd가 다시 켜 줌
            os._exit(0)
        os.execv(sys.executable, [sys.executable] + sys.argv)

def _apply_code(code):
    """mmtool_update.zip 의 app 폴더를 exe 옆 code 폴더에 풀기(새 폴더에 푼 뒤 바꿔치기)"""
    import shutil
    z = zipfile.ZipFile(io.BytesIO(_read("mmtool_update.zip")))
    names = [n for n in z.namelist() if n.startswith("app/") and n.endswith(".py") and ".." not in n]
    if "app/__init__.py" not in names:
        raise ValueError("mmtool_update.zip 에 app 폴더가 없습니다")
    tmp = code + ".new"
    shutil.rmtree(tmp, ignore_errors=True)
    for n in names:
        p = os.path.join(tmp, *n.split("/"))
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "wb") as f:
            f.write(z.read(n))
    old = code + ".old"
    shutil.rmtree(old, ignore_errors=True)
    if os.path.exists(code):
        os.replace(code, old)
    os.replace(tmp, code)
    shutil.rmtree(old, ignore_errors=True)

def _restart_exe(exe):
    bat = os.path.join(os.path.dirname(exe), "_restart.bat")
    args = " ".join(f'"{a}"' for a in sys.argv[1:] if a != "--no-browser") + " --no-browser"
    with open(bat, "w", encoding="cp949", errors="replace") as f:
        f.write(f'@echo off\r\nping 127.0.0.1 -n 4 >nul\r\nstart "" "{exe}" {args}\r\ndel "%~f0"\r\n')
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith(("_PYI_", "_MEI"))}
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    env["MM_JUST_UPDATED"] = "1"
    subprocess.Popen(["cmd", "/c", bat], creationflags=0x00000008 | 0x00000200, close_fds=True, env=env)
    os._exit(0)

def auto_on():
    return get_setting("auto_update", True)

def startup():
    """프로그램을 켤 때: 새 버전이 있고 자동 업데이트가 켜져 있으면 바로 교체."""
    if os.environ.pop("MM_JUST_UPDATED", None):
        return
    if auto_on() and check():
        print(f"  새 버전 {state['latest']} 발견 → 업데이트합니다…")
        try:
            apply()
        except Exception as ex:
            state["error"] = f"자동 업데이트 실패: {ex}"
            print("  " + state["error"])

def loop():
    """켜져 있는 동안 10분마다 확인. 자동이면 새 버전을 바로 바꿔 끼움(몇 초 뒤 다시 켜짐)."""
    while True:
        time.sleep(60)
        try:
            if time.time() - state["checked"] > 600:
                check()
            if available() and auto_on() and not busy():
                apply()
        except Exception as ex:
            state["error"] = str(ex)[:300]

def start_background():
    threading.Thread(target=loop, daemon=True).start()
