"""오너클랜 판매사 API (GraphQL) — 위탁상품 조회·품절/가격 변경 확인·발주(주문 등록)·송장 확인.
문서: ownerclan.com/V2/service/api-center-guide.php (API 센터에서 Sandbox/Production 각각 신청 필요)
인증: POST https://auth.ownerclan.com/auth {service, userType:"seller", username, password} → JWT(약 한 달 유효)
※ 이 프로그램을 만든 곳에서는 오너클랜에 접속할 수 없어 실제 호출은 아직 확인하지 못했습니다. 오류가 나면 화면의 메시지를 그대로 보내 주세요."""
import json, os, time, uuid, urllib.request, urllib.error
from .paths import OUTBOX
from .db import get_setting, set_setting
from .secret import unseal

HOSTS = {"prod": ("https://auth.ownerclan.com/auth", "https://api.ownerclan.com/v1/graphql"),
         "sandbox": ("https://auth-sandbox.ownerclan.com/auth", "https://api-sandbox.ownerclan.com/v1/graphql")}

ITEM_FULL = "key name model price fixedPrice shippingFee shippingType status options { optionAttributes { name value } price quantity } images content updatedAt"
ITEM_MIN = "key name price status options { optionAttributes { name value } price quantity }"

class OCError(Exception):
    pass

def conf():
    return get_setting("ownerclan", {}) or {}

class OwnerClan:
    def __init__(self, force_dry=False):
        c = conf()
        self.c = c
        self.env = c.get("env", "prod")
        self.user = c.get("username", "")
        self.pw = unseal(c.get("password", "")) if c.get("password") else ""
        self.dry = force_dry or not (self.user and self.pw)

    # ---------- 공통 ----------
    def _http(self, url, body, token=None):
        # 파이썬 기본 User-Agent는 오너클랜 Cloudflare가 막음(Error 1010). 브라우저로 위장하지 않고 프로그램 이름을 그대로 밝힘. 막히면 오너클랜에 IP 허용 요청
        from . import VERSION
        h = {"Content-Type": "application/json", "Accept": "application/json",
             "User-Agent": f"MultiMarketManager/{VERSION} (ownerclan seller api client)"}
        if token:
            h["Authorization"] = "Bearer " + token
        req = urllib.request.Request(url, data=json.dumps(body, ensure_ascii=False).encode(), method="POST", headers=h)
        try:
            with urllib.request.urlopen(req, timeout=40) as r:
                txt = r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            txt = e.read().decode("utf-8", "replace")
            if e.code == 403 and ("1010" in txt or "browser_signature" in txt or "cloudflare" in txt.lower()):
                set_setting("ownerclan_blocked", time.time())   # 자동 확인을 멈춰 반복 접속으로 더 막히지 않게
                raise OCError("오너클랜 보안(Cloudflare)이 서버 접속을 막았습니다(Error 1010). 자동 확인은 멈췄습니다. "
                              "'연결 확인'을 한 번 눌러 보고, 계속 막히면 오너클랜 고객센터에 'API 호출 서버 IP 168.110.41.196 허용'을 요청해 주세요.")
            raise OCError(f"오너클랜 {e.code}: {txt[:1200]}")
        except urllib.error.URLError as e:
            raise OCError(f"오너클랜 접속 실패: {e.reason}")
        try:
            return json.loads(txt)
        except ValueError:
            return txt.strip().strip('"')   # 인증은 토큰 문자열만 돌려줄 수 있음

    def token(self):
        t = get_setting("ownerclan_token", {}) or {}
        if t.get("tok") and t.get("exp", 0) > time.time() + 3600 and t.get("user") == self.user and t.get("env") == self.env:
            return t["tok"]
        r = self._http(HOSTS[self.env][0], {"service": "ownerclan", "userType": "seller", "username": self.user, "password": self.pw})
        tok = r if isinstance(r, str) else (r.get("token") or r.get("accessToken") or r.get("access_token") or (r.get("data") or {}).get("token"))
        if not tok:
            raise OCError("오너클랜 로그인 실패: " + json.dumps(r, ensure_ascii=False)[:500])
        set_setting("ownerclan_token", {"tok": tok, "exp": time.time() + 25 * 86400, "user": self.user, "env": self.env})
        return tok

    def gql(self, query, variables=None):
        r = self._http(HOSTS[self.env][1], {"query": query, "variables": variables or {}}, self.token())
        if isinstance(r, dict) and r.get("errors"):
            raise OCError("오너클랜: " + "; ".join(str(e.get("message")) for e in r["errors"])[:1200])
        return (r or {}).get("data") or {}

    def _items_query(self, tmpl, variables):
        try:
            return self.gql(tmpl.replace("@F", ITEM_FULL), variables)
        except OCError as ex:   # 필드 이름이 다르면 최소 필드로 다시
            if "Cannot query field" in str(ex) or "field" in str(ex).lower():
                return self.gql(tmpl.replace("@F", ITEM_MIN), variables)
            raise

    def save_dry(self, action, payload):
        fn = os.path.join(OUTBOX, f"{time.strftime('%Y%m%d-%H%M%S')}_ownerclan_{action}_{uuid.uuid4().hex[:6]}.json")
        with open(fn, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        return fn

    # ---------- 상품 ----------
    def test(self):
        if self.dry:
            return "아이디·비밀번호가 없어 미리보기 모드입니다"
        self.token()
        d = self.gql("query { allItems(first: 1) { edges { node { key name } } } }")
        n = ((d.get("allItems") or {}).get("edges") or [{}])[0].get("node", {})
        return f"연결 성공 ({'테스트(샌드박스)' if self.env == 'sandbox' else '실서버'}) · 예: {n.get('key', '')} {n.get('name', '')}"

    def item(self, key):
        if self.dry:
            return demo_item(key)
        return self._items_query("query($key: ID!) { item(key: $key) { @F } }", {"key": key}).get("item")

    def items(self, keys):
        if self.dry:
            return [demo_item(k) for k in keys]
        out = []
        for i in range(0, len(keys), 50):
            chunk = keys[i:i + 50]
            try:
                d = self._items_query("query($keys: [ID!]!) { itemsByKeys(keys: $keys) { @F } }", {"keys": chunk})
                out += [x for x in (d.get("itemsByKeys") or []) if x]
            except OCError:
                for k in chunk:
                    try:
                        it = self.item(k)
                        if it:
                            out.append(it)
                    except OCError:
                        pass
        return out

    def search(self, word, first=30, min_price=None, max_price=None):
        if self.dry:
            return [demo_item(f"W{i:06d}", word) for i in range(1, 6)]
        args = {"first": first, "search": word}
        if min_price: args["minPrice"] = min_price
        if max_price: args["maxPrice"] = max_price
        d = self._items_query("query($first: Int, $search: String, $minPrice: Int, $maxPrice: Int) { allItems(first: $first, search: $search, minPrice: $minPrice, maxPrice: $maxPrice) { edges { node { @F } } } }", args)
        return [e["node"] for e in ((d.get("allItems") or {}).get("edges") or [])]

    def soldout_history(self, date_from):
        """품절·단종 이력(itemHistories). date_from: 유닉스 초"""
        if self.dry:
            return []
        out = []
        for kind in ("soldout", "discontinued"):
            try:
                d = self.gql("query($df: Int, $kind: String) { itemHistories(first: 500, dateFrom: $df, kind: $kind) { edges { node { itemKey kind valueBefore valueAfter createdAt } } } }",
                             {"df": int(date_from), "kind": kind})
                out += [e["node"] for e in ((d.get("itemHistories") or {}).get("edges") or [])]
            except OCError:
                pass
        return out

    # ---------- 발주 ----------
    def order_input(self, lines, rcv, note=""):
        """lines: [(item_key, [옵션값...], 수량)], rcv: {name, phone, zip, addr1, addr2}"""
        return {"products": [{"itemKey": k, "quantity": int(qty), "optionAttributes": opts} for k, opts, qty in lines],
                "recipient": {"name": rcv["name"], "phoneNumber": rcv["phone"],
                              "destinationAddress": {"addr1": rcv["addr1"], "addr2": rcv.get("addr2", ""), "postalCode": rcv["zip"]}},
                "note": note or "", "sellerNote": note or ""}

    def simulate(self, inp):
        if self.dry:
            return {"dry": True}
        return self.gql("mutation($input: OrderInput!) { simulateCreateOrder(input: $input) }", {"input": inp}).get("simulateCreateOrder")

    def create_order(self, inp):
        if self.dry:
            return {"dry": True, "key": "DRY-" + uuid.uuid4().hex[:8], "file": self.save_dry("order", inp)}
        sim = self.simulate(inp)
        d = self.gql("mutation($input: OrderInput!, $sim: JSON) { createOrder(input: $input, simulationResult: $sim) { key id status } }",
                     {"input": inp, "sim": sim})
        o = d.get("createOrder") or {}
        if isinstance(o, list):
            o = o[0] if o else {}
        if not o.get("key"):
            raise OCError("오너클랜 발주 응답에 주문번호가 없습니다: " + json.dumps(d, ensure_ascii=False)[:500])
        return {"key": o["key"], "status": o.get("status"), "raw": d}

    def order(self, key):
        """송장 확인: 상품별 운송장·택배사"""
        if self.dry or str(key).startswith("DRY-"):
            return {"key": key, "status": "미리보기", "products": []}
        return self.gql("query($key: ID!) { order(key: $key) { key status products { itemKey quantity trackingNumber shippingCompanyName shippingCompanyCode shippedDate } } }",
                        {"key": key}).get("order") or {}

    def cancel(self, key):
        if self.dry or str(key).startswith("DRY-"):
            return {"dry": True}
        return self.gql("mutation($key: ID!) { cancelOrder(key: $key) { key status } }", {"key": key})

def demo_item(key, word="예시"):
    """미리보기 모드용 가짜 상품(화면·흐름 확인용)"""
    return {"key": key, "name": f"[미리보기] {word} 위탁상품 {key}", "price": 4500, "fixedPrice": 0, "shippingFee": 3000,
            "status": "available", "options": [{"optionAttributes": [{"name": "색상", "value": "블랙"}], "price": 4500, "quantity": 99},
                                               {"optionAttributes": [{"name": "색상", "value": "화이트"}], "price": 4700, "quantity": 0}],
            "images": [], "content": ""}

def option_text(opt):
    return " / ".join(f"{a.get('name')}:{a.get('value')}" for a in (opt or {}).get("optionAttributes") or [])

def is_soldout(it, opt_values=None):
    st = str(it.get("status") or "").lower()
    if st and st not in ("available", "onsale", "on_sale", "selling", "판매중", "active"):
        return True
    opts = it.get("options") or []
    if opt_values and opts:
        for o in opts:
            if [a.get("value") for a in o.get("optionAttributes") or []] == opt_values:
                return (o.get("quantity") or 0) <= 0
        return True   # 옵션이 사라짐
    if opts:
        return all((o.get("quantity") or 0) <= 0 for o in opts)
    return False

def price_of(it, opt_values=None):
    for o in it.get("options") or []:
        if opt_values and [a.get("value") for a in o.get("optionAttributes") or []] == opt_values and o.get("price"):
            return float(o["price"])
    return float(it.get("price") or 0)

def images_of(it):
    im = it.get("images") or []
    out = []
    for x in im:
        if isinstance(x, str):
            out.append(x)
        elif isinstance(x, dict):
            out.append(x.get("url") or x.get("src") or "")
    return [u for u in out if u.startswith("http")]
