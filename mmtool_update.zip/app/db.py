import sqlite3, json, threading, time
from .paths import DB_PATH

_lock = threading.RLock()
SCHEMA = """
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT UNIQUE, name TEXT, pw TEXT, role TEXT DEFAULT 'staff', created REAL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY, user_id INTEGER, expires REAL);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS accounts(id INTEGER PRIMARY KEY, market TEXT, label TEXT, creds TEXT, extra TEXT, active INTEGER DEFAULT 1, owner TEXT, created REAL);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, name TEXT, theme TEXT, keyword TEXT, source_name TEXT, source_url TEXT,
  cost_cny REAL, cost_krw REAL, set_qty INTEGER DEFAULT 1, set_desc TEXT, moq TEXT, points TEXT, cautions TEXT,
  images TEXT DEFAULT '[]', price_override INTEGER, stock INTEGER DEFAULT 100, naver_cat TEXT, coupang_cat TEXT, esm_cat TEXT,
  detail_html TEXT, template TEXT DEFAULT 'clean', status TEXT DEFAULT '준비', memo TEXT, updated REAL, updated_by TEXT);
CREATE TABLE IF NOT EXISTS listings(id INTEGER PRIMARY KEY, product_id INTEGER, account_id INTEGER, market TEXT, market_id TEXT, sub_id TEXT,
  price INTEGER, stock INTEGER, status TEXT, last_result TEXT, dry INTEGER, updated REAL);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, account_id INTEGER, market TEXT, order_id TEXT, product_name TEXT, qty INTEGER,
  amount INTEGER, buyer TEXT, status TEXT, ordered_at TEXT, raw TEXT, UNIQUE(market, order_id));
CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY, code TEXT UNIQUE, name TEXT, api TEXT, fee REAL, margin REAL, ship REAL,
  currency TEXT DEFAULT 'KRW', fx REAL DEFAULT 1, round_to REAL DEFAULT 100, ending TEXT DEFAULT '900', name_max INTEGER DEFAULT 100,
  active INTEGER DEFAULT 1, sort INTEGER DEFAULT 0, memo TEXT);
CREATE TABLE IF NOT EXISTS policies(id INTEGER PRIMARY KEY, name TEXT, data TEXT);
CREATE TABLE IF NOT EXISTS finds(id INTEGER PRIMARY KEY, keyword TEXT, volume INTEGER, comp_total INTEGER, ratio REAL, mkt_low INTEGER, mkt_avg INTEGER,
  item_key TEXT, item_name TEXT, supply_price REAL, our_price INTEGER, profit INTEGER, score REAL, why TEXT, image TEXT,
  status TEXT DEFAULT '추천', product_id INTEGER, found_at REAL, run_id TEXT);
CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY, ts REAL, user TEXT, action TEXT, detail TEXT);
"""

def conn():
    c = sqlite3.connect(DB_PATH, check_same_thread=False, timeout=30)
    c.row_factory = sqlite3.Row
    return c

_c = None
def db():
    global _c
    if _c is None:
        _c = conn()
        _c.executescript(SCHEMA)
        _c.execute("PRAGMA journal_mode=WAL")
        cols = {r[1] for r in _c.execute("PRAGMA table_info(products)")}
        for col, typ in (("margin", "REAL"), ("policy_id", "INTEGER"), ("ship", "REAL"), ("ch_margin", "TEXT"), ("ch_ship", "TEXT"),
                         ("supply_type", "TEXT DEFAULT '사입'"), ("supplier", "TEXT"), ("supplier_key", "TEXT"), ("supplier_option", "TEXT"),
                         ("supply_price", "REAL"), ("supply_ship", "REAL"), ("fixed_price", "REAL"), ("supplier_status", "TEXT"),
                         ("supplier_checked", "REAL"), ("import_json", "TEXT")):
            if col not in cols:
                _c.execute(f"ALTER TABLE products ADD COLUMN {col} {typ}")
        ocols = {r[1] for r in _c.execute("PRAGMA table_info(orders)")}
        for col, typ in (("product_id", "INTEGER"), ("supply_type", "TEXT"), ("seller_code", "TEXT"), ("option_text", "TEXT"),
                         ("rcv", "TEXT"), ("ship_ref", "TEXT"), ("po_status", "TEXT DEFAULT ''"), ("po_key", "TEXT"), ("po_msg", "TEXT"),
                         ("courier", "TEXT"), ("tracking", "TEXT"), ("shipped_at", "REAL"), ("collected", "REAL")):
            if col not in ocols:
                _c.execute(f"ALTER TABLE orders ADD COLUMN {col} {typ}")
        fcols = {r[1] for r in _c.execute("PRAGMA table_info(finds)")}
        if "mkt_min" not in fcols:
            _c.execute("ALTER TABLE finds ADD COLUMN mkt_min INTEGER")
        if "price_fixed" not in fcols:
            _c.execute("ALTER TABLE finds ADD COLUMN price_fixed INTEGER DEFAULT 0")
        if "skip_why" not in fcols:
            _c.execute("ALTER TABLE finds ADD COLUMN skip_why TEXT")
        if "supply_ship" not in fcols:
            _c.execute("ALTER TABLE finds ADD COLUMN supply_ship REAL")
        lcols = {r[1] for r in _c.execute("PRAGMA table_info(listings)")}
        if "channel" not in lcols:
            _c.execute("ALTER TABLE listings ADD COLUMN channel TEXT")
            _c.execute("UPDATE listings SET channel = CASE market WHEN 'esm' THEN 'gmarket' ELSE market END")
        if not _c.execute("SELECT 1 FROM channels LIMIT 1").fetchone():
            for i, (code, name, api, fee, nm) in enumerate([("naver", "네이버 스마트스토어", "naver", 5.63, 100), ("coupang", "쿠팡", "coupang", 10.8, 100),
                                                           ("gmarket", "지마켓", "esm", 13, 50), ("auction", "옥션", "esm", 13, 50)]):
                _c.execute("INSERT INTO channels(code,name,api,fee,currency,fx,round_to,ending,name_max,sort) VALUES(?,?,?,?,'KRW',1,100,'900',?,?)", (code, name, api, fee, nm, i))
        if not _c.execute("SELECT 1 FROM policies WHERE name='위탁 기본'").fetchone():
            _c.execute("INSERT INTO policies(name, data) VALUES(?,?)", ("위탁 기본", json.dumps(
                {"name": "위탁 기본", "margin_mode": "pct", "margin": 30, "cny_krw": 200, "landed_mult": 1, "pack_cost": 0, "ship_cost": 3000,
                 "round_to": 100, "end_with_900": True, "min_price": 0, "market_margin": {}, "market_ship": {}}, ensure_ascii=False)))
        _c.commit()
    return _c

def q(sql, args=(), one=False):
    with _lock:
        cur = db().execute(sql, args)
        rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows

def x(sql, args=()):
    with _lock:
        cur = db().execute(sql, args)
        db().commit()
        return cur.lastrowid

def get_setting(key, default=None):
    r = q("SELECT value FROM settings WHERE key=?", (key,), one=True)
    return json.loads(r["value"]) if r else default

def set_setting(key, value):
    x("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, json.dumps(value, ensure_ascii=False)))

def log(user, action, detail=""):
    x("INSERT INTO logs(ts,user,action,detail) VALUES(?,?,?,?)", (time.time(), user, action, str(detail)[:2000]))
