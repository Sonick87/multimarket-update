import hashlib, hmac, os, secrets, time
from .db import q, x

def hash_pw(pw):
    salt = os.urandom(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200000)
    return salt.hex() + ":" + h.hex()

def check_pw(pw, stored):
    try:
        salt, h = stored.split(":")
        return hmac.compare_digest(hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), 200000).hex(), h)
    except Exception:
        return False

def create_user(username, name, pw, role="staff"):
    return x("INSERT INTO users(username,name,pw,role,created) VALUES(?,?,?,?,?)", (username, name, hash_pw(pw), role, time.time()))

def login(username, pw):
    u = q("SELECT * FROM users WHERE username=?", (username,), one=True)
    if not u or not check_pw(pw, u["pw"]):
        return None
    tok = secrets.token_urlsafe(32)
    x("INSERT INTO sessions VALUES(?,?,?)", (tok, u["id"], time.time() + 12 * 3600))
    return tok

def user_for(token):
    if not token:
        return None
    s = q("SELECT * FROM sessions WHERE token=?", (token,), one=True)
    if not s or s["expires"] < time.time():
        return None
    return q("SELECT * FROM users WHERE id=?", (s["user_id"],), one=True)

def logout(token):
    x("DELETE FROM sessions WHERE token=?", (token,))
