"""상품명 가공(다팔자식): 앞·뒤 문구, 금지어 삭제, 단어 바꾸기, 마켓별 길이 제한 + 테마별 카테고리 자동 매칭."""
import re
from .db import get_setting

MAXLEN = {"naver": 100, "coupang": 100, "esm": 50}

def maxlen(code):
    """판매처 설정의 상품명 길이(ESM은 지마켓·옥션 중 짧은 쪽)"""
    from . import channels as chs
    codes = ("gmarket", "auction") if code == "esm" else (code,)
    vals = [int(c["name_max"]) for c in (chs.get(k) for k in codes) if c and c["name_max"]]
    return min(vals) if vals else MAXLEN.get(code, 100)

def rules():
    return get_setting("name_rules", {}) or {}

def process(name, market):
    r = rules()
    n = name or ""
    for pair in (r.get("replace") or "").splitlines():
        if "=>" in pair:
            a, b = pair.split("=>", 1)
            if a.strip():
                n = n.replace(a.strip(), b.strip())
    for w in re.split(r"[,\n]", r.get("banned") or ""):
        if w.strip():
            n = n.replace(w.strip(), "")
    n = " ".join(x for x in [r.get("prefix", "").strip(), n.strip(), r.get("suffix", "").strip()] if x)
    n = re.sub(r"\s+", " ", n).strip()
    return n[:maxlen(market)]

def category_map():
    """설정의 '테마 = 네이버, 쿠팡, ESM' 줄을 읽어 {테마: (n, c, e)}"""
    out = {}
    for line in (get_setting("category_map", "") or "").splitlines():
        if "=" not in line:
            continue
        k, v = line.split("=", 1)
        parts = [x.strip() for x in v.split(",")] + ["", "", ""]
        out[k.strip()] = tuple(parts[:3])
    return out

def fill_categories(p):
    """비어 있는 카테고리 칸을 테마 매칭으로 채운 dict 반환"""
    d = dict(p)
    m = category_map()
    hit = None
    for key, cats in m.items():
        if key and key in f"{d.get('theme') or ''} {d.get('name') or ''}":
            hit = cats
            break
    if hit:
        for i, col in enumerate(("naver_cat", "coupang_cat", "esm_cat")):
            if not d.get(col) and hit[i]:
                d[col] = hit[i]
    return d
