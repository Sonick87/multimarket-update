"""상세페이지 자동 제작. 마켓에 그대로 들어가도록 인라인 스타일 HTML로 만듭니다."""
import html, json, re, urllib.request
from .db import get_setting

THEMES = {
    "clean": {"label": "깔끔(화이트)", "bg": "#ffffff", "fg": "#222222", "accent": "#2f6fed", "soft": "#f3f6fd"},
    "warm":  {"label": "따뜻(베이지)", "bg": "#fbf7f1", "fg": "#3b2f25", "accent": "#c2703d", "soft": "#f3e9dc"},
    "bold":  {"label": "강렬(블랙)", "bg": "#111111", "fg": "#f5f5f5", "accent": "#ffcc00", "soft": "#222222"},
    "pink":  {"label": "러블리(핑크)", "bg": "#fff7fa", "fg": "#3a2730", "accent": "#e35d8f", "soft": "#fde6ef"},
}

# 상품명 키워드 → 기본 셀링 포인트(AI 키가 없을 때 사용)
RULES = [
    (r"집게|헤어|머리|핀|곱창|밴드", ["한 번에 고정되는 튼튼한 이빨", "코트·니트에 어울리는 컬러 구성", "가방에 쏙 들어가는 크기", "여러 개 두고 기분 따라 골라 쓰기"]),
    (r"책갈피|북마크", ["책장을 상하지 않게 붙는 자석식", "얇아서 책이 덜 벌어짐", "학급 선물·답례품으로 넉넉한 수량", "귀여운 디자인으로 독서 습관 만들기"]),
    (r"봉투|세뱃돈|용돈", ["받는 사람 기분까지 챙기는 디자인", "넉넉한 수량으로 조카·지인 모두 챙기기", "빳빳한 종이로 지폐가 구겨지지 않음", "올해 띠·시즌 디자인"]),
    (r"키링|열쇠", ["가방·파우치에 포인트", "튼튼한 고리", "선물 포장 없이 바로 선물", "여러 개 모아 꾸미기"]),
    (r"스티커|다꾸|씰", ["다이어리·폰케이스 꾸미기", "깔끔하게 떨어지는 칼선", "다양한 디자인 한 번에", "선물용으로도 좋음"]),
    (r"단추|DIY|비즈|부자재", ["랜덤 믹스로 다양한 모양", "키링·헤어핀 만들기 재료", "넉넉한 수량", "아이와 함께하는 만들기"]),
]
DEFAULT_POINTS = ["매일 쓰기 좋은 실용적인 구성", "넉넉한 수량으로 가성비", "선물용으로도 좋은 디자인", "국내 발송으로 빠른 배송"]

def auto_copy(p):
    text = f"{p['name']} {p['theme'] or ''} {p['keyword'] or ''}"
    points = None
    for pat, pts in RULES:
        if re.search(pat, text):
            points = pts
            break
    points = points or DEFAULT_POINTS
    if p["points"]:
        try:
            custom = json.loads(p["points"])
            if isinstance(custom, list) and custom:
                points = custom
        except ValueError:
            points = [x.strip() for x in p["points"].splitlines() if x.strip()] or points
    return {
        "headline": p["name"],
        "sub": f"{p['set_desc'] or ''} · 국내 재고 · 빠른 발송".strip(" ·"),
        "points": points[:6],
        "tips": ["받으신 뒤 구성품을 먼저 확인해 주세요", "직사광선·고온을 피해 보관해 주세요"],
        "cautions": [x.strip() for x in (p["cautions"] or "").splitlines() if x.strip()] or
                    ["모니터 환경에 따라 실제 색상과 약간 다를 수 있습니다", "작은 부품은 어린이 손이 닿지 않게 보관해 주세요"],
    }

def ai_copy(p):
    """Claude API로 문구 생성. 설정에 키가 없으면 None."""
    s = get_setting("ai", {}) or {}
    key = s.get("api_key")
    if not key:
        return None
    from .secret import unseal
    key = unseal(key)
    prompt = (f"한국 오픈마켓 상세페이지 문구를 써 줘. 상품: {p['name']}\n테마: {p['theme'] or ''}\n구성: {p['set_desc'] or ''}\n"
              f"원문 상품명: {p['source_name'] or ''}\n참고 메모: {p['memo'] or ''}\n"
              "과장·허위 표현, 의학적 효능, 타사 상표는 쓰지 말 것. JSON만 출력: "
              '{"headline":"20자 이내","sub":"40자 이내","points":["포인트 4~5개, 각 25자 이내"],"tips":["사용 팁 2~3개"],"cautions":["주의사항 2~3개"]}')
    body = {"model": s.get("model") or "claude-sonnet-5-5", "max_tokens": 1200,
            "messages": [{"role": "user", "content": prompt}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(), method="POST",
                                 headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    with urllib.request.urlopen(req, timeout=60) as r:
        out = json.loads(r.read())
    txt = "".join(b.get("text", "") for b in out.get("content", []) if b.get("type") == "text")
    m = re.search(r"\{.*\}", txt, re.S)
    return json.loads(m.group()) if m else None

def render(p, copy, image_urls, theme="clean", shop=None):
    t = THEMES.get(theme, THEMES["clean"])
    e = html.escape
    shop = shop or (get_setting("shop", {}) or {})
    W = "max-width:860px;margin:0 auto;"
    img = lambda u: f'<img src="{e(u)}" style="display:block;width:100%;max-width:860px;margin:0 auto;" alt="">'
    parts = [f'<div style="{W}background:{t["bg"]};color:{t["fg"]};font-family:\'Noto Sans KR\',\'Malgun Gothic\',sans-serif;line-height:1.6;">']
    if shop.get("banner"):
        parts.append(f'<div style="background:{t["accent"]};color:{t["bg"]};text-align:center;padding:10px;font-size:15px;font-weight:700;">{e(shop["banner"])}</div>')
    parts.append(f'<div style="text-align:center;padding:56px 24px 28px;"><div style="color:{t["accent"]};font-size:16px;font-weight:700;letter-spacing:2px;">{e(shop.get("name") or "BEST ITEM")}</div>'
                 f'<h1 style="font-size:34px;margin:12px 0 10px;font-weight:800;">{e(copy["headline"])}</h1>'
                 f'<p style="font-size:18px;opacity:.8;margin:0;">{e(copy["sub"])}</p></div>')
    if image_urls:
        parts.append(img(image_urls[0]))
    parts.append(f'<div style="padding:44px 28px;"><h2 style="text-align:center;font-size:26px;margin:0 0 26px;">이런 점이 좋아요</h2>')
    for i, pt in enumerate(copy["points"], 1):
        parts.append(f'<div style="background:{t["soft"]};border-radius:14px;padding:18px 22px;margin:0 0 12px;font-size:18px;">'
                     f'<b style="color:{t["accent"]};margin-right:10px;">POINT {i:02d}</b>{e(pt)}</div>')
    parts.append("</div>")
    for u in image_urls[1:]:
        parts.append(img(u))
    rows = [("상품명", p["name"]), ("구성", p["set_desc"] or f"{p['set_qty'] or 1}개"), ("원산지", "중국"),
            ("배송", "국내 발송 (평일 오후 2시 이전 주문 당일 출고 목표)")]
    parts.append(f'<div style="padding:40px 28px;"><h2 style="font-size:22px;margin:0 0 14px;">상품 정보</h2><table style="width:100%;border-collapse:collapse;font-size:16px;">')
    for k, v in rows:
        parts.append(f'<tr><th style="text-align:left;width:28%;padding:12px;border-bottom:1px solid {t["soft"]};background:{t["soft"]};">{e(k)}</th>'
                     f'<td style="padding:12px;border-bottom:1px solid {t["soft"]};">{e(str(v))}</td></tr>')
    parts.append("</table></div>")
    for title, items in (("사용 팁", copy.get("tips") or []), ("꼭 읽어 주세요", copy.get("cautions") or [])):
        if items:
            parts.append(f'<div style="padding:8px 28px 28px;"><h3 style="font-size:19px;margin:0 0 10px;color:{t["accent"]};">{e(title)}</h3><ul style="margin:0;padding-left:20px;font-size:16px;">')
            parts += [f"<li style='margin:4px 0;'>{e(x)}</li>" for x in items]
            parts.append("</ul></div>")
    parts.append(f'<div style="padding:28px;text-align:center;font-size:14px;opacity:.7;border-top:1px solid {t["soft"]};">'
                 f'교환·반품: 수령 후 7일 이내 · 단순 변심 시 왕복 배송비 구매자 부담<br>{e(shop.get("cs") or "")}</div></div>')
    return "".join(parts)
