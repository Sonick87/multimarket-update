import os, sys

def base_dir():
    # .exe로 실행하면 exe가 있는 폴더, 아니면 프로젝트 폴더
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

DATA = os.environ.get("MM_DATA") or os.path.join(base_dir(), "data")
IMAGES = os.path.join(DATA, "images")
OUTBOX = os.path.join(DATA, "outbox")
PAGES = os.path.join(DATA, "detail_pages")
for d in (DATA, IMAGES, OUTBOX, PAGES):
    os.makedirs(d, exist_ok=True)
DB_PATH = os.path.join(DATA, "app.db")
