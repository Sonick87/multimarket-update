"""도매꾹·도매매 오픈API — 상품 검색·상품 정보(가격·재고·품절·사진·상세) 읽기.
키 신청: 도매꾹 로그인 → 오픈API(openapi.domeggook.com) → API 키 발급.
요청: GET https://domeggook.com/ssl/api/?ver=..&mode=getItemList|getItemView&aid=<키>&om=json
※ 이 프로그램을 만든 곳에서는 도매꾹에 접속할 수 없어 실제 응답 모양은 아직 확인하지 못했습니다.
  그래서 필드 이름을 여러 후보로 찾고, '연결 확인' 때 받은 응답 일부를 화면에 보여 줍니다(맞춰 고칠 수 있게).
※ 도매꾹은 구매(발주) API를 공개하지 않아 발주는 도매꾹 사이트에서 직접 하고, 송장은 이 프로그램에 넣습니다."""
import json, re, time, urllib.request, urllib.error
from urllib.parse import urlencode
from .db import get_setting, set_setting
from .secret import unseal

API = "https://domeggook.com/ssl/api/"
VER_LIST, VER_VIEW = "4.1", "4.5"

class OCError(Exception):
    pass

def conf():
    return get_setting("domeggook", {}) or {}

def item_url(key, market="supply"):
    return (f"https://domeme.domeggook.com/s/{key}" if market == "supply" else f"https://domeggook.com/{key}")

# ---------- 응답에서 값 찾기(필드 이름이 확실하지 않아 후보를 차례로) ----------
def _num(v):
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, dict):
        for k in ("dome", "supply", "price", "value", "amount"):
            if k in v:
                n = _num(v[k])
                if n is not None:
                    return n
        return None
    s = str(v)
    m = re.search(r"(\d+)\+(\d[\d,]*)", s)       # 수량별 가격 "1+3000|10+2800" → 첫 단가
    if m:
        return float(m.group(2).replace(",", ""))
    m = re.search(r"\d[\d,]*(\.\d+)?", s)
    return float(m.group(0).replace(",", "")) if m else None

def _get(d, *paths):
    for p in paths:
        cur = d
        for k in p.split("."):
            if isinstance(cur, dict) and k in cur:
                cur = cur[k]
            else:
                cur = None
                break
        if cur not in (None, "", [], {}):
            return cur
    return None

def _list(v):
    if v is None:
        return []
    return v if isinstance(v, list) else [v]

def _imgs(*vals):
    out = []
    for v in vals:
        if isinstance(v, dict):
            v = v.get("original") or v.get("large") or v.get("big") or v.get("url") or next((x for x in v.values() if isinstance(x, str)), "")
        if isinstance(v, str):
            out += re.findall(r"https?://[^\s\"'<>|]+", v)
    return list(dict.fromkeys(u for u in out if re.search(r"\.(jpe?g|png|gif|webp)", u, re.I) or "image" in u))

def norm_view(r, key):
    """getItemView 응답 → 공통 모양"""
    d = r.get("domeggook", r) if isinstance(r, dict) else {}
    name = _get(d, "basis.title", "title", "basis.name")
    status = str(_get(d, "basis.status", "status", "basis.saleStatus") or "")
    stock = _num(_get(d, "qty.inventory", "qty.stock", "inventory", "stock"))
    price = _num(_get(d, "price.supply", "price.dome", "price", "basis.price")) or 0
    ship = _num(_get(d, "deli.dome.fee", "deli.supply.fee", "deli.fee", "deli.pay.fee", "delivery.fee"))
    moq = _num(_get(d, "qty.domeMoq", "qty.supplyMoq", "qty.moq", "basis.moq", "unitQty"))
    desc = _get(d, "desc.contents.item", "desc.contents", "desc", "detail")
    if isinstance(desc, dict):
        desc = next((v for v in desc.values() if isinstance(v, str)), "")
    imgs = _imgs(_get(d, "thumb.original", "thumb"), _get(d, "thumb.large"))
    soldout = (stock is not None and stock <= 0) or any(w in status for w in ("품절", "중지", "종료", "soldout", "stop"))
    return {"key": str(key), "name": name, "price": price, "fixedPrice": 0, "shippingFee": ship, "moq": int(moq or 1),
            "status": "soldout" if soldout else "available", "stock": int(stock) if stock is not None else 99,
            "options": [], "images": imgs, "content": desc or ""}

def norm_list_item(it):
    return {"key": str(_get(it, "no", "itemNo", "id") or ""), "name": _get(it, "title", "name"),
            "price": _num(_get(it, "price", "priceSupply", "priceDome")) or 0, "fixedPrice": 0,
            "shippingFee": _num(_get(it, "deli.fee", "deliFee")), "moq": int(_num(_get(it, "unitQty", "moq")) or 1),
            "status": "available", "options": [], "images": _imgs(_get(it, "thumb", "image")), "content": ""}

class Dome:
    def __init__(self, force_dry=False):
        c = conf()
        self.c = c
        self.key = unseal(c["api_key"]) if c.get("api_key") else ""
        self.market = c.get("market", "supply")
        self.dry = force_dry or not self.key

    def _call(self, params):
        from . import VERSION
        p = dict(params, aid=self.key, om="json")
        req = urllib.request.Request(API + "?" + urlencode(p), headers={"Accept": "application/json", "User-Agent": f"MultiMarketManager/{VERSION}"})
        try:
            with urllib.request.urlopen(req, timeout=30) as r:
                txt = r.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            raise OCError(f"도매매 {e.code}: {e.read().decode('utf-8', 'replace')[:600]}")
        except urllib.error.URLError as e:
            raise OCError(f"도매매 접속 실패: {e.reason}")
        set_setting("domeggook_last_raw", txt[:3000])   # 응답 모양 확인용
        try:
            j = json.loads(txt)
        except ValueError:
            raise OCError("도매매 응답을 읽지 못했습니다: " + txt[:300])
        err = j.get("errors") if isinstance(j, dict) else None
        if err:
            msg = err.get("message") if isinstance(err, dict) else err
            raise OCError(f"도매매 오류: {msg}"[:600])
        return j

    def test(self):
        if self.dry:
            return "미리보기 모드(API 키 없음): 예시 상품으로 보여 줍니다"
        r = self.search("양말", 3)
        return f"연결 성공 · 검색 시험 {len(r)}개 받음 ({'도매매' if self.market == 'supply' else '도매꾹'})"

    def search(self, word, first=30, min_price=None, max_price=None):
        if self.dry:
            return [demo_item(f"{100000 + i}", word) for i in range(3)]
        p = {"ver": VER_LIST, "mode": "getItemList", "market": self.market, "kw": word, "sz": min(int(first or 30), 200), "pg": 1}
        if min_price:
            p["mnp"] = int(min_price)
        if max_price:
            p["mxp"] = int(max_price)
        j = self._call(p)
        d = j.get("domeggook", j)
        out = [norm_list_item(it) for it in _list(_get(d, "list.item", "list", "items"))]
        return [o for o in out if o["key"] and (not min_price or o["price"] >= min_price) and (not max_price or o["price"] <= max_price)]

    def item(self, key):
        key = re.sub(r"\D", "", str(key))
        if self.dry:
            return demo_item(key)
        return norm_view(self._call({"ver": VER_VIEW, "mode": "getItemView", "no": key, "market": self.market}), key)

    def items(self, keys):
        out = []
        for k in keys:
            try:
                out.append(self.item(k))
            except OCError as ex:
                if "접속 실패" in str(ex):
                    raise
                out.append(None)
            time.sleep(0.25)
        return out

    # 도매꾹은 발주 API가 없음: 사이트에서 직접 주문
    def order_input(self, lines, rcv, note=""):
        return {"lines": lines, "rcv": rcv, "note": note}

    @staticmethod
    def order_api_ready():
        c = get_setting("domeggook_order", {}) or {}
        return bool(c.get("url") and c.get("body"))

    def create_order(self, inp):
        """주문 API 설정(setting domeggook_order)이 있으면 그 양식대로 도매매에 주문, 없으면 '직접 주문함'으로만 표시.
        ※ 도매매 프라이빗 주문 API 문서를 받으면 주소·요청 양식·응답 경로를 화면에서 맞춰 넣는 구조(코드 수정 불필요)."""
        c = get_setting("domeggook_order", {}) or {}
        if not (c.get("url") and c.get("body")):
            return {"key": "도매매 직접주문", "dry": False}
        code, vals, qty = inp["lines"][0]
        r = inp["rcv"]
        sub = {"code": code, "qty": qty, "option": " / ".join(vals), "name": r.get("name", ""), "phone": r.get("phone", ""), "zip": r.get("zip", ""),
               "addr1": r.get("addr1", ""), "addr2": r.get("addr2", ""), "memo": inp.get("note") or r.get("memo", "")}
        btype = c.get("body_type", "json")
        txt = c["body"]
        for k, v in sub.items():
            v = str(v)
            if btype == "json":
                v = json.dumps(v, ensure_ascii=False)[1:-1]
            else:
                from urllib.parse import quote
                v = quote(v)
            txt = txt.replace("{" + k + "}", v)
        method = (c.get("method") or "POST").upper()
        url = c["url"]
        headers = {"User-Agent": "MultiMarketManager", "Accept": "application/json",
                   "Content-Type": "application/json; charset=utf-8" if btype == "json" else "application/x-www-form-urlencoded; charset=utf-8"}
        key = self.key
        if c.get("key_in") == "header":
            headers[c.get("key_name") or "Authorization"] = (c.get("key_prefix") or "") + key
        else:
            url += ("&" if "?" in url else "?") + urlencode({c.get("key_name") or "aid": key})
        req = urllib.request.Request(url, data=txt.encode("utf-8") if method != "GET" else None, headers=headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                raw = resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as ex:
            raise OCError(f"도매매 주문 {ex.code}: {ex.read().decode('utf-8', 'replace')[:400]}")
        except urllib.error.URLError as ex:
            raise OCError(f"도매매 주문 접속 실패: {ex.reason}")
        set_setting("domeggook_order_last", raw[:3000])
        try:
            j = json.loads(raw)
        except ValueError:
            raise OCError("도매매 주문 응답을 읽지 못했습니다: " + raw[:300])
        ok_path, ok_val = c.get("ok_path") or "", str(c.get("ok_value") or "")
        if ok_path:
            got = _get(j, ok_path)
            if str(got) != ok_val:
                raise OCError("도매매가 주문을 받지 않았습니다: " + raw[:300])
        no = _get(j, c.get("no_path") or "") if c.get("no_path") else None
        return {"key": str(no or "주문완료"), "dry": False}
    def order(self, key):
        return {}

OwnerClan = Dome   # 예전 코드와 같은 이름으로 쓸 수 있게

def demo_item(key, word="예시"):
    return {"key": str(key), "name": f"[미리보기] {word} 도매매 상품 {key}", "price": 4500, "fixedPrice": 0, "shippingFee": 3000,
            "moq": 1, "status": "available", "stock": 99, "options": [], "images": [], "content": ""}

def is_soldout(it, opt_values=None):
    return str(it.get("status") or "") == "soldout" or (it.get("stock") is not None and it.get("stock") <= 0)

def price_of(it, opt_values=None):
    return float(it.get("price") or 0)

def images_of(it):
    return [u for u in (it.get("images") or []) if isinstance(u, str) and u.startswith("http")]
